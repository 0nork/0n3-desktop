/**
 * OUTREACH (2026-11-14) — the AI designer. Mike: "an AI designer that can generate logos, complete HTML email designs, social
 * media posts with images and content etc… create the plumbing. It will be available to be added into jobs as well as pages
 * and canvases."
 *
 * THE PLUMBING, ONE PLACE. Every design kind is declared here once (what it makes, what it needs, how the AI is told) and every
 * surface reads this file: the API (/api/outreach), the job step (flows.js, AI step key `outreach`), the page block (`outreach`
 * in 0n3 Pages) and the board (a board item of kind `outreach`). Designs are saved in their PROJECT's canvas (`canvas.outreach`),
 * beside its pages and jobs, so a nurture campaign's emails live with the pages and jobs that send them.
 *
 * Built today: the text an AI can make honestly — an SVG logo, a complete HTML email (subject, preheader, table layout, inline
 * styles), a social post per network with the picture DESCRIBED as an image prompt. NOT built: drawing the picture itself.
 * `image` is the slot for it (an image model from the vault: openai / stability / replicate); until one is wired, a post carries
 * `imagePrompt` and `imageUrl: null`, and says so, rather than pretending.
 */
import crypto from 'node:crypto';

export const KINDS = {
  logo: {
    label: 'Logo', icon: 'Shapes', sub: 'A clean SVG logo and wordmark',
    fields: [['brand', 'Business name', ''], ['brief', 'What it should feel like', 'Modern, friendly, one colour']],
    system: `You design a LOGO as SVG. Answer ONE JSON object and nothing else: { "name": "<short name for this design>", "svg": "<a complete <svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 400 120\\">…</svg>>", "colors": ["#hex", ...], "notes": "<one sentence on the idea>" }. Simple flat shapes and text only, at most 3 colours, readable at 32 px tall, no <script>, no external images or fonts (font-family: Helvetica, Arial, sans-serif).`,
  },
  email: {
    label: 'Email design', icon: 'Mail', sub: 'A complete HTML email, ready to send from a job',
    fields: [['brand', 'Business name', ''], ['brief', 'What the email is for', 'Welcome a new subscriber'], ['cta', 'Button text and link', 'Book a time → https://']],
    system: `You design ONE marketing EMAIL. Answer ONE JSON object and nothing else: { "name": "<short name>", "subject": "<under 60 characters>", "preheader": "<under 90 characters>", "html": "<a COMPLETE email: <!doctype html>, a 600px centred table layout, ALL styles inline, web-safe fonts, a heading, 2 to 4 short paragraphs, one button (a table cell with a link), a footer with {{unsubscribe_url}}>", "text": "<the plain-text version>" }. Write real, specific copy in short plain sentences. NEVER invent prices, discounts, reviews, phone numbers or addresses that were not given. Merge tags allowed: {{contact.firstName}}, {{unsubscribe_url}}.`,
  },
  social: {
    label: 'Social post', icon: 'Megaphone', sub: 'Post copy per network, with the picture described',
    fields: [['brand', 'Business name', ''], ['brief', 'What to post about', 'Our new fall special'], ['networks', 'Networks', 'facebook, instagram, linkedin']],
    system: `You write ONE social media post for each network asked. Answer ONE JSON object and nothing else: { "name": "<short name>", "posts": [ { "network": "facebook"|"instagram"|"linkedin"|"x"|"tiktok"|"google", "text": "<the post, sized for that network>", "hashtags": ["#tag", ...] } ], "imagePrompt": "<one paragraph describing the picture to go with it: subject, setting, light, style, no text in the image>" }. Real, specific copy; never invent prices, offers or reviews that were not given.`,
  },
};

export const IMAGE_PROVIDERS = ['openai', 'stability', 'replicate'];

/** The kinds as the API and the palettes list them (no prompts). */
export const kindsList = () => Object.entries(KINDS).map(([key, k]) => ({ key, label: k.label, icon: k.icon, sub: k.sub, fields: k.fields.map(([name, label, placeholder]) => ({ name, label, placeholder })) }));

/** What the AI is asked: the kind's own instructions, and the brief as the person (or the job) gave it. */
export function promptFor(kind, input = {}, brand = {}) {
  const k = KINDS[kind];
  if (!k) throw new Error(`Outreach makes: ${Object.keys(KINDS).join(', ')}. "${kind}" is not one of them.`);
  const lines = k.fields.map(([name, label]) => (input[name] ? `${label}: ${String(input[name]).slice(0, 1500)}` : '')).filter(Boolean);
  if (brand.color) lines.push(`Brand colour: ${brand.color}`);
  if (brand.name && !input.brand) lines.push(`Business name: ${brand.name}`);
  if (!lines.length) throw new Error('Say what to design (the brief).');
  return { system: k.system, user: lines.join('\n') };
}

/** Strips anything active from an AI-written SVG: scripts, event handlers, external references. */
export function safeSvg(svg) {
  let s = String(svg || '').trim();
  const m = /<svg[\s\S]*<\/svg>/i.exec(s); if (!m) return null; s = m[0];
  s = s.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, '').replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*')/gi, '').replace(/(href|xlink:href)\s*=\s*("|')\s*(?!#)[^"']*\2/gi, '');
  return s.length > 60000 ? null : s;
}

/** Strips scripts and handlers from an AI-written email; email clients run neither, and a preview frame must not. */
export function safeHtml(html) {
  const s = String(html || '').replace(/<script[\s\S]*?<\/script>/gi, '').replace(/\son[a-z]+\s*=\s*("[^"]*"|'[^']*')/gi, '').replace(/javascript:/gi, '');
  return s.length > 200000 ? s.slice(0, 200000) : s;
}

/** The AI's answer → one saved design. Refuses with a reason instead of saving something broken. */
export function shapeDesign(kind, raw, input = {}) {
  const j = typeof raw === 'string' ? parseLoose(raw) : raw;
  if (!j || typeof j !== 'object') throw new Error('The designer did not answer with a design. Try again or say it differently.');
  const base = { id: 'od' + crypto.randomBytes(4).toString('hex'), kind, name: String(j.name || KINDS[kind].label).slice(0, 80), brief: String(input.brief || '').slice(0, 1500), createdAt: Date.now() };
  if (kind === 'logo') { const svg = safeSvg(j.svg); if (!svg) throw new Error('The logo came back without a usable SVG.'); return { ...base, svg, colors: (Array.isArray(j.colors) ? j.colors : []).filter((c) => /^#[0-9a-f]{3,8}$/i.test(c)).slice(0, 4), notes: String(j.notes || '').slice(0, 300) }; }
  if (kind === 'email') { const html = safeHtml(j.html); if (!/<table|<div|<p/i.test(html)) throw new Error('The email came back without a body.'); return { ...base, subject: String(j.subject || '').slice(0, 120), preheader: String(j.preheader || '').slice(0, 160), html, text: String(j.text || '').slice(0, 20000) }; }
  if (kind === 'social') {
    const posts = (Array.isArray(j.posts) ? j.posts : []).slice(0, 8).map((p) => ({ network: String(p.network || '').toLowerCase().slice(0, 20), text: String(p.text || '').slice(0, 3000), hashtags: (Array.isArray(p.hashtags) ? p.hashtags : []).map(String).slice(0, 15) })).filter((p) => p.text);
    if (!posts.length) throw new Error('The post came back empty.');
    return { ...base, posts, imagePrompt: String(j.imagePrompt || '').slice(0, 1500), imageUrl: null, image: 'not drawn yet: no image model is wired into Outreach' };
  }
  throw new Error(`Unknown kind ${kind}`);
}

function parseLoose(text) {
  const t = String(text || '').replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
  try { return JSON.parse(t); } catch { /* fall through */ }
  const a = t.indexOf('{'); const b = t.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch { return null; } }
  return null;
}

/** A saved design, cleaned for the canvas (cleanCanvas keeps `outreach` with these). */
export function cleanDesign(d) {
  if (!d || !KINDS[d.kind] || !d.id) return null;
  const o = { id: String(d.id).slice(0, 24), kind: d.kind, name: String(d.name || '').slice(0, 80), brief: String(d.brief || '').slice(0, 1500), createdAt: Number(d.createdAt) || Date.now() };
  if (d.kind === 'logo') return { ...o, svg: safeSvg(d.svg) || '', colors: Array.isArray(d.colors) ? d.colors.slice(0, 4) : [], notes: String(d.notes || '').slice(0, 300) };
  if (d.kind === 'email') return { ...o, subject: String(d.subject || '').slice(0, 120), preheader: String(d.preheader || '').slice(0, 160), html: safeHtml(d.html), text: String(d.text || '').slice(0, 20000) };
  return { ...o, posts: Array.isArray(d.posts) ? d.posts.slice(0, 8) : [], imagePrompt: String(d.imagePrompt || '').slice(0, 1500), imageUrl: d.imageUrl && /^https:\/\//.test(d.imageUrl) ? String(d.imageUrl).slice(0, 500) : null };
}

/** A list row: never the full html/svg. */
export const designSummary = (d) => ({ id: d.id, kind: d.kind, name: d.name, createdAt: d.createdAt, ...(d.subject ? { subject: d.subject } : {}), ...(d.posts ? { networks: d.posts.map((p) => p.network) } : {}) });
