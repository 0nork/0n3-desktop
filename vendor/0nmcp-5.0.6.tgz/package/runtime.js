/**
 * THE RUNTIME — one MCP server, one registration path, one tool surface.
 *
 *   createRuntime({ resolver, account })
 *
 * The same function builds the CLI's stdio server and every hosted request.
 * What differs is only the resolver it is handed. Tools never touch a
 * credential store; they ask `resolver.get(service, label)` and use what comes
 * back for that one call.
 */
import { createRequire } from 'node:module';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { listServices, getService, canonicalService } from './catalog.js';
import { freshCredentials, familyOf, FAMILY_PARENTS } from './tokens.js';
import { executeEndpoint } from './catalog-exec.js';
import { registerCrmTools } from './crm/register.js';
import { NullResolver } from './resolver.js';
import { stripSecrets } from './envelope.js';
import { listRemoteTools, callRemoteTool, mcpConfigOf, redact } from './mcp-exec.js';
import { listApps, getApp, loadApps, Receipt } from './apps/registry.js';
import { V3_MODULES } from './crm/v3/index.js';
import contactsLegacy from './crm/contacts.js';

/** The stand-in record for a public (authType "none") catalog service — no secrets, labelled so receipts say what ran. */
const PUBLIC_ENV = (service) => ({ $0n: { name: `${service} (public)` }, auth: { credentials: {} }, meta: {} })
export const takesLocation = (ep) => !!ep && (/\{locationId\}/.test(ep.path || '') || (ep.body && typeof ep.body === 'object' && 'locationId' in ep.body) || (Array.isArray(ep.query) && ep.query.includes('locationId')));
import { baseTierTools, messagingTierTools, TIER_REFUSAL } from './crm-provision.js';
const BASE_TIER_TOOLS = baseTierTools({ V3_MODULES, legacyContacts: contactsLegacy });
const MESSAGING_TIER_TOOLS = messagingTierTools({ V3_MODULES, legacyContacts: contactsLegacy });

const require = createRequire(import.meta.url);
export const VERSION = require('./package.json').version;

const text = (v) => ({ content: [{ type: 'text', text: typeof v === 'string' ? v : JSON.stringify(v, null, 2) }] });

/**
 * @param {{ resolver?: { get: Function, list: Function }, account?: { accountId: string, email?: string } | null,
 *           audit?: (info: any) => Promise<void>, fetchImpl?: typeof fetch, name?: string }} o
 */
/**
 * What an AI client is told when it connects (MCP `initialize.instructions`, 2026-10-29). Short, and in the order that
 * works: who am I → what is connected → what can it do → do it, with a receipt. Mike: "the 0n3 MCP can be a massive help."
 */
export const INSTRUCTIONS = [
  '0n3 is the person\'s own hub: every app they connected to their 0n3 account is reachable here, with their keys, in their accounts.',
  'Start with `whoami` (who this is, how many connections) and `connections` (which apps). `services` lists every app 0n3 can reach and whether it is connected.',
  'To act on an app: `service_info` shows its endpoints and parameters, then `api_call` runs one endpoint. Use the exact endpoint names service_info gives.',
  'For a whole job (several calls with one receipt) use `apps` → `app_info` → `app_run`, e.g. publishing an MCP server to npm or setting a site up with Google.',
  'The CRM: `crm_*` tools act on a CRM location; pass `location_id`. Email and texting go through crm conversations; voicemail drops run a CRM workflow that contains the drop.',
  'If an app is not connected, say so and point the person to https://0n3.app/connect — never invent a result. If a change comes back `pending_approval`, the person approves it on their phone; check it with `approval_status`.',
  'A `plan_limit` answer names the plan that lifts it; pass that on as is.',
].join('\n');

/**
 * `gate` (2026-10-29): when the person switched on "ask me before AI changes anything", every change a full-access AI
 * client tries — a non-GET catalog call, a mini-app run, a call to a connected MCP server, a CRM write — is handed to the
 * gate instead of running. The gate holds it for the person's OK and returns what the AI is told. Reads never wait.
 */
/**
 * A FAMILY CHILD THAT HOLDS SETTINGS BUT NO SIGN-IN borrows its family's sign-in. Google Ads is the case: its record
 * carries the developer token and customer id (Google Ads' own), while the person signed in once with Google. The
 * child's record looked "usable" (it has developerToken), so it was sent with no Authorization at all. Merge the
 * parent's credentials UNDER the child's, so the child's own values win and the Google refresh token is there to mint.
 */
const MINTS = ['refresh_token', 'access_token', 'accessToken', 'private_key'];
export async function withFamilyToken(resolver, service, env, label) {
  const fam = familyOf(service);
  if (!env || !fam || env.service === fam) return env;
  const c = env.auth?.credentials || {};
  if (MINTS.some((k) => c[k])) return env;
  const parent = (await resolver.get(fam, label)) || (label ? await resolver.get(fam) : null);
  if (!parent) return env;
  return { ...env, auth: { ...env.auth, credentials: { ...(parent.auth?.credentials || {}), ...c } } };
}

/** Writes a rotated refresh token back onto the record it came from (tokens.js onRotate). */
const rotateInto = (resolver, env) => (resolver?.save ? (credentials) => resolver.save({ ...env, auth: { ...env.auth, credentials } }) : null);

export function createRuntime({ resolver = new NullResolver(), account = null, audit = async () => {}, fetchImpl = fetch, name = '0n3', gate = null, approvalLookup = null, desk = null, jobs = null } = {}) {
  const server = new McpServer({ name, version: VERSION }, { instructions: INSTRUCTIONS });
  const safeAudit = async (info) => { try { await audit({ ...info, accountId: account?.accountId || null }); } catch (e) { console.error('[0n3] audit:', e.message); } };

  server.registerTool('whoami', { description: 'Which 0n account this session acts as, and how many connections it holds.', inputSchema: {} }, async () => {
    const conns = await resolver.list();
    return text({ account: account ? { id: account.accountId, email: account.email || null, scope: account.scope || 'local' } : { id: null, scope: 'local' }, connections: conns.length, services: [...new Set(conns.map((c) => c.service))] });
  });

  server.registerTool('services', { description: 'Every service in the 0n catalog, with whether this account has it connected.', inputSchema: { connected_only: z.boolean().optional().describe('Only services this account has a connection for') } }, async ({ connected_only } = {}) => {
    const conns = await resolver.list();
    // Through the CANONICAL name, or an alias splits the truth in two: a vault
    // record stored as `ga4` would leave `google_analytics` reading "not
    // connected" while api_call happily served it. Same concept, two answers —
    // exactly the split this runtime exists to stop.
    const have = new Set(conns.map((c) => canonicalService(c.service) || c.service));
    const rows = listServices().map((s) => ({ key: s.key, name: s.name, type: s.type, endpoints: Object.keys(getService(s.key)?.endpoints || {}).length, connected: have.has(s.key) }));

    // A RECORD THE CATALOG DOES NOT KNOW IS STILL A RECORD, AND SAYING NOTHING
    // ABOUT IT IS THE WORST OPTION.
    //
    // Measured 2026-09-19: `ga4` and `google` sat in the vault while the
    // catalog had no such keys, so `whoami` reported them as connected
    // services and `api_call ga4 …` answered "Unknown service". Credentials
    // stored, reported green, uncallable — "connected" and "working" as two
    // different states, which is the failure this estate keeps paying for.
    // They are listed now, with callable:false and the reason.
    const orphans = [...have].filter((k) => !getService(k)).map((k) => {
      const rec = conns.find((c) => c.service === k);
      const mcp = !!rec?.options?.mcp?.url;
      if (FAMILY_PARENTS.has(k)) {
        const kids = listServices().map((x) => x.key).filter((x) => familyOf(x) === k);
        return {
          key: k, name: rec?.$0n?.name || k, type: 'identity',
          endpoints: 0, connected: true, callable: false,
          note: `A credential record, not a service. ${kids.length} services authenticate through it automatically — ${kids.slice(0, 5).join(', ')}${kids.length > 5 ? ', …' : ''}. Call those, not this.`,
        };
      }
      return {
        key: k, name: rec?.$0n?.name || k, type: mcp ? 'mcp-server' : 'unknown',
        endpoints: 0, connected: true, callable: mcp,
        note: mcp
          ? 'An MCP server — call its tools with mcp_tools / mcp_call, not api_call.'
          : `Stored in the vault, but "${k}" is not a catalog service, so api_call cannot reach it. Connect it under a catalog key, or add the service to the catalog.`,
      };
    });
    const all = [...rows.map((r) => ({ ...r, callable: true })), ...orphans];
    return text(connected_only ? all.filter((r) => r.connected) : all);
  });

  server.registerTool('service_info', { description: 'Endpoints, auth type and credential keys for one catalog service.', inputSchema: { service: z.string().describe('Service key, e.g. stripe') } }, async ({ service }) => {
    const svc = getService(service);
    if (!svc) return text({ error: `Unknown service: ${service}`, available: listServices().map((s) => s.key) });
    const conns = (await resolver.list()).filter((c) => c.service === service);
    return text({ key: service, name: svc.name, type: svc.type, description: svc.description, authType: svc.authType, credentialKeys: svc.credentialKeys, baseUrl: svc.baseUrl || null, capabilities: Array.isArray(svc.capabilities) ? svc.capabilities.map((c) => ({ name: c.name, actions: c.actions || [], description: c.description || '' })) : [], connected: conns.length > 0, records: conns.map((c) => ({ label: c.$0n?.name, environment: c.environment, meta: c.meta })), endpoints: Object.entries(svc.endpoints || {}).map(([k, e]) => ({ name: k, method: e.method, path: e.path })) });
  });

  server.registerTool('connections', { description: 'The connection records this account holds (never the secrets).', inputSchema: {} }, async () => text(await resolver.list()));


  /**
   * Can this record actually authenticate a call to this service?
   *
   * Not "does a record exist" — that question has been answered yes for
   * credentials that hold nothing but a property id. A record is usable when it
   * carries at least one key the catalog says the service authenticates with,
   * or an OAuth pair it can mint one from.
   */
  const usable = (service, env) => {
    const creds = env?.auth?.credentials || {};
    const present = Object.keys(creds).filter((k) => creds[k] !== null && creds[k] !== undefined && creds[k] !== '');
    if (!present.length) return false;
    if (present.includes('access_token') || present.includes('refresh_token') || present.includes('apiKey')) return true;
    const want = getService(service)?.credentialKeys || [];
    return want.length ? want.some((k) => present.includes(k)) : true;
  };


  /**
   * An account can hold SEVERAL records for one service, and they do not carry
   * the same grant.
   *
   * Measured live 2026-09-19: this account holds three `google` records. Two
   * can read Search Console and GA4; the third — an Apps Script connection —
   * cannot, and it is the one an unlabelled call happened to resolve. Google
   * answered 403 ACCESS_TOKEN_SCOPE_INSUFFICIENT, which is true, unhelpful,
   * and indistinguishable from "you do not have access to this at all".
   *
   * The account DID have access. It was one word away. So when a call is
   * refused for scope or permission and other records exist, say which ones —
   * an opaque 403 becomes an instruction.
   */
  const scopeHint = (service, used, result) => scopeHintFor(resolver, service, used, result);

  server.registerTool('api_call', {
    description: 'Call any endpoint of any catalog service with this account\'s own connection. Use service_info to see endpoint names and params.',
    inputSchema: { service: z.string().describe('Service key, e.g. stripe'), endpoint: z.string().describe('Endpoint name from service_info'), params: z.record(z.string(), z.any()).optional().describe('Path, query or body params'), label: z.string().optional().describe('Which record when the account holds several (name, or a meta value like a location id)') },
  }, async ({ service, endpoint, params, label }) => {
    if (gate) {
      const m = String(getService(service)?.endpoints?.[endpoint]?.method || 'POST').toUpperCase();
      if (m !== 'GET') { const held = await gate({ kind: 'api_call', service, endpoint, method: m, args: params || {}, label }); if (held) return text(held); }
    }
    // A family member (gmail, google_sheets, outlook…) reads its family's record when it has none of its own.
    let env = await resolver.get(service, label);
    if (!env && familyOf(service)) env = await resolver.get(familyOf(service), label);
    // ...OR when the record it has cannot authenticate anything.
    //
    // Measured live 2026-09-19: the `ga4` record in this account holds exactly
    // one key — `property_id`. It is a CONFIG row, not a credential. Because a
    // record existed, the family fallback never fired, so `api_call ga4` sent a
    // request with no Authorization header and Google answered 401. Every
    // surface called it connected and it could not make a single call.
    //
    // "Has a record" was standing in for "can authenticate", and those are not
    // the same question. Ask the real one: does this record carry any of the
    // keys the service actually needs?
    if (env && !usable(service, env) && familyOf(service)) {
      const parent = await resolver.get(familyOf(service), label);
      if (parent && usable(familyOf(service), parent)) {
        // Keep the child's meta (property_id lives there and callers pass it).
        env = { ...parent, meta: { ...(parent.meta || {}), ...(env.meta || {}) } };
      }
    }
    env = await withFamilyToken(resolver, service, env, label);
    // A public service (authType "none" — RDAP, Substack's public API…) needs no credential, so it needs no vault record either.
    if (!env && getService(service)?.authType === 'none') env = PUBLIC_ENV(service)
    if (!env) return text({ error: `${service} is not connected for this account`, fix: `Connect it at 0n3.app/connect` });
    // The CRM's location is part of the connection, not something a person should type into every step.
    // Only where the endpoint takes it (path, body template or query): the contact-scoped endpoints reject an unknown
    // field — POST /contacts/{id}/tags answered 422 "property locationId should not exist" (2026-11-08, Eagles follow form).
    if ((canonicalService(service) || service) === 'crm') { const loc = env.meta?.location_id || env.auth?.credentials?.location_id || env.auth?.credentials?.locationId; if (loc && !(params && params.locationId) && takesLocation(getService(service)?.endpoints?.[endpoint])) params = { ...(params || {}), locationId: loc }; }
    // Same for Cloudflare's account id: every Workers/KV/R2/D1/Pages path is /accounts/{accountId}/…, and the record holds it.
    if ((canonicalService(service) || service) === 'cloudflare') { const acc = env.auth?.credentials?.accountId; if (acc && !(params && params.accountId) && /\{accountId\}/.test(getService(service)?.endpoints?.[endpoint]?.path || '')) params = { ...(params || {}), accountId: acc }; }
    // Connected but not in the catalog: say THAT. "Unknown service" to someone
    // looking at a green tick is how an afternoon disappears.
    if (!getService(service)) {
      return text({
        error: `${service} is in your vault, but it is not a catalog service, so api_call has no endpoints for it.`,
        fix: mcpConfigOf(env) ? `This record is an MCP server — use mcp_tools / mcp_call with service "${service}".`
          : `Reconnect the credential under a catalog key (see the services tool), or ask for "${service}" to be added to the catalog.`,
      });
    }
    try {
      // Long-lived credentials → a live access token, minted and cached here; the vault never holds an hour-old token.
      const creds = await freshCredentials(service, env.auth.credentials, { fetchImpl, onRotate: rotateInto(resolver, env) });
      const r = await executeEndpoint(service, endpoint, params || {}, creds, fetchImpl);
      await safeAudit({ service, label: env.$0n?.name || null, tool: 'api_call', action: endpoint, ok: r.ok, status: r.status });
      const hint = await scopeHint(service, env.$0n?.name || null, r);
      return text({ success: r.ok, status: r.status, used: env.$0n?.name || null, data: r.data, ...(r.usage ? { usage: r.usage } : {}), ...(hint ? { fix: hint } : {}) });
    } catch (e) {
      await safeAudit({ service, label: env.$0n?.name || null, tool: 'api_call', action: endpoint, ok: false, detail: e.message });
      return text({ error: e.message });
    }
  });

  // ── MCP-to-MCP ────────────────────────────────────────────────────────
  //
  // `api_call` reaches 113 REST services through this account's vault.
  // `mcp_call` reaches any MCP SERVER the account has connected, through the
  // same vault, the same account and the same 0n token. A remote MCP is not a
  // new kind of thing: it is a connection record whose `options.mcp.url` says
  // where to speak MCP, so it lists in `connections`, strips like every other
  // record, and is isolated per account by the resolver that is already there.
  //
  // Gateway, not federation: remote tools do NOT appear in `tools/list`. That
  // is deliberate. `tools/list` is the most-called method in the protocol, and
  // fanning it out to third parties on every call puts their uptime on our
  // hottest path — the same shape as the outage that took 1,084 tools off
  // 0nMCP 4.x because ONE list-assembly pass could throw. Federation is a
  // per-connection opt-in (`options.mcp.federate`) and a later step.
  const mcpRecordFor = async (service, label) => {
    const env = await resolver.get(service, label);
    if (!env) return { error: { error: `${service} is not connected for this account`, fix: 'Connect it at 0n3.app/connect' } };
    if (!mcpConfigOf(env)) {
      return { error: { error: `${service} is connected, but as an API service — not an MCP server`, fix: 'Use api_call for catalog services, or reconnect this record with options.mcp.url' } };
    }
    return { env };
  };

  server.registerTool('mcp_tools', {
    description: "Tools available on one MCP server this account has connected. Use before mcp_call.",
    inputSchema: {
      service: z.string().describe('Connection key of the MCP server, e.g. godaddy_mcp'),
      label: z.string().optional().describe('Which record when the account holds several'),
    },
  }, async ({ service, label }) => {
    const { env, error } = await mcpRecordFor(service, label);
    if (error) return text(error);
    try {
      const r = await listRemoteTools(env, { fetchImpl, persist: resolver.save ? (e) => resolver.save(e) : null });
      await safeAudit({ service, label: env.$0n?.name || null, tool: 'mcp_tools', action: 'list', ok: true, status: 200 });
      return text({ service, url: env.options.mcp.url, tools: r.tools, total_on_remote: r.total, allowlisted: r.allowlisted });
    } catch (e) {
      const detail = redact(e.message, env.auth?.credentials);
      await safeAudit({ service, label: env.$0n?.name || null, tool: 'mcp_tools', action: 'list', ok: false, detail });
      return text({ error: detail, service });
    }
  });

  server.registerTool('mcp_call', {
    description: "Call a tool on an MCP server this account has connected. Use mcp_tools to see names and arguments.",
    inputSchema: {
      service: z.string().describe('Connection key of the MCP server, e.g. godaddy_mcp'),
      tool: z.string().describe('Tool name from mcp_tools'),
      args: z.record(z.string(), z.any()).optional().describe("Arguments for that tool, as the remote's own schema defines them"),
      label: z.string().optional().describe('Which record when the account holds several'),
    },
  }, async ({ service, tool, args, label }) => {
    if (gate) { const held = await gate({ kind: 'mcp_call', service, endpoint: tool, method: 'CALL', args: { service, tool, args: args || {}, label } }); if (held) return text(held); }
    const { env, error } = await mcpRecordFor(service, label);
    if (error) return text(error);
    try {
      const r = await callRemoteTool(env, tool, args || {}, { fetchImpl, persist: resolver.save ? (e) => resolver.save(e) : null });
      await safeAudit({ service, label: env.$0n?.name || null, tool: 'mcp_call', action: tool, ok: !r.isError, status: r.isError ? 0 : 200 });
      // The remote's own error is RELAYED, not swallowed and not relabelled —
      // its words are the only ones that can tell a caller what to fix.
      return text({ success: !r.isError, service, tool, content: r.content, structuredContent: r.structuredContent });
    } catch (e) {
      const detail = redact(e.message, env.auth?.credentials);
      await safeAudit({ service, label: env.$0n?.name || null, tool: 'mcp_call', action: tool, ok: false, detail });
      return text(e.blocked ? { error: detail, blocked_by: 'this connection\'s toolAllowlist' } : { error: detail, service, tool });
    }
  });

  // ── MINI-APPS ─────────────────────────────────────────────────────────
  //
  // `api_call` is a verb; an app is a RESULT. "Set Google up for this domain"
  // is nine calls across four services, and a button in 0nCore should not have
  // to know that. Three tools, forever, however many apps exist — the same
  // bargain `services / service_info / api_call` already makes.
  server.registerTool('apps', {
    description: 'Mini-apps: whole jobs this account can run in one call, with what each one needs connected.',
    inputSchema: {},
  }, async () => {
    await loadApps();
    const have = new Set((await resolver.list()).map((c) => canonicalService(c.service) || c.service));
    const connected = (svc) => { const c = canonicalService(svc) || svc; return have.has(c) || (familyOf(svc) ? have.has(familyOf(svc)) : false); };
    return text(listApps().map((a) => ({
      ...a,
      ready: a.needs.every((n) => n.optional || connected(n.service)),
      missing: a.needs.filter((n) => !n.optional && !connected(n.service)).map((n) => n.service),
    })));
  });

  server.registerTool('app_info', {
    description: 'What one mini-app does, what it needs connected, and what it takes as input.',
    inputSchema: { app: z.string().describe('App key from the apps tool') },
  }, async ({ app }) => {
    await loadApps();
    const a = listApps().find((x) => x.key === app);
    if (!a) return text({ error: `Unknown app: ${app}`, available: listApps().map((x) => x.key) });
    const have = new Set((await resolver.list()).map((c) => canonicalService(c.service) || c.service));
    return text({ ...a, needs: a.needs.map((n) => ({ ...n, connected: have.has(canonicalService(n.service) || n.service) || (familyOf(n.service) ? have.has(familyOf(n.service)) : false) })) });
  });

  server.registerTool('app_run', {
    description: "Run a mini-app with this account's own connections. Returns a receipt of every step it took.",
    inputSchema: {
      app: z.string().describe('App key from the apps tool'),
      input: z.record(z.string(), z.any()).optional().describe('Inputs — see app_info'),
      label: z.string().optional().describe('Which connection record to use when the account holds several for a service'),
    },
  }, async ({ app, input, label }) => {
    if (gate) { const held = await gate({ kind: 'app_run', service: 'app', endpoint: app, method: 'RUN', args: { app, input: input || {}, label } }); if (held) return text(held); }
    return text(await runApp({ resolver, fetchImpl, audit: safeAudit, scopeHint, desk, jobs }, { app, input, label }));
  });

  // Only when changes are being held: the AI can see what happened to a change it asked for (pending / done / declined + result).
  if (gate && approvalLookup) server.registerTool('approval_status', {
    description: 'What happened to a change that was held for the person\'s OK: pending, done (with the result), declined or failed.',
    inputSchema: { approval_id: z.string().describe('The approval_id a held change returned') },
  }, async ({ approval_id }) => text((await approvalLookup(approval_id)) || { error: 'No such request on this account.' }));

  server.registerTool('vault_record', { description: 'Inspect one connection record without its secrets: label, environment, meta, credential key names.', inputSchema: { service: z.string(), label: z.string().optional() } }, async ({ service, label }) => {
    const env = await resolver.get(service, label);
    return text(env ? stripSecrets(env) : { error: `${service} is not connected for this account` });
  });

  const crmCount = registerCrmTools(server, z, {
    fetch: fetchImpl,
    // THE BASE TIER: an auto-provisioned 0ncore sub-account may use contacts, forms and surveys; the rest waits for a plan.
    allowTool: async (def, args) => {
      if (gate && String(def.method || 'GET').toUpperCase() !== 'GET') { const held = await gate({ kind: 'crm', service: 'crm', endpoint: def.name, method: String(def.method).toUpperCase(), args }); if (held) return held; }
      if (args.access_token) return null; // a token passed explicitly is the caller's own business
      const env = await resolver.get('crm', args.location_id || account?.crmLocationId || undefined);
      if (env && env.meta?.tier === 'base' && !BASE_TIER_TOOLS.has(def.name)) return TIER_REFUSAL(def.name, 'base');
      if (env && env.meta?.tier === 'messaging' && !MESSAGING_TIER_TOOLS.has(def.name)) return TIER_REFUSAL(def.name, 'messaging');
      return null;
    },
    resolveToken: async (args) => {
      // No location asked for → the account's own CRM location (profiles.crm_location_id), never "whichever row came first".
      const env = await resolver.get('crm', args.location_id || account?.crmLocationId || undefined);
      if (!env) return null;
      if (!args.location_id && env.meta?.location_id) args.location_id = env.meta.location_id;
      // A managed record mints through 0nCore; a pasted PIT or OAuth record is used as stored.
      const creds = await freshCredentials('crm', env.auth?.credentials || {}, { fetchImpl, onRotate: rotateInto(resolver, env) });
      return creds.access_token || null;
    },
    onCall: (info) => safeAudit({ service: 'crm', tool: info.tool, action: info.tool, ok: info.ok, status: info.status, label: info.locationId }),
  });

  server.__0n3 = { crmTools: crmCount };
  return server;
}

/** See the comment above api_call: an opaque 403 becomes an instruction when another record would have worked. */
export async function scopeHintFor(resolver, service, used, result) {
  if (result.status !== 403 && result.status !== 401) return null;
  const msg = JSON.stringify(result.data || '').toLowerCase();
  if (!/scope|insufficient|permission/.test(msg)) return null;
  const fam = familyOf(service);
  const others = (await resolver.list())
    .filter((c) => (c.service === service || (fam && c.service === fam)) && (c.$0n?.name || null) !== used)
    .map((c) => c.$0n?.name)
    .filter(Boolean);
  if (!others.length) return null;
  return `This connection ("${used}") does not hold the scope for that call. You also have: ${others.map((o) => `"${o}"`).join(', ')} — pass one as \`label\` to use it instead.`;
}

/**
 * RUN A MINI-APP for one account — the ONE implementation behind the `app_run`
 * tool and the workspace "Run" button. Two callers, one engine; a workspace
 * run is exactly what an MCP client would get, receipt included.
 *
 * @param {{ resolver: { get: Function, list: Function }, fetchImpl?: typeof fetch, audit?: (info: any) => Promise<void>, scopeHint?: Function }} ctx
 * @param {{ app: string, input?: Record<string, any>, label?: string }} args
 */
export async function runApp({ resolver, fetchImpl = fetch, audit = async () => {}, scopeHint = null, desk = null, jobs = null }, { app, input, label }) {
  await loadApps();
  const def = getApp(app);
  if (!def) return { error: `Unknown app: ${app}`, available: listApps().map((x) => x.key) };
  const hint = scopeHint || ((service, used, result) => scopeHintFor(resolver, service, used, result));

  // Refuse BEFORE doing anything, naming what to connect. An app that writes
  // three things and then discovers it cannot finish has still written three.
  const have = new Set((await resolver.list()).map((c) => canonicalService(c.service) || c.service));
  // Family-aware, or the precheck refuses a run the app could actually do:
  // an account connects `google` once and `search_console` reads that same
  // record through GOOGLE_FAMILY. Checking the literal key would demand a
  // connection that, by design, nobody ever makes.
  const connected = (svc) => { const c = canonicalService(svc) || svc; return have.has(c) || (familyOf(svc) ? have.has(familyOf(svc)) : false); };
  const missing = def.needs.filter((n) => !n.optional && !connected(n.service));
  if (missing.length) {
    return {
      error: `${def.name} needs ${missing.map((m) => m.service).join(' and ')} connected first.`,
      missing: missing.map((m) => ({ service: m.service, why: m.why })),
      fix: 'Connect them at 0n3.app/connect, then run this again.',
    };
  }

  const has = async (svc) => connected(svc);
  /** One call, resolved and audited exactly as api_call does it. */
  const call = async (service, endpoint, params = {}) => {
    let env = await resolver.get(service, label);
    if (!env && familyOf(service)) env = await resolver.get(familyOf(service), label);
    env = await withFamilyToken(resolver, service, env, label);
    if (!env && getService(service)?.authType === 'none') env = PUBLIC_ENV(service)
    if (!env) return { ok: false, status: 0, error: `${service} is not connected for this account` };
    try {
      const creds = await freshCredentials(service, env.auth.credentials, { fetchImpl, onRotate: rotateInto(resolver, env) });
      const res = await executeEndpoint(service, endpoint, params, creds, fetchImpl);
      await audit({ service, label: env.$0n?.name || null, tool: `app:${app}`, action: `${service}.${endpoint}`, ok: res.ok, status: res.status });
      const h = await hint(service, env.$0n?.name || null, res);
      return {
        ok: res.ok, status: res.status, data: res.data, ...(res.usage ? { usage: res.usage } : {}),
        error: res.ok ? null : [(res.data?.error?.message || res.data?.message || `HTTP ${res.status}`), h].filter(Boolean).join(' — '),
      };
    } catch (e) {
      await audit({ service, label: env.$0n?.name || null, tool: `app:${app}`, action: `${service}.${endpoint}`, ok: false, detail: e.message });
      return { ok: false, status: 0, error: e.message };
    }
  };

  try {
    return await def.run({ input: input || {}, call, has, desk, jobs, r: new Receipt(app, input || {}) });
  } catch (e) {
    return { app, complete: false, error: e.message };
  }
}

/**
 * CALL A TOOL IN-PROCESS — the REST facade and the workspace chat reach the
 * exact same handlers an MCP client does, without a transport in between.
 * Returns the parsed JSON the tool would have sent as text.
 */
export async function callTool(server, name, args = {}) {
  const t = (server._registeredTools || {})[name];
  if (!t) throw new Error(`No tool called ${name}`);
  if (t.enabled === false) throw new Error(`Tool ${name} is disabled`);
  const r = await t.handler(args || {}, {});
  const text = (r?.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n');
  try { return JSON.parse(text); } catch { return text; }
}

/** Registered tool count for a runtime (for /, doctor and tests). */
export function countTools(server) {
  const reg = server._registeredTools || {};
  return Object.keys(reg).length;
}
