/**
 * HOSTED MODE — the same runtime behind a bearer token.
 *
 *   GET  /            → what this is (counts derived at request time, never constants)
 *   POST /mcp         → Streamable HTTP MCP, stateless; `Authorization: Bearer 0n_…` REQUIRED
 *   GET  /vault       → this account's records (no secrets)
 *   PUT  /vault/:svc  → store a .0n connection envelope for this account
 *   DELETE /vault/:svc[?label=] → remove one
 *
 * Every request resolves the token to an account first; a request with no
 * valid token gets 401 and touches nothing. There is no shared credential
 * anywhere in this process: the master key decrypts records, the account
 * decides which records, the resolver hands them to the tool for that call.
 */
import { linksFor, verifyLink, cleanSite, schematicThumb, summary as pageSummary, decodeThumb, SITE_SYSTEM } from './pages.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { createRuntime, countTools, runApp, callTool, VERSION } from './runtime.js';
import { INSTALL_CLIENTS, installClient, artifactsFor, openapi, skillMarkdown } from './install.js';
import { PROVIDERS, providerOf, chatTurn, keyOf, complete as completeOnce, botIntro } from './chat.js';
import { listApps } from './apps/registry.js';
import { uid as newId } from './flow-defs.js';
/** crm-ask: the (location, agent) that answered for an account, so the next question goes straight there (per instance). */
const CRM_ASK_CACHE = new Map();
import { AiRouter } from './ai-router.js';
import { runFlow, fenceFromAccess } from './flows.js';
import { listJobs, findJob, runView, newRunKey, onPage, appSite, appHolding, appOutput } from './jobs.js';
import { createPartner, partnerOk } from './partner.js';
import { kindsList, promptFor, shapeDesign, designSummary, KINDS as OUTREACH_KINDS } from './outreach.js';
import { flowForButton, cleanDoc, wireJobBlocks, wiring } from './workspaces.js';
import { draft as draftSpec, missingFromSequence, parseSpec } from './draft.js';
import { randomBytes, createHash, timingSafeEqual } from 'node:crypto';
import { decodeUploads, safeName } from './files.js';
import { ASK_MAX_FILES } from './desk.js';
import { parseAlert, runRule, summarize, APP_EVENTS, SCHEDULES } from './alerts.js';
import { makeConnection } from './envelope.js';
import { VaultResolver, NullResolver } from './resolver.js';
import { grantOf, GrantResolver, jwks, parseScopes, keyLimitsOf, keyScopes, keyAllows } from './oidc.js';
import { signFor, publicKeys as deskPublicKeys } from './desk-sign.js';
import { priceList, limitsFor, overLimit, PAID, addonList } from './billing.js';
import { yhlEvent, cleanContact } from './yhl-crm.js';
import { nextSteps } from './next-steps.js';
import { resolveIdentity, bearerOf } from './identity.js';
import { listServices, getService, SERVICE_CATALOG } from './catalog.js';
import { publicGuides } from './connect-guides.js';
import { Hub } from './hub.js';
import { askRequest, cleanSelection, extractCanvas, describeSystemPrompt, parseDescribe, DESCRIBE_KINDS } from './canvas.js';
import { createSheetBus, vaultToken, SheetMirror, PROVIDERS as SHEET_PROVIDERS, within } from './sheet-bus.js';
import { renderAuthorize } from './oauth-page.js';
import { Inbound } from './inbound.js';
import { createAppStudio } from './appstudio.js';
import { WaitStore } from './waits.js';
import { getProfile, getProfileByEmail, patchProfile, shape } from './profile.js';

const json = (res, status, body) => { res.statusCode = status; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(body)); };

const html = (res, status, body) => { res.statusCode = status; res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.setHeader('Cache-Control', 'no-store'); res.end(body); };
/** JSON or application/x-www-form-urlencoded, pre-parsed by the platform or read from the stream. */
async function readBody(req) {
  const parse = (text) => { const t = String(text || '').trim(); if (!t) return {}; if (t[0] === '{') { try { return JSON.parse(t); } catch { /* fall through */ } } return Object.fromEntries(new URLSearchParams(t)); };
  if (req.body !== undefined && req.body !== null && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') return parse(req.body);
  const chunks = []; for await (const c of req) chunks.push(c);
  return parse(Buffer.concat(chunks).toString('utf8'));
}
const WWW_AUTH = (base) => `Bearer resource_metadata="${base}/.well-known/oauth-protected-resource"`;
async function readJson(req) {
  if (req.body !== undefined && req.body !== null && typeof req.body === 'object') return req.body;
  if (typeof req.body === 'string') { try { return JSON.parse(req.body); } catch { return undefined; } }
  const chunks = [];
  for await (const c of req) chunks.push(c);
  if (!chunks.length) return undefined;
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return undefined; }
}

/**
 * @param {{ store: import('./vault/store.js').VaultStore, identityRest: { select: Function }, identity?: (token: string) => Promise<any>, fetchImpl?: typeof fetch }} o
 */
export function createHandler({ store, identityRest, identity, fetchImpl = fetch, hub = null, workspaces = null, desk = null, files = null, alerts = null, security = null, billing = null, usage = null, onboarding = null, canvas = null, busFor = null, cronSecret = process.env.CRON_SECRET || '' }) {
  const resolveId = identity || ((token) => resolveIdentity(token, identityRest));
  // PARTNER DOOR (partner.js): one 0n3 account per CRM sub-account for the marketplace app; its usage billed through the CRM.
  const createUserFor = async (email, name) => {
    if (!hub?.sb?.url || !hub?.sb?.serviceKey) throw new Error('Account creation is not configured on this server.');
    const r = await fetchImpl(`${hub.sb.url.replace(/\/$/, '')}/auth/v1/admin/users`, { method: 'POST', headers: { apikey: hub.sb.serviceKey, Authorization: `Bearer ${hub.sb.serviceKey}`, 'content-type': 'application/json' }, body: JSON.stringify({ email, email_confirm: true, user_metadata: { full_name: name || '', source: 'crm_marketplace' } }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.id) throw new Error(`The 0n3 account could not be made: ${j.msg || j.message || j.error_description || r.status}`);
    // The profile row comes from the sign-up trigger; wait for it briefly so the first key can be minted against it.
    for (let i = 0; i < 10; i++) { const p = (await identityRest.select('profiles', { id: j.id }, 'id'))[0]; if (p) break; await new Promise((ok) => setTimeout(ok, 300)); }
    return j.id;
  };
  const partner = hub && usage ? createPartner({ rest: identityRest, hub, usage, createUser: createUserFor, base: hub.base }) : null;
  const firstParty = (req) => { const internal = process.env.ON3_INTERNAL_SECRET || ''; return !!internal && String(req.headers?.['x-0n3-internal'] || '') === internal; };
  let infoCache = null;
  // INBOUND WEBHOOKS (2026-11-05): one receiver for every connected app's events — inbound.js.
  // THE AI ROUTER (2026-11-06): every AI call walks the person's own AIs in their order, with fallback — ai-router.js.
  const router = store ? new AiRouter({ store, rest: identityRest || null, fetchImpl }) : null;
  // WAITING RUNS (2026-11-09): a line's wait parks the rest of a sequence here; the 5-minute clock resumes it — waits.js.
  const waits = identityRest ? new WaitStore({ rest: identityRest }) : null;
  /** The park() a REAL run of a stored sequence gets. Test runs get none, so they never wait. */
  const parkFor = (accountId, { workspaceId, sequence, actor, access = null }) => (waits && sequence?.id ? (w) => waits.park(accountId, { workspaceId, sequenceId: sequence.id, sequenceName: sequence.name, node: w.node, step: (sequence.nodes || []).find((n) => n.id === w.node)?.title, from: w.from, ctx: w.ctx, dueAt: w.dueAt, wait: w.wait, actor, access }) : null);
  // THE TABLE BLOCKS' three seams (blocks.js, 2026-11-11). Pictures a step keeps live in the same private bucket desk files
  // do; a reading is a desk ASK on the person's own computer (no API key, no credits); what "Update a table" wrote is
  // remembered per table so a cell a person changed afterwards is never overwritten.
  const filesFor = (accountId) => (files ? { put: async (name, buffer, type) => ({ name: safeName(name), ...(await files.put(`${accountId}/flow/${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}/${safeName(name)}`, buffer, type)) }) } : null);
  const readerFor = (accountId, from) => (desk && files ? {
    start: async ({ pictures, prompt, label }) => (await desk.create(accountId, { request: prompt, source: { kind: 'ask', app: '0n3-sequence', want: 'json', model: 'smart', from: `${label}${from ? ` · ${from}` : ''}`, files: pictures.map((p) => ({ name: p.name, type: p.type, size: p.size, path: p.path })) } })).id,
    check: async (id) => { const r = await desk.get(accountId, id); if (!r) return { state: 'failed', reply: 'the reading is gone' }; return { state: r.state, reply: [...(r.thread || [])].reverse().find((t) => t.role === 'receipt')?.text || '' }; },
  } : null);
  const memoryFor = (accountId) => (identityRest ? {
    load: async (target) => (await identityRest.select('table_memory', { account_id: accountId, target }))[0]?.cells || {},
    save: async (target, cells) => { await identityRest.upsert('table_memory', { account_id: accountId, target, cells, updated_at: new Date().toISOString() }, 'account_id,target'); },
  } : null);
  const inbound = identityRest && store ? new Inbound({ rest: identityRest, store, base: hub?.base || process.env.ON3_PUBLIC_URL || 'https://0n3.app' }) : null;
  // The canvas chat's record: each person's own spreadsheet, reached with their own vault connection.
  const sheetBusFor = busFor || ((accountId, provider) => createSheetBus({ provider, fetchImpl, token: () => vaultToken(new VaultResolver(store, accountId), provider, { fetchImpl }) }));
  const mirror = canvas ? new SheetMirror({ canvas, busFor: sheetBusFor }) : null;
  const mirrorEvent = (accountId, run, ev, o) => (mirror && run?.source?.kind === 'canvas' ? within(mirror.event(accountId, run, ev, o)) : null);
  const redirect = (res, to) => { res.statusCode = 302; res.setHeader('Location', to); res.end(); };
  // APPS (2026-11-14): the CRM's AI app builder inside the dashboard, one renewable builder sign-in per sub-account in the vault.
  const apps = store ? createAppStudio({ store, fetchImpl, base: hub ? hub.base : 'https://0n3.app' }) : null;

  return async function handler(req, res) {
    const url = new URL(req.url || '/', 'http://0n3.local');
    // Vercel rewrites keep the original path in req.url; only a direct hit on the function itself needs stripping.
    let path = url.pathname.replace(/^\/api\/handler(?=\/|$)/, '') || '/';
    // RENAMES (2026-11-12): Workspaces are now PROJECTS. /api/projects/* is the name; /api/workspaces/* keeps working forever.
    if (path === '/api/projects' || path.startsWith('/api/projects/')) path = '/api/workspaces' + path.slice('/api/projects'.length);
    const method = (req.method || 'GET').toUpperCase();
    // THE DECOY LAYER (2026-10-29, security.js / 0n-decoy): trap paths, canary tokens and flagged addresses are answered
    // from a fake world before any real route runs. A valid token is never fed fake data.
    const clientIp = String(req.headers?.['x-real-ip'] || req.headers?.['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
    const clientUa = String(req.headers?.['user-agent'] || '');
    const decoyAnswer = async (d) => { if (d.delayMs) await new Promise((r) => setTimeout(r, d.delayMs)); if (d.action !== 'decoy') return false; res.statusCode = d.response.status; res.setHeader('Content-Type', d.response.type); res.setHeader('Cache-Control', 'no-store'); res.end(d.response.body); return true; };
    if (security) {
      // A request that carries a token is not slowed here: it is checked first, and only a token that fails is tarpitted (below).
      try { const tk = bearerOf(req); const d0 = await security.decoy.inspect({ ip: clientIp, path, token: tk, ua: clientUa }); if (await decoyAnswer(tk && d0.action === 'pass' ? { ...d0, delayMs: 0 } : d0)) return; } catch (e) { console.error('[0n3 security] inspect:', e.message); }
    }
  /** One rule, one check, with the owner's own connections. Shared by the cron and the "Run now" button. */
  const runOneAlert = async (rule) => {
    const accountId = rule.accountId;
    const recs = await store.list(accountId); const connected = [...new Set(recs.map((r) => r.service))];
    // Several CRM records? Prefer the one simply called "CRM" (the master), else the first that names a location; the same
    // record's label goes to api_call so the token and the location always match (an OAuth sub-record 403s on another's).
    const crms = recs.filter((r) => r.service === 'crm' && (r.meta?.location_id || r.meta?.locationId) && !/do not use/i.test(String(r.$0n?.name || '')));
    const candidates = crms.map((r) => ({ label: r.$0n?.name || null, locationId: r.meta?.location_id || r.meta?.locationId })).sort((a, b) => (String(b.label).toUpperCase() === 'CRM') - (String(a.label).toUpperCase() === 'CRM'));
    const rt = createRuntime({ resolver: new VaultResolver(store, accountId), account: { accountId }, fetchImpl, audit: (info) => store.audit({ ...info, actor: `alerts:${accountId}` }) });
    const call = (tool, args) => callTool(rt, tool, args);
    const notify = desk ? (payload) => desk.notify(accountId, { ...payload, url: '/alerts' }) : null;
    // A rule whose action is a SEQUENCE runs the CURRENT version of that sequence (read fresh from its canvas) with the
    // new item as {{trigger.*}}, counted against the plan's runs like a tap, and lands in the workspace's run history.
    const runSequence = rule.action?.kind === 'sequence' && workspaces ? async (payload) => {
      const wsId = rule.action.workspaceId;
      const c = await workspaces.getCanvas(accountId, wsId).catch(() => null);
      const q = (c?.sequences || []).find((x) => x.id === rule.action.sequenceId);
      if (!q) return { ok: false, error: `"${rule.action.name || 'That sequence'}" is no longer in its workspace.` };
      if (identityRest) {
        const plan = (await identityRest.select('profiles', { id: accountId }, 'plan').catch(() => []))[0]?.plan || 'free';
        // Paid plans are METERED past their allowance (usage.js), so they never stop. Free has no card: its allowance is a cap.
        const L = limitsFor(plan);
        if (L.plan === 'free' && usage) { const used = Number((await usage.month(accountId))?.units || 0); if (used >= L.runsPerMonth) return { ok: false, error: `The Free plan's ${L.runsPerMonth} actions this month are used up; it did not run. Any paid plan keeps it running.` }; }
      }
      const start = (q.nodes || []).find((n) => n.type === 'trigger');
      const actor = `automation:${rule.watch?.key === 'clock' ? 'schedule' : rule.watch?.service}`;
      const myDesk = desk ? { create: (o) => desk.create(accountId, { workspaceId: wsId, project: o.project, machine: o.machine, source: { ...(o.source || {}), from: actor }, request: o.request }) } : null;
      const receipt = await runFlow({ server: rt, nodes: q.nodes, edges: q.edges || [], startId: start?.id, payload, fetchImpl, desk: myDesk, files: filesFor(accountId), reader: readerFor(accountId, q.name), memory: memoryFor(accountId), readWaitMs: 15000, park: parkFor(accountId, { workspaceId: wsId, sequence: q, actor }), ai: async (prov) => (router ? { chat: (cc, t) => router.chat(accountId, { provider: prov }, cc, t, { task: 'logic' }) } : { apiKey: null }) });
      await workspaces.recordRun(accountId, wsId, { app_key: `flow:${start?.title || q.name}`, inputs: payload, receipt, ok: receipt.complete, actor }).catch(() => {});
      return { ok: !!receipt.complete, via: 'sequence', outcome: String(receipt.outcome || '').slice(0, 240) };
    } : null;
    return runRule({ rule, call, connected, candidates, notify, store: alerts, runSequence });
  };

  /** A due wait, resumed: the CURRENT sequence from the step it was waiting for, with what the run knew, on the owner's keys. */
  const resumeWait = async (row) => {
    const accountId = row.account_id; const wsId = row.workspace_id;
    const c = workspaces ? await workspaces.getCanvas(accountId, wsId).catch(() => null) : null;
    const q = (c?.sequences || []).find((x) => x.id === row.sequence_id);
    if (!q) { const outcome = `"${row.sequence_name || 'The sequence'}" is no longer in its workspace, so the wait ended without running.`; await waits.finish(row.id, { ok: false, outcome }); return { ok: false, outcome }; }
    const actor = `wait:${row.wait || 'timer'}${row.actor ? ` · ${row.actor}` : ''}`;
    const rt = createRuntime({ resolver: new VaultResolver(store, accountId), account: { accountId }, fetchImpl, audit: (info) => store.audit({ ...info, accountId, actor }) });
    const myDesk = desk ? { create: (o) => desk.create(accountId, { workspaceId: wsId, project: o.project, machine: o.machine, source: { ...(o.source || {}), from: actor }, request: o.request }) } : null;
    const receipt = await runFlow({ server: rt, nodes: q.nodes, edges: q.edges || [], resume: { node: row.node_id, ctx: row.ctx || {} }, access: row.access || null, fetchImpl, desk: myDesk, files: filesFor(accountId), reader: readerFor(accountId, q.name), memory: memoryFor(accountId), readWaitMs: 15000, park: parkFor(accountId, { workspaceId: wsId, sequence: q, actor: row.actor, access: row.access || null }), ai: async (prov) => (router ? { chat: (cc, t) => router.chat(accountId, { provider: prov }, cc, t, { task: 'logic' }) } : { apiKey: null }) });
    await workspaces.recordRun(accountId, wsId, { app_key: `flow:${q.name} (after ${row.wait || 'a wait'})`, inputs: row.ctx?.trigger || {}, receipt, ok: receipt.complete, actor }).catch(() => {});
    await waits.finish(row.id, { ok: !!receipt.complete, outcome: receipt.outcome });
    if (desk && !receipt.complete) await desk.notify(accountId, { title: `${q.name}: a step after the ${row.wait || ''} wait did not finish`, body: String(receipt.outcome || '').slice(0, 200), url: '/alerts' }).catch(() => {});
    return { ok: !!receipt.complete, outcome: receipt.outcome };
  };

    if (path === '/' && method === 'GET') {
      if (!infoCache) { const probe = createRuntime({ resolver: new NullResolver() }); infoCache = { tools: countTools(probe), crmTools: probe.__0n3.crmTools, services: listServices().length }; }
      return json(res, 200, { name: '0n3', version: VERSION, status: 'online', auth: 'Bearer 0n_ token on every request', endpoint: '/mcp', ...infoCache, measured_at: new Date().toISOString() });
    }

    // ── HQ routes that do not carry a 0n token ──────────────────────────
    if (hub && path === '/api/catalog' && method === 'GET') return json(res, 200, { services: hub.catalog() });
    // How to get each service's key: url, menu path, steps, scopes, field labels, and a key pattern the 0n Chrome
    // extension uses to spot a freshly made key on the provider's page. Public and cacheable — it holds no secret.
    if (path === '/api/connect/guides' && (method === 'GET' || method === 'HEAD')) {
      const services = publicGuides(SERVICE_CATALOG);
      res.setHeader('Cache-Control', 'public, max-age=300, s-maxage=3600'); res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('X-0n3-Guide-Count', String(Object.keys(services).length));
      return json(res, 200, services);
    }
    if (hub && path === '/api/connect/providers' && method === 'GET') return json(res, 200, { providers: hub.providers() });
    // eBay requires every production keyset to answer its Marketplace Account Deletion notifications:
    // GET ?challenge_code=… → sha256(challengeCode + verificationToken + endpointUrl) as {challengeResponse};
    // POST → 200 (the payload names a user who deleted their eBay account; we log it and drop nothing else).
    if (path === '/api/ebay/account-deletion') {
      const vt = process.env.EBAY_VERIFICATION_TOKEN || '';
      if (!vt) return json(res, 503, { error: 'EBAY_VERIFICATION_TOKEN is not set.' });
      if (method === 'GET') {
        const cc = url.searchParams.get('challenge_code') || '';
        if (!cc) return json(res, 400, { error: 'challenge_code is required.' });
        const endpoint = `${(hub ? hub.base : 'https://0n3.app')}/api/ebay/account-deletion`;
        const { createHash } = await import('node:crypto');
        return json(res, 200, { challengeResponse: createHash('sha256').update(cc + vt + endpoint).digest('hex') });
      }
      if (method === 'POST') { const b = (await readBody(req)) || {}; console.warn('[ebay] account deletion notice', JSON.stringify(b?.notification?.data || b).slice(0, 300)); return json(res, 200, { ok: true }); }
    }
    if (hub && path === '/api/session' && method === 'POST') {
      const body = (await readJson(req)) || {};
      const jwt = body.jwt || bearerOf(req);
      const r = await hub.session(jwt);
      return json(res, r.status, r.body);
    }
    const cbm = /^\/connect\/([a-z0-9_]+)\/callback$/.exec(path);
    if (hub && cbm && method === 'GET') {
      const prov = cbm[1];
      if (url.searchParams.get('error')) return redirect(res, `/connect?error=${encodeURIComponent(url.searchParams.get('error_description') || url.searchParams.get('error'))}&provider=${prov}`);
      const r = await hub.callback(prov, Object.fromEntries(url.searchParams));
      return redirect(res, r.ok ? `/connect?connected=${prov}` : `/connect?error=${encodeURIComponent(r.error)}&provider=${prov}`);
    }

    // ── OAuth 2.1 for MCP clients (no 0n token yet — this is how they get one) ──
    if (hub && path === '/.well-known/oauth-authorization-server' && method === 'GET') return json(res, 200, hub.oauthMetadata());
    if (hub && path === '/.well-known/openid-configuration' && method === 'GET') return json(res, 200, hub.openidConfiguration());
    if (path === '/.well-known/0n3-desk-key.json' && method === 'GET') return json(res, 200, deskPublicKeys());
    if (path === '/.well-known/jwks.json' && method === 'GET') { res.setHeader('Cache-Control', 'public, max-age=600'); return json(res, 200, jwks()); }
    if (hub && path === '/oauth/revoke' && method === 'POST') { await hub.revoke((await readBody(req)) || {}); return json(res, 200, {}); }
    if (hub && path === '/.well-known/oauth-protected-resource' && method === 'GET') return json(res, 200, hub.protectedResource());
    if (hub && path === '/oauth/register' && method === 'POST') { const r = await hub.registerClient((await readBody(req)) || {}); return json(res, r.status, r.body); }
    if (hub && path === '/oauth/token' && method === 'POST') { const r = await hub.exchange({ ...((await readBody(req)) || {}), authorization: req.headers.authorization || '' }); res.setHeader('Cache-Control', 'no-store'); return json(res, r.status, r.body); }
    if (hub && path === '/oauth/authorize') {
      const q = method === 'GET' ? Object.fromEntries(url.searchParams) : ((await readBody(req)) || {});
      const c = await hub.authorizeCheck(q);
      if (method === 'GET') return html(res, c.error ? 400 : 200, renderAuthorize({ q, client: c.client || null, scopes: c.scopes || [], error: c.error || null }));
      if (method !== 'POST') return json(res, 405, { error: 'GET or POST' });
      if (c.error) return html(res, 400, renderAuthorize({ q, client: null, error: c.error }));
      if (q.deny) { const to = new URL(q.redirect_uri); to.searchParams.set('error', 'access_denied'); if (q.state) to.searchParams.set('state', q.state); return redirect(res, to.toString()); }
      let userId = null; let err = null;
      if (q.jwt) { const se = await hub.session(String(q.jwt)); if (se.status === 200) userId = se.body.account.id; else err = 'Your sign-in expired. Sign in again.'; }
      else if (q.token) { const acct = await resolveId(String(q.token).trim()).catch(() => null); if (acct) userId = acct.accountId; else err = 'That 0n token is not valid, expired or revoked.'; }
      else if (q.email && q.password) { const l = await hub.loginPassword(q.email, q.password); if (l.userId) userId = l.userId; else err = l.error; }
      else err = 'Sign in to continue.';
      if (!userId) return html(res, 401, renderAuthorize({ q, client: c.client, scopes: c.scopes || [], error: err }));
      const code = await hub.issueCode({ clientId: c.client.client_id, userId, redirectUri: q.redirect_uri, codeChallenge: q.code_challenge, scopes: c.scopes, nonce: q.nonce || null });
      const to = new URL(q.redirect_uri); to.searchParams.set('code', code); if (q.state) to.searchParams.set('state', q.state);
      return redirect(res, to.toString());
    }

    // A browser opening /vault (deep link or refresh) is asking for the app, not
    // the API: the rewrite gives this path to the function, so send HTML
    // requests without a token back to the app with the destination attached.
    if (method === 'GET' && (path === '/vault' || path.startsWith('/vault/')) && !bearerOf(req) && String(req.headers.accept || '').includes('text/html')) {
      return redirect(res, `/?to=${encodeURIComponent(path)}`);
    }

    /*
      THE PROFILE, FOR A SIBLING 0n APP. 0nTask renders a header for someone
      already signed in to 0nTask; making them paste a 0n token to see their own
      name would be absurd. So a first-party app holding ON3_INTERNAL_SECRET may
      ask for one profile BY EMAIL. Same secret the vault already uses to release
      a credential, and it is read-only: no token is minted, nothing is written.
    */
    // THE PARTNER DOOR (partner.js) — the CRM marketplace app's backend, holding ON3_PARTNER_CRM_SECRET (never the internal
    // secret): a 0n3 session per sub-account, and the usage it bills through the CRM wallet at $0.10 per action.
    if (path.startsWith('/api/partner/crm/') && path !== '/api/partner/crm/link') {
      if (!partner) return json(res, 503, { error: 'The partner door is not configured on this server.' });
      if (!partnerOk(req)) return json(res, 403, { error: 'Partner only.' });
      const b = method === 'POST' ? ((await readJson(req)) || {}) : {};
      try {
        if (path === '/api/partner/crm/session' && method === 'POST') { const { status, ...out } = await partner.session(b); return json(res, status, out); }
        if (path === '/api/partner/crm/usage' && method === 'GET') { const month = url.searchParams.get('month') || new Date().toISOString().slice(0, 7); return json(res, 200, { ok: true, month, pricePerAction: 0.10, locations: await partner.due(month) }); }
        if (path === '/api/partner/crm/usage/ack' && method === 'POST') { const { status, ...out } = await partner.ack(String(b.locationId || ''), String(b.month || ''), b.units); return json(res, status, out); }
      } catch (e) { console.error('[0n3 partner]', e.message); return json(res, 502, { error: e.message }); }
      return json(res, 404, { error: `No route ${method} ${path}` });
    }
    if (path === '/api/profile/lookup' && method === 'GET') {
      const internal = process.env.ON3_INTERNAL_SECRET || '';
      const given = String(req.headers?.['x-0n3-internal'] || '');
      if (!internal || given !== internal) return json(res, 403, { error: 'First-party only.' });
      const prof = await getProfileByEmail(identityRest, url.searchParams.get('email') || '');
      if (!prof) return json(res, 404, { error: 'No 0n profile for that address.' });
      return json(res, 200, { ok: true, profile: shape(prof) });
    }

    /*
      THE VAULT, FOR A SIBLING 0n APP — the same door as the profile lookup,
      one floor down. 0nTask already holds a person's GitHub, Vercel and
      WordPress keys in tables of its own; that is the sixth credential store
      the 2026-09-13 audit warned about, and every one of them drifts from the
      others. So a first-party app holding ON3_INTERNAL_SECRET may read, write
      or remove ONE ACCOUNT'S records BY EMAIL — the estate's join key — and keep
      nothing of its own. Email is normalised in getProfileByEmail.

        GET    /api/vault/lookup?email=                      → non-secret list
        GET    /api/vault/lookup?email=&service=[&label=]    → the record, credentials included
        PUT    /api/vault/lookup?email=[&service=]           → store an envelope (write-through)
        DELETE /api/vault/lookup?email=&service=[&label=]    → remove one

      It MUST sit above the bearer gate below: a route that authenticates on
      the internal secret and is placed after `bearerOf` dies at "Missing
      bearer token" and the secret is never read (the profile lookup found that
      the hard way). Every release is audited with the calling app's name.
    */
    if (path === '/api/vault/lookup') {
      const internal = process.env.ON3_INTERNAL_SECRET || '';
      const given = String(req.headers?.['x-0n3-internal'] || '');
      if (!internal || given !== internal) return json(res, 403, { error: 'First-party only.' });
      const prof = await getProfileByEmail(identityRest, url.searchParams.get('email') || '');
      if (!prof) return json(res, 404, { error: 'No 0n profile for that address.' });
      const app = String(req.headers?.['x-0n3-app'] || 'first-party').slice(0, 40);
      const actor = `${app} for ${prof.email}`;
      const service = String(url.searchParams.get('service') || '').trim();
      const label = url.searchParams.get('label') || undefined;
      if (method === 'GET' && !service) return json(res, 200, { ok: true, account: prof.id, records: await store.list(prof.id) });
      if (method === 'GET') {
        const env = await store.get(prof.id, service, label);
        if (!env) return json(res, 404, { error: `${service} is not connected for this account` });
        await store.audit({ accountId: prof.id, service, label: env.$0n?.name || null, action: 'read_secret', tool: 'vault', ok: true, actor });
        return json(res, 200, { ok: true, account: prof.id, record: env });
      }
      if (method === 'PUT') {
        const env = await readJson(req);
        if (!env || typeof env !== 'object') return json(res, 400, { error: 'Body must be a .0n connection envelope' });
        env.service = env.service || service;
        if (!env.service) return json(res, 400, { error: 'service is required (query or envelope)' });
        // Connected apps per plan (2026-10-29): replacing a connection never counts, only a new one.
        try {
          const recs = await store.list(prof.id); const name = env.$0n?.name || null;
          const exists = recs.some((r) => r.service === env.service && (!name || r.$0n?.name === name));
          if (!exists) { const plan = (await identityRest.select('profiles', { id: prof.id }, 'plan'))[0]?.plan; const lim = limitsFor(plan).connections; if (recs.length >= lim) return json(res, 402, overLimit(plan, 'connected apps', recs.length, lim)); }
        } catch (e) { console.error('[0n3 billing] connection gate:', e.message); }
        try { return json(res, 200, { ok: true, account: prof.id, record: await store.put(prof.id, env, { actor }) }); }
        catch (e) { return json(res, 400, { error: e.message }); }
      }
      if (method === 'DELETE') {
        if (!service) return json(res, 400, { error: 'service is required' });
        await store.remove(prof.id, service, label, { actor });
        return json(res, 200, { ok: true });
      }
      return json(res, 405, { error: 'GET, PUT or DELETE' });
    }

    if (desk && path === '/api/push/vapid' && method === 'GET') return json(res, 200, { ok: true, publicKey: desk.push?.publicKey || null, configured: !!desk.push });

    // ── AUTOMATED ALERTS, the clock: every rule that is due, run with ITS account's runtime. Vercel calls this on a
    //    schedule with the CRON_SECRET; anything else is refused. One account's failure never stops the next.
    if (billing && path === '/api/cron/billing-sync' && (method === 'GET' || method === 'POST')) {
      const given = bearerOf(req) || url.searchParams.get('secret') || '';
      if (!cronSecret || given !== cronSecret) return json(res, 401, { error: 'cron secret required' });
      try { return json(res, 200, { ok: true, ...(await billing.reconcile()) }); } catch (e) { return json(res, 500, { ok: false, error: e.message }); }
    }
    // METERED USAGE → Stripe, every 10 minutes: each paid account's new actions go to the meter (usage.js). The first
    // days of a month also sweep last month's tail, so nothing counted on the 31st at 23:59 is lost.
    if (usage && billing && path === '/api/cron/usage-report' && (method === 'GET' || method === 'POST')) {
      const given = bearerOf(req) || url.searchParams.get('secret') || '';
      if (!cronSecret || given !== cronSecret) return json(res, 401, { error: 'cron secret required' });
      const d = new Date(); const months = [d.toISOString().slice(0, 7)];
      if (d.getUTCDate() <= 3) { const p = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1)); months.unshift(p.toISOString().slice(0, 7)); }
      try { return json(res, 200, { ok: true, ...(await usage.report({ paid: PAID, months })) }); } catch (e) { return json(res, 500, { ok: false, error: e.message }); }
    }
    // Push every permanent ban into the Vercel firewall of every project (edge block on all our sites). Every 5 minutes.
    if (security && path === '/api/cron/security-sync' && (method === 'GET' || method === 'POST')) {
      const given = bearerOf(req) || url.searchParams.get('secret') || '';
      if (!cronSecret || given !== cronSecret) return json(res, 401, { error: 'cron secret required' });
      try { return json(res, 200, await security.syncFirewall()); } catch (e) { return json(res, 500, { ok: false, error: e.message }); }
    }
    if (alerts && path === '/api/cron/alerts' && (method === 'GET' || method === 'POST')) {
      const given = bearerOf(req) || url.searchParams.get('secret') || '';
      if (!cronSecret || given !== cronSecret) return json(res, 401, { error: 'cron secret required' });
      const due = await alerts.due(); const out = []; const t0 = Date.now();
      for (const rule of due.slice(0, 50)) {
        // Sequences run inside this loop now; past 45 s the rest stay due and go first on the next 5-minute tick.
        if (Date.now() - t0 > 45000) { out.push({ id: rule.id, deferred: 'time budget' }); continue; }
        try { out.push({ id: rule.id, account: rule.accountId, ...(await runOneAlert(rule)) }); }
        catch (e) { out.push({ id: rule.id, error: e.message }); await alerts.record(rule.id, { result: { at: new Date().toISOString(), error: e.message } }).catch(() => {}); }
      }
      // Then every wait that came due: claimed one at a time (a second tick can never run it twice), resumed, recorded.
      const resumed = []; const dueWaits = waits ? await waits.due().catch(() => []) : [];
      for (const w of dueWaits.slice(0, 40)) {
        if (Date.now() - t0 > 45000) { resumed.push({ id: w.id, deferred: 'time budget' }); continue; }
        const row = await waits.claim(w.id).catch(() => null); if (!row) continue;
        try { resumed.push({ id: w.id, ...(await resumeWait(row)) }); }
        catch (e) { resumed.push({ id: w.id, error: e.message }); await waits.finish(w.id, { ok: false, outcome: e.message }).catch(() => {}); }
      }
      return json(res, 200, { ok: true, due: due.length, ran: out, waits: { due: dueWaits.length, resumed } });
    }

    // ── DOWNLOADS (2026-11-23) — the Desk Agent helper and its installer. Source: the PRIVATE repo 0nork/0n3-desk; its release
    //    workflow tests, packs and POSTs here with DL_PUBLISH_SECRET, so customers download from 0n3.app and never need GitHub.
    //    Stored in the files bucket under dl/0n3-desk/. GET /desk.sh · /dl/0n3-desk.tgz (latest) · /dl/0n3-desk-<v>.tgz ·
    //    /dl/0n3-desk/latest.json (what the helper's self-update reads).
    if (path === '/api/dl/publish' && method === 'POST') {
      const want = process.env.DL_PUBLISH_SECRET || ''; const got = String(req.headers['x-dl-secret'] || '');
      if (!want || got.length !== want.length || !timingSafeEqual(Buffer.from(got), Buffer.from(want))) return json(res, 401, { error: 'Not allowed.' });
      if (!files) return json(res, 503, { error: 'No file storage on this deployment.' });
      const b = (await readJson(req)) || {};
      if (b.name !== '0n3-desk' || !/^\d+\.\d+\.\d+$/.test(String(b.version || ''))) return json(res, 400, { error: 'name must be 0n3-desk and version x.y.z' });
      const tgz = Buffer.from(String(b.tgz || ''), 'base64'); if (tgz.length < 1000) return json(res, 400, { error: 'tgz missing' });
      const sha = createHash('sha256').update(tgz).digest('hex'); if (b.sha256 && b.sha256 !== sha) return json(res, 400, { error: 'sha256 does not match the upload' });
      // the bucket only takes text/image/pdf/json types, so the tarball is kept as base64 text and decoded on the way out
      await files.put(`dl/0n3-desk/0n3-desk-${b.version}.tgz.b64`, Buffer.from(tgz.toString('base64')), 'text/plain');
      if (b.install) await files.put('dl/0n3-desk/install.sh', Buffer.from(String(b.install), 'base64'), 'text/plain', { fresh: true });
      const latest = { name: '0n3-desk', version: b.version, url: `${hub ? hub.base : 'https://0n3.app'}/dl/0n3-desk-${b.version}.tgz`, sha256: sha, size: tgz.length, notes: String(b.notes || '').slice(0, 4000), publishedAt: new Date().toISOString() };
      await files.put('dl/0n3-desk/latest.json', Buffer.from(JSON.stringify(latest, null, 2)), 'application/json', { fresh: true });
      return json(res, 200, { ok: true, ...latest });
    }
    if ((method === 'GET' || method === 'HEAD') && (path === '/desk.sh' || path.startsWith('/dl/'))) {
      if (!files) return json(res, 404, { error: 'No downloads on this deployment.' });
      const send = (got, type, cache) => { res.statusCode = 200; res.setHeader('Content-Type', type || got.type); res.setHeader('Cache-Control', cache); res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Content-Length', got.buffer.length); return res.end(method === 'HEAD' ? undefined : got.buffer); };
      const latestJson = async () => { const l = await files.get('dl/0n3-desk/latest.json', { fresh: true }); return l ? JSON.parse(l.buffer.toString('utf8')) : null; };
      if (path === '/desk.sh') { const g = await files.get('dl/0n3-desk/install.sh', { fresh: true }); return g ? send(g, 'text/plain; charset=utf-8', 'no-cache') : json(res, 404, { error: 'The installer is not published yet.' }); }
      if (path === '/dl/0n3-desk/latest.json') { const g = await files.get('dl/0n3-desk/latest.json', { fresh: true }); return g ? send(g, 'application/json', 'no-cache') : json(res, 404, { error: 'Nothing published yet.' }); }
      const v = /^\/dl\/0n3-desk-(\d+\.\d+\.\d+)\.tgz$/.exec(path);
      if (path === '/dl/0n3-desk.tgz' || v) {
        const ver = v ? v[1] : (await latestJson())?.version; if (!ver) return json(res, 404, { error: 'Nothing published yet.' });
        const g0 = await files.get(`dl/0n3-desk/0n3-desk-${ver}.tgz.b64`); if (!g0) return json(res, 404, { error: `No version ${ver}.` });
        const g = { buffer: Buffer.from(g0.buffer.toString('utf8'), 'base64') };
        return send(g, 'application/gzip', v ? 'public, max-age=31536000, immutable' : 'no-cache');
      }
      return json(res, 404, { error: 'No such download.' });
    }

    // ── PAGE FILES — pictures and documents an owner uploaded into a page. Public by design (the page is), unguessable by
    //    name (a random prefix per upload), served from storage with the type it was stored with. Sits above the gate.
    const pf = /^\/api\/files\/pages\/([A-Za-z0-9_-]+)\/([A-Za-z0-9_-]+)\/([A-Za-z0-9_.-]+)$/.exec(path);
    if (pf && method === 'GET') {
      if (!files) return json(res, 404, { error: 'No file storage on this deployment.' });
      const got = await files.get(`pages/${pf[1]}/${pf[2]}/${pf[3]}`); if (!got) return json(res, 404, { error: 'No such file.' });
      res.statusCode = 200; res.setHeader('Content-Type', got.type); res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); res.setHeader('Content-Length', got.buffer.length); return res.end(got.buffer);
    }

    // ── INSTALL 0n3 INTO ANY AI — the public half (what exists, the spec, the skill) ──
    const base = hub ? hub.base : 'https://0n3.app';
    // The mobile app's per-sequence install (2026-10-28): "Add to home screen" on a sequence saves THAT sequence as its own
    // icon, opening /m/run/<workspace>/<sequence>. Public and stateless — it only echoes a bounded name, an id pair and an
    // icon that 0n3 itself hosts; the run screen behind it still needs the person's own sign-in.
    if (path === '/api/m/manifest' && method === 'GET') {
      const idOk = (v) => /^[A-Za-z0-9_-]{3,64}$/.test(v || '');
      const ws = url.searchParams.get('ws'), seq = url.searchParams.get('seq');
      const name = String(url.searchParams.get('name') || '0n3').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 30) || '0n3';
      const icon = String(url.searchParams.get('icon') || '');
      const ownIcon = /^https:\/\/(www\.)?0n3\.app\/api\/files\/[A-Za-z0-9/_.-]+$/.test(icon) && !icon.includes('..') ? icon : null;
      const start = idOk(ws) && idOk(seq) ? `/m/run/${ws}/${seq}` : '/m';
      const icons = ownIcon ? [{ src: ownIcon, sizes: '256x256', type: 'image/png', purpose: 'any' }] : [{ src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }, { src: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }];
      res.statusCode = 200; res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8'); res.setHeader('Cache-Control', 'public, max-age=300');
      return res.end(JSON.stringify({ name, short_name: name, id: start, start_url: start, scope: '/', display: 'standalone', background_color: '#fafafa', theme_color: '#fafafa', icons }));
    }
    if (path === '/api/install' && method === 'GET') return json(res, 200, { ok: true, mcp: `${base}/mcp`, clients: INSTALL_CLIENTS });
    if (path === '/api/install/openapi.json' && method === 'GET') return json(res, 200, openapi(base));
    // Public preview of one client's install steps (Downloads page pop-ups): the SAME artifacts /install hands out, with the
    // token left as a placeholder. Signing in on /install?client= mints the real one.
    { const m = method === 'GET' && path.match(/^\/api\/install\/([a-z_]+)\/preview$/);
      if (m) { const c = INSTALL_CLIENTS.find((x) => x.key === m[1]); if (!c) return json(res, 404, { error: `No install client "${m[1]}"` });
        return json(res, 200, { ok: true, client: c, artifacts: artifactsFor(c.key, { base, token: null }) }); } }
    if (path === '/api/install/skill' && method === 'GET') { res.statusCode = 200; res.setHeader('Content-Type', 'text/markdown; charset=utf-8'); res.setHeader('Content-Disposition', 'inline; filename="SKILL.md"'); return res.end(skillMarkdown(base)); }

    /*
      WORKSPACES, THE PUBLIC FACE. A visitor on 0n3.app/w/<slug> or on a
      customer's own domain holds no token, so these two sit above the gate.
      A token, when present, only widens the view to the owner (drafts and
      unverified hosts render for the person who made them, nobody else).
    */
    // 0n3 PAGES, signed links (pages.js): the editor and the preview read and save one page with a link, no login. A view
    // link reads; an edit link (12 h) also saves. The thumbnail answers the editor's screenshot, else a schematic from the JSON.
    const pgm = /^\/api\/pages\/(s|thumb|jobs|run)\/([A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{16,})$/.exec(path);
    if (workspaces && pgm) {
      const [, kind, tok] = pgm; const L = verifyLink(tok);
      if (!L) return json(res, 404, { error: 'This page link is not valid, or it has expired. Ask for a fresh link.' });
      const c = await workspaces.getCanvas(L.account, L.project);
      const pg = c && (c.pages || []).find((x) => x.id === L.page && x.format === 'struktur');
      if (!pg) return json(res, 404, { error: 'This page no longer exists.' });
      // APPS AND PLANS (Mike 2026-11-19): "Share is only for paid subs — yes for free it will [carry 0n3 branding], paid white
      // label." On Free an app runs only for its owner, signed in; a paid owner's app runs for anyone holding its link, with no badge.
      const ownerPlan = async () => { let plan = 'free'; try { plan = (await identityRest.select('profiles', { id: L.account }, 'plan'))[0]?.plan || 'free'; } catch { /* free */ } const lim = limitsFor(plan); const billed = partner ? await partner.crmBilled(L.account).catch(() => false) : false; return { plan: lim.plan, share: !!lim.share || billed, whiteLabel: !!lim.whiteLabel || billed, runsPerMonth: lim.runsPerMonth }; };
      const callerIsOwner = async () => { const t = bearerOf(req); if (!t) return false; const who = await resolveId(t).catch(() => null); return !!who && who.accountId === L.account; };
      if (kind === 'thumb' && method === 'GET') {
        if (pg.thumb && files) { try { const f = await files.get(pg.thumb); if (f) { res.statusCode = 200; res.setHeader('Content-Type', f.type); res.setHeader('Cache-Control', 'public, max-age=120'); res.setHeader('Access-Control-Allow-Origin', '*'); return res.end(f.buffer); } } catch (e) { console.error('[0n3 pages] thumb:', e.message); } }
        res.statusCode = 200; res.setHeader('Content-Type', 'image/svg+xml'); res.setHeader('Cache-Control', 'public, max-age=60'); res.setHeader('Access-Control-Allow-Origin', '*'); return res.end(schematicThumb(pg.site));
      }
      // JOBS ON A PAGE (Mike 2026-11-14: "drag and drop a complete Job onto the page"). The editor lists the account's Jobs with
      // how each shows on a page (jobs.js onPage): a button, a form with the fields the job reads, or a Job whose trigger is not
      // visible and must be connected on the canvas.
      if (kind === 'jobs' && method === 'GET') {
        if (L.scope !== 'edit') return json(res, 403, { error: 'Open the page from its edit link to add Jobs.' });
        const all = await listJobs(workspaces, L.account).catch(() => []);
        return json(res, 200, { ok: true, project: L.project, jobs: all.map((j) => ({ ...j, sameProject: j.project.id === L.project })) });
      }
      // A VISITOR presses a Job's button or sends its form on the published page. No login: the link is the page's address, the
      // OWNER's job runs on the owner's connections, and only a Job block that is ON this page, and visible (button or form),
      // can be started — with only the fields that Job reads. Throttled per visitor and per page.
      if (kind === 'run' && method === 'POST') {
        const b = (await readJson(req)) || {};
        const op = await ownerPlan(); const isOwner = await callerIsOwner();
        res.setHeader('Access-Control-Allow-Origin', '*');
        if (!op.share && !isOwner) return json(res, 403, { error: 'owner_only', message: 'On the Free plan an app runs only for its owner. Sign in to 0n3 as the owner to run it. Sharing an app with other people comes with any paid plan.' });
        if (op.plan === 'free' && usage) { const used = Number((await usage.month(L.account))?.units || 0); if (used >= op.runsPerMonth) return json(res, 402, { error: 'plan_limit', message: `This month's ${op.runsPerMonth} free actions are used up, so it did not run. Any paid plan keeps it running.` }); }
        const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '').split(',')[0].trim();
        const T = (globalThis.__on3PageRuns ||= new Map()); const now = Date.now();
        for (const [k, t] of T) if (now - t.at > 60000) T.delete(k);
        for (const key of [`ip:${ip}`, `pg:${pg.id}`]) { const t = T.get(key) || { at: now, n: 0 }; t.n++; T.set(key, t); if (t.n > (key.startsWith('ip') ? 6 : 60)) return json(res, 429, { error: 'Too many tries in a minute. Wait a moment and send it again.' }); }
        const block = (pg.site?.pages || []).flatMap((x) => x.blocks || []).find((x) => x.type === 'job' && x.id === b.block);
        if (!block) return json(res, 404, { error: 'That is not on this page.' });
        const all = await listJobs(workspaces, L.account).catch(() => []);
        const job = all.find((j) => j.id === block.content?.jobId);
        if (!job) return json(res, 404, { error: 'The Job on this block no longer exists.' });
        const jc = job.project.id === L.project ? c : await workspaces.getCanvas(L.account, job.project.id);
        const q = (jc?.sequences || []).find((x) => x.id === job.id);
        const how = onPage(q);
        if (how.showsAs === 'hidden') return json(res, 400, { error: 'This Job does not start from the page.' });
        const allowed = new Set(how.fields.map((f) => f.name));
        const input = b.input && typeof b.input === 'object' ? b.input : {};
        const payload = Object.fromEntries(Object.entries(input).filter(([k]) => allowed.has(k)).slice(0, 12).map(([k, val]) => [k, String(val ?? '').slice(0, 2000)]));
        for (const f of how.fields) if (f.type === 'email' && payload[f.name] && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload[f.name])) return json(res, 400, { error: `${f.label} does not look like an email address.` });
        payload.source = `page:${pg.name}`;
        const start = (q.nodes || []).find((n) => n.type === 'trigger');
        const actor = `visitor on page "${pg.name}"`;
        const rt = createRuntime({ resolver: new VaultResolver(store, L.account), account: { accountId: L.account }, fetchImpl, audit: (info) => store.audit({ ...info, accountId: L.account, actor }) });
        const ownerDesk = desk ? { create: (o) => desk.create(L.account, { workspaceId: job.project.id, project: o.project, machine: o.machine, source: { ...(o.source || {}), from: actor }, request: o.request }) } : null;
        const runKey = newRunKey();
        const receipt = await runFlow({ server: rt, nodes: q.nodes, edges: q.edges || [], startId: start?.id, payload, fetchImpl, desk: ownerDesk, files: filesFor(L.account), memory: memoryFor(L.account), readWaitMs: 15000, park: parkFor(L.account, { workspaceId: job.project.id, sequence: q, actor }), ai: async (prov) => (router ? { chat: (cc, t) => router.chat(L.account, { provider: prov }, cc, t, { task: 'logic' }) } : { apiKey: null }) });
        await workspaces.recordRun(L.account, job.project.id, { app_key: `job:${job.name}`, inputs: payload, receipt, ok: receipt.complete, actor, run_key: runKey, job_id: job.id, state: receipt.waiting?.length ? 'waiting' : 'done' }).catch(() => {});
        // The visitor sees whether it went through and the Job's Return value (what the owner chose to hand back), never the
        // receipt. The owner also sees what went wrong.
        const went = !!receipt.complete || !!receipt.waiting?.length;
        return json(res, 200, { ok: went, output: went ? appOutput(job, receipt) : null, message: went ? (block.content?.successText || 'Done.') : isOwner && receipt.outcome ? `It did not go through: ${String(receipt.outcome).slice(0, 400)}` : 'That did not go through. Please try again in a moment.' });
      }
      if (kind === 's' && method === 'GET') { res.setHeader('Cache-Control', 'no-store'); res.setHeader('Access-Control-Allow-Origin', '*'); const op = await ownerPlan(); return json(res, 200, { ok: true, id: pg.id, name: pg.name, site: pg.site, canEdit: L.scope === 'edit', expires: L.expires, plan: op.plan, share: op.share, branded: !op.whiteLabel }); }
      if (kind === 's' && method === 'PUT') {
        if (L.scope !== 'edit') return json(res, 403, { error: 'This is a view link. Open the page from its edit link to save.' });
        const b = (await readJson(req)) || {};
        let site; try { site = b.site ? cleanSite(b.site) : pg.site; } catch (e) { return json(res, 400, { error: e.message }); }
        let thumb = pg.thumb;
        if (b.thumb && files) { try { const t = decodeThumb(b.thumb); if (t) { const ext = t.type.split('/')[1].replace('jpeg', 'jpg'); thumb = `${L.account}/pages/${L.project}/${pg.id}.${ext}`; await files.put(thumb, t.buffer, t.type); } } catch (e) { return json(res, 400, { error: e.message }); } }
        let next = { ...c, pages: c.pages.map((x) => (x.id === pg.id ? { ...x, name: b.name ? String(b.name).slice(0, 120) : x.name, site, thumb, updatedAt: Date.now() } : x)) };
        next = wireJobBlocks(next, pg.id, site);
        await workspaces.setCanvas(L.account, L.project, next);
        return json(res, 200, { ok: true, savedAt: new Date().toISOString(), screenshot: !!thumb });
      }
      return json(res, 405, { error: `${method} is not allowed on this link.` });
    }
    if (workspaces && path === '/api/workspaces/public' && method === 'GET') {
      const t = bearerOf(req);
      const acct = t ? await resolveId(t).catch(() => null) : null;
      const v = await workspaces.publicView({ slug: url.searchParams.get('slug') || '', host: url.searchParams.get('host') || '', accountId: acct?.accountId || null, pageId: url.searchParams.get('page') || null });
      if (!v) return json(res, 404, { error: 'No workspace here.' });
      res.setHeader('Cache-Control', 'no-store');
      return json(res, 200, { ok: true, workspace: v });
    }
    // Everything that can be placed on a workspace — mini-apps, the integrated 0n apps, the catalog. Public: it is a catalogue, not an account.
    if (workspaces && path === '/api/apps/catalog' && method === 'GET') return json(res, 200, { ok: true, apps: await workspaces.palette() });
    // First-party: a sibling product (0nTask) lists one person's workspaces by email, the estate's join key.
    if (workspaces && path === '/api/workspaces/lookup' && method === 'GET') {
      if (!firstParty(req)) return json(res, 403, { error: 'First-party only.' });
      const prof = await getProfileByEmail(identityRest, url.searchParams.get('email') || '');
      if (!prof) return json(res, 404, { error: 'No 0n profile for that address.' });
      return json(res, 200, { ok: true, account: prof.id, workspaces: await workspaces.forAccount(prof.id) });
    }

    // A connected app's webhook delivery: authenticated by ITS signature against the person's vault secret, so above the bearer gate.
    if (inbound && method === 'POST' && path.startsWith('/api/hooks/')) {
      const chunks = []; for await (const c of req) chunks.push(c);
      try { const r = await inbound.receive(decodeURIComponent(path.slice('/api/hooks/'.length)), req.headers, Buffer.concat(chunks)); return json(res, r.status, r.body); }
      catch (e) { console.error('[0n3 inbound]', e.message); return json(res, 500, { error: 'could not store the event' }); }
    }
    // APPS sign-in: the browser follows these, so no bearer — the account rides in a signed ten-minute link, then a sealed cookie.
    if (apps && method === 'GET' && (path === '/api/apps/connect' || path === '/api/apps/callback')) {
      try {
        const r = path === '/api/apps/connect' ? await apps.begin(url.searchParams.get('c')) : await apps.finish(req.headers.cookie, url.searchParams);
        if (r.cookie) res.setHeader('Set-Cookie', r.cookie);
        return redirect(res, r.redirect);
      } catch (e) { console.error('[0n3 apps] sign-in:', e.message); return redirect(res, `/apps?error=${encodeURIComponent(e.message.slice(0, 200))}`); }
    }
    const token = bearerOf(req);
    // PLANS (2026-10-29): the public price list, and Stripe's webhook (its own signature, read from the RAW body).
    if (path === '/api/billing/plans' && method === 'GET') return json(res, 200, { ok: true, plans: priceList(), addons: addonList() });
    if (billing && path === '/api/billing/webhook' && method === 'POST') {
      const chunks = []; for await (const c of req) chunks.push(c); const raw = Buffer.concat(chunks).toString('utf8');
      try { const r = await billing.webhook(raw, req.headers['stripe-signature']); return json(res, r.status, r.body); } catch (e) { console.error('[0n3 billing] webhook:', e.message); return json(res, 500, { error: e.message }); }
    }
    // YHL → Kid-Cards CRM (2026-11-23): youthhockeyleagues.com reports events about the SIGNED-IN person only. The
    // bearer is that person's own Supabase access token (shared accounts, pwu); the email comes from Supabase, never the body.
    // YHL public contact form → Kid-Cards CRM (tag yhl:contact + note). hCaptcha (same secret as sign-in) is the gate.
    if (path === '/api/yhl/contact' && method === 'POST') {
      try {
        const b = (await readBody(req)) || {};
        const c = cleanContact(b); if (c.error) return json(res, 400, { error: c.error === 'spam' ? 'Could not send.' : c.error });
        const hv = await fetch('https://api.hcaptcha.com/siteverify', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ secret: process.env.HCAPTCHA_SECRET || '', response: String(b.captcha || '') }), signal: AbortSignal.timeout(6000) }).then((r) => r.json()).catch(() => ({}));
        if (!hv.success) return json(res, 400, { error: 'Tick the box to show you are human, then try again.' });
        const r = await yhlEvent('contact', c);
        return json(res, r.ok ? 200 : 502, r.ok ? { ok: true } : { error: 'Could not send right now. Try again in a minute.' });
      } catch (e) { console.error('[0n3 yhl] contact:', e.message); return json(res, 400, { error: 'Bad request.' }); }
    }
    if (path === '/api/yhl/event' && method === 'POST') {
      try {
        const body = (await readBody(req)) || {};
        if (!['confirmed', 'team-request'].includes(body.event)) return json(res, 400, { error: 'Unknown event.' });
        const ur = await fetch(`${process.env.SUPABASE_URL}/auth/v1/user`, { headers: { apikey: process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY, authorization: `Bearer ${token || ''}` }, signal: AbortSignal.timeout(5000) });
        const u = ur.ok ? await ur.json() : null;
        if (!u?.email) return json(res, 401, { error: 'Sign in first.' });
        if (body.event === 'confirmed' && !u.email_confirmed_at) return json(res, 409, { error: 'Email not confirmed yet.' });
        const note = body.event === 'team-request' ? `Team app request: ${String(body.note || '').slice(0, 600)}` : null;
        const r = await yhlEvent(body.event, { email: u.email, name: u.user_metadata?.full_name || '', note });
        return json(res, r.ok ? 200 : 502, r.ok ? { ok: true } : { error: 'Could not record it.' });
      } catch (e) { console.error('[0n3 yhl] event:', e.message); return json(res, 400, { error: 'Bad request.' }); }
    }
    if (!token) { res.setHeader('WWW-Authenticate', WWW_AUTH(hub ? hub.base : 'https://0n3.app')); return json(res, 401, { error: 'Missing bearer token. Send Authorization: Bearer <your 0n_ token> — find it at 0n3.app/tokens — or connect through OAuth (see /.well-known/oauth-authorization-server).' }); }
    const account = await resolveId(token).catch((e) => { console.error('[0n3] identity:', e.message); return null; });
    if (account && security) security.trust(clientIp).catch(() => {}); // a valid token from here: this address can never be banned
    if (!account && security) { try { if (await decoyAnswer(await security.decoy.inspect({ ip: clientIp, path, token, tokenValid: false, ua: clientUa }))) return; } catch (e) { console.error('[0n3 security] inspect:', e.message); } }
    if (!account) { res.setHeader('WWW-Authenticate', WWW_AUTH(hub ? hub.base : 'https://0n3.app')); return json(res, 401, { error: 'Invalid, expired or revoked 0n token.' }); }
    // A SCOPED API KEY (2026-11-11) reaches /mcp and /api/x/* only, sees only its apps, and (read-only) changes nothing.
    // Checked before every other bearer route, so a limited key can never reach the vault, tokens or settings.
    const keyLim = grantOf(account) ? null : keyLimitsOf(account);
    if (keyLim && !(path === '/mcp' || path.startsWith('/api/x/'))) return json(res, 403, { error: 'insufficient_scope', error_description: `This key is limited${keyLim.apps.length ? ` to ${keyLim.apps.join(', ')}` : ''}${keyLim.read ? ' (read-only)' : ''}. It can use /api/x/* and /mcp only — not ${path}.` });
    if (keyLim && path === '/api/x/crm-ask' && !keyAllows(keyLim, 'crm')) return json(res, 403, { error: 'insufficient_scope', error_description: `This key may use ${keyLim.apps.join(', ')} only — not the CRM.` });
    // Inbound webhooks, the account's own: create a receiving URL for a connection, list them, read what arrived.
    if (inbound && path === '/api/inbound/hooks' && method === 'POST') {
      const b = await readJson(req).catch(() => ({}));
      try { return json(res, 200, { ok: true, hook: await inbound.create(account.accountId, { service: b.service, label: b.label || null, secretService: b.secret_service || null, secretLabel: b.secret_label || null }) }); } catch (e) { return json(res, 400, { error: e.message }); }
    }
    if (inbound && path === '/api/inbound/hooks' && method === 'GET') return json(res, 200, { ok: true, hooks: await inbound.list(account.accountId) });
    if (inbound && path === '/api/inbound/events' && method === 'GET') return json(res, 200, { ok: true, events: await inbound.events(account.accountId, { service: url.searchParams.get('service'), limit: url.searchParams.get('limit') }) });

    // SIGN IN WITH 0n3 (2026-10-28): a token a person granted to an app reaches only what they granted. Identity-only
    // tokens may ask who the person is; app grants may also call /mcp and /api/x/* — with a vault narrowed to the granted apps.
    const grant = grantOf(account);
    if (hub && path === '/oauth/userinfo' && (method === 'GET' || method === 'POST')) { const r = await hub.userinfo(account); return json(res, r.status, r.body); }
    if (grant) {
      // An app grant uses its apps through /api/x/* (where changes wait for approval); /mcp is for full-access AI clients (scope mcp).
      const open = grant.identityOnly ? [] : grant.mcp ? ['/mcp', '/api/x/call', '/api/x/whoami', '/api/x/connections', '/api/x/services', '/api/x/apps'] : ['/api/x/call', '/api/x/whoami', '/api/x/connections', '/api/x/services'];
      const isOpen = open.includes(path) || (!grant.identityOnly && (/^\/api\/x\/services\/[A-Za-z0-9_.-]+$/.test(path) || /^\/api\/x\/approvals\/[0-9a-f-]{36}$/.test(path)));
      if (!isOpen) return json(res, 403, { error: 'insufficient_scope', error_description: `This token was granted for: ${grant.scopes.join(' ')}. It cannot use ${path}.` });
    }
    const narrow = (r) => (grant && !grant.mcp ? new GrantResolver(r, grant.apps) : keyLim?.apps.length ? new GrantResolver(r, keyLim.apps) : r);
    // FEATURE LOCKS (2026-10-29): one helper, one limit table (billing.js). 402 + what lifts it.
    const planCache = { v: undefined };
    const myPlan = async () => { if (planCache.v !== undefined) return planCache.v; try { planCache.v = (await identityRest.select('profiles', { id: account.accountId }, 'plan'))[0]?.plan || 'free'; } catch { planCache.v = 'free'; } return planCache.v; };
    const gate = async (what, used, key) => { if (partner && await partner.crmBilled(account.accountId)) return null; const plan = await myPlan(); const L = limitsFor(plan); const lim = L[key]; if (lim === true || lim === Infinity || (typeof lim === 'number' && used < lim)) return null; return overLimit(plan, what, used, lim === false ? 0 : lim); };
    // Actions this month — the metered unit the plan's allowance is measured in (usage.js); runs as the fallback.
    const runsThisMonth = async () => { if (usage) return Number((await usage.month(account.accountId))?.units || 0); if (!workspaces) return 0; const since = new Date(); since.setUTCDate(1); since.setUTCHours(0, 0, 0, 0); try { return (await identityRest.select('workspace_runs', { account_id: account.accountId }, 'at')).filter((r) => new Date(r.at) >= since).length; } catch { return 0; } };
    // ONBOARDING (2026-10-29, onboard.js): the person's own session only — never an app or AI token.
    if (onboarding && path.startsWith('/api/onboard/')) {
      if (grant || account.scope !== 'master') return json(res, 403, { error: 'Onboarding runs in your own signed-in session.' });
      try {
        if (path === '/api/onboard/state' && method === 'GET') return json(res, 200, { ok: true, ...(await onboarding.state(account.accountId)) });
        if (path === '/api/onboard/business' && method === 'POST') return json(res, 200, { ok: true, ...(await onboarding.business(account.accountId, (await readJson(req)) || {})) });
        if (path === '/api/onboard/google' && method === 'POST') return json(res, 200, { ok: true, ...(await onboarding.google(account.accountId, (await readJson(req)) || {})) });
        if (path === '/api/onboard/finish' && method === 'POST') return json(res, 200, { ok: true, ...(await onboarding.finish(account.accountId, (await readJson(req)) || {})) });
      } catch (e) { return json(res, 400, { error: e.message }); }
    }
    // THE PERSON'S OWN AI KEYS for their own 0n Chrome extension (2026-10-29): the extension's "use the AI you already pay for"
    // sync had pointed at a 0nCore route that never existed. Master token only (the person's own session), never an app or AI token.
    if (path === '/api/vault/ai-keys' && method === 'GET') {
      if (grant || account.scope !== 'master') return json(res, 403, { error: 'Only your own 0n sign-in can read your AI keys.' });
      const want = { openai: 'openai', gemini: 'gemini', google_ai: 'gemini', grok: 'grok', xai: 'grok', groq: 'groq', mistral: 'mistral' };
      const keys = {};
      for (const r of await store.list(account.accountId)) {
        const as = want[r.service]; if (!as || keys[as]) continue;
        const e = await store.get(account.accountId, r.service, r.$0n?.name).catch(() => null);
        const c = e?.auth?.credentials || {}; const k = c.apiKey || c.api_key || c.key || c.token;
        if (k) { keys[as] = k; await store.audit({ accountId: account.accountId, service: r.service, label: r.$0n?.name || null, action: 'read_secret', tool: 'extension-ai-keys', ok: true, actor: account.email || account.accountId }).catch(() => {}); }
      }
      return json(res, 200, { ok: true, keys });
    }
    // NEXT STEPS (2026-10-29): what this account should do next, from its real state.
    if (path === '/api/next-steps' && method === 'GET') {
      const [recs, wsl, machines] = await Promise.all([store.list(account.accountId).catch(() => []), workspaces ? workspaces.list(account.accountId).catch(() => []) : [], desk ? desk.machines(account.accountId).catch(() => []) : []]);
      return json(res, 200, { ok: true, steps: nextSteps({ plan: await myPlan(), services: [...new Set(recs.map((r) => r.service))], workspaces: wsl, runsThisMonth: await runsThisMonth(), deskMachines: machines.length }) });
    }
    if (billing && path === '/api/billing/me' && method === 'GET') return json(res, 200, { ok: true, ...(await billing.me(account.accountId)), plans: priceList(), runsThisMonth: await runsThisMonth() });
    if (billing && path === '/api/billing/checkout' && method === 'POST') { if (grant) return json(res, 403, { error: 'Sign in to 0n3 yourself to change plans.' }); try { const b = (await readJson(req)) || {}; return json(res, 200, { ok: true, ...(await billing.checkout(account, String(b.plan || ''), { flow: b.flow === 'checkout' ? 'checkout' : undefined, addons: b.addons })) }); } catch (e) { return json(res, 400, { error: e.message }); } }
    if (billing && path === '/api/admin/billing/webhooks' && method === 'GET') { if (grant || !hub?.isAdmin(account)) return json(res, 403, { error: 'Admins only.' }); try { const l = await billing.stripe('/webhook_endpoints?limit=100'); return json(res, 200, { ok: true, endpoints: (l.data || []).map((w) => ({ id: w.id, url: w.url, status: w.status, events: (w.enabled_events || []).length, created: new Date(w.created * 1000).toISOString().slice(0, 10), description: w.description || null })) }); } catch (e) { return json(res, 400, { error: e.message }); } }
    if (billing && path === '/api/admin/billing/setup' && method === 'POST') { if (grant || !hub?.isAdmin(account)) return json(res, 403, { error: 'Admins only.' }); try { return json(res, 200, { ok: true, ...(await billing.setup()) }); } catch (e) { return json(res, 400, { error: e.message }); } }
    if (billing && path === '/api/billing/confirm' && method === 'POST') { try { return json(res, 200, { ok: true, ...(await billing.confirm(account, ((await readJson(req)) || {}).session_id)) }); } catch (e) { return json(res, 400, { error: e.message }); } }
    if (billing && path === '/api/billing/portal' && method === 'POST') { if (grant) return json(res, 403, { error: 'Sign in to 0n3 yourself to manage billing.' }); try { return json(res, 200, { ok: true, ...(await billing.portal(account)) }); } catch (e) { return json(res, 400, { error: e.message }); } }
    /*
      ASK BEFORE AI CHANGES ANYTHING (2026-10-29, opt-in per account). A full-access AI client — any token that is not the
      person's own master session and not an app grant (apps are always held at /api/x/call) — has its changes held for
      the person's OK when the switch is on. The approval runs the held change exactly as the AI asked (POST /api/approvals/:id).
    */
    const approvalLookup = async (id) => { if (!hub || !/^[0-9a-f-]{36}$/.test(String(id))) return null; const r = await hub.approval(String(id), { accountId: account.accountId }); return r ? { approval_id: r.id, status: r.status, summary: r.summary, result: r.result ?? null, decided_at: r.decided_at || null } : null; };
    const readOnlyGate = (c) => ({ ok: false, status: 'read_only', error: 'read_only_key', message: `This key is read-only, so it cannot ${String(c.endpoint || c.kind).replace(/_/g, ' ')}${c.service && c.service !== 'app' ? ` in ${c.service}` : ''}. Make a key without "Read only" for changes.` });
    const writeGate = async () => (keyLim?.read ? async (c) => readOnlyGate(c) : aiGate());
    const aiGate = async () => {
      if (!hub || account.scope === 'master' || (grant && !grant.mcp)) return null;
      const st = await hub.settings(account.accountId).catch((e) => { console.error('[0n3] settings:', e.message); return null; });
      if (!st?.ask_ai_writes) return null;
      return async (c) => {
        const who = account.permissions?.client?.name || account.permissions?.tokenName || 'Your AI';
        const svcName = getService(c.service)?.name || c.service;
        const words = String(c.endpoint).replace(/_/g, ' ');
        const what = c.kind === 'app_run' ? `run the app "${words}"` : c.kind === 'mcp_call' ? `use ${words} on ${c.service}` : c.kind === 'crm' ? `${words} in the CRM` : `${words} in ${svcName}`;
        const summary = `${who} wants to ${what}`;
        const row = await hub.holdCall(account, { service: c.service, endpoint: c.endpoint, method: c.method, params: { __kind: c.kind, args: c.args || {}, label: c.label || null }, summary });
        if (desk) await desk.notify(account.accountId, { title: summary, body: 'Tap to approve or decline.', url: '/m', tag: `approval-${row?.id}` }).catch(() => {});
        return { ok: false, status: 'pending_approval', approval_id: row?.id, message: `Held for your OK: "${summary}". Approve or decline it in 0n3 on your phone (Home → requests waiting), then ask me to check approval ${row?.id}.` };
      };
    };

    /*
      A VISITOR RUNS A MINI-APP from a workspace's front end — signed in to
      0n, with THEIR OWN connections. The owner's keys never move on a
      stranger's click; the owner's board is the catalogue, the engine runs
      for whoever pressed the button. Recorded under the workspace with the
      visitor's email as actor, so the owner sees what their board is doing.
    */
    if (workspaces && path === '/api/w/run' && method === 'POST') {
      const b = (await readJson(req)) || {};
      const me = account.accountId; const actor = account.email || me;
      const v = await workspaces.publicView({ slug: b.slug || '', host: b.host || '', accountId: me });
      if (!v) return json(res, 404, { error: 'No workspace here.' });
      const tile = v.tiles.find((t) => t.kind === 'mini' && t.key === b.app);
      if (!tile) return json(res, 400, { error: `"${b.app}" is not on this workspace.` });
      const receipt = await runApp({ resolver: new VaultResolver(store, me), fetchImpl, audit: (info) => store.audit({ ...info, accountId: me, actor }) }, { app: b.app, input: b.input || {}, label: b.label });
      const ok = !receipt.error && receipt.complete !== false;
      const w = await workspaces.bySlug(v.slug);
      if (w) await workspaces.recordRun(w.account_id, w.id, { app_key: b.app, inputs: b.input || {}, receipt, ok, actor });
      return json(res, 200, { ok, receipt });
    }

    // ── INSTALL: mint a token named for the client and hand back its own dialect ──
    const im = /^\/api\/install\/([a-z_]+)$/.exec(path);
    if (im && method === 'POST') {
      const client = installClient(im[1]);
      if (!client) return json(res, 404, { error: `No such client. One of: ${INSTALL_CLIENTS.map((c) => c.key).join(', ')}` });
      let token = null;
      if (!client.oauth || /[?&]mint=1(&|$)/.test(String(req.url || ''))) {
        if (hub) token = (await hub.createToken(account.accountId, { name: `${client.name} · ${new Date().toISOString().slice(0, 10)}`, level: 'full', scopes: ['mcp'] })).token;
        else token = '<your 0n token>';
      }
      return json(res, 200, { ok: true, client, token, artifacts: artifactsFor(client.key, { base: hub ? hub.base : 'https://0n3.app', token }) });
    }

    /*
      THE REST FACADE — seven plain operations over the same runtime tools an
      MCP client gets, for every AI that speaks HTTP but not MCP (GPT Actions,
      agent frameworks, a curl in a cron). One runtime per request, bound to
      this account, audited like any other call.
    */
    if (path.startsWith('/api/x/')) {
      const rt = createRuntime({ resolver: narrow(new VaultResolver(store, account.accountId)), account, fetchImpl, gate: await writeGate(), approvalLookup, audit: (info) => store.audit({ ...info, actor: account.email || account.accountId }) });
      const out = (v) => json(res, 200, v && typeof v === 'object' && !Array.isArray(v) ? { ok: !v.error, ...v } : { ok: true, result: v });
      try {
        if (path === '/api/x/whoami' && method === 'GET') return out(await callTool(rt, 'whoami', {}));
        // ASK THE CRM'S AI (2026-11-10, for the Chrome extension: "can we use the CRM AI functionality?"). The person's CRM
        // Conversation AI is unlimited on the agency plan, so a page question costs nothing. Picks the first PUBLISHED Agent
        // Studio agent on the location when none is named; the agent answers in its own voice.
        if (path === '/api/x/crm-ask' && method === 'POST') {
          const b = (await readJson(req)) || {}; const message = String(b.message || '').trim();
          if (!message) return json(res, 400, { error: 'message is required' });
          const me = account.accountId; const askLoc = String(b.locationId || ''); const askAgent = String(b.agentId || '');
          const text = `${b.system ? `${String(b.system).slice(0, 2000)}\n\n` : ''}${message.slice(0, 12000)}`;
          const credsOf = (env) => ({ key: env?.auth?.credentials?.access_token || env?.auth?.credentials?.pit || env?.auth?.credentials?.token || null, loc: env?.meta?.location_id || env?.auth?.credentials?.location_id || '' });
          const tried = [];
          /** One location: its published Agent Studio agents in order, until one answers. null = nothing here could. */
          const askLocation = async (env, onlyAgent = '') => {
            const { key, loc } = credsOf(env); if (!key || !loc) return null;
            const H = { Authorization: `Bearer ${key}`, Version: '2021-07-28', 'Content-Type': 'application/json', Accept: 'application/json' };
            let agents = [];
            if (onlyAgent) agents = [{ id: onlyAgent }];
            else {
              // the list path from the CRM's own SDK (crm/v3/agent-studio.js): GET /agent-studio/agent?locationId=&isPublished=true → { agents: [...] }
              const r = await fetchImpl(`https://services.leadconnectorhq.com/agent-studio/agent?locationId=${encodeURIComponent(loc)}&isPublished=true&limit=50`, { headers: H });
              const d = await r.json().catch(() => ({}));
              const inner = Array.isArray(d) ? d : d.agents || d.data || d.items || d.results || [];
              agents = (Array.isArray(inner) ? inner : inner?.agents || []).filter((x) => x && (x.id || x._id || x.agentId)).sort((x, y) => Number(y.isPublished === true) - Number(x.isPublished === true)); // the CRM names the field agentId
              if (!agents.length) { tried.push({ location: loc, name: env?.$0n?.name || null, result: `no AI agent (${r.status})` }); return null; }
            }
            for (const ag of agents) {
              const id = String(ag.id || ag._id || ag.agentId);
              const r = await fetchImpl(`https://services.leadconnectorhq.com/agent-studio/agent/${encodeURIComponent(id)}/execute`, { method: 'POST', headers: H, body: JSON.stringify({ locationId: loc, message: text }) });
              const d = await r.json().catch(() => ({}));
              if (r.ok) return { reply: String(d.response ?? d.output ?? d.message ?? d.text ?? d.reply ?? (typeof d === 'string' ? d : JSON.stringify(d))).slice(0, 20000), agentId: id, locationId: loc, name: env?.$0n?.name || null };
              tried.push({ location: loc, name: env?.$0n?.name || null, agentId: id, result: `${r.status}: ${d.message || d.error || 'no detail'}` });
              if (!/publish/i.test(String(d.message || ''))) break; // an unpublished agent → try the next one; anything else → next record
            }
            return null;
          };
          // Which locations: the one asked for; else the one that answered last time; else every CRM record in the vault, newest first.
          let envs = [];
          if (askLoc) { const e = await store.get(me, 'crm', askLoc); if (!e) return json(res, 400, { error: `No CRM connection for location ${askLoc} in your 0n3 vault.` }); envs = [e]; }
          else {
            const remembered = CRM_ASK_CACHE.get(me); if (remembered) { const e = await store.get(me, 'crm', remembered.locationId).catch(() => null); if (e) envs.push(e); }
            const recs = (await store.list(me)).filter((r) => r.service === 'crm');
            for (const r of recs) { const e = await store.get(me, 'crm', r.$0n?.name || r.meta?.location_id || '').catch(() => null); if (e) envs.push(e); }
            // every RECORD, not every location: two records can hold one location with different keys, and only one of them
            // may be allowed to see Agent Studio (measured 2026-11-10: the OAuth record for 0nCore listed no agents, the PIT did)
            const seen = new Set(); envs = envs.filter((e) => { const { loc, key } = credsOf(e); const k = `${loc}|${String(key || '').slice(-10)}`; if (!loc || !key || seen.has(k)) return false; seen.add(k); return true; });
            if (!envs.length) return json(res, 400, { error: 'No CRM connection in your 0n3 vault yet — connect your CRM at 0n3.app/connect.' });
          }
          for (const env of envs) {
            const got = await askLocation(env, askLoc ? askAgent : (CRM_ASK_CACHE.get(me)?.locationId === credsOf(env).loc ? CRM_ASK_CACHE.get(me).agentId : ''));
            if (got) {
              CRM_ASK_CACHE.set(me, { locationId: got.locationId, agentId: got.agentId, at: Date.now() });
              await store.audit({ accountId: me, service: 'crm', label: got.name, action: 'crm_ask', tool: 'extension', ok: true, actor: account.email || me }).catch(() => {});
              return json(res, 200, { ok: true, ...got, tried });
            }
          }
          return json(res, 400, { error: `None of your CRM locations has a published AI agent that could answer. Build one in the CRM's Agent Studio and publish it. Tried: ${tried.map((t) => `${t.name || t.location} — ${t.result}`).join(' · ') || 'nothing'}`, tried });
        }
        if (path === '/api/x/connections' && method === 'GET') return out({ connections: await callTool(rt, 'connections', {}) });
        if (path === '/api/x/services' && method === 'GET') return out({ services: await callTool(rt, 'services', { connected_only: url.searchParams.get('connected_only') === 'true' }) });
        const sm2 = /^\/api\/x\/services\/([A-Za-z0-9_.-]+)$/.exec(path);
        if (sm2 && method === 'GET') return out(await callTool(rt, 'service_info', { service: sm2[1] }));
        // An app (not the person, not a full-access AI client) changing something waits for the person's OK: reads run
        // now; a write is held, pushed to their phone, and runs only when they approve (POST /api/approvals/:id).
        const apm = /^\/api\/x\/approvals\/([0-9a-f-]{36})$/.exec(path);
        if (apm && method === 'GET' && hub) { const r = await hub.approval(apm[1], { accountId: account.accountId, clientId: account.permissions?.client?.id || null }); if (!r) return json(res, 404, { error: 'No such approval.' }); return json(res, 200, { ok: r.status === 'done', status: r.status, result: r.result || null, decided_at: r.decided_at }); }
        if (path === '/api/x/call' && method === 'POST' && keyLim) {
          const b = (await readJson(req)) || {}; if (!b.service || !b.endpoint) return json(res, 400, { error: 'service and endpoint are required' });
          if (!keyAllows(keyLim, b.service)) return json(res, 403, { error: 'insufficient_scope', error_description: `This key may use ${keyLim.apps.join(', ')} only — not ${b.service}.` });
          const ep = getService(b.service)?.endpoints?.[b.endpoint];
          if (keyLim.read && String(ep?.method || 'POST').toUpperCase() !== 'GET') return json(res, 403, { error: 'read_only_key', error_description: `This key is read-only; ${b.endpoint} changes something.` });
          return out(await callTool(rt, 'api_call', { service: b.service, endpoint: b.endpoint, params: b.params || {}, label: b.label }));
        }
        if (path === '/api/x/call' && method === 'POST' && grant && !grant.mcp && hub) {
          const b = (await readJson(req)) || {}; if (!b.service || !b.endpoint) return json(res, 400, { error: 'service and endpoint are required' });
          // An app it was never granted is refused here, before anything is held or pushed to the person.
          if (!new GrantResolver({ list: async () => [], get: async () => null }, grant.apps).allowed(String(b.service))) return json(res, 403, { error: 'insufficient_scope', error_description: `This app was not granted ${b.service}. It may ask for it at sign-in with apps:${b.service}.` });
          const ep = getService(b.service)?.endpoints?.[b.endpoint];
          const m = String(ep?.method || 'POST').toUpperCase();
          const clientId = account.permissions?.client?.id || null;
          if (clientId) {
            // An unreviewed developer app may READ for anyone, but change things only for its own developer.
            const pol = await hub.clientPolicy(clientId);
            if (m !== 'GET' && pol && pol.owner && !pol.reviewed && pol.owner !== account.accountId) return json(res, 403, { error: 'app_not_reviewed', error_description: `${account.permissions?.client?.name || 'This app'} has not been reviewed by 0n3 yet, so it can read but not change anything. Its developer can request a review at 0n3.app/developers.` });
            // A per-person daily cap per app: a runaway or hostile app stops at the cap, not at the person's bill.
            const used = await hub.bumpUsage(account.accountId, clientId, m !== 'GET').catch((e) => { console.error('[0n3] usage:', e.message); return null; });
            const cap = hub.caps();
            if (used && (used.calls > cap.calls || (m !== 'GET' && used.writes > cap.writes))) return json(res, 429, { error: 'daily_cap', error_description: `This app reached today's limit for your account (${m !== 'GET' && used.writes > cap.writes ? `${cap.writes} changes` : `${cap.calls} calls`}). It resets at midnight UTC.`, used, cap });
          }
          if (m !== 'GET') {
            const who = account.permissions?.client?.name || 'An app';
            const summary = `${who} wants to ${String(b.endpoint).replace(/_/g, ' ')} in ${getService(b.service)?.name || b.service}`;
            const row = await hub.holdCall(account, { service: b.service, endpoint: b.endpoint, method: m, params: b.params || {}, summary });
            if (desk) await desk.notify(account.accountId, { title: summary, body: 'Tap to approve or decline.', url: '/m', tag: `approval-${row?.id}` }).catch(() => {});
            return json(res, 202, { ok: false, status: 'pending_approval', approval_id: row?.id, poll: `/api/x/approvals/${row?.id}`, message: 'Waiting for the person to approve this on their phone.' });
          }
          return out(await callTool(rt, 'api_call', { service: b.service, endpoint: b.endpoint, params: b.params || {}, label: b.label }));
        }
        if (path === '/api/x/call' && method === 'POST') { const b = (await readJson(req)) || {}; if (!b.service || !b.endpoint) return json(res, 400, { error: 'service and endpoint are required' }); return out(await callTool(rt, 'api_call', { service: b.service, endpoint: b.endpoint, params: b.params || {}, label: b.label })); }
        if (path === '/api/x/apps' && method === 'GET') return out({ apps: await callTool(rt, 'apps', {}) });
        const am = /^\/api\/x\/apps\/([A-Za-z0-9_-]+)\/run$/.exec(path);
        if (am && method === 'POST') { const b = (await readJson(req)) || {}; return out(await callTool(rt, 'app_run', { app: am[1], input: b.input || {}, label: b.label })); }
      } catch (e) { return json(res, 400, { error: e.message }); }
      return json(res, 404, { error: `No route ${method} ${path}. See ${hub ? hub.base : 'https://0n3.app'}/api/install/openapi.json` });
    }

    // THE AI PAGE: the person's AIs in order (drag-and-drop favourites, or sorted by tokens left / measured strength),
    // today's fuel from each provider's own limit headers, thumbs feedback, and 0n3's own logic test.
    if (router && path.startsWith('/api/ai/') && path !== '/api/ai/key') {
      const me = account.accountId;
      try {
        if (path === '/api/ai/router' && method === 'GET') return json(res, 200, await router.status(me));
        if (path === '/api/ai/router' && method === 'PUT') { await router.setPrefs(me, (await readJson(req)) || {}); return json(res, 200, await router.status(me)); }
        if (path === '/api/ai/plan' && method === 'GET') { const u = new URL(req.url, 'http://x'); return json(res, 200, { ok: true, plan: (await router.plan(me, { task: u.searchParams.get('task') || 'logic' })).map((c) => ({ provider: c.provider, model: c.model })) }); }
        if (path === '/api/ai/models' && method === 'GET') { const u = new URL(req.url, 'http://x'); return json(res, 200, await router.models(me, u.searchParams.get('provider') || '')); }
        if (path === '/api/ai/feedback' && method === 'POST') return json(res, 200, await router.feedback(me, { ...((await readJson(req)) || {}), source: 'person' }));
        if (path === '/api/ai/test' && method === 'POST') { const b = (await readJson(req)) || {}; return json(res, 200, await router.test(me, { providers: Array.isArray(b.providers) ? b.providers : null })); }
      } catch (e) { return json(res, 400, { error: e.message }); }
    }
    // A provider key for the chat, into the person's own vault under the provider's service key. The same record api_call would use.
    if (path === '/api/ai/key' && method === 'POST') {
      const b = (await readJson(req)) || {};
      const p = providerOf(b.provider);
      if (!p) return json(res, 400, { error: `provider must be one of ${Object.keys(PROVIDERS).join(', ')}` });
      if (p.keyless) return json(res, 400, { error: `${p.name} needs no key.` });
      const apiKey = String(b.apiKey || '').trim();
      if (apiKey.length < 8) return json(res, 400, { error: 'That does not look like a key.' });
      try { await store.put(account.accountId, makeConnection({ service: p.service, name: `${p.name.split(' (')[0]} · chat`, credentials: { apiKey } }), { actor: account.email || account.accountId }); }
      catch (e) { return json(res, 400, { error: e.message }); }
      return json(res, 200, { ok: true, service: p.service });
    }

    /** One chat turn on a board, for whoever is signed in: their key, their connections, the board's fence. */
    /*
      Two chat models, by what the board is:
      - a TILE board: whoever chats uses THEIR key and THEIR connections (the board is a catalogue);
      - a CANVAS page (the builder's mini page): the chat box is the OWNER's agent for their customer —
        it runs on the owner's model key and connections, FENCED to the apps and scopes set on that
        element, and the visitor is recorded as the actor. That is the handoff's model: "limited to
        the apps and scopes below."
    */
    const chatOn = async (view, wsRow, b) => {
      const me = account.accountId; const actor = account.email || me;
      const chatNode = view.page ? view.page.nodes.find((n) => n.key === 'chat') : null;
      const ownerMode = !!chatNode;
      const vaultId = ownerMode ? wsRow.account_id : me;
      const ai = ownerMode ? { provider: chatNode.app || 'groq', model: chatNode.values?.model || null } : workspaces.aiOf(view.tiles);
      if (!ai) return json(res, 400, { error: 'This board has no AI yet. Add one from the palette.' });
      const p = providerOf(ai.provider);
      if (!p) return json(res, 400, { error: `Unknown AI "${ai.provider}".` });
      let env = p.keyless ? null : await store.get(vaultId, p.service);
      if (!env && p.service === 'gemini') env = await store.get(vaultId, 'google_ai');
      const apiKey = env ? keyOf(env) : null;
      const rt = createRuntime({ resolver: new VaultResolver(store, vaultId), account: ownerMode ? { accountId: vaultId } : account, fetchImpl, audit: (info) => store.audit({ ...info, accountId: vaultId, actor: ownerMode ? `${actor} via ${view.slug}` : actor }) });
      const thread = await workspaces.thread(wsRow.id, me);
      const history = b.reset ? [] : (thread?.messages || []);
      const fence = ownerMode ? fenceFromAccess(chatNode.access) : workspaces.fenceOf(view.tiles);
      const chatCtx = { server: rt, fence, workspace: { name: view.name, tagline: view.tagline, intro: chatNode ? `You are "${chatNode.values?.title || 'the assistant'}" on this page.` : view.layout?.intro }, account };
      // The board's AI first; on a limit or error the same vault's other AIs, in that person's order (never after a tool ran).
      const turn = router ? await router.chat(vaultId, { provider: ai.provider, model: ai.model }, chatCtx, { history, message: b.message }) : await chatTurn({ provider: ai.provider, model: ai.model, apiKey, fetchImpl }, chatCtx, { history, message: b.message });
      if (turn.error) return json(res, 200, { ok: false, error: ownerMode && turn.missing ? `The owner has not connected a ${turn.missing} key for this page yet.` : turn.error, missing: ownerMode ? null : (turn.missing || null), trace: turn.trace || [], provider: ai.provider });
      const saved = await workspaces.saveThread(wsRow.id, me, { actor, provider: ai.provider, model: turn.model, messages: turn.history, trace: turn.trace });
      return json(res, 200, { ok: true, answer: turn.answer, trace: turn.trace, provider: ai.provider, model: turn.model, turns: saved.turns });
    };
    // A visitor's chat on a live board (or the owner's on any), by slug or host.
    // ── YOUR 0n3 BOT (2026-11-23): the account-wide assistant — the HQ chat box and the `0n3` terminal both talk here. Every
    //    service the person connected and every mini-app, on THEIR AIs in THEIR order (Free only respected), with their bot's
    //    name, tone and rules. Stateless: the caller keeps the history (the terminal keeps it in ~/.0n/bot-history.json).
    if (path === '/api/bot/chat' && method === 'POST') {
      if (!router) return json(res, 503, { error: 'The AI router is not configured on this server.' });
      const me = account.accountId; const b = (await readJson(req)) || {};
      const message = String(b.message || '').slice(0, 20000); if (!message.trim()) return json(res, 400, { error: 'Say something.' });
      const bot = (await hub.settings(me).catch(() => ({}))).bot || null;
      const recs = await store.list(me);
      const fence = { services: [...new Set(recs.map((r) => r.service))], apps: listApps().map((a) => a.key || a.name).filter(Boolean) };
      const rt = createRuntime({ resolver: new VaultResolver(store, me), account, fetchImpl, audit: (info) => store.audit({ ...info, accountId: me, actor: account.email || me }) });
      const chatCtx = { server: rt, fence, workspace: { name: bot?.name || '0n3 Bot', tagline: 'Your own assistant on 0n3, working across every app you connected.', intro: botIntro(bot) }, account };
      const history = Array.isArray(b.history) ? b.history.slice(-40) : [];
      const turn = await router.chat(me, null, chatCtx, { history, message });
      if (turn.error) return json(res, 200, { ok: false, error: turn.error, missing: turn.missing || null, tried: turn.tried || [] });
      return json(res, 200, { ok: true, bot: bot?.name || '0n3 Bot', answer: turn.answer, trace: turn.trace || [], history: turn.history, provider: turn.provider, model: turn.model, free: !!turn.free });
    }
    if (workspaces && path === '/api/w/chat') {
      const b = method === 'GET' ? Object.fromEntries(url.searchParams) : ((await readJson(req)) || {});
      const v = await workspaces.publicView({ slug: b.slug || '', host: b.host || '', accountId: account.accountId, pageId: b.page || null });
      if (!v) return json(res, 404, { error: 'No workspace here.' });
      const w = await workspaces.bySlug(v.slug);
      if (method === 'GET') { const t = await workspaces.thread(w.id, account.accountId); const cn = v.page ? v.page.nodes.find((n) => n.key === 'chat') : null; return json(res, 200, { ok: true, ai: cn ? { provider: cn.app, model: cn.values?.model || null } : workspaces.aiOf(v.tiles), messages: t?.messages || [], turns: t?.turns || 0 }); }
      if (method === 'DELETE') { await workspaces.clearThread(w.id, account.accountId); return json(res, 200, { ok: true }); }
      if (method === 'POST') { if (!String(b.message || '').trim()) return json(res, 400, { error: 'Say something.' }); return chatOn(v, w, b); }
      return json(res, 405, { error: 'GET, POST or DELETE' });
    }

    // A PAGE BUTTON pressed by a signed-in visitor: the OWNER's flow runs on the owner's connections, fenced to the apps
    // and scopes set on that button, with the form's fields as the trigger payload and the visitor as actor.
    if (workspaces && path === '/api/w/flow' && method === 'POST') {
      const b = (await readJson(req)) || {};
      const v = await workspaces.publicView({ slug: b.slug || '', host: b.host || '', accountId: account.accountId, pageId: b.page || null });
      if (!v || !v.page) return json(res, 404, { error: 'No page here.' });
      const btn = v.page.nodes.find((n) => n.key === 'button' && n.id === b.button);
      if (!btn) return json(res, 400, { error: 'That button is not on this page.' });
      const w = await workspaces.bySlug(v.slug);
      const canvas = await workspaces.getCanvas(w.account_id, w.id);
      const fl = flowForButton(canvas, v.page.id, btn);
      if (!fl) return json(res, 200, { ok: false, error: `Nothing is attached to "${btn.values?.label || 'this button'}" yet. On the board, attach a sequence to it.` });
      const start = fl.start;
      const actor = `${account.email || account.accountId} via ${v.slug}`;
      const rt = createRuntime({ resolver: new VaultResolver(store, w.account_id), account: { accountId: w.account_id }, fetchImpl, audit: (info) => store.audit({ ...info, accountId: w.account_id, actor }) });
      const payload = Object.fromEntries(Object.entries(b.payload && typeof b.payload === 'object' ? b.payload : {}).slice(0, 40).map(([k, val]) => [String(k).slice(0, 40), typeof val === 'string' ? val.slice(0, 4000) : val]));
      payload.actor = account.email || null;
      // A terminal step on the OWNER's flow becomes a run on the OWNER's desk; the visitor who pressed the button is named as the source.
      const ownerDesk = desk ? { create: (o) => desk.create(w.account_id, { workspaceId: w.id, project: o.project, machine: o.machine, source: { ...(o.source || {}), from: account.email || undefined }, request: o.request }) } : null;
      const receipt = await runFlow({ server: rt, nodes: fl.nodes, edges: fl.edges, startId: start.id, payload, access: btn.access || {}, fetchImpl, desk: ownerDesk, park: parkFor(w.account_id, { workspaceId: w.id, sequence: fl.sequence, actor, access: btn.access || {} }), ai: async (prov) => (router ? { chat: (c, t) => router.chat(w.account_id, { provider: prov }, c, t, { task: 'logic' }) } : { apiKey: await (async () => { const p = providerOf(prov); const env = p && !p.keyless ? await store.get(w.account_id, p.service) : null; return env ? keyOf(env) : null; })() }) });
      await workspaces.recordRun(w.account_id, w.id, { app_key: `flow:${start.title || start.key}`, inputs: payload, receipt, ok: receipt.complete, actor });
      return json(res, 200, { ok: receipt.complete, receipt: { ...receipt, steps: receipt.steps.map((s) => ({ step: s.step, state: s.state, detail: s.detail })) } });
    }

    /*
      THE DESK — runs that can wait. The desktop agent (the mail poller on the owner's machine today) creates runs from
      requests, CLAIMS queued ones for its machine, asks and finishes; the phone answers. Everything is on the owner's
      own token; the actor is recorded on every entry.
    */
    /*
      THE CANVAS CHAT (2026-10-31) — an Excalidraw board + the person's own local AI. A question asked on the board is an
      ordinary desk run (source.kind 'canvas'), so the desk agent works it unchanged; the board polls /runs for the thread.
      The linked spreadsheet (Google Sheets or OneDrive Excel) is the record: every request, note and reply lands there.
    */
    // The sites a canvas can work on. A person may keep nothing locally (Mike, 2026-11-03): offer their GitHub repos
    // from the github connection in their vault; the desk agent clones what it does not have.
    if (path === '/api/sites/github/repos' && method === 'GET') {
      const me = account.accountId;
      const env = await store.get(me, 'github').catch(() => null);
      const tok = env?.auth?.credentials?.token || env?.auth?.credentials?.access_token || env?.auth?.credentials?.apiKey || null;
      if (!tok) return json(res, 200, { ok: true, connected: false, repos: [] });
      try {
        const r = await fetchImpl('https://api.github.com/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member', { headers: { Authorization: `Bearer ${tok}`, Accept: 'application/vnd.github+json', 'User-Agent': '0n3' } });
        if (!r.ok) return json(res, 200, { ok: true, connected: true, repos: [], error: `GitHub answered ${r.status}` });
        const list = (await r.json()).map((x) => ({ fullName: x.full_name, url: x.html_url, defaultBranch: x.default_branch, private: !!x.private, homepage: x.homepage || null, updatedAt: x.pushed_at || x.updated_at }));
        return json(res, 200, { ok: true, connected: true, repos: list });
      } catch (e) { return json(res, 200, { ok: true, connected: true, repos: [], error: e.message }); }
    }

    if (canvas && (path === '/api/canvas' || path.startsWith('/api/canvas/'))) {
      const me = account.accountId; const actor = account.email || me;
      try {
        if (path === '/api/canvas' && method === 'GET') return json(res, 200, { ok: true, boards: await canvas.list(me) });
        if (path === '/api/canvas' && method === 'POST') { const b = (await readJson(req)) || {}; return json(res, 200, { ok: true, board: await canvas.create(me, { title: b.title }) }); }
        const cm = /^\/api\/canvas\/([A-Za-z0-9_-]{3,})(?:\/(sheet|ask|runs|describe|sequence|restore))?$/.exec(path);
        if (cm) {
          const [, bid, act] = cm;
          if (act === 'restore' && method === 'POST') { const bd = await canvas.restore(me, bid); return bd === null ? json(res, 404, { error: 'No such board.' }) : bd === false ? json(res, 400, { error: 'There is no earlier drawing to put back.' }) : json(res, 200, { ok: true, board: bd }); }
          if (!act && method === 'GET') { const bd = await canvas.get(me, bid); return bd ? json(res, 200, { ok: true, board: bd }) : json(res, 404, { error: 'No such board.' }); }
          if (!act && method === 'PUT') { const b = (await readJson(req)) || {}; const bd = await canvas.update(me, bid, { title: b.title, scene: b.scene }); return bd ? json(res, 200, { ok: true, board: bd }) : json(res, 404, { error: 'No such board.' }); }
          if (!act && method === 'DELETE') return (await canvas.remove(me, bid)) ? json(res, 200, { ok: true }) : json(res, 404, { error: 'No such board.' });
          if (act === 'runs' && method === 'GET') { if (!(await canvas.row(me, bid))) return json(res, 404, { error: 'No such board.' }); return json(res, 200, { ok: true, runs: desk ? await desk.forBoard(me, bid) : [] }); }
          if (act === 'sheet' && method === 'POST') {
            if (grant) return json(res, 403, { error: 'Sign in to 0n3 yourself to link a spreadsheet.' });
            const b = (await readJson(req)) || {}; const provider = String(b.provider || '');
            if (!SHEET_PROVIDERS.includes(provider)) return json(res, 400, { error: 'provider must be google or microsoft.' });
            const row = await canvas.row(me, bid); if (!row) return json(res, 404, { error: 'No such board.' });
            if (row.sheet?.id) return json(res, 200, { ok: true, existing: true, sheet: { provider: row.sheet.provider, id: row.sheet.id, url: row.sheet.url } });
            try {
              const made = await sheetBusFor(me, provider).create(row.title, { shareWith: account.email || null });
              const sheet = { ...made, created_at: new Date().toISOString(), pending: [], flushed: {} };
              await canvas.setSheet(me, bid, sheet);
              await store.audit({ accountId: me, service: provider === 'google' ? 'google_sheets' : 'microsoft', label: null, action: 'canvas_sheet_create', tool: 'canvas', ok: true, actor }).catch(() => {});
              return json(res, 200, { ok: true, sheet: { provider, id: made.id, url: made.url } });
            } catch (e) { console.error(`[SHEET MIRROR FAILED] create ${provider} for board ${bid}: ${e.message}`); return json(res, 400, { error: e.message }); }
          }
          // DESCRIBE IT, ON THE BOARD (0nCanvas, 2026-11-09): the person says what to draw; one of THEIR AIs (their order, or the
          // one they picked) answers; the answer is checked (canvas.js parseDescribe) and the board draws it — a Mermaid
          // diagram, a 0n3 sequence as blocks and wires, a page wireframe, or free shapes. The desk brain goes through /ask instead.
          if (act === 'describe' && method === 'POST') {
            const row = await canvas.row(me, bid); if (!row) return json(res, 404, { error: 'No such board.' });
            const b = (await readJson(req)) || {}; const prompt = String(b.prompt || '').trim();
            if (!prompt) return json(res, 400, { error: 'Say what to draw.' });
            const kind = DESCRIBE_KINDS.includes(b.kind) ? b.kind : 'diagram';
            const prefer = b.provider && b.provider !== 'auto' && providerOf(b.provider) ? b.provider : null;
            const system = describeSystemPrompt(kind);
            const prior = kind === 'sequence' && b.prior && typeof b.prior === 'object' && Array.isArray(b.prior.nodes) ? b.prior : null;
            const user = prior
              ? `CURRENT SEQUENCE (JSON): ${JSON.stringify({ name: prior.name, nodes: (prior.nodes || []).slice(0, 30).map((n) => ({ type: n.type, key: n.key, title: n.title, app: n.app, values: n.values })), edges: (prior.edges || []).slice(0, 40).map((e) => ({ from: (prior.nodes || []).findIndex((n) => n.id === e.from), to: (prior.nodes || []).findIndex((n) => n.id === e.to), port: e.port || 0, ...(e.wait ? { wait: e.wait } : {}) })) }).slice(0, 6000)}\n\nCHANGE REQUEST: ${prompt}`
              : `${prompt}${b.sceneText ? `\n\nAlready on the board (draw beside it, do not repeat it):\n${String(b.sceneText).slice(0, 3000)}` : ''}`;
            // A small model often answers with nothing drawable (measured 2026-11-10: "no usable blocks" twice from the same AI).
            // So: walk the person's AIs in THEIR order, up to three, until one answers with something that passes the check;
            // the error names what each one did.
            let out = null; let r = null; const tried = [];
            const plan = router ? await router.plan(me, { task: 'json', prefer }) : [];
            if (plan.length) {
              for (const c of plan.slice(0, 3)) {
                out = await router.complete(me, { system, user }, { task: 'json', only: c.provider });
                if (out.error) { tried.push(`${providerOf(c.provider)?.name || c.provider}: ${out.error}`); continue; }
                r = parseDescribe(kind, out.text); if (!r.error) break;
                tried.push(`${providerOf(c.provider)?.name || c.provider}: ${r.error}`); r = null;
              }
            } else {
              let ai = null;
              for (const prov of prefer ? [prefer] : ['groq', 'cerebras', 'gemini', 'openai', 'anthropic']) { const p = providerOf(prov); if (!p) continue; let env = p.keyless ? null : await store.get(me, p.service); if (!env && p.service === 'gemini') env = await store.get(me, 'google_ai'); if (p.keyless || env) { ai = { provider: prov, apiKey: env ? keyOf(env) : null }; break; } }
              if (!ai) return json(res, 400, { error: 'Connect an AI first (Groq, Gemini, OpenAI or Claude with your own key) — or switch to "The AI on my computer".', missing: 'ai' });
              for (let i = 0; i < 2 && !r; i++) { out = await completeOnce({ ...ai, system, user, fetchImpl }); if (out.error) { tried.push(`${providerOf(ai.provider)?.name || ai.provider}: ${out.error}`); break; } r = parseDescribe(kind, out.text); if (r.error) { tried.push(`${providerOf(ai.provider)?.name || ai.provider}: ${r.error}`); r = null; } }
            }
            if (!r) return json(res, 400, { error: `Your AI did not answer with something drawable. ${tried.join(' · ') || 'No AI answered.'} Try saying it more plainly, or pick another AI under More options.`, tried });
            // ONE CORRECTION TURN when the answer plainly dropped something that was asked for (a text, an email, a wait, a
            // branch, the CRM step). Same AI, the sequence it drew, and the list of what is missing; kept only if it is better.
            let corrected = false;
            if (kind === 'sequence' && r.sequence) {
              const miss = missingFromSequence(prompt, r.sequence);
              if (miss.length) {
                const q0 = r.sequence; const idx = (id) => q0.nodes.findIndex((n) => n.id === id);
                const user2 = `CURRENT SEQUENCE (JSON): ${JSON.stringify({ name: q0.name, nodes: q0.nodes.map((n) => ({ type: n.type, key: n.key, title: n.title, app: n.app, values: n.values })), edges: q0.edges.map((e) => ({ from: idx(e.from), to: idx(e.to), port: e.port || 0, ...(e.wait ? { wait: e.wait } : {}) })) }).slice(0, 6000)}\n\nCHANGE REQUEST: The person asked for: "${prompt.slice(0, 1200)}". The sequence above is missing: ${miss.join('; ')}. Add each one in the right place, wire every block in order, and return the FULL sequence.`;
                let out2 = null;
                try { out2 = plan.length ? await router.complete(me, { system, user: user2 }, { task: 'json', only: out.provider }) : null; } catch { out2 = null; }
                const r2 = out2 && !out2.error ? parseDescribe(kind, out2.text) : null;
                if (r2 && !r2.error && r2.sequence && missingFromSequence(prompt, r2.sequence).length < miss.length && r2.sequence.nodes.length >= q0.nodes.length) { r = { ...r2, questions: r2.questions.length ? r2.questions : r.questions, suggest: r2.suggest.length ? r2.suggest : r.suggest }; corrected = true; }
              }
            }
            await store.audit({ accountId: me, service: out.provider || prefer || 'ai', label: null, action: `canvas_describe_${kind}`, tool: 'canvas', ok: true, actor }).catch(() => {});
            return json(res, 200, { ok: true, kind, provider: out.provider || prefer || null, model: out.model || null, ...(corrected ? { corrected: true } : {}), ...r });
          }
          // SAVE WHAT IS DRAWN AS A SEQUENCE: the board's blocks and wires become (or replace) a sequence in a workspace, so the
          // same test run, waits and automations the builder has apply to it. The drawing stays the source; this is a copy of it.
          if (act === 'sequence' && method === 'POST') {
            if (!workspaces) return json(res, 503, { error: 'Workspaces are not configured on this server.' });
            if (!(await canvas.row(me, bid))) return json(res, 404, { error: 'No such board.' });
            const b = (await readJson(req)) || {}; const wid = String(b.workspaceId || ''); const q = b.sequence;
            if (!wid || !q || !Array.isArray(q.nodes) || !q.nodes.length) return json(res, 400, { error: 'Pick a workspace and draw at least one block.' });
            const c = await workspaces.getCanvas(me, wid); if (!c) return json(res, 404, { error: 'No such workspace.' });
            if (c.v !== 2) return json(res, 400, { error: 'Open this workspace in the builder once first, then save here.' });
            const sid = String(q.id || '').slice(0, 24) || newId(); const isNew = !c.sequences.some((x) => x.id === sid);
            if (isNew) { const all = await workspaces.list(me); const total = all.reduce((n, w) => n + (w.sequences || 0), 0) + 1; const g = await gate('sequences', total - 1, 'sequences'); if (g) return json(res, 402, g); }
            const seqs = c.sequences.filter((x) => x.id !== sid); const idx = c.sequences.findIndex((x) => x.id === sid);
            seqs.splice(idx === -1 ? seqs.length : idx, 0, { id: sid, name: String(q.name || 'Drawn sequence').slice(0, 120), nodes: q.nodes, edges: Array.isArray(q.edges) ? q.edges : [] });
            const items = c.board.items.some((i) => i.kind === 'seq' && i.ref === sid) ? c.board.items : [...c.board.items, { id: newId(), kind: 'seq', ref: sid, x: 576, y: 128 + c.board.items.filter((i) => i.kind === 'seq').length * 248, w: 336, h: 200 }];
            const saved = await workspaces.setCanvas(me, wid, { ...c, sequences: seqs, board: { ...c.board, items } });
            let automations = null; if (alerts) { try { automations = await alerts.syncSequences(me, wid, saved.sequences || []); } catch (e) { automations = { error: e.message }; } }
            return json(res, 200, { ok: true, workspaceId: wid, sequenceId: sid, created: isNew, sequences: saved.sequences.length, automations });
          }
          if (act === 'ask' && method === 'POST') {
            if (!desk) return json(res, 503, { error: 'The desk is not configured on this server.' });
            const row = await canvas.row(me, bid); if (!row) return json(res, 404, { error: 'No such board.' });
            const b = (await readJson(req)) || {}; const message = String(b.message || '').trim();
            if (!message) return json(res, 400, { error: 'Type a message to ask.' });
            const selection = cleanSelection(b.selection); const sceneText = String(b.sceneText || '').slice(0, 8000);
            // WHAT POWERS THIS MESSAGE (Mike, 2026-11-03: "an option to choose what powers Excalidraw and the chat"):
            //   desk      — the person's own desktop AI (Claude Code on their computer), the only brain that can BUILD; default
            //   crm       — their CRM's Agent Studio agent (unlimited on the agency plan), answers in the thread, cannot touch a repo
            //   openai|groq|gemini|anthropic — a model under the person's OWN key in the vault, answers in the thread
            // WHICH SITE: `site` = { name, folder, crmLocation?, agentId? } — remembered by the page, carried on the run so the desk
            // agent works in that folder (if that computer allows it) and the CRM brain talks to that site's location.
            const brain = String(b.brain || 'desk'); const site = b.site && typeof b.site === 'object' ? { name: String(b.site.name || '').slice(0, 80), url: String(b.site.url || '').slice(0, 300), repo: String(b.site.repo || '').replace(/[^A-Za-z0-9_.\-\/]/g, '').slice(0, 140), folder: String(b.site.folder || '').slice(0, 300), crmLocation: String(b.site.crmLocation || '').slice(0, 40), agentId: String(b.site.agentId || '').slice(0, 80) } : null;
            // Only the DESK brain is a plan feature (Starter and up). A brain under the person's OWN key, or their CRM agent, is theirs
            // on every plan — measured 2026-11-04: a Free account with a Groq key in its vault was refused 'no desk agent' here.
            if (brain === 'desk') { const g = await gate('desk agent', 0, 'desk'); if (g) return json(res, 402, g); }
            const desks = workspaces ? await workspaces.deskConfigs(me).catch(() => []) : [];
            // Among this person's desks, prefer one on a machine that is online right now (measured 2026-11-09: the first desk
            // alphabetically pointed at a folder that was not on the Mac, and every canvas ask was refused).
            const onlineMachines = new Set((await desk.machines(me).catch(() => [])).filter((m) => Date.now() - Date.parse(m.lastSeenAt || 0) < 90000).map((m) => m.name || m.machine));
            // A site that names its own folder or repo never borrows another desk's folder.
            const dk = desks.find((d) => d.workspace === b.workspace) || desks.find((d) => (site?.name || b.project) && d.project === (site?.name || b.project)) || ((site?.folder || site?.repo) ? null : (desks.find((d) => d.machine && onlineMachines.has(d.machine)) || desks[0])) || null;
            const project = site?.name || dk?.project || b.project || null;
            const source = { kind: 'canvas', from: actor, subject: row.title, boardId: row.id, selection, sceneText, brain, ...(site ? { site: site.name, url: site.url, repo: site.repo, folder: site.folder || (site.repo ? '' : dk?.folder || '') } : {}) };
            const run = await desk.create(me, { workspaceId: dk?.workspace || null, project, machine: b.machine || dk?.machine || null, source, request: askRequest(site ? `[Site: ${site.name}${site.url ? ` · ${site.url}` : ''}${site.repo ? ` · GitHub ${site.repo}` : ''}${site.folder ? ` · folder ${site.folder}` : ''}]\n${message}` : message, selection, sceneText) });
            await mirrorEvent(me, run, { kind: 'request', text: message, from: actor, status: 'queued' }, { final: true });
            if (brain === 'desk') return json(res, 200, { ok: true, run });
            // Immediate brains: answer now, close the run with the reply so the thread, the board and the sheet record all work unchanged.
            const sys = `You are the website and marketing assistant for ${project || 'this person'} on 0n3. Answer plainly. If the request is a CHANGE to a site, say what you would change and that only their desktop AI can apply it (they can switch the brain to "Your desktop AI" to have it done). ${sceneText ? `What is on their board:\n${sceneText.slice(0, 4000)}` : ''}`;
            let reply = '', ok = true;
            try {
              if (brain === 'crm') {
                const loc = site?.crmLocation || b.crmLocation || ''; const agentId = site?.agentId || b.agentId || '';
                const env = loc ? await store.get(me, 'crm', loc) : await store.get(me, 'crm');
                const key = env?.auth?.credentials?.access_token || env?.auth?.credentials?.pit || env?.auth?.credentials?.token || null;
                if (!key) throw new Error(`No CRM connection${loc ? ` for location ${loc}` : ''} in your vault.`);
                if (!agentId) throw new Error('Pick the CRM agent for this site (Agent Studio → a PUBLISHED agent id).');
                const locId = loc || env?.meta?.location_id || '';
                const r = await fetchImpl(`https://services.leadconnectorhq.com/agent-studio/agent/${encodeURIComponent(agentId)}/execute`, { method: 'POST', headers: { Authorization: `Bearer ${key}`, Version: '2021-07-28', 'Content-Type': 'application/json' }, body: JSON.stringify({ locationId: locId, message: `${sys}\n\n${message}` }) });
                const d = await r.json().catch(() => ({}));
                if (!r.ok) throw new Error(`CRM agent: ${d.message || r.status}`);
                reply = String(d.response ?? d.output ?? d.message ?? d.text ?? d.reply ?? (typeof d === 'string' ? d : JSON.stringify(d))).slice(0, 20000);
              } else {
                if (brain !== 'auto' && !providerOf(brain)) throw new Error(`Unknown brain "${brain}".`);
                const args = { system: `${sys}\nReply as JSON: {"reply": "<your answer in plain text>"}`, user: message };
                // "auto" = the person's AI order; a named brain goes first and the rest of their AIs catch a limit or error.
                const out = router ? await router.complete(me, args, { task: 'logic', prefer: brain === 'auto' ? null : brain })
                  : await (async () => { const p = providerOf(brain); let env = p.keyless ? null : await store.get(me, p.service); if (!env && p.service === 'gemini') env = await store.get(me, 'google_ai'); const { complete } = await import('./chat.js'); return complete({ provider: brain, apiKey: env ? keyOf(env) : null, ...args, fetchImpl }); })();
                if (out.error) throw new Error(out.error);
                try { reply = String(JSON.parse(out.text).reply || out.text); } catch { reply = String(out.text || ''); }
              }
            } catch (e) { reply = e.message; ok = false; }
            const done = await desk.finish(me, run.id, { reply, ok }, `brain:${brain}`);
            await mirrorEvent(me, done, { kind: 'receipt', text: reply, from: `brain:${brain}`, status: ok ? 'done' : 'failed' }, { final: true });
            return json(res, 200, { ok: true, run: done });
          }
        }
      } catch (e) { return json(res, 400, { error: e.message }); }
      return json(res, 404, { error: `No route ${method} ${path}` });
    }

    if (desk && (path.startsWith('/api/desk') || path.startsWith('/api/push'))) {
      const me = account.accountId; const actor = account.email || me;
      const bad = (e) => json(res, 400, { error: e.message });
      try {
        if (path === '/api/push/subscribe' && method === 'POST') { const b = (await readJson(req)) || {}; return json(res, 200, await desk.subscribe(me, b.subscription || b, String(req.headers['user-agent'] || ''))); }
        if (path === '/api/push/subscribe' && method === 'DELETE') { const b = (await readJson(req)) || {}; return json(res, 200, await desk.unsubscribe(me, b.endpoint)); }
        if (path === '/api/push/phones' && method === 'GET') return json(res, 200, { ok: true, phones: await desk.phones(me) });
        if (path === '/api/push/test' && method === 'POST') return json(res, 200, { ok: true, ...(await desk.notify(me, { title: '0n3', body: 'Alerts are on. Questions from your desk will land here.', url: '/alerts', tag: 'test' })) });
        if (path === '/api/desk/alerts' && method === 'GET') return json(res, 200, { ok: true, ...(await desk.alerts(me)) });
        if (path === '/api/desk/config' && method === 'GET') { const desks = workspaces ? await workspaces.deskConfigs(me) : []; return json(res, 200, { ok: true, desks, signature: signFor('config', desks) }); }
        if (path === '/api/desk/runs' && method === 'GET') return json(res, 200, { ok: true, runs: await desk.list(me, { state: url.searchParams.get('state') || null, limit: Number(url.searchParams.get('limit')) || 50 }) });
        if (path === '/api/desk/runs' && method === 'POST') { const g = await gate('desk agent', 0, 'desk'); if (g) return json(res, 402, g); }
        if (path === '/api/desk/runs' && method === 'POST') {
          const b = (await readJson(req)) || {};
          // Files ride along as base64 in the same JSON (phones downscale first). They are validated BEFORE the run
          // exists, stored under the owner's account, and recorded on the run as metadata only.
          // an ASK carries a batch of small photos for the desktop AI to read (CardFlow: up to 25 card fronts at 768 px)
          const uploads = decodeUploads(b.files, b.source?.kind === 'ask' ? ASK_MAX_FILES : undefined);
          if (uploads.length && !files) return json(res, 503, { error: 'File storage is not configured on this server.' });
          let run = await desk.create(me, { workspaceId: b.workspace || null, project: b.project, machine: b.machine, source: b.source || {}, request: b.request });
          if (uploads.length) {
            const stored = [];
            for (const f of uploads) stored.push({ name: f.name, type: f.type, ...(await files.put(`${me}/${run.id}/${f.name}`, f.data, f.type)) });
            run = await desk.attach(me, run.id, stored) || run;
          }
          return json(res, 200, { ok: true, run });
        }
        // The poll is the heartbeat: every ask for work records the machine as seen (agent + version when the CLI says them).
        if (path === '/api/desk/next' && method === 'GET') { const mach = url.searchParams.get('machine') || ''; if (mach) await desk.seen(me, mach, { agent: url.searchParams.get('agent'), version: url.searchParams.get('version') }).catch(() => {}); return json(res, 200, { ok: true, runs: await desk.next(me, mach, { compute: url.searchParams.get('compute') === '1' }) }); }
        if (path === '/api/desk/hello' && method === 'POST') { const b = (await readJson(req)) || {}; if (!b.machine) return json(res, 400, { error: 'machine is required' }); return json(res, 200, { ok: true, machine: await desk.seen(me, b.machine, { agent: b.agent, version: b.version, caps: b.caps || null }) }); }
        if (path === '/api/desk/machines' && method === 'GET') return json(res, 200, { ok: true, machines: await desk.machines(me), onlineWithinMs: 90000 });
        const fm = /^\/api\/desk\/runs\/([A-Za-z0-9_-]{3,})\/files\/([\w.-]{1,120})$/.exec(path);
        if (fm && method === 'GET') {
          const r = await desk.get(me, fm[1]); if (!r) return json(res, 404, { error: 'No such run.' });
          const meta = (r.source?.files || []).find((f) => f.name === fm[2]); if (!meta || !files) return json(res, 404, { error: 'No such file on this run.' });
          const got = await files.get(meta.path); if (!got) return json(res, 404, { error: 'The file is gone from storage.' });
          res.statusCode = 200; res.setHeader('Content-Type', got.type || meta.type); res.setHeader('Content-Length', String(got.buffer.length)); res.setHeader('Cache-Control', 'private, max-age=0'); return res.end(got.buffer);
        }
        const rm = /^\/api\/desk\/runs\/([A-Za-z0-9_-]{3,})(?:\/(claim|note|ask|done))?$/.exec(path);
        if (rm) {
          const [, rid, act] = rm; const b = method === 'GET' ? {} : ((await readJson(req)) || {});
          if (!act && method === 'GET') { const r = await desk.get(me, rid); return r ? json(res, 200, { ok: true, run: r }) : json(res, 404, { error: 'No such run.' }); }
          if (act === 'claim' && method === 'POST') { const r = await desk.claim(me, rid, b.machine || ''); return r ? json(res, 200, { ok: true, run: r, signature: r.claimed ? signFor('claim', r) : null }) : json(res, 404, { error: 'No such run.' }); }
          // A canvas run's notes, questions and reply are mirrored into the board's spreadsheet — never failing the call.
          if (act === 'note' && method === 'POST') { const r = await desk.note(me, rid, b.text || '', b.by || 'agent'); if (r) await mirrorEvent(me, r, { kind: 'note', text: b.text || '' }); return r ? json(res, 200, { ok: true, run: r }) : json(res, 404, { error: 'No such run.' }); }
          if (act === 'ask' && method === 'POST') { const r = await desk.ask(me, rid, { text: b.text, options: b.options || [] }, b.by || 'agent'); if (r) await mirrorEvent(me, r.run, { kind: 'question', text: `${b.text || ''}${(b.options || []).length ? ` [${b.options.join(' | ')}]` : ''}` }, { final: true }); return r ? json(res, 200, { ok: true, ...r }) : json(res, 404, { error: 'No such run.' }); }
          if (act === 'done' && method === 'POST') {
            let reply = b.reply || ''; let receipt = b.receipt || null;
            // The AI drawing back: a ```0n3-canvas block leaves the reply text and becomes receipt.canvas for the board to draw.
            const pre = canvas ? await desk.get(me, rid) : null;
            if (pre?.source?.kind === 'canvas') { const x = extractCanvas(reply); reply = x.text; if (x.elements || x.mermaid || x.sequence) receipt = { ...(receipt && typeof receipt === 'object' ? receipt : {}), ...(x.elements ? { canvas: x.elements } : {}), ...(x.mermaid ? { mermaid: x.mermaid } : {}), ...(x.sequence ? { sequence: x.sequence } : {}) }; }
            const r = await desk.finish(me, rid, { receipt, reply, ok: b.ok !== false }, b.by || 'agent');
            const drew = [receipt?.canvas ? `${receipt.canvas.length} element(s)` : '', receipt?.mermaid ? 'a diagram' : '', receipt?.sequence ? `the sequence "${receipt.sequence.name}"` : ''].filter(Boolean).join(', ');
            if (r) await mirrorEvent(me, r, { kind: 'reply', text: `${b.ok === false ? '[did not finish] ' : ''}${reply}${drew ? `\n[drew ${drew} on the board]` : ''}` }, { final: true });
            return r ? json(res, 200, { ok: true, run: r }) : json(res, 404, { error: 'No such run.' });
          }
        }
        const qm = /^\/api\/desk\/questions\/([A-Za-z0-9_-]{3,})\/answer$/.exec(path);
        if (qm && method === 'POST') { const b = (await readJson(req)) || {}; const r = await desk.answer(me, qm[1], { answer: b.answer }, actor); return r ? json(res, 200, { ok: true, ...r }) : json(res, 404, { error: 'No such question.' }); }
      } catch (e) { return bad(e); }
      return json(res, 404, { error: `No route ${method} ${path}` });
    }

    // ── automated alerts on the 0n token ─────────────────────────────────
    if (alerts && path.startsWith('/api/alerts')) {
      const me = account.accountId;
      const connected = async () => [...new Set((await store.list(me)).map((r) => r.service))];
      if (path === '/api/alerts/parse' && method === 'POST') { const b = (await readJson(req)) || {}; return json(res, 200, { ok: true, ...parseAlert(b.text, { connected: await connected(), email: account.email || '' }) }); }
      if (path === '/api/alerts/rules' && method === 'GET') return json(res, 200, { ok: true, rules: await alerts.list(me) });
      // What a sequence can start from by itself: the app events 0n3 can watch and the schedules it keeps (the phone's picker).
      if (path === '/api/alerts/options' && method === 'GET') { const have = new Set(await connected()); return json(res, 200, { ok: true, events: APP_EVENTS().map((e) => ({ ...e, connected: have.has(e.service) })), schedules: Object.entries(SCHEDULES).map(([k, v]) => ({ key: k, label: v.label, at: !!v.at })) }); }
      if (path === '/api/alerts/rules' && method === 'POST') {
        const b = (await readJson(req)) || {};
        const p = b.rule && typeof b.rule === 'object' ? { ok: true, rule: b.rule } : parseAlert(b.text, { connected: await connected(), email: account.email || '' });
        if (!p.ok) return json(res, 400, { error: p.error, hint: p.hint });
        if (!p.rule.watch?.key || !p.rule.action?.kind) return json(res, 400, { error: 'A rule needs a watch and an action.' });
        const rule = await alerts.create(me, { ...p.rule, text: b.text || p.rule.text });
        return json(res, 200, { ok: true, rule, warning: p.warning || null });
      }
      const am = /^\/api\/alerts\/rules\/([A-Za-z0-9_-]{3,})(?:\/(run))?$/.exec(path);
      if (am) {
        const [, rid, act] = am; const rule = await alerts.get(me, rid); if (!rule) return json(res, 404, { error: 'No such alert.' });
        if (act === 'run' && method === 'POST') return json(res, 200, { ok: true, result: await runOneAlert({ ...rule, accountId: me }), rule: await alerts.get(me, rid) });
        if (!act && method === 'PATCH') return json(res, 200, { ok: true, rule: await alerts.update(me, rid, (await readJson(req)) || {}) });
        if (!act && method === 'DELETE') return json(res, 200, { ok: (await alerts.remove(me, rid)) });
      }
      return json(res, 404, { error: `No route ${method} ${path}` });
    }

    // ── JOBS on the 0n token (2026-11-12) ────────────────────────────────
    // A Job = a stored sequence. GET /api/jobs lists them numbered; POST /api/jobs/:job/run runs one and hands back its OUTPUT
    // (the Return block's value, else the last step's) with the receipt; {"wait": false} answers 202 with a run id at once and
    // GET /api/jobs/runs/:runId reads it. :job is the number ("12"), the id or the name. Same engine, same run history, same plan
    // allowance as Run on the canvas. jobsFor() is the ONE runner: these routes and the job_* mini-apps (any AI on /mcp) use it.
    const jobsFor = (acct) => {
      const me = acct.accountId; const actor = acct.email || me;
      const list = () => listJobs(workspaces, me);
      const find = async (ref) => findJob(await list(), ref);
      const get = async (runId) => { const row = await workspaces.getRun(me, runId); if (!row) return { error: 'No such run on this account.' }; const job = (await list()).find((x) => x.id === row.job_id) || null; return { run: runView(row, job) }; };
      const runs = async (ref, limit = 10) => { const f = await find(ref); if (f.error) return f; return { job: f.job, runs: (await workspaces.jobRuns(me, f.job.id, Math.min(50, limit))).map((r) => runView(r, f.job)) }; };
      const run = async (ref, { input = {}, wait = true, dry = false, start: startRef = null } = {}) => {
        const f = await find(ref); if (f.error) return { status: 404, error: f.error };
        const job = f.job;
        if (!dry) { const g = await gate('runs this month', await runsThisMonth(), 'runsPerMonth'); if (g) return { status: 402, ...g }; }
        const c = await workspaces.getCanvas(me, job.project.id);
        const q = (c?.sequences || []).find((x) => x.id === job.id);
        if (!q) return { status: 404, error: `Job #${job.no} is no longer in "${job.project.name}".` };
        const flow = (q.nodes || []).filter((n) => n.type !== 'shape');
        const start = startRef ? flow.find((n) => n.id === startRef) : (flow.find((n) => n.type === 'trigger') || flow[0]);
        if (!start) return { status: 400, error: startRef ? 'That start step is not in this Job. Nothing ran.' : `Job #${job.no} has no blocks to run.` };
        const payload = input && typeof input === 'object' ? input : {};
        const runKey = newRunKey();
        const rt = createRuntime({ resolver: new VaultResolver(store, me), account: acct, fetchImpl, audit: (info) => store.audit({ ...info, actor }) });
        const myDesk = desk ? { create: (o) => desk.create(me, { workspaceId: job.project.id, project: o.project, machine: o.machine, source: { ...(o.source || {}), from: acct.email || undefined }, request: o.request }) } : null;
        const go = () => runFlow({ server: rt, nodes: q.nodes, edges: q.edges || [], startId: start.id, payload, fetchImpl, desk: myDesk, dry, files: filesFor(me), reader: readerFor(me, q.name), memory: memoryFor(me), readWaitMs: wait === false ? 250000 : 60000, park: dry ? null : parkFor(me, { workspaceId: job.project.id, sequence: q, actor }), ai: async (prov) => (router ? { chat: (cc, t) => router.chat(me, { provider: prov }, cc, t, { task: 'logic' }) } : { apiKey: null }) });
        const label = `job:#${job.no} ${job.name}`;
        if (wait === false) {
          await workspaces.recordRun(me, job.project.id, { app_key: label, inputs: payload, receipt: { startedAt: new Date().toISOString(), dry }, ok: false, actor, run_key: runKey, job_id: job.id, state: 'running', output: null });
          const work = go().then((rc) => workspaces.finishRun(me, runKey, { receipt: rc, ok: rc.complete }))
            .catch((e) => workspaces.finishRun(me, runKey, { receipt: { outcome: `The run stopped: ${e.message}`, steps: [], output: null }, ok: false }).catch(() => {}));
          // Keep the function alive until the run is written (Vercel's request context; a plain server just carries on).
          try { globalThis[Symbol.for('@vercel/request-context')]?.get?.()?.waitUntil?.(work); } catch { /* not on Vercel */ }
          return { status: 202, ok: true, runId: runKey, state: 'running', job: { no: job.no, id: job.id, name: job.name }, poll: `/api/jobs/runs/${runKey}` };
        }
        const rc = await go();
        const state = rc.waiting?.length ? 'waiting' : 'done';
        await workspaces.recordRun(me, job.project.id, { app_key: label, inputs: payload, receipt: rc, ok: rc.complete, actor, run_key: runKey, job_id: job.id, state }).catch(() => {});
        return { status: 200, ok: !!rc.complete, ...runView({ run_key: runKey, job_id: job.id, state, ok: rc.complete, receipt: rc, output: rc.output, at: rc.startedAt }, job) };
      };
      return { list, find, run, get, runs };
    };
    if (workspaces && (path === '/api/jobs' || path.startsWith('/api/jobs/'))) {
      const J = jobsFor(account);
      if (path === '/api/jobs' && method === 'GET') return json(res, 200, { ok: true, jobs: await J.list() });
      const rm = /^\/api\/jobs\/runs\/(run_[a-z0-9]{6,40})$/.exec(path);
      if (rm && method === 'GET') { const r = await J.get(rm[1]); return r.error ? json(res, 404, r) : json(res, 200, { ok: true, ...r }); }
      const jm = /^\/api\/jobs\/([^/]{1,140})(?:\/(run|runs))?$/.exec(path);
      if (!jm) return json(res, 404, { error: `No route ${method} ${path}` });
      const ref = decodeURIComponent(jm[1]);
      if (!jm[2] && method === 'GET') { const f = await J.find(ref); return f.error ? json(res, 404, f) : json(res, 200, { ok: true, job: f.job, run: { method: 'POST', url: `/api/jobs/${f.job.no}/run`, body: { input: { '…': 'arrives in the Job as {{trigger.…}}' }, wait: true } } }); }
      if (jm[2] === 'runs' && method === 'GET') { const r = await J.runs(ref, Number(url.searchParams.get('limit')) || 10); return r.error ? json(res, 404, r) : json(res, 200, { ok: true, ...r }); }
      if (jm[2] !== 'run' || method !== 'POST') return json(res, 405, { error: `No route ${method} ${path}` });
      const b = (await readJson(req)) || {};
      const { status, ...out } = await J.run(ref, { input: b.input ?? b.payload ?? {}, wait: b.wait !== false, dry: b.dry === true, start: b.start || null });
      return json(res, status, out);
    }

    // ── workspaces on the 0n token ──────────────────────────────────────
    // THE BUILD SCREEN (2026-11-14, Mike: "a chat box, an app list, a connected app list … the AI builds the entire job, the
    // pages, the entire workflow, saves it to a project"). One message → plan (which apps, a job, a page) → the job drafted
    // against the apps this account has connected → the page written as a 0n3 Pages site → both saved to one project, on its
    // board. Answers what is missing (apps to connect) in the same breath. Running is the existing flow/run.
    if (workspaces && path === '/api/build' && method === 'POST') {
      const me = account.accountId;
      const b = (await readJson(req)) || {};
      const message = String(b.message || '').trim().slice(0, 4000);
      if (!message) return json(res, 400, { error: 'Say what you want to build.' });
      let ai = router ? { provider: 'auto', run: (a) => router.complete(me, a, { task: 'json' }) } : null;
      if (ai && !(await router.plan(me, { task: 'json' })).length) ai = null;
      if (!ai) for (const prov of ['groq', 'openai', 'gemini', 'anthropic']) { const p = providerOf(prov); if (!p) continue; let env = p.keyless ? null : await store.get(me, p.service); if (!env && p.service === 'gemini') env = await store.get(me, 'google_ai'); if (p.keyless || env) { ai = { provider: prov, apiKey: env ? keyOf(env) : null }; break; } }
      if (!ai) return json(res, 400, { error: 'Connect an AI first (Groq is free) so I can build for you.', missing: 'ai' });
      const ask = async (system, user) => { const out = ai.run ? await ai.run({ system, user }) : await completeOnce({ provider: ai.provider, apiKey: ai.apiKey, system, user, fetchImpl, maxTokens: 6000 }); if (out.error) throw new Error(out.error); return out.text || ''; };
      const recs = await store.list(me).catch(() => []);
      const connected = [...new Set(recs.map((r) => r.service))];
      const nameOfSvc = (k) => (SERVICE_CATALOG[k] && SERVICE_CATALOG[k].name) || k;
      try {
        // Names people read: "stripe_payment" / "DogGroomLanding" → "Stripe payment" / "Dog Groom Landing".
        const plain = (t) => { const x = String(t || '').trim(); if (!x || /\s/.test(x)) return x; const w = x.replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim(); return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase().replace(/\b(crm|ai|sms|seo)\b/g, (m) => m.toUpperCase()); };
        const planSys = `You plan a build in 0n3. Answer ONE JSON object and nothing else: {"reply":"<one or two plain sentences to the person about what you are building>","projectName":"<2 to 4 plain words with spaces, e.g. Dog Grooming Site>","job":true|false,"page":true|false,"apps":["<service keys the job needs>"],"question":"<ONLY if you truly cannot build without an answer; else empty>"}. A job is an automation (something that happens by itself or when a button is pressed); a page is a web page people visit. The person's connected apps: ${connected.join(', ') || 'none'}. All service keys: ${Object.keys(SERVICE_CATALOG).join(', ')}. Prefer apps they already connected; when they need a kind of app they have not connected, name the most likely service key.`;
        const plan = parseSpec(await ask(planSys, message)) || {};
        if (plan.question && !plan.job && !plan.page) return json(res, 200, { ok: true, reply: String(plan.question), ask: true, connected });
        // The project: the one named, else a new one.
        let projectId = b.projectId || null; let projectName = '';
        if (projectId) { const w = await workspaces.get(me, projectId); if (!w) return json(res, 404, { error: 'No such project.' }); projectName = w.name; }
        else { const g = await gate('workspaces', (await workspaces.list(me)).length, 'workspaces'); if (g) return json(res, 402, g); const w = await workspaces.create(me, { name: plain(plan.projectName || 'New project').slice(0, 80) }); projectId = w.id; projectName = w.name; }
        const c = await workspaces.getCanvas(me, projectId);
        if (c.v !== 2 && (c.nodes || []).length) return json(res, 409, { error: 'That project uses the older canvas. Start a new project for this build.' });
        const rid = () => Math.random().toString(36).slice(2, 10);
        const pages = [...(c.pages || [])]; const sequences = [...(c.sequences || [])]; const items = [...((c.board && c.board.items) || [])];
        let job = null; let page = null; let jobError = null;
        // A job is attempted unless the plan says page-only; a failed draft is retried once and then SAID, never dropped silently.
        if (plan.job !== false || !plan.page) {
          const hint = `${message}\n\nBuild EXACTLY the steps described above, in order, including any wait ("the day before", "2 days later") as a wait on the line. Do not add steps the person did not ask for; never add a charge or payment unless they asked for one. For each step use an app they have connected when one fits (${connected.join(', ') || 'none'}); otherwise use the app the step needs (for a text message: twilio) even though it is not connected yet — they will be asked to connect it.`;
          let r = await draftSpec({ kind: 'sequence', prompt: hint, brand: projectName.split(' ')[0] || 'Acme', ai, fetchImpl, sequences: sequences.map((q) => q.name) });
          if (!(r.ok && r.sequence && r.sequence.nodes.length)) r = await draftSpec({ kind: 'sequence', prompt: hint, brand: projectName.split(' ')[0] || 'Acme', ai, fetchImpl, sequences: sequences.map((q) => q.name) });
          if (!(r.ok && r.sequence && r.sequence.nodes.length)) jobError = r.error || 'The job could not be drafted. Say it again with the steps in order.';
          if (r.ok && r.sequence && r.sequence.nodes.length) {
            const q = { id: 'q' + rid(), name: plain(r.sequence.name) || 'New job', nodes: r.sequence.nodes, edges: r.sequence.edges || [] };
            sequences.push(q); items.push({ id: 'bi' + rid(), kind: 'seq', ref: q.id, x: 420, y: 60 + items.length * 30, w: 336, h: 200, text: q.name });
            const start = (q.nodes.find((n) => n.isStart) || q.nodes.find((n) => n.type === 'trigger') || q.nodes[0]).id;
            job = { id: q.id, name: q.name, nodes: q.nodes, edges: q.edges, start, steps: q.nodes.map((n) => ({ id: n.id, title: n.title || n.key, type: n.type, app: n.app || null, appName: n.app ? nameOfSvc(n.app) : null })), questions: r.questions || [] };
          }
        }
        if (plan.page) {
          const site = cleanSite(parseSpec(await ask(SITE_SYSTEM, message)));
          const pid = 'pg' + rid();
          pages.push({ id: pid, name: String(site.title || 'New page').slice(0, 120), format: 'struktur', site, nodes: [], edges: [], updatedAt: Date.now() });
          items.push({ id: 'bi' + rid(), kind: 'page', ref: pid, x: 60, y: 60 + items.length * 30, w: 280, h: 200, text: site.title });
          page = { id: pid, name: site.title, ...linksFor({ base: hub ? hub.base : 'https://0n3.app', account: me, project: projectId, page: pid }) };
        }
        if (!job && !page) return json(res, 200, { ok: true, reply: plan.reply || 'I could not turn that into a job or a page. Say what should happen, and when.', ask: true, connected });
        await workspaces.setCanvas(me, projectId, { ...c, v: 2, pages, sequences, board: { items, links: (c.board && c.board.links) || [] } });
        // Missing = apps the job's own steps use and this account has not connected (the planner's guesses are not steps).
        const need = [...new Set(job ? job.steps.map((s) => s.app).filter(Boolean) : [])];
        const missing = need.filter((k) => !connected.includes(k) && SERVICE_CATALOG[k]).map((k) => ({ key: k, name: nameOfSvc(k) }));
        return json(res, 200, { ok: true, reply: (plan.reply || 'Built.') + (jobError ? ` (The job did not come out: ${jobError})` : ''), project: { id: projectId, name: projectName }, job, page, missing, connected, jobError });
      } catch (e) { return json(res, 502, { error: `The build did not finish: ${e.message}` }); }
    }
    // OUTREACH — the AI designer (outreach.js): the kinds, and a project's designs. A design made here is saved in the project
    // beside its pages and jobs; a job makes them with its "Design it (Outreach)" step; the board shows them as cards.
    if (path === '/api/outreach' && method === 'GET') return json(res, 200, { ok: true, kinds: kindsList(), image: { drawn: false, providers: ['openai', 'stability', 'replicate'], note: 'Pictures are described (imagePrompt) until an image model is wired in.' } });
    const orm = workspaces && /^\/api\/workspaces\/([A-Za-z0-9_-]{3,})\/(outreach|wiring)(?:\/([A-Za-z0-9_-]{2,24}))?$/.exec(path);
    if (orm) {
      const me = account.accountId; const [, wid, what, sub] = orm;
      const w = await workspaces.get(me, wid); if (!w) return json(res, 404, { error: 'No such project.' });
      const c = await workspaces.getCanvas(me, wid);
      if (what === 'wiring') {
        if (method === 'GET' && !sub) return json(res, 200, { ok: true, ...wiring(c) });
        // Give a line its condition: { el } = the page element (form, button, Job block) whose action starts the job.
        if (method === 'PATCH' && sub) {
          const b = (await readJson(req)) || {}; const wr = wiring(c); const line = wr.lines.find((l) => l.id === sub);
          if (!line) return json(res, 404, { error: 'No such line on this board.' });
          if (b.el && !(wr.choices[line.from] || []).some((x) => x.el === b.el)) return json(res, 400, { error: 'That page has no such form or button.', choices: wr.choices[line.from] || [] });
          await workspaces.setCanvas(me, wid, { ...c, board: { ...c.board, links: c.board.links.map((l) => (l.id === sub ? { ...l, el: b.el || '', auto: false } : l)) } });
          return json(res, 200, { ok: true, ...wiring(await workspaces.getCanvas(me, wid)) });
        }
        return json(res, 405, { error: 'GET the wiring, or PATCH /wiring/<line> with { el }.' });
      }
      const list = c.outreach || [];
      if (method === 'GET' && !sub) return json(res, 200, { ok: true, designs: list.map(designSummary) });
      if (method === 'GET' && sub) { const d = list.find((x) => x.id === sub); return d ? json(res, 200, { ok: true, design: d }) : json(res, 404, { error: 'No such design.' }); }
      if (method === 'DELETE' && sub) { await workspaces.setCanvas(me, wid, { ...c, outreach: list.filter((x) => x.id !== sub), board: { ...c.board, items: (c.board?.items || []).filter((i) => !(i.kind === 'outreach' && i.ref === sub)) } }); return json(res, 200, { ok: true }); }
      if (method === 'POST' && !sub) {
        if (c.v !== 2) return json(res, 409, { error: 'That project uses the older canvas. Start a new project for designs.' });
        const b = (await readJson(req)) || {}; const kind = String(b.kind || '').toLowerCase();
        if (!OUTREACH_KINDS[kind]) return json(res, 400, { error: `Say which design: ${Object.keys(OUTREACH_KINDS).join(', ')}.` });
        let pr; try { pr = promptFor(kind, { brand: w.name, ...(b.input || b) }, { color: w.brand?.color }); } catch (e) { return json(res, 400, { error: e.message }); }
        let ai = router ? { run: (a) => router.complete(me, a, { task: 'json' }) } : null;
        if (ai && !(await router.plan(me, { task: 'json' })).length) ai = null;
        if (!ai) for (const prov of ['groq', 'openai', 'gemini', 'anthropic']) { const p = providerOf(prov); if (!p) continue; let env = p.keyless ? null : await store.get(me, p.service); if (!env && p.service === 'gemini') env = await store.get(me, 'google_ai'); if (p.keyless || env) { ai = { provider: prov, apiKey: env ? keyOf(env) : null }; break; } }
        if (!ai) return json(res, 400, { error: 'Connect an AI first (Groq is free) so Outreach can design.', missing: 'ai' });
        try {
          const outp = ai.run ? await ai.run({ system: pr.system, user: pr.user }) : await completeOnce({ provider: ai.provider, apiKey: ai.apiKey, system: pr.system, user: pr.user, fetchImpl, maxTokens: 6000 });
          if (outp.error) throw new Error(outp.error);
          const d = shapeDesign(kind, outp.text || '', b.input || b);
          const items = [...(c.board?.items || [])];
          if (b.board !== false) items.push({ id: 'bi' + Math.random().toString(36).slice(2, 10), kind: 'outreach', ref: d.id, x: 60 + (items.length % 4) * 320, y: 520 + Math.floor(items.length / 4) * 240, w: 280, h: 200, text: d.name });
          await workspaces.setCanvas(me, wid, { ...c, outreach: [...list, d], board: { ...(c.board || {}), items, links: c.board?.links || [] } });
          return json(res, 200, { ok: true, design: d });
        } catch (e) { return json(res, 502, { error: `Outreach did not finish: ${e.message}` }); }
      }
      return json(res, 405, { error: `No route ${method} ${path}` });
    }
    if (workspaces && path.startsWith('/api/workspaces')) {
      const me = account.accountId; const actor = account.email || me;
      const bad = (e) => json(res, 400, { error: e.message });
      if (path === '/api/workspaces' && method === 'GET') return json(res, 200, { ok: true, workspaces: await workspaces.list(me) });
      if (path === '/api/workspaces' && method === 'POST') { const g = await gate('workspaces', (await workspaces.list(me)).length, 'workspaces'); if (g) return json(res, 402, g); try { return json(res, 200, { ok: true, workspace: await workspaces.create(me, (await readJson(req)) || {}) }); } catch (e) { return bad(e); } }
      const wm = /^\/api\/workspaces\/([A-Za-z0-9_-]{3,})(?:\/(apps|run|domains|chat|canvas|flow|draft|duplicate|upload|waits|pages|app-from-job)(?:\/([^/]+)(?:\/(verify|links))?)?)?$/.exec(path);
      if (!wm) return json(res, 404, { error: `No route ${method} ${path}` });
      const [, id, sub, arg, action] = wm;
      if (!sub) {
        if (method === 'GET') { const w = await workspaces.get(me, id); return w ? json(res, 200, { ok: true, workspace: w }) : json(res, 404, { error: 'No such workspace.' }); }
        if (method === 'PATCH') { try { const w = await workspaces.update(me, id, (await readJson(req)) || {}); return w ? json(res, 200, { ok: true, workspace: w }) : json(res, 404, { error: 'No such workspace.' }); } catch (e) { return bad(e); } }
        if (method === 'DELETE') return (await workspaces.remove(me, id)) ? json(res, 200, { ok: true }) : json(res, 404, { error: 'No such workspace.' });
      }
      // What is waiting on a line in this workspace, and cancelling one before it is due.
      if (sub === 'waits') {
        if (!waits) return json(res, 503, { error: 'Waiting runs are not configured on this deployment.' });
        if (!(await workspaces.get(me, id))) return json(res, 404, { error: 'No such workspace.' });
        if (!arg && method === 'GET') return json(res, 200, { ok: true, waits: await waits.list(me, id) });
        if (arg && method === 'DELETE') { const w = await waits.cancel(me, arg); return w ? json(res, 200, { ok: true, wait: w }) : json(res, 404, { error: 'No such wait.' }); }
        return json(res, 405, { error: 'GET, or DELETE /waits/<id>' });
      }
      if (sub === 'apps' && method === 'PUT') { try { const b = (await readJson(req)) || {}; const apps = await workspaces.setApps(me, id, b.apps || b, { arrange: !!b.arrange }); return apps ? json(res, 200, { ok: true, apps }) : json(res, 404, { error: 'No such workspace.' }); } catch (e) { return bad(e); } }
      // A picture or document for a page: decoded and bounded like a desk upload, stored under the workspace, handed back as a
      // public URL the page element keeps. Browsers downscale photos first (the body cap is 4.5 MB).
      if (sub === 'upload' && method === 'POST') {
        if (!files) return json(res, 503, { error: 'File storage is not configured on this deployment.' });
        const w = await workspaces.get(me, id); if (!w) return json(res, 404, { error: 'No such workspace.' });
        try {
          const b = (await readJson(req)) || {}; const [f] = decodeUploads([{ name: b.name, type: b.type, data: b.data }]);
          const name = `${randomBytes(5).toString('hex')}-${f.name}`;
          const stored = await files.put(`pages/${me}/${id}/${name}`, f.data, f.type);
          return json(res, 200, { ok: true, file: { name: f.name, type: f.type, size: stored.size, url: `${hub ? hub.base : 'https://0n3.app'}/api/files/pages/${me}/${id}/${name}` } });
        } catch (e) { return bad(e); }
      }
      if (sub === 'duplicate' && method === 'POST') { try { const w = await workspaces.duplicate(me, id, (await readJson(req)) || {}); return w ? json(res, 200, { ok: true, workspace: w }) : json(res, 404, { error: 'No such workspace.' }); } catch (e) { return bad(e); } }
      if (sub === 'run' && method === 'POST') { const g = await gate('runs this month', await runsThisMonth(), 'runsPerMonth'); if (g) return json(res, 402, g); }
      if (sub === 'run' && method === 'POST') {
        const w = await workspaces.get(me, id);
        if (!w) return json(res, 404, { error: 'No such workspace.' });
        const b = (await readJson(req)) || {};
        const tile = w.apps.find((t) => t.kind === 'mini' && t.app_key === b.app);
        if (!tile) return json(res, 400, { error: `"${b.app}" is not a mini-app on this workspace.` });
        const resolver = new VaultResolver(store, me);
        const receipt = await runApp({ resolver, fetchImpl, audit: (info) => store.audit({ ...info, accountId: me, actor }) }, { app: b.app, input: { ...(tile.config?.defaults || {}), ...(b.input || {}) }, label: b.label });
        const ok = !receipt.error && receipt.complete !== false;
        await workspaces.recordRun(me, id, { app_key: b.app, inputs: b.input || {}, receipt, ok, actor });
        return json(res, 200, { ok, receipt });
      }
      // 0n3 PAGES (pages.js): the project's drag-and-drop pages. Create from the builder's JSON (an AI writes it from plain
      // words), list with a thumbnail + preview + edit link each, read, update, delete, and mint fresh links.
      // MAKE IT AN APP (Domino's button): the app in this project that already holds the Job, else a new one-section app.
      if (sub === 'app-from-job' && method === 'POST') {
        const base = hub ? hub.base : 'https://0n3.app';
        const b = (await readJson(req)) || {};
        const c = await workspaces.getCanvas(me, id); if (!c) return json(res, 404, { error: 'No such project.' });
        if (c.v !== 2) return json(res, 409, { error: 'This project uses the older canvas. Open it on 0n3.app/canvas once, then make the app.' });
        const job = (await listJobs(workspaces, me)).find((j) => j.id === b.jobId && j.project.id === id);
        if (!job) return json(res, 404, { error: 'Save the job first, then make it an app.' });
        const L = (pid) => linksFor({ base, account: me, project: id, page: pid });
        const fresh = (await workspaces.getCanvas(me, id)) || c; // listJobs may have just numbered the job and saved
        const have = appHolding(fresh.pages, job.id);
        if (have) return json(res, 200, { ok: true, existed: true, page: pageSummary(have, L(have.id)) });
        let site; try { site = cleanSite(appSite(job)); } catch (e) { return json(res, 400, { error: e.message }); }
        const pid = 'pg' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
        const name = `${job.name} app`.slice(0, 120);
        const items = (fresh.board && fresh.board.items) || [];
        const card = { id: 'bi' + pid.slice(2), kind: 'page', ref: pid, x: 60 + (items.length % 4) * 320, y: 60 + Math.floor(items.length / 4) * 260, w: 280, h: 200, text: name };
        let next = { ...fresh, pages: [...(fresh.pages || []), { id: pid, name, format: 'struktur', site, nodes: [], edges: [], updatedAt: Date.now() }], board: { items: [...items, card], links: (fresh.board && fresh.board.links) || [] } };
        next = wireJobBlocks(next, pid, site);
        await workspaces.setCanvas(me, id, next);
        return json(res, 200, { ok: true, existed: false, page: pageSummary({ id: pid, name, site, updatedAt: Date.now() }, L(pid)) });
      }
      if (sub === 'pages') {
        const base = hub ? hub.base : 'https://0n3.app';
        const c = await workspaces.getCanvas(me, id); if (!c) return json(res, 404, { error: 'No such project.' });
        const mine = (c.pages || []).filter((x) => x.format === 'struktur');
        const L = (pid) => linksFor({ base, account: me, project: id, page: pid });
        if (!arg && method === 'GET') return json(res, 200, { ok: true, pages: mine.map((x) => pageSummary(x, L(x.id))) });
        if (!arg && method === 'POST') {
          // A v1 project keeps its blocks only as long as it stays v1; adding a page makes it v2 and would drop them.
          if (c.v !== 2 && (c.nodes || []).length) return json(res, 409, { error: 'This project uses the older canvas. Open it on 0n3.app/canvas once (it upgrades itself), then add pages.' });
          const b = (await readJson(req)) || {};
          let site; try { site = cleanSite(b.site); } catch (e) { return json(res, 400, { error: e.message }); }
          const pid = 'pg' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
          const name = String(b.name || site.title || 'New page').slice(0, 120);
          const items = (c.board && c.board.items) || [];
          const card = { id: 'bi' + pid.slice(2), kind: 'page', ref: pid, x: 60 + (items.length % 4) * 320, y: 60 + Math.floor(items.length / 4) * 260, w: 280, h: 200, text: name };
          await workspaces.setCanvas(me, id, { ...c, pages: [...(c.pages || []), { id: pid, name, format: 'struktur', site, nodes: [], edges: [], updatedAt: Date.now() }], board: { items: [...items, card], links: (c.board && c.board.links) || [] } });
          return json(res, 200, { ok: true, page: pageSummary({ id: pid, name, site, updatedAt: Date.now() }, L(pid)) });
        }
        const pg = arg && mine.find((x) => x.id === arg);
        if (arg && !pg) return json(res, 404, { error: 'No such page in this project.' });
        if (arg && !action && method === 'GET') return json(res, 200, { ok: true, page: { ...pageSummary(pg, L(pg.id)), site: pg.site } });
        if (arg && !action && method === 'PUT') {
          const b = (await readJson(req)) || {};
          let site; try { site = b.site ? cleanSite(b.site) : pg.site; } catch (e) { return json(res, 400, { error: e.message }); }
          const name = b.name ? String(b.name).slice(0, 120) : pg.name;
          await workspaces.setCanvas(me, id, { ...c, pages: c.pages.map((x) => (x.id === pg.id ? { ...x, name, site, updatedAt: Date.now() } : x)), board: c.board ? { ...c.board, items: (c.board.items || []).map((i) => (i.ref === pg.id ? { ...i, text: name } : i)) } : c.board });
          return json(res, 200, { ok: true, page: pageSummary({ ...pg, name, site, updatedAt: Date.now() }, L(pg.id)) });
        }
        if (arg && !action && method === 'DELETE') {
          const items = ((c.board && c.board.items) || []).filter((i) => i.ref !== pg.id); const keep = new Set(items.map((i) => i.id));
          await workspaces.setCanvas(me, id, { ...c, pages: c.pages.filter((x) => x.id !== pg.id), board: { items, links: ((c.board && c.board.links) || []).filter((l) => keep.has(l.from) && keep.has(l.to)) } });
          return json(res, 200, { ok: true });
        }
        if (arg && action === 'links' && method === 'POST') return json(res, 200, { ok: true, ...L(pg.id) });
        return json(res, 405, { error: `${method} is not allowed here.` });
      }
      if (sub === 'canvas') {
        if (method === 'GET') {
          const c = await workspaces.getCanvas(me, id); if (!c) return json(res, 404, { error: 'No such workspace.' });
          // 0n3 Pages: a website page carries its thumbnail, preview and a fresh edit link, so Sites and the board can show
          // and open it (its design lives in `site`, not in nodes). `links` is dropped again on save by cleanCanvas.
          const base = hub ? hub.base : 'https://0n3.app';
          if (c.pages) c.pages = c.pages.map((p) => (p.format === 'struktur' ? { ...p, links: linksFor({ base, account: me, project: id, page: p.id }) } : p));
          return json(res, 200, { ok: true, canvas: c });
        }
        if (method === 'PUT') { const body = (await readJson(req)) || {}; const seqs = Array.isArray(body.sequences) ? body.sequences.length : 0; if (seqs) { const all = await workspaces.list(me); const before = all.find((w) => w.id === id)?.sequences || 0; if (seqs > before) { const total = all.reduce((n, w) => n + (w.id === id ? seqs : (w.sequences || 0)), 0); const g = await gate('sequences', total - 1, 'sequences'); if (g) return json(res, 402, g); } } try {
          const c = await workspaces.setCanvas(me, id, body);
          if (!c) return json(res, 404, { error: 'No such workspace.' });
          // The canvas is the one source of truth for what runs by itself: re-derive this workspace's automation rules from it.
          let automations = null; if (alerts) { try { automations = await alerts.syncSequences(me, id, c.sequences || []); } catch (e) { console.error('[0n3 automations] sync:', e.message); automations = { error: e.message }; } }
          return json(res, 200, { ok: true, canvas: c, automations });
        } catch (e) { return bad(e); } }
      }
      // What runs by itself in this workspace: one row per sequence started by an app event or a schedule, with its last check.
      if (sub === 'automations' && method === 'GET') {
        if (!alerts) return json(res, 200, { ok: true, automations: [] });
        const rows = await alerts.forWorkspace(me, id);
        return json(res, 200, { ok: true, automations: rows.map((r) => ({ id: r.id, sequenceId: r.action.sequenceId, summary: summarize(r), state: r.state, fires: r.fires, lastRunAt: r.lastRunAt, nextAt: r.cursor?.nextAt || null, lastResult: r.lastResult })) });
      }
      if (sub === 'automations' && arg && method === 'POST' && alerts) {
        // "Check now" from the phone: run this sequence's rule once, right away, exactly as the cron would.
        const r = (await alerts.forWorkspace(me, id)).find((x) => x.sequenceId === arg || x.action.sequenceId === arg);
        if (!r) return json(res, 404, { error: 'That sequence does not run by itself.' });
        return json(res, 200, { ok: true, result: await runOneAlert(r) });
      }
      // "Describe it": the person's own AI drafts a board, a page or a sequence in the builder's vocabulary. The provider is
      // the one asked for, else the first the account holds a key for; the key never leaves the server.
      if (sub === 'draft' && method === 'POST') {
        const w = await workspaces.get(me, id); if (!w) return json(res, 404, { error: 'No such workspace.' });
        const b = (await readJson(req)) || {};
        if (!String(b.prompt || '').trim()) return json(res, 400, { error: 'Say what it is for.' });
        let ai = router ? { provider: b.provider || 'auto', run: (a) => router.complete(me, a, { task: 'json', prefer: b.provider || null }) } : null;
        if (ai && !(await router.plan(me, { task: 'json' })).length) ai = null;
        const order = ai ? [] : b.provider ? [b.provider] : ['groq', 'openai', 'gemini', 'anthropic'];
        for (const prov of order) { const p = providerOf(prov); if (!p) continue; let env = p.keyless ? null : await store.get(me, p.service); if (!env && p.service === 'gemini') env = await store.get(me, 'google_ai'); if (p.keyless || env) { ai = { provider: prov, apiKey: env ? keyOf(env) : null, model: b.model || undefined }; break; } }
        if (!ai) return json(res, 400, { error: 'Connect an AI first (Groq, OpenAI, Gemini or Claude with your own key) and Describe it drafts with it.', missing: 'ai' });
        const existing = await workspaces.getCanvas(me, id).catch(() => null); const seqNames = (existing?.sequences || []).map((q) => q.name).filter(Boolean);
        const r = await draftSpec({ kind: b.kind, prompt: b.prompt, brand: (w.name || 'Acme').split(' ')[0], ai, fetchImpl, sequences: seqNames });
        return json(res, r.ok ? 200 : 400, r);
      }
      if (sub === 'flow' && arg === 'run' && method === 'POST') { const g = await gate('runs this month', await runsThisMonth(), 'runsPerMonth'); if (g) return json(res, 402, g); }
      if (sub === 'flow' && arg === 'run' && method === 'POST') {
        const c = await workspaces.getCanvas(me, id);
        if (!c) return json(res, 404, { error: 'No such workspace.' });
        const b = (await readJson(req)) || {};
        // RUN WHAT WAS SENT. On a v2 canvas the flat nodes are derived from the saved sequences, so blocks that were posted but
        // not saved used to vanish — and the engine then started the FIRST trigger in the workspace: another sequence ran
        // (measured 2026-11-10: a posted Stripe probe answered with "Email to the desk"). The posted document is cleaned
        // and run as is; a start that is not in it is refused, never replaced.
        const posted = Array.isArray(b.nodes) ? cleanDoc({ nodes: b.nodes, edges: Array.isArray(b.edges) ? b.edges : [] }) : null;
        let nodes; let edges;
        if (posted && c.v === 2) { nodes = posted.nodes; edges = posted.edges; }
        else if (posted) { nodes = (await workspaces.setCanvas(me, id, { ...c, nodes: b.nodes, edges: b.edges || c.edges })).nodes; edges = Array.isArray(b.edges) ? b.edges : c.edges; }
        else { nodes = c.nodes; edges = c.edges; }
        if (b.start && !nodes.some((n) => n.id === b.start)) return json(res, 400, { error: 'The step this run should start from is not among the blocks that were sent. Nothing ran.' });
        const dry = b.dry === true;
        const rt = createRuntime({ resolver: new VaultResolver(store, me), account, fetchImpl, audit: (info) => store.audit({ ...info, actor }) });
        const myDesk = desk ? { create: (o) => desk.create(me, { workspaceId: id, project: o.project, machine: o.machine, source: { ...(o.source || {}), from: account.email || undefined }, request: o.request }) } : null;
        // Pictures posted with a test run stand in for an email's: they are kept like any step's and arrive as {{trigger.pictures}}.
        let payload = b.payload && typeof b.payload === 'object' ? b.payload : { email: 'test@example.com', name: 'Test', amount: 149, message: 'A test run from the builder' };
        if (Array.isArray(b.files) && b.files.length) {
          let ups; try { ups = decodeUploads(b.files); } catch (e) { return json(res, 400, { error: e.message }); }
          const keep = filesFor(me); if (!keep) return json(res, 503, { error: 'File storage is not configured on this server.' });
          const pictures = []; for (const f of ups) pictures.push(await keep.put(f.name, f.data, f.type));
          payload = { ...payload, pictures };
        }
        const receipt = await runFlow({ server: rt, nodes, edges, startId: b.start, payload, fetchImpl, desk: myDesk, dry, files: filesFor(me), reader: readerFor(me, account.email || ''), memory: memoryFor(me), readWaitMs: 250000, ai: async (prov) => (router ? { chat: (c, t) => router.chat(me, { provider: prov }, c, t, { task: 'logic' }) } : { apiKey: await (async () => { const p = providerOf(prov); let env = p && !p.keyless ? await store.get(me, p.service) : null; if (!env && p?.service === 'gemini') env = await store.get(me, 'google_ai'); return env ? keyOf(env) : null; })() }) });
        // Mike: CRM-billed accounts pay per action for TEST runs too — each change a test held back counts as one.
        if (dry && usage && partner && await partner.crmBilled(me)) { const held = (receipt.steps || []).filter((x) => x.state === 'held' || x.dry).length; if (held) usage.count(me, held).catch(() => {}); }
        if (!dry) await workspaces.recordRun(me, id, { app_key: `flow:${(nodes.find((n) => n.id === receipt.start) || {}).title || 'flow'}`, inputs: b.payload || {}, receipt, ok: receipt.complete, actor });
        return json(res, 200, { ok: receipt.complete, receipt });
      }
      if (sub === 'chat') {
        const w = await workspaces.get(me, id);
        if (!w) return json(res, 404, { error: 'No such workspace.' });
        if (method === 'GET') { const t = await workspaces.thread(id, me); return json(res, 200, { ok: true, messages: t?.messages || [], trace: t?.trace || [], turns: t?.turns || 0 }); }
        if (method === 'DELETE') { await workspaces.clearThread(id, me); return json(res, 200, { ok: true }); }
        if (method === 'POST') {
          const b = (await readJson(req)) || {};
          if (!String(b.message || '').trim()) return json(res, 400, { error: 'Say something.' });
          const v = await workspaces.publicView({ slug: w.slug, accountId: me });
          return chatOn(v, { id }, b);
        }
      }
      if (sub === 'domains' && !arg && method === 'POST') { const n = (await workspaces.list(me)).reduce((k, w) => k + (w.domains || []).length, 0); const g = await gate('custom domains', n, 'domains'); if (g) return json(res, 402, g); try { const d = await workspaces.addDomain(me, id, ((await readJson(req)) || {}).host); return d ? json(res, 200, { ok: true, domain: d, dns: workspaces.dnsInstructions(d) }) : json(res, 404, { error: 'No such workspace.' }); } catch (e) { return bad(e); } }
      if (sub === 'domains' && arg && !action && method === 'DELETE') return (await workspaces.removeDomain(me, id, decodeURIComponent(arg))) ? json(res, 200, { ok: true }) : json(res, 404, { error: 'No such domain on this workspace.' });
      if (sub === 'domains' && arg && action === 'verify' && method === 'POST') { const d = await workspaces.verifyDomain(me, id, decodeURIComponent(arg)); return d ? json(res, 200, { ok: true, domain: d, dns: workspaces.dnsInstructions(d) }) : json(res, 404, { error: 'No such domain on this workspace.' }); }
      return json(res, 405, { error: `No route ${method} ${path}` });
    }

    if (path === '/mcp') {
      if (method !== 'POST') return json(res, 405, { error: 'Stateless server: POST only. Each request carries its own token.' });
      const body = await readJson(req);
      const resolver = narrow(new VaultResolver(store, account.accountId));
      // desk_request / desk_status (apps/desk-request.js): the same door as POST /api/desk/runs — caller's account, caller's
      // workspace, the same plan gate — so an AI on this connection can hand a job to the owner's desk and read the reply.
      const deskDoor = desk && workspaces && (!grant || grant.mcp) ? {
        create: async ({ workspace, request, source }) => {
          const g = await gate('desk agent', 0, 'desk'); if (g) return { error: g.error || 'Your plan does not include the desk.', plan_limit: g };
          const ws = (await workspaces.list(account.accountId)).find((w) => w.slug === workspace || w.id === workspace);
          if (!ws) return { error: `No workspace "${workspace}" on this account.` };
          return { workspace: ws, run: await desk.create(account.accountId, { workspaceId: ws.id, source, request }) };
        },
        get: (id) => desk.get(account.accountId, id),
        list: () => desk.list(account.accountId),
      } : null;
      const jobsDoor = workspaces && (!grant || grant.mcp) ? jobsFor(account) : null;
      const server = createRuntime({ resolver, account, fetchImpl, gate: await writeGate(), approvalLookup, desk: deskDoor, jobs: jobsDoor, audit: (info) => store.audit({ ...info, actor: account.email || account.accountId }) });
      const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
      res.on('close', () => { transport.close().catch(() => {}); server.close().catch(() => {}); });
      await server.connect(transport);
      await transport.handleRequest(req, res, body);
      return;
    }

    // ── HQ routes on the 0n token ───────────────────────────────────────
    if (hub) {
      if (path === '/api/profile' && method === 'GET') {
        const recs = await store.list(account.accountId);
        const toks = await hub.listTokens(account.accountId);
        const prof = await getProfile(identityRest, account.accountId);
        return json(res, 200, { ok: true, profile: shape(prof, {
          connected: [...new Set(recs.map((r) => r.service))],
          records: recs.length,
          tokens: toks.filter((t) => t.active).length,
        }) });
      }
      if (path === '/api/profile' && method === 'PATCH') {
        if (account.scope !== 'master') return json(res, 403, { error: 'A scoped token cannot change the profile it is scoped to.' });
        const b = (await readJson(req)) || {};
        const r = await patchProfile(identityRest, account.accountId, b);
        return json(res, r.ok ? 200 : 400, r);
      }
      if (apps && path === '/api/apps' && method === 'GET') return json(res, 200, { ok: true, ...(await apps.list(account.accountId)) });
      if (apps && path === '/api/apps/link' && method === 'POST') return json(res, 200, { ok: true, url: apps.link(account.accountId) });
      if (apps && path === '/api/apps/op' && method === 'POST') {
        try { const r = await apps.op(account.accountId, (await readJson(req)) || {}); return json(res, r.status, r.body); }
        catch (e) { return json(res, e.status || 500, { error: e.message }); }
      }
      if (path === '/api/me' && method === 'GET') { const recs = await store.list(account.accountId); const toks = await hub.listTokens(account.accountId); return json(res, 200, { account, records: recs.length, connected: [...new Set(recs.map((r) => r.service))], tokens: toks.filter((t) => t.active).length }); }
      if (path === '/api/tokens' && method === 'GET') return json(res, 200, { tokens: await hub.listTokens(account.accountId) });
      if (path === '/api/grants' && method === 'GET') return json(res, 200, { ok: true, grants: await hub.grants(account.accountId) });
      if (path === '/api/settings' && method === 'GET') return json(res, 200, { ok: true, settings: await hub.settings(account.accountId) });
      if (path === '/api/settings' && method === 'PATCH') {
        const b = (await readJson(req)) || {};
        // An AI client must not be able to switch off the switch that holds its own changes: only the person's own session can.
        if (b.ask_ai_writes === false && account.scope !== 'master') return json(res, 403, { error: 'Only you, signed in to 0n3 yourself, can turn this off.' });
        return json(res, 200, { ok: true, settings: await hub.setSettings(account.accountId, b) });
      }
      // The owner of an existing 0n3 account links a CRM sub-account to it, signed in as themselves (partner.js).
      if (path === '/api/partner/crm/link' && method === 'POST') {
        if (!partner) return json(res, 503, { error: 'The partner door is not configured on this server.' });
        if (grant || account.scope !== 'master') return json(res, 403, { error: 'Link it signed in to 0n3 yourself.' });
        const { status, ...out } = await partner.link(account.accountId, String(((await readJson(req)) || {}).code || ''));
        return json(res, status, out);
      }
      if (path === '/api/approvals' && method === 'GET') return json(res, 200, { ok: true, approvals: await hub.pendingApprovals(account.accountId) });
      const dm2 = /^\/api\/approvals\/([0-9a-f-]{36})$/.exec(path);
      if (dm2 && method === 'POST') {
        const r = await hub.approval(dm2[1], { accountId: account.accountId });
        if (!r) return json(res, 404, { error: 'No such request.' });
        if (r.status !== 'pending') return json(res, 409, { error: `Already ${r.status}.` });
        const b = (await readJson(req)) || {}; const now = new Date().toISOString();
        if (b.decision !== 'approve') { await hub.settleApproval(r.id, { status: 'declined', decided_at: now }); return json(res, 200, { ok: true, status: 'declined' }); }
        // Run it now, as the person, with the vault narrowed to the one app the request named.
        const rt2 = createRuntime({ resolver: new GrantResolver(new VaultResolver(store, account.accountId), [r.service]), account, fetchImpl, audit: (info) => store.audit({ ...info, actor: `${r.client_name || r.client_id} (approved by ${account.email || account.accountId})` }) });
        // What was held decides what runs: an app's catalog call (plain params), or one of an AI client's held changes.
        const kind = r.params?.__kind || null; const args = kind ? (r.params.args || {}) : (r.params || {}); const lbl = kind ? (r.params.label || undefined) : undefined;
        const rtAll = () => createRuntime({ resolver: new VaultResolver(store, account.accountId), account, fetchImpl, audit: (info) => store.audit({ ...info, actor: `${r.client_name || 'AI'} (approved by ${account.email || account.accountId})` }) });
        let result;
        try {
          if (!kind || kind === 'api_call') result = await callTool(rt2, 'api_call', { service: r.service, endpoint: r.endpoint, params: args, ...(lbl ? { label: lbl } : {}) });
          else if (kind === 'crm') result = await callTool(rt2, r.endpoint, args);
          else if (kind === 'mcp_call') result = await callTool(rt2, 'mcp_call', args);
          else if (kind === 'app_run') result = await callTool(rtAll(), 'app_run', args); // an app may need several services; it is the person's own AI and the person approved it
          else result = { error: `Unknown held change: ${kind}` };
        } catch (e) { result = { error: e.message }; }
        // The provider's own word decides: an error, ok:false or success:false is a failure, whatever the HTTP layer said.
        const failed = !!(result && typeof result === 'object' && (result.error || result.ok === false || result.success === false));
        await hub.settleApproval(r.id, { status: failed ? 'failed' : 'done', decided_at: now, executed_at: new Date().toISOString(), result: result ?? null });
        return json(res, 200, { ok: !failed, status: failed ? 'failed' : 'done', result });
      }
      if (path === '/api/grants' && method === 'DELETE') { const b = (await readJson(req)) || {}; if (!b.clientId) return json(res, 400, { error: 'clientId is required' }); return json(res, 200, { ok: true, revoked: await hub.revokeGrant(account.accountId, String(b.clientId)) }); }
    // SECURITY DASHBOARD (2026-10-29): what attackers touched, flagged addresses, planted canaries. Admins, own session only.
    if (security && path === '/api/admin/security' && method === 'GET') { if (grant || !hub?.isAdmin(account)) return json(res, 403, { error: 'Admins only.' }); return json(res, 200, { ok: true, ...(await security.overview()) }); }
    if (security && path === '/api/admin/security/unban' && method === 'POST') { if (grant || !hub?.isAdmin(account) || account.scope !== 'master') return json(res, 403, { error: 'Admins only, signed in yourself.' }); const b = (await readJson(req)) || {}; return json(res, 200, await security.unban(String(b.ip || ''))); }
    if (security && path === '/api/admin/security/sync' && method === 'POST') { if (grant || !hub?.isAdmin(account)) return json(res, 403, { error: 'Admins only.' }); return json(res, 200, await security.syncFirewall()); }
    if (security && path === '/api/admin/security/canaries' && method === 'POST') { if (grant || !hub?.isAdmin(account) || account.scope !== 'master') return json(res, 403, { error: 'Admins only, signed in yourself.' }); const b = (await readJson(req)) || {}; return json(res, 201, { ok: true, ...(await security.mintCanary(b.label, account.email)), note: 'Shown once. Plant it where you want to know about a leak; any use alerts you with this label.' }); }
    // REVIEW QUEUE (2026-10-29): who may lift an app out of read-only. ON3_ADMIN_EMAILS, signed in as yourself (not an app token).
    if (hub && path === '/api/admin/clients' && method === 'GET') { if (grant || !hub.isAdmin(account)) return json(res, 403, { error: 'Admins only.' }); return json(res, 200, { ok: true, queue: await hub.reviewQueue() }); }
    const arm = /^\/api\/admin\/clients\/([A-Za-z0-9_-]+)\/review$/.exec(path);
    if (hub && arm && method === 'POST') { if (grant || !hub.isAdmin(account)) return json(res, 403, { error: 'Admins only.' }); const b = (await readJson(req)) || {}; const ok = await hub.reviewClient(arm[1], { reviewed: b.reviewed !== false, by: account.email }); return json(res, ok ? 200 : 404, ok ? { ok: true, client_id: arm[1], reviewed: b.reviewed !== false } : { error: 'No such app.' }); }
      if (path === '/api/dev/clients' && method === 'GET') return json(res, 200, { ok: true, clients: await hub.devClients(account.accountId) });
      if (path === '/api/dev/clients' && method === 'POST') { const g = await gate('developer apps', (await hub.devClients(account.accountId)).length, 'devApps'); if (g) return json(res, 402, g); }
      if (path === '/api/dev/clients' && method === 'POST') { const b = (await readJson(req)) || {}; if (!String(b.name || '').trim()) return json(res, 400, { error: 'Give the app a name.' }); const r = await hub.createDevClient(account.accountId, { ...b, scopes: [...parseScopes((b.scopes || []).join(' ')), ...((b.scopes || []).includes('apps:*') ? ['apps:*'] : [])] }); return json(res, r.status, r.body); }
      if (path === '/api/dev/clients' && method === 'DELETE') { const b = (await readJson(req)) || {}; return json(res, (await hub.deleteDevClient(account.accountId, String(b.clientId || ''))) ? 200 : 404, { ok: true }); }
      if (path === '/api/tokens' && method === 'POST') { const b = (await readJson(req)) || {}; const scopes = keyScopes({ apps: b.apps, readOnly: b.readOnly === true }, (a) => !!getService(a) || !!getService(`${a}_api`) || ['google', 'microsoft', 'crm', 'ebay', 'godaddy_mcp'].includes(a)); return json(res, 200, { ok: true, scopes, ...(await hub.createToken(account.accountId, { name: b.name, level: b.level, expiresInDays: b.expiresInDays, scopes })) }); }
      if (path === '/api/tokens/rotate' && method === 'POST') { if (account.scope !== 'master') return json(res, 403, { error: 'Only the master token can rotate itself.' }); const t = await hub.mintMaster(account.accountId, account.crmLocationId || ''); return json(res, 200, { ok: true, token: t }); }
      const tm = /^\/api\/tokens\/([A-Za-z0-9_-]+)$/.exec(path);
      if (tm && method === 'DELETE') { await hub.revokeToken(account.accountId, tm[1]); return json(res, 200, { ok: true }); }
      const sm = /^\/api\/connect\/([a-z0-9_]+)\/start$/.exec(path);
      if (sm && method === 'POST') { const r = hub.startUrl(sm[1], account.accountId, { service: String(url.searchParams.get('for') || '') }); return json(res, r.url ? 200 : 400, r); }
      if (path === '/api/mcp/probe' && method === 'POST') {
        const r = await hub.mcpProbe(account.accountId, (await readJson(req)) || {});
        return json(res, r.status, r.body);
      }
      if (path === '/api/crm/provision' && method === 'POST') { const r = await hub.provisionCrmFor(account.accountId); return json(res, r.ok ? 200 : 400, r); }
      if (path === '/api/support' && method === 'POST') { const b = (await readJson(req)) || {}; const r = await hub.support(account.accountId, account.email, b); return json(res, r.status, r.body); }
      if (path === '/api/support' && method === 'GET') return json(res, 200, { requests: await hub.supportList(account.accountId) });
    }

    if (path === '/vault' && method === 'GET') return json(res, 200, { account: account.accountId, records: await store.list(account.accountId) });
    // First-party only: a 0n app acting for this account may read one record's credentials, if it also holds the internal secret.
    const sec = /^\/vault\/([A-Za-z0-9_.-]+)\/secret$/.exec(path);
    if (sec && method === 'GET') {
      const internal = process.env.ON3_INTERNAL_SECRET || '';
      const given = String(req.headers?.['x-0n3-internal'] || '');
      if (!internal || given !== internal) return json(res, 403, { error: 'Secrets are only released to first-party 0n apps.' });
      const env = await store.get(account.accountId, sec[1], url.searchParams.get('label') || undefined);
      if (!env) return json(res, 404, { error: `${sec[1]} is not connected for this account` });
      await store.audit({ accountId: account.accountId, service: sec[1], label: env.$0n?.name || null, action: 'read_secret', tool: 'vault', ok: true, actor: account.email || account.accountId });
      return json(res, 200, { ok: true, record: env });
    }
    const m = /^\/vault\/([A-Za-z0-9_.-]+)$/.exec(path);
    if (m && method === 'PUT') {
      const env = await readJson(req);
      if (!env || typeof env !== 'object') return json(res, 400, { error: 'Body must be a .0n connection envelope' });
      env.service = env.service || m[1];
      try { return json(res, 200, { ok: true, record: await store.put(account.accountId, env, { actor: account.email || account.accountId }) }); }
      catch (e) { return json(res, 400, { error: e.message }); }
    }
    if (m && method === 'DELETE') { await store.remove(account.accountId, m[1], url.searchParams.get('label') || undefined, { actor: account.email || account.accountId }); return json(res, 200, { ok: true }); }
    return json(res, 404, { error: `No route ${method} ${path}` });
  };
}

/** Node http server for `0n3 serve` and tests. */
export async function listen(opts, port = Number(process.env.PORT || 8787)) {
  const { createServer } = await import('node:http');
  const handler = createHandler(opts);
  const srv = createServer((req, res) => handler(req, res).catch((e) => { console.error('[0n3]', e); if (!res.headersSent) json(res, 500, { error: e.message }); }));
  await new Promise((r) => srv.listen(port, r));
  return srv;
}
