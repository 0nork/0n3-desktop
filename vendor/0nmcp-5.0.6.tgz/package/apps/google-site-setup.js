import { defineApp, Receipt } from './registry.js';

/**
 * 0nGOOGLE — "set this domain up in Google" as one call.
 *
 * Nine calls across four services, so a button in any 0nCore app can be one
 * click:
 *
 *   site_verification  get_token          → a DNS TXT value for the domain
 *   godaddy/cloudflare add_dns_records    → write that TXT record  ← the automatic bit
 *   site_verification  verify             → claim ownership
 *   search_console     add_site           → the property exists
 *   search_console     submit_sitemap     → optional
 *   analytics_admin    list_account_summaries → which GA4 account
 *   analytics_admin    create_property    → the GA4 property
 *   analytics_admin    create_data_stream → the MEASUREMENT ID, the deliverable
 *
 * ═══ WHY DNS IS THE WHOLE TRICK ═══
 *
 * Google verifies domain ownership with a DNS TXT record. Without DNS write
 * this app has to stop and tell a human to go paste a string into their
 * registrar — which is the moment a one-click setup becomes a support ticket.
 * With the registrar connected it writes the record itself and carries on.
 *
 * GoDaddy's own MCP server CANNOT do this: it is read-only, availability and
 * suggestions only, by their own documentation and by measurement. DNS writes
 * need GoDaddy's REST API with an apiKey/apiSecret — which is the `godaddy`
 * catalog service, reached through `api_call`. Cloudflare works too and is
 * tried in the same step.
 *
 * ═══ WHAT IT WILL NOT DO ═══
 *
 * It does not wait for DNS to propagate and then swear it verified. Propagation
 * is minutes to hours; a verify that fails on a freshly-written record is
 * reported as "written, not yet verified — run again shortly", because the
 * alternative is telling someone their site is verified when it is not.
 */
defineApp({
  key: 'google_site_setup',
  name: 'Set up Google for a domain',
  what: 'Verifies the domain with Google, adds it to Search Console, and creates a GA4 property with a web data stream — returning the measurement ID. Writes the DNS TXT record itself when the registrar is connected.',
  needs: [
    { service: 'google', why: 'Search Console, Site Verification and GA4 all run on the account\'s Google connection. Needs the analytics.edit, webmasters and siteverification scopes.' },
    { service: 'godaddy', why: 'To write the DNS TXT record automatically. Without it the app returns the record for you to add by hand.', optional: true },
    { service: 'cloudflare', why: 'Alternative to GoDaddy for the same DNS step.', optional: true },
  ],
  inputs: {
    domain: { type: 'string', required: true, describe: 'The bare domain, e.g. example.com (no scheme, no www)' },
    property_name: { type: 'string', describe: 'GA4 property display name. Defaults to the domain.' },
    time_zone: { type: 'string', describe: 'IANA zone for the GA4 property, e.g. America/New_York' },
    sitemap: { type: 'string', describe: 'Sitemap path to submit, e.g. sitemap.xml' },
    ga4_account: { type: 'string', describe: 'GA4 account name (accounts/123). Defaults to the first account the user can administer.' },
    dns_provider: { type: 'string', describe: 'godaddy | cloudflare | none. Defaults to whichever is connected.' },
  },

  async run({ input, call, has, r = new Receipt('google_site_setup', {}) }) {
    const domain = String(input.domain || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
    if (!domain || !domain.includes('.')) {
      return r.done({ error: `"${input.domain}" is not a domain. Pass a bare domain like example.com.` });
    }
    r.inputs = { ...input, domain };
    const siteUrl = `sc-domain:${domain}`;

    // ── 1. the verification token ──────────────────────────────────────────
    const tok = await call('site_verification', 'get_token', {
      site: { type: 'INET_DOMAIN', identifier: domain }, verificationMethod: 'DNS_TXT',
    });
    // NOT an early return. The GA4 half of this app never touches the
    // verification token — different API, different scope — so abandoning the
    // whole run here throws away work the account is perfectly entitled to do.
    // Measured live 2026-09-19: the siteverification scope was missing, step 1
    // failed, and a run that could have produced a GA4 property and a
    // measurement ID produced nothing at all. Fail the branch, not the app.
    let txt = null;
    if (!tok.ok) r.fail('get_verification_token', tok.error || tok.data, tok.status);
    else { txt = tok.data?.token; r.ok('get_verification_token', { method: 'DNS_TXT', token: txt }, tok.status); }

    // ── 2. write the TXT record, if a registrar is connected ───────────────
    const want = String(input.dns_provider || '').toLowerCase();
    const provider = want && want !== 'none' ? want
      : (await has('godaddy')) ? 'godaddy' : (await has('cloudflare')) ? 'cloudflare' : null;

    let dnsWritten = false;
    if (!txt) {
      r.skip('write_dns_txt', 'No verification token to write — see get_verification_token above.');
    } else if (want === 'none') {
      r.skip('write_dns_txt', 'dns_provider=none — add the TXT record yourself, then run this app again.');
    } else if (!provider) {
      r.skip('write_dns_txt', 'No registrar connected. Connect godaddy or cloudflare, or add this TXT record by hand and run again.');
    } else if (provider === 'godaddy') {
      // GoDaddy replaces the whole TXT set for a name, so anything already at
      // "@" would be lost by a naive PUT. Read first, then write the union.
      const cur = await call('godaddy', 'list_dns_records', { domain, type: 'TXT', name: '@' });
      const keep = (cur.ok && Array.isArray(cur.data) ? cur.data : [])
        .filter((rec) => String(rec.data || '') !== txt)
        .map((rec) => ({ data: rec.data, ttl: rec.ttl || 3600 }));
      const res = await call('godaddy', 'add_dns_records', {
        domain, records: [...keep, { type: 'TXT', name: '@', data: txt, ttl: 3600 }],
      });
      if (res.ok) { dnsWritten = true; r.ok('write_dns_txt', { provider: 'godaddy', name: '@', kept_existing: keep.length }, res.status); }
      else r.fail('write_dns_txt', res.error || JSON.stringify(res.data), res.status);
    } else if (provider === 'cloudflare') {
      const zones = await call('cloudflare', 'list_zones', { name: domain });
      const zoneId = zones.ok ? zones.data?.result?.[0]?.id : null;
      if (!zoneId) r.fail('write_dns_txt', `No Cloudflare zone for ${domain}`, zones.status);
      else {
        const res = await call('cloudflare', 'create_dns_record', { zone_id: zoneId, type: 'TXT', name: domain, content: txt, ttl: 3600 });
        if (res.ok) { dnsWritten = true; r.ok('write_dns_txt', { provider: 'cloudflare', zoneId }, res.status); }
        else r.fail('write_dns_txt', res.error || JSON.stringify(res.data), res.status);
      }
    }

    // ── 3. verify ──────────────────────────────────────────────────────────
    let verified = false;
    const ver = txt
      ? await call('site_verification', 'verify', { verificationMethod: 'DNS_TXT', site: { type: 'INET_DOMAIN', identifier: domain } })
      : null;
    if (!ver) {
      r.skip('verify_ownership', 'Cannot verify without a verification token.');
    } else if (ver.ok) { verified = true; r.ok('verify_ownership', ver.data, ver.status); }
    else {
      // Expected on a record written seconds ago. Say which it is.
      r.fail('verify_ownership', dnsWritten
        ? `TXT record written but Google cannot see it yet (DNS propagation). Run this app again in a few minutes. Google said: ${ver.error || JSON.stringify(ver.data)}`
        : (ver.error || JSON.stringify(ver.data)), ver.status);
    }

    // ── 4. Search Console ──────────────────────────────────────────────────
    if (!verified) {
      r.skip('add_to_search_console', 'Search Console will not accept an unverified domain. It is added automatically once verification succeeds.');
    } else {
      const add = await call('search_console', 'add_site', { siteUrl });
      add.ok ? r.ok('add_to_search_console', { siteUrl }, add.status)
             : r.fail('add_to_search_console', add.error || JSON.stringify(add.data), add.status);
      if (add.ok && input.sitemap) {
        const sm = await call('search_console', 'submit_sitemap', { siteUrl, feedpath: `https://${domain}/${String(input.sitemap).replace(/^\//, '')}` });
        sm.ok ? r.ok('submit_sitemap', { sitemap: input.sitemap }, sm.status)
              : r.fail('submit_sitemap', sm.error || JSON.stringify(sm.data), sm.status);
      }
    }

    // ── 5. GA4 — property and data stream ──────────────────────────────────
    let measurementId = null, propertyName = null;
    let account = input.ga4_account || null;
    if (!account) {
      const accts = await call('google_analytics_admin', 'list_account_summaries', {});
      account = accts.ok ? accts.data?.accountSummaries?.[0]?.account : null;
      accts.ok ? r.ok('find_ga4_account', { account, choices: (accts.data?.accountSummaries || []).length }, accts.status)
               : r.fail('find_ga4_account', accts.error || JSON.stringify(accts.data), accts.status);
    }
    if (!account) {
      r.skip('create_ga4_property', 'No GA4 account available to create a property under. Pass ga4_account, or create an Analytics account first.');
    } else {
      const prop = await call('google_analytics_admin', 'create_property', {
        parent: account,
        displayName: input.property_name || domain,
        timeZone: input.time_zone || 'America/New_York',
        currencyCode: 'USD',
      });
      if (!prop.ok) r.fail('create_ga4_property', prop.error || JSON.stringify(prop.data), prop.status);
      else {
        propertyName = prop.data?.name;
        r.ok('create_ga4_property', { property: propertyName, displayName: prop.data?.displayName }, prop.status);
        const stream = await call('google_analytics_admin', 'create_data_stream', {
          parent: propertyName, type: 'WEB_DATA_STREAM',
          displayName: `${domain} web`, webStreamData: { defaultUri: `https://${domain}` },
        });
        if (!stream.ok) r.fail('create_data_stream', stream.error || JSON.stringify(stream.data), stream.status);
        else {
          measurementId = stream.data?.webStreamData?.measurementId || null;
          r.ok('create_data_stream', { stream: stream.data?.name, measurementId }, stream.status);
        }
      }
    }

    return r.done({
      domain,
      verified,
      dns_record_written: dnsWritten,
      // THE VALUE ITSELF, at the top, whenever a human still has to paste it.
      // Telling someone "add this TXT record by hand" and then keeping the
      // string inside step 1 of a nine-step receipt is a instruction they
      // cannot follow. Returned only while it is still needed.
      verification_txt: verified || !txt ? undefined : { name: '@', type: 'TXT', value: txt },
      search_console_property: verified ? siteUrl : null,
      ga4_property: propertyName,
      measurement_id: measurementId,
      // The one thing a caller most wants next, said outright.
      next: !verified
        // Only claim the other half survived if it actually did. Run live
        // 2026-09-19 this sentence said "the GA4 half is unaffected" on a run
        // where GA4 had failed on the same missing scope two lines above it.
        ? (!txt ? (measurementId
            ? 'Google would not issue a verification token for this connection — see get_verification_token. GA4 was set up regardless.'
            : 'Google would not issue a verification token for this connection. Check the scopes on the connection named in `used`, or pass a different `label`.')
          : dnsWritten ? 'Wait a few minutes for DNS, then run this app again — it picks up where it stopped.'
                       : `Add a TXT record at @ with the value "${txt}", then run this app again.`)
        : measurementId ? `Install the GA4 tag with measurement ID ${measurementId} on https://${domain}.`
                        : 'Verified and in Search Console. GA4 still needs a property — see steps.',
    });
  },
});
