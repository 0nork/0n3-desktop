import { defineApp } from './registry.js';

/**
 * DESK REQUESTS FROM ANY AI (2026-11-08). Mike: a claude.ai Project (ATLO) must "route requests directly" to the work.
 * The work happens on the owner's own computer through the desk (desk.js + `0n3 desk`): a run is queued on a workspace
 * that has a "Desk agent" step, the owner's machine claims it, runs one headless turn in that desk's folder under the
 * desk's Rules, and writes the reply back on the run. These two apps are the same door POST /api/desk/runs is, reachable
 * through app_run, so any AI connected to 0n3 (claude.ai, phone, Dispatch) can hand a job over and read the answer.
 *
 * Runs are created under the CALLER's account only, on a workspace the caller owns, and the desk plan limit applies
 * exactly as it does on the HTTP route. Nothing here runs anything — the owner's machine decides, under its allow list.
 */
const noDesk = { error: 'The desk is not available on this connection (it needs a signed-in 0n3 account on 0n3.app/mcp).' };

defineApp({
  key: 'desk_request',
  name: 'Send a job to my desk',
  what: "Queue a request on one of my desks (a workspace with a Desk agent step). My computer picks it up, works in that desk's folder under its rules, and writes the reply on the run — read it with desk_status.",
  needs: [],
  noConnections: "It uses no connected app: it talks to this account's own desk, which runs on the owner's computer.",
  inputs: {
    desk: { type: 'string', required: true, describe: 'The desk workspace slug, e.g. "atlo-desk" or "eagles-desk"' },
    request: { type: 'string', required: true, describe: 'What to do, in plain words — everything the worker needs, it sees nothing else' },
    from: { type: 'string', describe: 'Where the request came from, e.g. "claude.ai ATLO project"' },
  },
  async run({ input, desk, r }) {
    if (!desk) return { ...r.done(), ...noDesk, complete: false };
    const request = String(input.request || '').trim();
    if (!input.desk || !request) { r.fail('check inputs', 'desk and request are both required'); return r.done(); }
    const out = await desk.create({ workspace: String(input.desk), request, source: { kind: 'app', from: String(input.from || 'AI via 0n3').slice(0, 160) } });
    if (out.error) { r.fail('queue the run', out.error); return r.done({ plan_limit: out.plan_limit || undefined }); }
    r.ok('queue the run', { runId: out.run.id, state: out.run.state, desk: out.workspace.slug });
    return r.done({ runId: out.run.id, state: out.run.state, watch: `https://0n3.app/desk/${out.run.id}`, next: 'Call desk_status with this runId to read progress notes, questions and the reply.' });
  },
});

defineApp({
  key: 'desk_status',
  name: 'Read a desk job',
  what: 'Read one desk run: its state (queued, running, waiting, done, failed), progress notes, any question it is waiting on, and the reply. Without runId, lists my latest runs.',
  needs: [],
  noConnections: "It uses no connected app: it talks to this account's own desk, which runs on the owner's computer.",
  inputs: {
    runId: { type: 'string', describe: 'The runId desk_request returned; leave out to list the latest runs' },
    limit: { type: 'number', describe: 'How many runs to list when no runId is given (default 10)' },
  },
  async run({ input, desk, r }) {
    if (!desk) return { ...r.done(), ...noDesk, complete: false };
    if (!input.runId) {
      const runs = (await desk.list()).slice(0, Math.min(50, Number(input.limit) || 10));
      r.ok('list runs', { count: runs.length });
      return r.done({ runs: runs.map((x) => ({ runId: x.id, state: x.state, project: x.project, request: x.request.slice(0, 200), updatedAt: x.updatedAt })) });
    }
    const run = await desk.get(String(input.runId));
    if (!run) { r.fail('read the run', 'No such run on this account.'); return r.done(); }
    r.ok('read the run', { state: run.state });
    const last = (role) => [...run.thread].reverse().find((t) => t.role === role) || null;
    return r.done({ runId: run.id, state: run.state, request: run.request, reply: last('receipt')?.text || null, waitingOn: run.state === 'waiting' ? (last('question')?.text || 'a question on the phone') : null, thread: run.thread.map((t) => ({ at: t.at, role: t.role, text: String(t.text || '').slice(0, 4000) })), updatedAt: run.updatedAt });
  },
});
