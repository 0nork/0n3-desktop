import { defineApp } from './registry.js';

/**
 * JOBS FROM ANY AI (2026-11-12). "Have 0n run Job #12": these three mini-apps are the same door as /api/jobs — the caller's
 * account, the same engine, the same plan allowance and run history — reachable through app_run, so the chat, claude.ai on the
 * phone or any MCP client can list Jobs, run one and read what it handed back. Nothing new runs here; http.js jobsFor() does.
 */
const noJobs = { error: 'Jobs are not available on this connection (it needs a signed-in 0n3 account on 0n3.app/mcp).' };

defineApp({
  key: 'job_list',
  name: 'List my Jobs',
  what: 'Every Job on this account with its number (run it as "Job #12"), its Project, what starts it and whether it has a Return block.',
  needs: [],
  noConnections: 'It reads this account\'s own Projects; no connected app is used.',
  inputs: {},
  async run({ jobs, r }) {
    if (!jobs) return { ...r.done(), ...noJobs, complete: false };
    const list = await jobs.list();
    r.ok('list jobs', { count: list.length });
    return r.done({ jobs: list });
  },
});

defineApp({
  key: 'job_run',
  name: 'Run a Job',
  what: 'Run one Job by number, id or name and get back its OUTPUT (the Return block\'s value, else the last step\'s) with every step. wait:false starts it and returns a runId to read with job_result.',
  needs: [],
  noConnections: 'The Job uses the apps it was built with; they are checked step by step and a missing one is named in the steps.',
  inputs: {
    job: { type: 'string', required: true, describe: 'The Job: its number ("12"), id or name' },
    input: { type: 'object', describe: 'Values the Job reads as {{trigger.<name>}}' },
    wait: { type: 'boolean', describe: 'true (default) waits for the answer; false starts it and returns a runId' },
    dry: { type: 'boolean', describe: 'true = dry run: reads run for real, nothing that changes an account is sent' },
  },
  async run({ input, jobs, r }) {
    if (!jobs) return { ...r.done(), ...noJobs, complete: false };
    const out = await jobs.run(String(input.job ?? ''), { input: input.input && typeof input.input === 'object' ? input.input : {}, wait: input.wait !== false, dry: input.dry === true });
    const { status, ...rest } = out;
    if (rest.error) { r.fail('run the job', rest.error); return r.done({ plan_limit: status === 402 ? rest : undefined }); }
    if (status === 202) { r.ok('start the job', { runId: rest.runId }); return r.done({ ...rest, next: 'Read it with job_result {runId}.' }); }
    if (rest.ok) r.ok('run the job', { runId: rest.runId, state: rest.state }); else r.fail('run the job', rest.outcome || 'A step did not finish — see steps.');
    // The app's own receipt owns `steps`; the Job's steps travel as jobSteps so neither hides the other.
    const { steps: jobSteps, ...restOut } = rest;
    return r.done({ ...restOut, jobSteps });
  },
});

defineApp({
  key: 'job_result',
  name: 'Read a Job run',
  what: 'Read one Job run by runId: its state (running, waiting, done), its output and its steps. Give job instead to list that Job\'s latest runs.',
  needs: [],
  noConnections: 'It reads this account\'s own run history.',
  inputs: {
    runId: { type: 'string', describe: 'The runId job_run returned' },
    job: { type: 'string', describe: 'Or: a Job number, id or name, to list its latest runs' },
  },
  async run({ input, jobs, r }) {
    if (!jobs) return { ...r.done(), ...noJobs, complete: false };
    const out = input.runId ? await jobs.get(String(input.runId)) : await jobs.runs(String(input.job ?? ''), 10);
    if (out.error) { r.fail('read the run', out.error); return r.done(); }
    r.ok('read the run');
    if (out.run) { const { steps: jobSteps, ...run } = out.run; return r.done({ run: { ...run, jobSteps } }); }
    return r.done({ ...out, runs: (out.runs || []).map(({ steps: jobSteps, ...x }) => ({ ...x, jobSteps })) });
  },
});
