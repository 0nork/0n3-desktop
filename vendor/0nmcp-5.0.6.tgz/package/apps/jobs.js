import { defineApp } from './registry.js';

/**
 * JOBS FROM ANY AI (2026-11-12). "Have 0n run Job #12": these three mini-apps are the same door as /api/jobs — the caller's
 * account, the same engine, the same plan allowance and run history — reachable through app_run, so the chat, claude.ai on the
 * phone or any MCP client can list Jobs, run one and read what it handed back. Nothing new runs here; http.js jobsFor() does.
 */
const noJobs = { error: 'Jobs are not available on this connection (it needs a signed-in 0n3 account on 0n3.app/mcp).' };

defineApp({
  key: 'job_list',
  name: 'List my Jobs',
  what: 'Every Job on this account with its number (run it as "Job #12"), its Project, what starts it and whether it has a Return block.',
  needs: [],
  noConnections: 'It reads this account\'s own Projects; no connected app is used.',
  inputs: {},
  async run({ jobs, r }) {
    if (!jobs) return { ...r.done(), ...noJobs, complete: false };
    const list = await jobs.list();
    r.ok('list jobs', { count: list.length });
    return r.done({ jobs: list });
  },
});

defineApp({
  key: 'job_run',
  name: 'Run a Job',
  what: 'Run one Job by number, id or name and get back its OUTPUT (the Return block\'s value, else the last step\'s) with every step. wait:false starts it and returns a runId to read with job_result.',
  needs: [],
  noConnections: 'The Job uses the apps it was built with; they are checked step by step and a missing one is named in the steps.',
  inputs: {
    job: { type: 'string', required: true, describe: 'The Job: its number ("12"), id or name' },
    input: { type: 'object', describe: 'Values the Job reads as {{trigger.<name>}}' },
    wait: { type: 'boolean', describe: 'true (default) waits for the answer; false starts it and returns a runId' },
    dry: { type: 'boolean', describe: 'true = dry run: reads run for real, nothing that changes an account is sent' },
  },
  async run({ input, jobs, r }) {
    if (!jobs) return { ...r.done(), ...noJobs, complete: false };
    const out = await jobs.run(String(input.job ?? ''), { input: input.input && typeof input.input === 'object' ? input.input : {}, wait: input.wait !== false, dry: input.dry === true });
    const { status, ...rest } = out;
    if (rest.error) { r.fail('run the job', rest.error); return r.done({ plan_limit: status === 402 ? rest : undefined }); }
    if (status === 202) { r.ok('start the job', { runId: rest.runId }); return r.done({ ...rest, next: 'Read it with job_result {runId}.' }); }
    if (rest.ok) r.ok('run the job', { runId: rest.runId, state: rest.state }); else r.fail('run the job', rest.outcome || 'A step did not finish — see steps.');
    // The app's own receipt owns `steps`; the Job's steps travel as jobSteps so neither hides the other.
    const { steps: jobSteps, ...restOut } = rest;
    return r.done({ ...restOut, jobSteps });
  },
});

defineApp({
  key: 'job_result',
  name: 'Read a Job run',
  what: 'Read one Job run by runId: its state (running, waiting, done), its output and its steps. Give job instead to list that Job\'s latest runs.',
  needs: [],
  noConnections: 'It reads this account\'s own run history.',
  inputs: {
    runId: { type: 'string', describe: 'The runId job_run returned' },
    job: { type: 'string', describe: 'Or: a Job number, id or name, to list its latest runs' },
  },
  async run({ input, jobs, r }) {
    if (!jobs) return { ...r.done(), ...noJobs, complete: false };
    const out = input.runId ? await jobs.get(String(input.runId)) : await jobs.runs(String(input.job ?? ''), 10);
    if (out.error) { r.fail('read the run', out.error); return r.done(); }
    r.ok('read the run');
    if (out.run) { const { steps: jobSteps, ...run } = out.run; return r.done({ run: { ...run, jobSteps } }); }
    return r.done({ ...out, runs: (out.runs || []).map(({ steps: jobSteps, ...x }) => ({ ...x, jobSteps })) });
  },
});

/**
 * SAVE AS WORKFLOW (2026-11-24). After a task is finished, the AI that did it hands over the app calls it made and they
 * become a Job on the board: visible, runnable, with its own run history, and exportable as a .0n file.
 */
defineApp({
  key: 'job_save',
  name: 'Save steps as a workflow',
  what: 'Save a finished task as a workflow the person can see on their board and run again: give it a name and the app calls that did the work, in order (app, endpoint, params as used with api_call). Use {{trigger.<name>}} in a value that should be asked for at run time. Ask the person before saving.',
  needs: [],
  noConnections: 'It saves to this account\'s own Projects. The apps in the steps are checked when the workflow runs.',
  inputs: {
    name: { type: 'string', required: true, describe: 'What the workflow is called, in the person\'s words' },
    steps: { type: 'array', required: true, describe: 'In order: [{ app, endpoint, params, label?, title? }] — app and endpoint exactly as service_info names them; label picks the record when the account holds several' },
    project: { type: 'string', describe: 'Project name or id to save into (default: the first Project that holds Jobs)' },
  },
  async run({ input, jobs, r }) {
    if (!jobs || !jobs.save) return { ...r.done(), ...noJobs, complete: false };
    const { status, ...out } = await jobs.save({ name: input.name, steps: input.steps, project: input.project });
    if (out.error) { r.fail('save the workflow', out.error); return r.done({ plan_limit: status === 402 ? out : undefined, errors: out.errors }); }
    r.ok('save the workflow', { job: `#${out.job.no} ${out.job.name}`, steps: out.steps });
    return r.done({ ...out, next: `It is on the board at 0n3.app${out.open} as Job #${out.job.no}. Run it with job_run, or download it as a .0n file from ${out.export}.` });
  },
});

defineApp({
  key: 'job_export',
  name: 'Export a Job as a .0n file',
  what: 'One Job as a .0n workflow file (the open 0n standard): its app steps in order, portable to anything that reads .0n.',
  needs: [],
  noConnections: 'It reads this account\'s own Projects.',
  inputs: { job: { type: 'string', required: true, describe: 'The Job: its number ("12"), id or name' } },
  async run({ input, jobs, r }) {
    if (!jobs || !jobs.exportJob) return { ...r.done(), ...noJobs, complete: false };
    const out = await jobs.exportJob(String(input.job ?? ''));
    if (out.error) { r.fail('export the job', out.error); return r.done(); }
    r.ok('export the job', { steps: out.file.steps.length });
    return r.done({ job: { no: out.job.no, name: out.job.name }, file: out.file, download: `/api/jobs/${out.job.no}/export` });
  },
});
