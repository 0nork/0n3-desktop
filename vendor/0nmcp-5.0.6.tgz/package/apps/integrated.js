/**
 * INTEGRATED APPS — the 0n products that run on 0n3 and are cross-sold everywhere.
 *
 * Ruling (Mike, 2026-10-22): two products — 0n3 (advanced) and 0nTask (everyone).
 * Everything else is an integrated app: it stays exactly as built, reads the
 * 0n3 vault by email, and is offered inside both products from THIS list.
 * One registration here is what makes an app appear on a workspace palette,
 * on the 0n3 home page and in 0nTask's catalogue. No hand-added nav links.
 *
 * `needs` names the vault service an app reads for the signed-in person, so a
 * workspace can say "connect X first" before the tile is useful. `for` is the
 * audience word the UI shows; it is copy, not a gate.
 */

export const INTEGRATED_APPS = [
  {
    key: '0ntask', name: '0nTask', product: true,
    what: 'Tasks for everyone. Dump what is in your head, it becomes tasks, and the ones you hand to your AI come back done.',
    url: 'https://app.0ntask.com', for: 'everyone', needs: [],
  },
  {
    key: '0ncore', name: '0nCore',
    what: 'CRM portal: agent studio, burst executor, add-ons and the ecosystem map.',
    url: 'https://www.0ncore.com', for: 'agencies', needs: [{ service: 'crm', why: 'acts inside your CRM location' }],
  },
  {
    key: 'cro9', name: 'CRO9 / SXO',
    what: 'Site scanning, AEO scoring and auto-implementation for the sites you run.',
    url: 'https://www.0ncore.com/crm/sxo', for: 'marketers', needs: [{ service: 'cro9', why: 'your CRO9 account key' }],
  },
  {
    key: 'cardflow', name: 'CardFlow',
    what: 'eBay selling engine for card collectors: scan, price, list, pack, ship.',
    url: 'https://cardflow-nu.vercel.app', for: 'sellers', needs: [{ service: 'ebay', why: 'lists and ships on your eBay account' }],
  },
  {
    key: 'kidcard', name: 'KidCard',
    what: 'A family card vault for kids, with grown-up approvals on everything that leaves the house.',
    url: 'https://mykidcard.com', for: 'families', needs: [],
  },
  {
    key: '0nmcp', name: '0nmcp.com',
    what: 'The community, the docs and the sign-in everyone shares.',
    url: 'https://0nmcp.com', for: 'everyone', needs: [],
  },
];

export const integratedApp = (key) => INTEGRATED_APPS.find((a) => a.key === key) || null;
