import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import { defineApp } from './registry.js';
import { SERVICE_CATALOG } from '../catalog.js';

/**
 * 0nNPM — "publish an MCP server" as one call (2026-10-29).
 *
 * Mike: "make [npm] an application people can connect with an API key … this will allow us to publish and create MCP
 * servers." A person (or their AI) describes the tools; this app writes a real MCP server package, packs it exactly like
 * `npm pack` (gzipped tar, everything under package/), checks the name is free or theirs, publishes it with THEIR npm
 * token, and confirms the version is on the registry.
 *
 * The server it writes is small on purpose: each tool forwards to one endpoint of one app the person connected to 0n3
 * (POST https://0n3.app/api/x/call with the user's own 0n3 token, ON3_TOKEN). Their app keys never go into the package —
 * whoever installs it brings their own 0n3 token, and 0n3 uses their vault. Publishing from a third-party app waits for
 * the person's approval like any other write.
 *
 *   npm  get_package      → is the name free, or does this npm user maintain it? (and the next version when not given)
 *   npm  whoami           → who is publishing
 *   npm  publish_package  → the registry PUT, tarball attached
 *   npm  get_version      → the version answers on the registry
 */
const NAME_RE = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]{0,213}$/;
const TOOL_RE = /^[a-z][a-z0-9_]{0,63}$/;
const VER_RE = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
const esc = (s) => JSON.stringify(String(s ?? ''));

// ── a tarball npm accepts: POSIX ustar, every path under package/, gzipped ──
function tarHeader(path, size, mtime) {
  const h = Buffer.alloc(512);
  let name = path, prefix = '';
  if (Buffer.byteLength(name) > 100) { const i = path.lastIndexOf('/', 154); prefix = path.slice(0, i); name = path.slice(i + 1); }
  const put = (str, off, len) => h.write(str, off, Math.min(len, Buffer.byteLength(str)), 'utf8');
  const oct = (n, len) => n.toString(8).padStart(len - 1, '0') + '\0';
  put(name, 0, 100); put(oct(0o644, 8), 100, 8); put(oct(0, 8), 108, 8); put(oct(0, 8), 116, 8);
  put(oct(size, 12), 124, 12); put(oct(mtime, 12), 136, 12); h.fill(0x20, 148, 156); put('0', 156, 1);
  put('ustar\0', 257, 6); put('00', 263, 2); put(prefix, 345, 155);
  let sum = 0; for (const b of h) sum += b;
  put(sum.toString(8).padStart(6, '0') + '\0 ', 148, 8);
  return h;
}
export function makeTarball(files, mtime = Math.floor(Date.now() / 1000)) {
  const parts = [];
  for (const [p, content] of Object.entries(files)) {
    const body = Buffer.isBuffer(content) ? content : Buffer.from(String(content), 'utf8');
    parts.push(tarHeader(`package/${p}`, body.length, mtime), body, Buffer.alloc((512 - (body.length % 512)) % 512));
  }
  parts.push(Buffer.alloc(1024));
  return gzipSync(Buffer.concat(parts), { level: 9 });
}

/** The MCP server's files from a list of tools. Pure — exported so it is tested without publishing anything. */
export function buildServer({ name, version, description, tools }) {
  const bin = name.replace(/^@[^/]+\//, '');
  const pkg = {
    name, version, description: description || `MCP server: ${tools.map((t) => t.name).join(', ')} — powered by 0n3`,
    type: 'module', main: 'index.js', bin: { [bin]: 'index.js' }, files: ['index.js', 'README.md'],
    keywords: ['mcp', 'model-context-protocol', '0n3'], license: 'MIT', engines: { node: '>=18' },
    dependencies: { '@modelcontextprotocol/sdk': '^1.20.0', zod: '^3.23.8' },
  };
  const zodOf = (t) => ({ string: 'z.string()', number: 'z.number()', boolean: 'z.boolean()' }[t] || 'z.string()');
  const toolCode = tools.map((t) => {
    const ins = Object.entries(t.inputs || {});
    return `server.registerTool(${esc(t.name)}, {
  description: ${esc(t.description || `${t.endpoint} on ${t.service}`)},
  inputSchema: { ${ins.map(([k, ty]) => `${JSON.stringify(k)}: ${zodOf(ty)}.optional()`).join(', ')} },
}, async (args) => call(${esc(t.service)}, ${esc(t.endpoint)}, { ...${JSON.stringify(t.params || {})}, ...args }));`;
  }).join('\n\n');
  const index = `#!/usr/bin/env node
// ${name}@${version} — an MCP server published with 0n3 (https://0n3.app). Each tool calls one app you connected to 0n3.
// Set ON3_TOKEN to your own 0n3 token (0n3.app → Token). Your app keys stay in your 0n3 vault; this package holds none.
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

const BASE = process.env.ON3_URL || 'https://0n3.app';
async function call(service, endpoint, params) {
  if (!process.env.ON3_TOKEN) return { isError: true, content: [{ type: 'text', text: 'Set ON3_TOKEN to your 0n3 token (0n3.app → Token), then restart this server.' }] };
  const r = await fetch(BASE + '/api/x/call', { method: 'POST', headers: { Authorization: 'Bearer ' + process.env.ON3_TOKEN, 'Content-Type': 'application/json' }, body: JSON.stringify({ service, endpoint, params }) });
  const text = await r.text();
  let failed = !r.ok; try { const j = JSON.parse(text); if (j && (j.ok === false || j.error)) failed = true; } catch { /* plain text */ }
  return { isError: failed, content: [{ type: 'text', text }] };
}

const server = new McpServer({ name: ${esc(name)}, version: ${esc(version)} });

${toolCode}

await server.connect(new StdioServerTransport());
`;
  const readme = `# ${name}

${pkg.description}

An MCP server made with [0n3](https://0n3.app). Each tool calls one app through your own 0n3 account — your keys stay in your 0n3 vault.

## Tools
${tools.map((t) => `- **${t.name}** — ${t.description || `${t.endpoint} on ${t.service}`} (uses your ${t.service} connection)`).join('\n')}

## Use it
1. Get your 0n3 token at https://0n3.app (menu → Token) and connect the apps above.
2. Add to your MCP client (e.g. Claude Desktop):

\`\`\`json
{ "mcpServers": { ${JSON.stringify(bin)}: { "command": "npx", "args": ["-y", ${JSON.stringify(name)}], "env": { "ON3_TOKEN": "your 0n3 token" } } } }
\`\`\`
`;
  return { pkg, files: { 'package.json': JSON.stringify(pkg, null, 2) + '\n', 'index.js': index, 'README.md': readme } };
}

/** The registry document npm itself sends on publish (same shape as libnpmpublish). */
export function packument({ pkg, tarball, tag = 'latest', access = 'public' }) {
  const file = `${pkg.name}-${pkg.version}.tgz`;
  const integrity = 'sha512-' + createHash('sha512').update(tarball).digest('base64');
  const shasum = createHash('sha1').update(tarball).digest('hex');
  return {
    _id: pkg.name, name: pkg.name, description: pkg.description || '', 'dist-tags': { [tag]: pkg.version },
    versions: { [pkg.version]: { ...pkg, _id: `${pkg.name}@${pkg.version}`, dist: { integrity, shasum, tarball: `https://registry.npmjs.org/${pkg.name}/-/${pkg.name.replace(/^@[^/]+\//, '')}-${pkg.version}.tgz` } } },
    access, readme: '',
    _attachments: { [file]: { content_type: 'application/octet-stream', data: tarball.toString('base64'), length: tarball.length } },
  };
}

const bump = (v) => { const m = /^(\d+)\.(\d+)\.(\d+)/.exec(v || ''); return m ? `${m[1]}.${m[2]}.${Number(m[3]) + 1}` : '1.0.0'; };

defineApp({
  key: 'npm_publish_mcp_server',
  name: 'Publish an MCP server to npm',
  what: 'Writes an MCP server whose tools each call one of your connected apps through 0n3, packs it, and publishes it to npm under your account — then confirms the version is live. Anyone who installs it uses their own 0n3 token; no keys go into the package.',
  needs: [{ service: 'npm', why: 'Publishes with your npm access token (npmjs.com → Access Tokens → an automation or granular token that can publish).' }],
  inputs: {
    name: { type: 'string', required: true, describe: 'Package name, e.g. "@you/sales-mcp" or "sales-mcp-server"' },
    tools: { type: 'array', required: true, describe: 'Tools: [{ name, description, service, endpoint, inputs: { field: "string"|"number"|"boolean" }, params: { fixed values } }] — service/endpoint are 0n3 catalog names' },
    version: { type: 'string', describe: 'Version to publish; default: 1.0.0 for a new package, else the next patch' },
    description: { type: 'string', describe: 'One line for npm' },
    tag: { type: 'string', describe: 'dist-tag, default "latest"' },
  },
  async run({ input, call, r }) {
    const name = String(input.name || '').trim().toLowerCase();
    const tools = Array.isArray(input.tools) ? input.tools : [];
    if (!NAME_RE.test(name)) { r.fail('check name', 'A package name is lowercase letters, digits, - . _ and an optional @scope/.'); return r.done(); }
    const bad = tools.find((t) => !TOOL_RE.test(String(t?.name || '')) || !t?.service || !t?.endpoint);
    if (!tools.length || tools.length > 50 || bad) { r.fail('check tools', bad ? `Tool ${JSON.stringify(bad?.name)} needs a snake_case name, a service and an endpoint.` : 'Give 1–50 tools.'); return r.done(); }
    // Every tool must name a real catalog endpoint, or the published server is broken for everyone who installs it.
    const unknown = tools.filter((t) => !SERVICE_CATALOG[t.service]?.endpoints?.[t.endpoint]);
    if (unknown.length) {
      r.fail('check tools', unknown.map((t) => SERVICE_CATALOG[t.service]
        ? `${t.name}: ${t.service} has no endpoint "${t.endpoint}" (it has ${Object.keys(SERVICE_CATALOG[t.service].endpoints).slice(0, 12).join(', ')})`
        : `${t.name}: "${t.service}" is not a 0n3 service`).join(' · '));
      return r.done();
    }
    r.ok('check tools', { tools: tools.map((t) => `${t.name} → ${t.service}.${t.endpoint}`) });
    const me = await call('npm', 'whoami', {});
    if (!me.ok) { r.fail('who is publishing', me.error); return r.done(); }
    const user = me.data?.username; r.ok('who is publishing', { npmUser: user }, me.status);
    const existing = await call('npm', 'get_package', { pkg: name });
    let version = input.version ? String(input.version) : '1.0.0';
    if (existing.ok) {
      const maint = (existing.data?.maintainers || []).map((m) => m.name);
      if (maint.length && !maint.includes(user)) { r.fail('name is yours or free', `${name} already exists on npm and ${user} is not a maintainer (${maint.join(', ')}).`); return r.done(); }
      if (!input.version) version = bump(existing.data?.['dist-tags']?.latest);
      if (existing.data?.versions?.[version]) { r.fail('name is yours or free', `${name}@${version} is already published — choose a higher version.`); return r.done(); }
      r.ok('name is yours or free', { exists: true, latest: existing.data?.['dist-tags']?.latest, publishing: version });
    } else if (existing.status === 404) r.ok('name is yours or free', { exists: false, publishing: version });
    else { r.fail('name is yours or free', existing.error, existing.status); return r.done(); }
    if (!VER_RE.test(version)) { r.fail('version', `${version} is not a valid version (e.g. 1.0.0).`); return r.done(); }
    const { pkg, files } = buildServer({ name, version, description: input.description, tools });
    const tarball = makeTarball(files);
    r.ok('build the package', { files: Object.keys(files), bytes: tarball.length });
    const pub = await call('npm', 'publish_package', { pkg: name, ...packument({ pkg, tarball, tag: input.tag || 'latest' }) });
    if (!pub.ok) { r.fail('publish', pub.error, pub.status); return r.done(); }
    r.ok('publish', { name, version }, pub.status);
    const live = await call('npm', 'get_version', { pkg: name, version });
    if (live.ok) r.ok('live on npm', { url: `https://www.npmjs.com/package/${name}`, install: `npx -y ${name}` }, live.status);
    else r.skip('live on npm', `The registry accepted it; it can take a minute to answer (${live.status}). Check https://www.npmjs.com/package/${name}.`);
    return r.done({ package: name, version, url: `https://www.npmjs.com/package/${name}` });
  },
});
