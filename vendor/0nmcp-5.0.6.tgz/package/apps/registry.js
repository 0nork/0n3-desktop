/**
 * MINI-APPS — a named outcome, not a named endpoint.
 *
 *   services · service_info · api_call   →  113 REST services, one call each
 *   apps     · app_info     · app_run    →  a whole job, many calls, one receipt
 *
 * `api_call` is a verb. A mini-app is a RESULT: "set Google up for this domain"
 * is nine calls across four services, and nobody clicking a button in 0nCore
 * should have to know that. The tool surface stays at +3 no matter how many
 * apps exist, which is the same bargain the six generic tools already make.
 *
 * ═══ WHAT EVERY APP MUST DO ═══
 *
 * 1. DECLARE WHAT IT NEEDS, so `app_info` can tell a user what to connect
 *    BEFORE they run it and get a failure four steps in.
 * 2. RETURN A RECEIPT — every step, what it did, what came back. An app that
 *    says only "ok" is unauditable, and these apps write to people's Google
 *    and DNS.
 * 3. NEVER PRETEND. A step that could not run is `skipped` with a reason; a
 *    step that failed is `failed` with the provider's own words. Partial
 *    success is reported as partial, because an app that writes four things and
 *    fails on the fifth has still written four things and the user must know.
 */

/** @typedef {{ ok: boolean, step: string, detail?: string, data?: any, status?: number }} StepResult */

export class Receipt {
  constructor(app, inputs) {
    this.app = app;
    this.inputs = inputs;
    this.steps = [];
    this.startedAt = new Date().toISOString();
  }
  ok(step, data, status) { this.steps.push({ step, state: 'ok', status, data }); return data; }
  skip(step, why) { this.steps.push({ step, state: 'skipped', why }); return null; }
  fail(step, why, status) { this.steps.push({ step, state: 'failed', why, status }); return null; }
  /** The shape every app returns. `complete` is false the moment anything failed. */
  done(summary = {}) {
    const failed = this.steps.filter((s) => s.state === 'failed');
    return {
      app: this.app,
      complete: failed.length === 0,
      // Said plainly, because "ok: true" with three failures underneath is how
      // a caller learns to stop reading the rest.
      outcome: failed.length === 0 ? 'Everything requested was done.'
        : `${this.steps.filter((s) => s.state === 'ok').length} of ${this.steps.length} steps done — ${failed.length} failed. See steps.`,
      ...summary,
      startedAt: this.startedAt,
      finishedAt: new Date().toISOString(),
      steps: this.steps,
    };
  }
}

const REGISTRY = new Map();

/**
 * @param {{ key: string, name: string, what: string, needs: {service: string, why: string, optional?: boolean}[],
 *           inputs: Record<string, {type: string, required?: boolean, describe: string}>,
 *           run: (ctx: any) => Promise<any> }} app
 */
export function defineApp(app) {
  for (const f of ['key', 'name', 'what', 'needs', 'inputs', 'run']) {
    if (!app[f]) throw new Error(`mini-app is missing "${f}"`);
  }
  REGISTRY.set(app.key, app);
  return app;
}

export const listApps = () => [...REGISTRY.values()].map(({ key, name, what, needs, inputs, noConnections }) => ({
  key, name, what, ...(noConnections ? { noConnections } : {}),
  needs: needs.map((n) => ({ service: n.service, why: n.why, optional: !!n.optional })),
  inputs: Object.fromEntries(Object.entries(inputs).map(([k, v]) => [k, { type: v.type, required: !!v.required, describe: v.describe }])),
}));

export const getApp = (key) => REGISTRY.get(key) || null;

/** Load every app so importing the registry is enough to have them all. */
export async function loadApps() {
  await import('./google-site-setup.js');
  await import('./hostinger-site-launch.js');
  await import('./npm-publish-mcp.js');
  await import('./desk-request.js');
  return REGISTRY.size;
}
