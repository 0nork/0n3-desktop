import { defineApp, Receipt } from './registry.js';

/**
 * 0nHOSTINGER — "put this domain live on Hostinger" as one call.
 *
 * Mike, 2026-09-30: "we can start writing a bunch of connections to them and
 * probably offer a full solution with CRO9 and auto build the website too."
 * This is the first connection: a domain goes from a name to a served site.
 *
 *   domains        get_domain_list           → is the domain already in the portfolio?
 *   domains        purchase_new_domain       → buy it (ONLY when buy_domain:true — it costs money)
 *   agency-hosting list_orders               → an agency plan to put the site on   ┐ one of
 *   hosting        list_orders               → or a regular hosting plan          ┘ these
 *   agency-hosting create_a_new_website      → the site (WordPress flavour by default)
 *   agency-hosting get_website_setup_status  → polled until Hostinger says it is up
 *   agency-hosting link_domain_to_website    → the domain points at it
 *   dns            update_dns_records        → A record, when the zone is at Hostinger
 *   wordpress      deploy_wordpress_plugin   → e.g. the CRO9 SXO Sync plugin, when asked
 *
 * ═══ MEASURED BEFORE THIS WAS WRITTEN (2026-09-30, Mike's account) ═══
 * The billing catalog sells DOMAINS (899 TLDs), VPS (8) and EMAIL by API —
 * NOT shared or agency hosting plans. A hosting plan is bought once in hPanel;
 * after that this app creates as many sites under it as the plan allows. With
 * no plan on the account the app stops at "no hosting order" and says so,
 * because inventing a website to put a domain on is not a thing.
 *
 * Nothing here is guessed to have succeeded: every Hostinger answer lands in
 * the receipt with its status, and a setup that is still "in progress" when
 * polling stops is reported as in progress, not as live.
 */
const bare = (d) => String(d || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

defineApp({
  key: 'hostinger_site_launch',
  name: 'Launch a site on Hostinger',
  what: 'Puts a domain live on Hostinger: buys the domain if asked, creates the website on the account\'s agency or hosting plan (WordPress by default), links the domain, writes the DNS A record when the zone is at Hostinger, and deploys plugins such as the CRO9 SXO Sync plugin. Returns the website id, its IP and what is still pending.',
  needs: [
    { service: 'hostinger', why: 'Everything runs on the account\'s Hostinger API token (hPanel → Account → API).' },
  ],
  inputs: {
    domain: { type: 'string', required: true, describe: 'Bare domain, e.g. example.com' },
    buy_domain: { type: 'boolean', describe: 'Purchase the domain through Hostinger if it is not in the portfolio. Costs money; default false.' },
    payment_method_id: { type: 'string', describe: 'Hostinger payment method id for the purchase (billing → payment methods). Required when buy_domain is true.' },
    flavor: { type: 'string', describe: 'Website flavour for an agency plan: wordpress (default) | empty | nodejs' },
    datacenter_code: { type: 'string', describe: 'Agency-plan datacenter code (agency-hosting → datacenters). Defaults to the first one Hostinger lists.' },
    order_id: { type: 'string', describe: 'Which hosting / agency order to create the site under. Defaults to the first active one.' },
    settings: { type: 'object', describe: 'Extra website setup settings passed straight to Hostinger (e.g. WordPress admin email / title).' },
    dns: { type: 'boolean', describe: 'Write the A record when the domain\'s DNS zone is at Hostinger. Default true.' },
    plugins: { type: 'array', describe: 'WordPress plugins to deploy after setup: [{ slug, plugin_path }] — plugin_path is a public zip URL. CRO9 SXO Sync goes here.' },
    wait_seconds: { type: 'number', describe: 'How long to poll the setup before reporting it as still in progress. Default 90.' },
  },

  async run({ input, call, r = new Receipt('hostinger_site_launch', {}) }) {
    const domain = bare(input.domain);
    if (!domain || !domain.includes('.')) return r.done({ error: `"${input.domain}" is not a domain. Pass a bare domain like example.com.` });
    const list = (d) => (Array.isArray(d) ? d : Array.isArray(d?.data) ? d.data : []);

    // 1. the domain: in the portfolio, or bought on request, or somebody else's
    const port = await call('hostinger', 'domains_get_domain_list', {});
    const owned = port.ok ? list(port.data).find((x) => bare(x.domain) === domain) : null;
    let domainState = 'elsewhere';
    if (!port.ok) r.fail('list_domains', port.error, port.status);
    else if (owned) { r.ok('domain_in_portfolio', { domain, status: owned.status, type: owned.type }, port.status); domainState = 'hostinger'; }
    else if (input.buy_domain) {
      if (!input.payment_method_id) r.fail('buy_domain', 'buy_domain is true but no payment_method_id was given (billing → payment methods).');
      else {
        const avail = await call('hostinger', 'domains_check_domain_availability', { domain: domain.split('.')[0], tlds: [domain.split('.').slice(1).join('.')] });
        const ok = avail.ok && list(avail.data).some((x) => bare(x.domain) === domain && x.is_available !== false);
        if (!ok) r.fail('buy_domain', avail.ok ? `${domain} is not available to buy` : avail.error, avail.status);
        else {
          const buy = await call('hostinger', 'domains_purchase_new_domain', { domain, item_id: `hostingercom-domain-${domain.split('.').slice(1).join('').replace(/\./g, '')}`, payment_method_id: input.payment_method_id });
          if (buy.ok) { r.ok('buy_domain', buy.data, buy.status); domainState = 'hostinger'; } else r.fail('buy_domain', buy.error, buy.status);
        }
      }
    } else r.skip('buy_domain', `${domain} is not in the Hostinger portfolio; pass buy_domain:true and a payment_method_id to buy it, or point its DNS at the site by hand.`);

    // 2. somewhere to put the site: an agency order first, then a regular hosting order
    const agency = await call('hostinger', 'agency_hosting_list_orders', {});
    const agencyOrders = agency.ok ? list(agency.data) : [];
    const hosting = agencyOrders.length ? { ok: true, data: [] } : await call('hostinger', 'hosting_list_orders', {});
    const hostingOrders = hosting.ok ? list(hosting.data) : [];
    const pick = (orders) => (input.order_id ? orders.find((o) => String(o.id || o.order_id) === String(input.order_id)) : orders.find((o) => /active/i.test(String(o.status || 'active'))) || orders[0]);
    const agencyOrder = pick(agencyOrders); const hostingOrder = agencyOrder ? null : pick(hostingOrders);
    if (!agencyOrder && !hostingOrder) {
      r.fail('find_hosting_plan', agency.ok || hosting.ok ? 'This Hostinger account has no agency or hosting plan to put a website on. Plans are bought in hPanel (the API sells domains, VPS and email only); buy one once and run again.' : agency.error || hosting.error);
      return r.done({ domain, website: null });
    }

    // 3. the website
    let website = null;
    if (agencyOrder) {
      const orderId = String(agencyOrder.id || agencyOrder.order_id);
      let dc = input.datacenter_code;
      if (!dc) { const dcs = await call('hostinger', 'agency_hosting_list_available_datacenters', { order_id: orderId }); dc = dcs.ok ? (list(dcs.data)[0]?.code || list(dcs.data)[0]?.datacenter_code || list(dcs.data)[0]) : null; if (!dc) r.fail('pick_datacenter', dcs.ok ? 'Hostinger listed no datacenter for this order' : dcs.error, dcs.status); }
      if (dc) {
        const setup = await call('hostinger', 'agency_hosting_create_a_new_website', { order_id: orderId, datacenter_code: dc, flavor: input.flavor || 'wordpress', settings: { domain, ...(input.settings || {}) } });
        if (!setup.ok) r.fail('create_website', setup.error, setup.status);
        else {
          r.ok('create_website', setup.data, setup.status);
          const setupId = setup.data?.uuid || setup.data?.setup_uuid || setup.data?.data?.uuid;
          const deadline = Date.now() + (Number(input.wait_seconds) || 90) * 1000;
          let status = null;
          while (setupId && Date.now() < deadline) {
            const st = await call('hostinger', 'agency_hosting_get_website_setup_status', { order_id: orderId, setup_uuid: setupId });
            status = st.ok ? st.data : null;
            const state = String(status?.status || status?.state || '').toLowerCase();
            if (/complete|finished|success|ready|active/.test(state)) break;
            if (/fail|error/.test(state)) { r.fail('website_setup', `Hostinger reported ${state}`, st.status); break; }
            await sleep(5000);
          }
          const state = String(status?.status || status?.state || 'unknown').toLowerCase();
          website = { uid: status?.website_uid || status?.website?.uid || setup.data?.website_uid || null, state, ip: status?.ip || status?.website?.ip || null, order_id: orderId };
          if (/complete|finished|success|ready|active/.test(state)) r.ok('website_setup', website);
          else if (!r.steps.some((s) => s.step === 'website_setup')) r.skip('website_setup', `Setup is still "${state}" after ${Number(input.wait_seconds) || 90}s — run again with the same domain to continue; nothing is lost.`);
          if (website.uid) {
            const link = await call('hostinger', 'agency_hosting_link_domain_to_website', { website_uid: website.uid, domain });
            if (link.ok) r.ok('link_domain', link.data, link.status); else r.fail('link_domain', link.error, link.status);
          }
        }
      }
    } else {
      const orderId = String(hostingOrder.id || hostingOrder.order_id);
      const made = await call('hostinger', 'hosting_create_website', { domain, order_id: orderId });
      if (!made.ok) r.fail('create_website', made.error, made.status);
      else { r.ok('create_website', made.data, made.status); website = { uid: made.data?.uid || made.data?.id || null, state: String(made.data?.status || 'created'), ip: made.data?.ip || null, order_id: orderId }; }
    }

    // 4. DNS, only when the zone is at Hostinger and we know the IP
    if (input.dns !== false && domainState === 'hostinger' && website?.ip) {
      const cur = await call('hostinger', 'dns_get_dns_records', { domain });
      if (!cur.ok) r.fail('read_dns', cur.error, cur.status);
      else {
        const upd = await call('hostinger', 'dns_update_dns_records', { domain, overwrite: false, zone: [{ name: '@', type: 'A', ttl: 3600, records: [{ content: website.ip }] }, { name: 'www', type: 'CNAME', ttl: 3600, records: [{ content: `${domain}.` }] }] });
        if (upd.ok) r.ok('write_dns', { a: website.ip, www: domain }, upd.status); else r.fail('write_dns', upd.error, upd.status);
      }
    } else r.skip('write_dns', domainState !== 'hostinger' ? 'The domain is not at Hostinger — point its A record at the site\'s IP at your registrar.' : website?.ip ? 'dns:false' : 'No IP yet — DNS is written on the next run once the setup finishes.');

    // 5. plugins (CRO9 SXO Sync lives here)
    for (const p of Array.isArray(input.plugins) ? input.plugins : []) {
      if (!p?.slug || !p?.plugin_path) { r.fail('deploy_plugin', 'each plugin needs { slug, plugin_path }'); continue; }
      const dep = await call('hostinger', 'wordpress_deploy_wordpress_plugin', { username: input.settings?.username || hostingOrder?.username || agencyOrder?.username || '', domain, slug: p.slug, plugin_path: p.plugin_path });
      if (dep.ok) r.ok(`deploy_plugin:${p.slug}`, dep.data, dep.status); else r.fail(`deploy_plugin:${p.slug}`, dep.error, dep.status);
    }

    return r.done({ domain, website, next: website?.state && !/complete|finished|success|ready|active/.test(website.state) ? 'Run again with the same domain once Hostinger finishes the setup.' : undefined });
  },
});
