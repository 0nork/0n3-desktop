import { defineApp } from './registry.js';

/**
 * TRUCK ROUTE CHECK (Mike 2026-11-10: "our own builtin mapping that we can build just for trucking").
 *
 * One call, one receipt: where the two places are (OpenStreetMap's Nominatim, no key), the road route with its miles and
 * hours (GraphHopper — one routing request), and what a truck cares about ALONG that road, asked of OpenStreetMap itself
 * through Overpass: posted bridge heights, weight limits, roads closed to trucks, truck fuel, weigh stations, rest areas.
 *
 * What it is NOT, said in the receipt every time:
 *   - Not a truck-legal route. GraphHopper's truck profile is not on the connected plan (it answers "the profile parameter
 *     can only be one of [car, bike, foot]"), so the line is a CAR route; this app tries truck first and says which it got.
 *   - Not a survey. OpenStreetMap only knows a bridge height somebody mapped. No entry is not clearance.
 *   - "Near the route" is measured to the route line; a posted limit on a cross street or a parallel road shows up too.
 *
 * Costs: 1 GraphHopper routing request (2 when truck is refused first), 2 Nominatim lookups spaced over a second apart
 * (their limit is one a second), 1 Overpass query bounded to the route line with a timeout.
 */

const MI = 1609.344;
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

/** "41.24,-82.61" → [lat, lng]; anything else → null (it is a place name). */
export function parseCoord(v) {
  const m = /^\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*$/.exec(String(v ?? ''));
  if (!m) return null;
  const lat = Number(m[1]), lng = Number(m[2]);
  return Math.abs(lat) <= 90 && Math.abs(lng) <= 180 ? [lat, lng] : null;
}

/** A posted height as metres: "4.1", "4.1 m", "13'6\"", "13 ft 6 in", "13.5 ft". null when it is not a number ("default", "none"). */
export function heightMetres(raw) {
  const s = String(raw ?? '').trim().toLowerCase();
  if (!s) return null;
  let m = /^(\d+(?:\.\d+)?)\s*(m|meter|metre|meters|metres)?$/.exec(s);
  if (m) return Number(m[1]);
  m = /^(\d+)\s*(?:'|ft|feet)\s*(?:(\d+(?:\.\d+)?)\s*(?:"|in|inch|inches)?)?$/.exec(s);
  if (m) return Math.round((Number(m[1]) * 0.3048 + Number(m[2] || 0) * 0.0254) * 100) / 100;
  m = /^(\d+(?:\.\d+)?)\s*(?:ft|feet|')$/.exec(s);
  if (m) return Math.round(Number(m[1]) * 0.3048 * 100) / 100;
  return null;
}

/** Keep at most `max` points of a line, evenly, always the first and the last. */
export function thin(points, max) {
  if (points.length <= max) return points;
  const out = []; const step = (points.length - 1) / (max - 1);
  for (let i = 0; i < max; i++) out.push(points[Math.round(i * step)]);
  return out;
}

/** The Overpass query: everything a truck cares about within `nearM` of the route line (restrictions) and `stopM` (places to stop). */
export function corridorQuery(latlngs, { nearM = 300, stopM = 2500, timeout = 60 } = {}) {
  const line = latlngs.map(([la, lo]) => `${la.toFixed(5)},${lo.toFixed(5)}`).join(',');
  const near = `(around:${nearM},${line})`, stop = `(around:${stopM},${line})`;
  return `[out:json][timeout:${timeout}];(` +
    `way${near}[maxheight];way${near}["maxheight:physical"];way${near}[maxweight];way${near}[hgv=no];` +
    `nwr${stop}[amenity=fuel][hgv=yes];nwr${stop}[highway=rest_area];nwr${stop}[highway=services];nwr${stop}[amenity=weighbridge];` +
    `);out center tags 600;`;
}

const TRUCK_HEIGHT_M = 4.11; // 13 ft 6 in — the standard US trailer height

/** Sort Overpass elements into what they mean for a truck. */
export function classify(elements) {
  const at = (e) => { const la = e.lat ?? e.center?.lat, lo = e.lon ?? e.center?.lon; return la == null || lo == null ? null : { lat: Math.round(la * 1e5) / 1e5, lng: Math.round(lo * 1e5) / 1e5 }; };
  const out = { lowClearance: [], heightPosted: [], weightLimits: [], noTrucks: [], truckFuel: [], restAreas: [], weighStations: [] };
  const seen = new Set();
  for (const e of elements || []) {
    const t = e.tags || {}; const where = at(e); if (!where) continue;
    const id = `${e.type}/${e.id}`; if (seen.has(id)) continue; seen.add(id);
    const base = { ...where, name: t.name || t.ref || null, osm: id };
    const hRaw = t.maxheight ?? t['maxheight:physical'];
    if (hRaw != null) {
      const m = heightMetres(hRaw);
      const row = { ...base, posted: String(hRaw), metres: m, road: t.highway || null };
      if (m != null && m < TRUCK_HEIGHT_M) out.lowClearance.push(row); else out.heightPosted.push(row);
    }
    if (t.maxweight != null) out.weightLimits.push({ ...base, posted: String(t.maxweight), road: t.highway || null });
    if (t.hgv === 'no' && t.highway) out.noTrucks.push({ ...base, road: t.highway });
    if (t.amenity === 'fuel' && t.hgv === 'yes') out.truckFuel.push({ ...base, brand: t.brand || null });
    if (t.highway === 'rest_area' || t.highway === 'services') out.restAreas.push({ ...base, kind: t.highway === 'services' ? 'service plaza' : 'rest area' });
    if (t.amenity === 'weighbridge') out.weighStations.push(base);
  }
  out.lowClearance.sort((a, b) => (a.metres ?? 99) - (b.metres ?? 99));
  return out;
}

defineApp({
  key: 'truck_route_check',
  name: 'Truck route check',
  what: 'Road miles and drive time between two places, plus what OpenStreetMap knows a truck should watch for along that road: posted bridge heights under 13 ft 6 in, weight limits, roads closed to trucks, truck fuel, weigh stations and rest areas. One receipt.',
  needs: [
    { service: 'graphhopper', why: 'The road route, its miles and its drive time come from GraphHopper (one routing request per run).' },
  ],
  inputs: {
    origin: { type: 'string', required: true, describe: 'Where the truck starts: a place ("Norwalk, OH") or coordinates as "lat,lng"' },
    destination: { type: 'string', required: true, describe: 'Where it ends: a place ("Jefferson City, TN") or coordinates as "lat,lng"' },
    near_feet: { type: 'number', describe: 'How close to the route line a posted limit must be to be listed (default 1000 ft, max 3000)' },
    stop_miles: { type: 'number', describe: 'How far off the route to look for truck fuel, rest areas and weigh stations (default 1.5 miles, max 5)' },
  },
  async run({ input, call, r }) {
    const nearM = Math.round(Math.min(3000, Math.max(100, Number(input.near_feet) || 1000)) * 0.3048);
    const stopM = Math.round(Math.min(5, Math.max(0.25, Number(input.stop_miles) || 1.5)) * MI);

    // 1. WHERE — coordinates as given, or OpenStreetMap's own search (one request per second at most).
    const places = []; let asked = false;
    for (const key of ['origin', 'destination']) {
      const raw = String(input[key] ?? '').trim();
      if (!raw) { r.fail(`find the ${key}`, `${key} is required`); return r.done(); }
      const c = parseCoord(raw);
      if (c) { places.push({ label: raw, lat: c[0], lng: c[1] }); r.ok(`find the ${key}`, { given: raw, as: 'coordinates' }); continue; }
      if (asked) await sleep(1100); asked = true;
      const g = await call('nominatim', 'search', { q: raw, limit: 1, countrycodes: 'us,ca,mx' });
      const hit = Array.isArray(g.data) ? g.data[0] : null;
      if (!g.ok || !hit) { r.fail(`find the ${key}`, g.ok ? `OpenStreetMap found no place called "${raw}"` : (g.error || `HTTP ${g.status}`), g.status); return r.done(); }
      places.push({ label: hit.display_name, lat: Number(hit.lat), lng: Number(hit.lon) });
      r.ok(`find the ${key}`, { given: raw, found: hit.display_name, lat: Number(hit.lat), lng: Number(hit.lon) }, g.status);
    }

    // 2. THE ROAD — truck first; the plan may refuse it, and then the receipt says the line is a car route.
    const points = places.map((p) => [p.lng, p.lat]);
    let route = null, profile = null, usage = null;
    for (const p of ['truck', 'car']) {
      const g = await call('graphhopper', 'route', { points, profile: p, calc_points: true, points_encoded: false, instructions: false });
      usage = g.usage || usage;
      const path = g.data?.paths?.[0];
      if (g.ok && path) { route = path; profile = p; r.ok(`route it (${p} profile)`, { miles: Math.round(path.distance / MI * 10) / 10, hours: Math.round(path.time / 360000) / 10, ...(g.usage ? { credits: g.usage } : {}) }, g.status); break; }
      const why = g.data?.message || g.error || `HTTP ${g.status}`;
      if (p === 'truck') r.skip('route it (truck profile)', `GraphHopper refused the truck profile: ${why}`);
      else { r.fail('route it (car profile)', why, g.status); return r.done({ places }); }
    }
    const coords = route.points?.coordinates || [];
    if (coords.length < 2) { r.fail('read the route line', 'GraphHopper returned no line for this route'); return r.done({ places }); }

    // 3. WHAT A TRUCK CARES ABOUT ALONG IT — OpenStreetMap's public query server is slow and often full, and this whole run
    // has 60 seconds. So the route is asked in two halves AT THE SAME TIME (the server allows two at once), each capped; a
    // half that does not answer is reported as NOT CHECKED with its mile range — never as "nothing found".
    const all = coords.map(([lng, lat]) => [lat, lng]);
    const totalMi = route.distance / MI;
    const halves = totalMi < 60 ? [all] : [all.slice(0, Math.ceil(all.length / 2) + 1), all.slice(Math.ceil(all.length / 2))];
    const span = (i) => halves.length === 1 ? [0, Math.round(totalMi)] : i === 0 ? [0, Math.round(totalMi / 2)] : [Math.round(totalMi / 2), Math.round(totalMi)];
    const answers = await Promise.all(halves.map((h) => call('overpass', 'query', { data: corridorQuery(thin(h, 110), { nearM, stopM, timeout: 35 }) })));
    const elements = []; const checked = [], notChecked = [];
    answers.forEach((q, i) => {
      const [m0, m1] = span(i); const label = `ask OpenStreetMap along miles ${m0}–${m1}`;
      // Overpass answers 200 with a "remark" and no elements when the query ran out of time or memory: that is a failure.
      if (q.ok && Array.isArray(q.data?.elements) && !q.data.remark) { elements.push(...q.data.elements); checked.push([m0, m1]); r.ok(label, { elements: q.data.elements.length }, q.status); }
      else { notChecked.push([m0, m1]); r.fail(label, q.data?.remark || q.data?.message || (typeof q.data === 'string' ? q.data.replace(/<[^>]+>/g, ' ').replace(/[#*]/g, '').replace(/\s+/g, ' ').trim().slice(0, 220) : (q.error || `HTTP ${q.status}`)), q.status); }
    });
    const found = checked.length ? classify(elements) : null;

    return r.done({
      from: places[0], to: places[1],
      miles: Math.round(route.distance / MI * 10) / 10,
      hours: Math.round(route.time / 360000) / 10,
      profile,
      profileNote: profile === 'truck' ? 'Routed with GraphHopper\'s truck profile.' : 'This is a CAR route: the connected GraphHopper plan does not include the truck profile, so the line does not avoid low bridges or truck-restricted roads by itself. The lists below are what OpenStreetMap has posted near that line.',
      lookedWithin: { postedLimitsFeet: Math.round(nearM / 0.3048), stopsMiles: Math.round(stopM / MI * 100) / 100 },
      checkedMiles: checked, notCheckedMiles: notChecked,
      ...(notChecked.length ? { notCheckedNote: `OpenStreetMap's public server did not answer for miles ${notChecked.map(([x, y]) => `${x}–${y}`).join(' and ')}. Nothing is known about that stretch from this run; run it again.` } : {}),
      ...(found ? {
        counts: Object.fromEntries(Object.entries(found).map(([k, v]) => [k, v.length])),
        lowClearance: found.lowClearance.slice(0, 40),
        weightLimits: found.weightLimits.slice(0, 40),
        noTrucks: found.noTrucks.slice(0, 40),
        truckFuel: found.truckFuel.slice(0, 60),
        weighStations: found.weighStations.slice(0, 40),
        restAreas: found.restAreas.slice(0, 60),
        heightPostedAtOrOver13ft6: found.heightPosted.length,
      } : {}),
      caveats: [
        'OpenStreetMap lists only limits somebody mapped. A bridge with no entry is not a cleared bridge.',
        'Limits are listed when they are near the route LINE; a posted limit on a cross street or a parallel road is listed too. Check each one on the map before relying on it.',
        'Low clearance = a posted height under 13 ft 6 in (4.11 m).',
      ],
      ...(usage ? { graphhopperCredits: usage } : {}),
    });
  },
});
