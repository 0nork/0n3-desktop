/**
 * SIGNED DESK JOBS (2026-10-29).
 *
 * The server signs what it hands a desk — the claimed run (request + the whole thread) and the desk config (folder,
 * rules, agent) — with an Ed25519 key that lives only in the deploy's environment (ON3_DESK_SIGNING_KEY), never in the
 * database. Each desk pins the public key the first time it sees it (~/.0n/desk-trust.json) and from then on refuses
 * anything unsigned, signed by another key, altered, or older than ten minutes.
 *
 * What this stops: a job planted or edited directly in the database, a job altered in transit, an old job replayed,
 * and a server that quietly stops signing. What it does NOT stop: someone holding the account's 0n token queueing a
 * real job through the API — the server signs that, because it is a real job. That is what the token is for; guard
 * the token (and the allow list on each computer limits where any job can work).
 */
import { createPrivateKey, createPublicKey, sign, verify, createHash } from 'node:crypto';

/** Stable JSON: keys sorted at every depth, so the same value signs the same after a JSON round trip. */
export function canon(v) {
  if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
  if (Array.isArray(v)) return `[${v.map(canon).join(',')}]`;
  return `{${Object.keys(v).filter((k) => v[k] !== undefined).sort().map((k) => `${JSON.stringify(k)}:${canon(v[k])}`).join(',')}}`;
}

let cached = null;
export function deskKey(env = process.env) {
  const pem = env.ON3_DESK_SIGNING_KEY; if (!pem) return null;
  if (cached && cached.pem === pem) return cached.k;
  const priv = createPrivateKey(pem.replace(/\\n/g, '\n'));
  const x = createPublicKey(priv).export({ format: 'jwk' }).x;
  const k = { priv, x, kid: createHash('sha256').update(x).digest('hex').slice(0, 16) };
  cached = { pem, k }; return k;
}
export const publicKeys = (env = process.env) => { const k = deskKey(env); return { keys: k ? [{ kty: 'OKP', crv: 'Ed25519', kid: k.kid, x: k.x, use: 'desk' }] : [] }; };

/** Sign `body` for `kind` ('claim' | 'config'). Null when the deploy has no key (desks that never pinned one carry on). */
export function signFor(kind, body, env = process.env, now = Date.now()) {
  const k = deskKey(env); if (!k) return null;
  const iat = Math.floor(now / 1000);
  return { kid: k.kid, iat, sig: sign(null, Buffer.from(canon({ v: 1, kind, iat, body })), k.priv).toString('base64url') };
}

/** The desk's side. `trust` = the pinned { kid, x }. Returns { ok } or { ok:false, why } in words a person can act on. */
export function verifyFor(kind, body, signature, trust, { now = Date.now(), maxAgeS = 600 } = {}) {
  if (!trust) return { ok: true, unpinned: true };
  if (!signature?.sig) return { ok: false, why: 'the job came without a signature, but this computer trusts only signed jobs' };
  if (signature.kid !== trust.kid) return { ok: false, why: `the job was signed by a different key (${signature.kid}) than the one this computer trusts (${trust.kid})` };
  const age = Math.floor(now / 1000) - Number(signature.iat);
  if (!(age <= maxAgeS && age >= -120)) return { ok: false, why: `the signature is ${age}s old (a replayed or delayed job)` };
  const pub = createPublicKey({ key: { kty: 'OKP', crv: 'Ed25519', x: trust.x }, format: 'jwk' });
  const good = verify(null, Buffer.from(canon({ v: 1, kind, iat: Number(signature.iat), body })), pub, Buffer.from(String(signature.sig), 'base64url'));
  return good ? { ok: true } : { ok: false, why: 'the signature does not match the job (it was changed after 0n3 signed it)' };
}
