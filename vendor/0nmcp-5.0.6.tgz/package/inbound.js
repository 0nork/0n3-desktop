/**
 * INBOUND WEBHOOKS — one receiver for every connected app (Mike, 2026-11-05: Whatnot's webhooks first, "a BUNCH of new
 * applications" after). A connection's events land at https://0n3.app/api/hooks/<id>, are verified against the signing secret
 * the person keeps in their OWN vault, de-duplicated by event id, stored, and answered 2xx at once (Whatnot allows 5 s).
 *
 * Scheme "standard-webhooks" (standardwebhooks.com — Whatnot, Svix-based senders and others):
 *   headers  webhook-id · webhook-timestamp (unix s) · webhook-signature ("v1,<base64>" entries, space-separated)
 *   signed   `${id}.${timestamp}.${raw body}` with HMAC-SHA256, key = base64-decoded secret AFTER its vendor prefix
 *            (Whatnot "wn_wh_", Svix "whsec_") — leaving the prefix on decodes a wrong key and every check fails, silently
 *   window   ±5 minutes on the timestamp; retries keep the id, so the id is the de-duplication key
 *
 * The secret never lives in these tables: a hook row names the vault record (secret_service / secret_label) that holds it.
 */
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';

export const TOLERANCE_S = 5 * 60;
const PREFIXES = /^(wn_wh_|whsec_)/;

/** Verify one Standard Webhooks delivery. Returns { ok, reason }. Never throws on bad input. */
export function verifyStandard(secret, headers, raw, nowS = Math.floor(Date.now() / 1000)) {
  const h = (k) => String(headers?.[k] ?? headers?.[k.toLowerCase()] ?? '');
  const id = h('webhook-id'), ts = h('webhook-timestamp'), sig = h('webhook-signature');
  if (!id || !ts || !sig) return { ok: false, reason: 'missing webhook-id / webhook-timestamp / webhook-signature' };
  const t = Number(ts);
  if (!Number.isFinite(t) || Math.abs(nowS - t) > TOLERANCE_S) return { ok: false, reason: 'timestamp outside the 5-minute window' };
  const keyB64 = String(secret || '').trim().replace(PREFIXES, '');
  if (!keyB64) return { ok: false, reason: 'no signing secret in the vault record' };
  const expected = createHmac('sha256', Buffer.from(keyB64, 'base64')).update(`${id}.${ts}.`).update(Buffer.isBuffer(raw) ? raw : Buffer.from(String(raw))).digest();
  for (const part of sig.split(' ')) {
    const [v, b64] = part.split(',');
    if (v !== 'v1' || !b64) continue;
    const got = Buffer.from(b64, 'base64');
    if (got.length === expected.length && timingSafeEqual(got, expected)) return { ok: true, id, timestamp: t };
  }
  return { ok: false, reason: 'signature does not match' };
}

export class Inbound {
  /** @param {{ rest: any, store: any, base?: string }} o */
  constructor({ rest, store, base = 'https://0n3.app' }) { this.rest = rest; this.store = store; this.base = base.replace(/\/$/, ''); }

  url(id) { return `${this.base}/api/hooks/${id}`; }

  /** A receiving URL for one of this account's connections. The secret stays in the named vault record. */
  async create(accountId, { service, label = null, secretService = null, secretLabel = null, scheme = 'standard-webhooks' }) {
    if (!service) throw new Error('service is required');
    const id = randomBytes(18).toString('base64url');
    await this.rest.insert('inbound_hooks', { id, account_id: accountId, service, label, scheme, secret_service: secretService || service, secret_label: secretLabel || (secretService ? null : label) });
    return { id, url: this.url(id), service, label, scheme, secret_record: secretService || service };
  }

  async list(accountId) {
    const rows = await this.rest.select('inbound_hooks', { account_id: accountId });
    return rows.map((r) => ({ id: r.id, url: this.url(r.id), service: r.service, label: r.label, scheme: r.scheme, secret_record: r.secret_service, created_at: r.created_at, last_event_at: r.last_event_at, events: r.event_count }));
  }

  /** One delivery. Returns { status, body } — 2xx only for a verified (or already-seen) event, 4xx when it fails verification. */
  async receive(hookId, headers, raw) {
    const [hook] = await this.rest.select('inbound_hooks', { id: hookId });
    if (!hook) return { status: 404, body: { error: 'unknown hook' } };
    const env = await this.store.get(hook.account_id, hook.secret_service, hook.secret_label || undefined);
    const c = env?.auth?.credentials || {};
    const secret = c.signing_secret || c.webhook_secret || c.secret;
    const v = verifyStandard(secret, headers, raw);
    if (!v.ok) return { status: 401, body: { error: v.reason } };
    let payload = null; try { payload = JSON.parse(Buffer.isBuffer(raw) ? raw.toString('utf8') : raw); } catch { /* stored as text below */ }
    const row = { hook_id: hookId, account_id: hook.account_id, service: hook.service, event_id: v.id, type: payload?.type || null, payload: payload ?? { raw: String(raw) }, event_at: payload?.timestamp || null };
    // Retries reuse webhook-id: the unique (hook_id, event_id) makes a repeat a no-op, and a repeat is still a success to the sender.
    const fresh = (await this.rest.select('inbound_events', { hook_id: hookId, event_id: v.id }, 'id')).length === 0;
    if (fresh) {
      await this.rest.upsert('inbound_events', row, 'hook_id,event_id');
      await this.rest.rpc('inbound_hook_touch', { p_id: hookId }).catch(() => {});
    }
    return { status: 200, body: { ok: true, duplicate: !fresh } };
  }

  async events(accountId, { service = null, limit = 50 } = {}) {
    const filters = { account_id: accountId, ...(service ? { service } : {}) };
    const rows = await this.rest.select('inbound_events', filters);
    return rows.sort((a, b) => String(b.received_at).localeCompare(String(a.received_at))).slice(0, Math.min(500, Number(limit) || 50))
      .map((r) => ({ id: r.event_id, service: r.service, type: r.type, at: r.event_at, received_at: r.received_at, payload: r.payload }));
  }
}
