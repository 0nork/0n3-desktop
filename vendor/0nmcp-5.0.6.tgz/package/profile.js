/**
 * THE 0n PROFILE — one profile for the whole ecosystem, owned here.
 *
 * Mike, 2026-09-15: "I want you to add a profile into the site. BUT this
 * profile should actually be pull on the 0n3 site and we will feed it over."
 *
 * So 0n3 is the source and every other surface reads it. That is the whole
 * point of one account: a person changes their name or photo once, and 0nTask,
 * 0nCore and 0nmcp.com all show the new one, because none of them keeps a copy.
 *
 * It is stored on the shared `profiles` row the identity layer already reads,
 * so this adds a view and an editor, NOT a second store.
 *
 * READ IT TWO WAYS:
 *   1. the person's own 0n token — that is them, asking for themselves
 *   2. a first-party 0n app holding ON3_INTERNAL_SECRET, naming an email — that
 *      is 0nTask rendering a header for someone already signed in to 0nTask
 * The second exists so a customer never has to paste a token into a sibling app
 * just to see their own face.
 */

/** Columns a profile is made of. Everything else on `profiles` is machinery. */
const FIELDS = 'id, email, full_name, avatar_url, company, website, business_name, brand_color, plan, is_vip, created_at, crm_location_id';

/** Only these may be written. plan, is_vip and the CRM link are NOT editable here. */
const WRITABLE = new Set(['full_name', 'avatar_url', 'company', 'website', 'business_name', 'brand_color']);

const clean = (v) => (typeof v === 'string' ? v.trim().slice(0, 300) : undefined);

/** Shape a row for the wire. Never returns a token, a key or a CRM credential. */
export function shape(p, extra = {}) {
  if (!p) return null;
  return {
    id: p.id,
    email: p.email || null,
    name: p.full_name || null,
    avatarUrl: p.avatar_url || null,
    company: p.company || p.business_name || null,
    website: p.website || null,
    brandColor: p.brand_color || null,
    plan: p.plan || 'free',
    vip: !!p.is_vip,
    memberSince: p.created_at || null,
    /** Whether this account has its own CRM sub-account — what gates client email. */
    hasWorkspace: !!p.crm_location_id,
    ...extra,
  };
}

export async function getProfile(rest, accountId) {
  const p = (await rest.select('profiles', { id: accountId }, FIELDS))[0];
  return p || null;
}

export async function getProfileByEmail(rest, email) {
  const e = String(email || '').trim().toLowerCase();
  if (!e) return null;
  const p = (await rest.select('profiles', { email: e }, FIELDS))[0];
  return p || null;
}

/**
 * Write the editable fields. Silently ignores anything not writable rather than
 * failing the whole call — a client sending `plan` is a client that misread the
 * contract, not a reason to lose the name the person just typed.
 */
export async function patchProfile(rest, accountId, body) {
  const patch = {};
  for (const [k, v] of Object.entries(body || {})) {
    const key = k === 'name' ? 'full_name' : k === 'avatarUrl' ? 'avatar_url' : k === 'brandColor' ? 'brand_color' : k;
    if (!WRITABLE.has(key)) continue;
    const s = clean(v);
    if (s !== undefined) patch[key] = s;
  }
  if (!Object.keys(patch).length) return { ok: false, error: 'Nothing to change.' };
  await rest.update('profiles', { id: accountId }, patch);
  return { ok: true, profile: shape(await getProfile(rest, accountId)) };
}
