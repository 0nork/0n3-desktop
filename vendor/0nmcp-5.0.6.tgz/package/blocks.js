/**
 * THE TABLE BLOCKS (2026-11-11, Mike: "could you have just created a sequence in the 0n3 dashboard to do this exact thing…
 * all these steps should be available in the canvas"). The job they were built from is a real one: a broker emails a
 * SCREENSHOT of a spreadsheet several times a day and its rows have to land in a shared Excel tab without one wrong digit
 * and without undoing anything a person typed there. In code that was five hundred lines only a programmer could read.
 * Here it is five blocks anyone can open:
 *
 *   Email arrives → Get the pictures from the email → Read a picture (twice) → Keep what agrees → Keep rows that pass → Update a table
 *
 * Everything in this file is PURE (no network): the engine (flows.js) does the calls and hands the data in, so each rule
 * below is tested on its own. The safety rules are the product:
 *   · a picture is read more than once, separately, and a row survives only when the readings give it IDENTICALLY;
 *   · when too few rows agree, nothing is written at all;
 *   · a cell a person changed is kept, and named.
 */

export const READ_PROMPT =
  'This image is a table. Return ONLY a JSON array with one object per data row, top to bottom. Use the column headers EXACTLY ' +
  'as printed in the header row as the keys, include EVERY column in EVERY object, and use "" for a cell that is empty in the ' +
  'image. Copy every value exactly as shown: never correct, guess, reformat, or fill a blank cell from the row above. The print ' +
  'is small: read every digit one character at a time, and count the rows before you answer so none is skipped or repeated.';

const str = (v) => (v === null || v === undefined ? '' : String(v));
const norm = (v) => str(v).toUpperCase().replace(/\s+/g, ' ').trim();
const colKey = (v) => str(v).toLowerCase().replace(/[^a-z0-9#]+/g, '');
/** Formatting only, never content: 08:15 = 8:15, 11/05/2026 = 11/5/26. A different digit is still a different value. */
export const cellPrint = (v) => {
  const s = norm(v); let m;
  if ((m = /^(\d{1,2}):(\d{2})(?::00)?$/.exec(s))) return `${Number(m[1])}:${m[2]}`;
  if ((m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/.exec(s))) return `${Number(m[1])}/${Number(m[2])}/${m[3].slice(-2)}`;
  return s;
};

/** What a reader answered → rows. Keys are the reader's own column names, so a column can never slide into its neighbour. */
export function rowsFromReading(text) {
  if (Array.isArray(text)) return text.filter((r) => r && typeof r === 'object' && !Array.isArray(r)).map(cleanRow);
  const t = str(text).replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/```[a-z]*\n?|```/gi, '');
  const a = t.indexOf('['), b = t.lastIndexOf(']');
  if (a < 0 || b <= a) return [];
  let rows; try { rows = JSON.parse(t.slice(a, b + 1)); } catch { return []; }
  return Array.isArray(rows) ? rows.filter((r) => r && typeof r === 'object' && !Array.isArray(r)).map(cleanRow) : [];
}
const cleanRow = (r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [str(k).replace(/\s+/g, ' ').trim(), typeof v === 'object' && v !== null ? JSON.stringify(v) : str(v).trim()]));

/** The row's own name for a column the person typed ("pro" finds "Pro", "Cons St" finds "Cons  St"). */
export function findColumn(row, wanted) {
  const w = colKey(wanted); if (!w) return null;
  return Object.keys(row || {}).find((k) => colKey(k) === w) || null;
}

/** "50%", "0.5", 50 → 0.5. Anything unreadable is the default half. */
export function parseShare(v, dflt = 0.5) {
  const m = /^\s*(\d+(?:\.\d+)?)\s*(%?)\s*$/.exec(str(v)); if (!m) return dflt;
  const n = Number(m[1]); return m[2] || n > 1 ? Math.min(1, n / 100) : n;
}

/**
 * KEEP WHAT AGREES. Two (or more) separate readings of the same picture; a row is kept only when EVERY reading has it and
 * gives every column the same. Everything else is held back and named with the reason, in words a person can check against
 * the picture. `ok` is false when fewer than `min` of the rows agree: the readings cannot be trusted, so nothing goes on.
 */
export function agreeRows(readings, { key = '', min = 0.5 } = {}) {
  const lists = (readings || []).map((r) => rowsFromReading(r));
  const out = { rows: [], held: [], readings: lists.map((l) => l.length), total: 0, share: 0, ok: false, key: '', why: '' };
  if (lists.length < 2) { out.why = 'It needs at least two separate readings to compare.'; return out; }
  if (lists.some((l) => !l.length)) { out.why = `A reading came back with no rows (${lists.map((l) => l.length).join(' and ')} rows).`; return out; }
  const keyName = (key && findColumn(lists[0][0], key)) || Object.keys(lists[0][0])[0];
  out.key = keyName;
  const index = (list) => { const m = new Map(); const twice = new Set(); for (const r of list) { const k = norm(r[findColumn(r, keyName) || keyName]); if (!k) continue; if (m.has(k)) twice.add(k); m.set(k, r); } return { m, twice }; };
  const idx = lists.map(index);
  const all = []; for (const { m } of idx) for (const k of m.keys()) if (!all.includes(k)) all.push(k);
  const blank = lists[0].filter((r) => !norm(r[findColumn(r, keyName) || keyName])).length;
  if (blank) out.held.push({ key: '', why: `${blank} row${blank === 1 ? ' has' : 's have'} nothing in "${keyName}", so ${blank === 1 ? 'it' : 'they'} cannot be matched.` });
  for (const k of all) {
    const rows = idx.map((x) => x.m.get(k));
    if (idx.some((x) => x.twice.has(k))) { out.held.push({ key: k, why: `"${k}" appears twice in one reading.` }); continue; }
    if (rows.some((r) => !r)) { out.held.push({ key: k, why: `Only ${rows.filter(Boolean).length} of ${rows.length} readings saw "${k}".` }); continue; }
    const cols = Object.keys(rows[0]); let diff = null;
    for (const c of cols) {
      const vals = rows.map((r) => cellPrint(r[findColumn(r, c) ?? c]));
      if (vals.some((v) => v !== vals[0])) { diff = { column: c, values: rows.map((r) => str(r[findColumn(r, c) ?? c])) }; break; }
    }
    if (!diff) for (const r of rows.slice(1)) { const extra = Object.keys(r).find((c) => !findColumn(rows[0], c) && norm(r[c])); if (extra) { diff = { column: extra, values: rows.map((x) => str(x[findColumn(x, extra) ?? extra])) }; break; } }
    if (diff) out.held.push({ key: k, column: diff.column, why: `The readings disagree on "${diff.column}": ${diff.values.map((v) => `"${v}"`).join(' vs ')}.` });
    else out.rows.push(rows[0]);
  }
  out.total = all.length + (blank ? blank : 0);
  out.share = out.total ? out.rows.length / out.total : 0;
  out.ok = out.rows.length > 0 && out.share >= min;
  if (!out.ok) out.why = out.rows.length ? `Only ${out.rows.length} of ${out.total} rows agree (${Math.round(out.share * 100)}%), under the ${Math.round(min * 100)}% this step needs. Nothing goes on.` : 'No row was read the same way by every reading. Nothing goes on.';
  return out;
}

/**
 * KEEP ROWS THAT PASS. One rule per line, in plain words, each starting with a column name:
 *   Cons St is not CA, WA, OR        Eqpt Type contains R        Pro is not empty        Miles < 2500
 * A row stays only when every rule is true for it; a dropped row is named with the first rule it broke. A rule that names
 * a column no row has is a PROBLEM, reported — never silently true.
 */
const OPS = [
  [/^is not one of\s+(.*)$/i, (v, x) => !list(x).includes(norm(v))], [/^is one of\s+(.*)$/i, (v, x) => list(x).includes(norm(v))],
  [/^is not empty$/i, (v) => norm(v) !== ''], [/^is empty$/i, (v) => norm(v) === ''],
  [/^(?:does not|doesn't) contain\s+(.*)$/i, (v, x) => !list(x).some((p) => norm(v).includes(p))], [/^contains\s+(.*)$/i, (v, x) => list(x).some((p) => norm(v).includes(p))],
  [/^(?:does not|doesn't) start with\s+(.*)$/i, (v, x) => !list(x).some((p) => norm(v).startsWith(p))], [/^starts with\s+(.*)$/i, (v, x) => list(x).some((p) => norm(v).startsWith(p))],
  [/^is not\s+(.*)$/i, (v, x) => !list(x).includes(norm(v))], [/^(?:is|=|==)\s+(.*)$/i, (v, x) => list(x).includes(norm(v))], [/^!=\s*(.*)$/i, (v, x) => !list(x).includes(norm(v))],
  [/^>=\s*(.*)$/, (v, x) => num(v) >= num(x)], [/^<=\s*(.*)$/, (v, x) => num(v) <= num(x)], [/^>\s*(.*)$/, (v, x) => num(v) > num(x)], [/^<\s*(.*)$/, (v, x) => num(v) < num(x)],
];
const list = (x) => str(x).split(',').map((p) => norm(p.replace(/^["']|["']$/g, ''))).filter((p) => p !== '');
const num = (v) => { const n = Number(str(v).replace(/[$,\s]/g, '')); return Number.isNaN(n) ? NaN : n; };

export function parseRule(line, columns) {
  const text = str(line).replace(/\{\{\s*row\.([^}]+)\}\}/g, '$1').trim(); if (!text || text.startsWith('#')) return null;
  const low = text.toLowerCase();
  // the longest column name the line starts with (so "Cons St" wins over "Cons")
  const col = [...columns].sort((a, b) => b.length - a.length).find((c) => low.startsWith(c.toLowerCase()) && /^(\s|$|[<>=!])/.test(text.slice(c.length)))
    || [...columns].sort((a, b) => b.length - a.length).find((c) => colKey(text).startsWith(colKey(c)) && colKey(c));
  if (!col) return { text, problem: `"${text}" does not start with a column of these rows (${columns.slice(0, 8).join(', ')}${columns.length > 8 ? ', …' : ''}).` };
  let rest = text.slice(col.length).trim();
  if (low.slice(0, col.length) !== col.toLowerCase()) { // matched loosely: walk the same number of letters
    let need = colKey(col).length; let i = 0; for (; i < text.length && need > 0; i++) if (colKey(text[i])) need--; rest = text.slice(i).trim();
  }
  for (const [re, fn] of OPS) { const m = re.exec(rest); if (m) return { text, column: col, test: (v) => fn(v, m[1]) }; }
  return { text, problem: `"${text}": I do not know the comparison "${rest}". Use is, is not, is one of, contains, starts with, is empty, is not empty, >, <, >= or <=.` };
}

export function keepRows(rows, rulesText, { key = '' } = {}) {
  const list0 = rowsFromReading(Array.isArray(rows) ? rows : str(rows));
  const columns = []; for (const r of list0) for (const k of Object.keys(r)) if (!columns.includes(k)) columns.push(k);
  const rules = str(rulesText).split('\n').map((l) => parseRule(l, columns)).filter(Boolean);
  const problems = rules.filter((r) => r.problem).map((r) => r.problem);
  const out = { rows: [], dropped: [], rules: rules.length, problems, ok: !problems.length };
  if (problems.length) return out; // a rule that cannot be read stops the step: a filter must never pass rows by mistake
  const keyName = (key && list0[0] && findColumn(list0[0], key)) || columns[0];
  for (const r of list0) {
    const broke = rules.find((u) => !u.test(r[findColumn(r, u.column) ?? u.column]));
    if (broke) out.dropped.push({ key: str(r[keyName]), why: broke.text }); else out.rows.push(r);
  }
  return out;
}

/** 1 → A, 27 → AA. */
export const colLetter = (n) => { let s = ''; for (let x = n; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s; return s; };
const same = (a, b) => { const x = str(a).trim(), y = str(b).trim(); if (x === y) return true; const nx = Number(x), ny = Number(y); return x !== '' && y !== '' && !Number.isNaN(nx) && !Number.isNaN(ny) && nx === ny; };
export const memKey = (ref, col) => `${norm(ref)}\u0001${colKey(col)}`;

/**
 * UPDATE A TABLE, keeping what people typed. `grid` is the tab as it reads now (row 1 = the header), `rows` what should be
 * in it, `key` the column that names a row, `memory` every cell this step wrote before ({ [memKey(ref, column)]: value }).
 *
 *   · a row whose key is already on the tab is updated IN PLACE; a new one goes under the last used row;
 *   · a cell is written only when it is empty or still reads what this step last wrote there. Anything else was typed or
 *     changed by a person: it is kept and named;
 *   · columns are found by NAME, so a column moved or inserted on the tab costs nothing. A value with no column on the tab
 *     is reported, not dropped in silence.
 *
 * Returns one rectangle to write, with null in every cell that must not be touched (both Excel and Google Sheets leave a
 * null cell exactly as it is).
 */
export function planTable({ grid, text = null, rows, key, map = '', memory = {} }) {
  const out = { ok: false, error: '', keyColumn: '', added: 0, updated: 0, unchanged: 0, kept: [], noColumn: [], skipped: [], patch: null, wrote: [] };
  const header = (grid?.[0] || []).map((c) => str(c).replace(/\s+/g, ' ').trim());
  if (!header.some(Boolean)) { out.error = 'Row 1 of the tab is empty. The first row must hold the column names.'; return out; }
  const list0 = rowsFromReading(Array.isArray(rows) ? rows : str(rows));
  if (!list0.length) { out.ok = true; return out; }
  const width = header.length;
  const at = (name) => { const w = colKey(name); const i = header.findIndex((h) => colKey(h) === w); return i; };
  // "what the row calls it → what the tab calls it", one per line; anything not listed goes to the column of the same name
  const rename = {}; for (const line of str(map).split('\n')) { const m = /^(.*?)\s*(?:→|->|=>)\s*(.*)$/.exec(line.trim()); if (m && m[1].trim() && m[2].trim()) rename[colKey(m[1])] = m[2].trim(); }
  const target = (c) => rename[colKey(c)] || c;
  const keyName = (key && findColumn(list0[0], key)) || Object.keys(list0[0])[0];
  const keyAt = at(target(keyName));
  if (keyAt < 0) { out.error = `The tab has no column called "${target(keyName)}", which is the column that names a row. Its columns are: ${header.filter(Boolean).slice(0, 12).join(', ')}.`; return out; }
  out.keyColumn = header[keyAt];
  const cols = []; for (const r of list0) for (const c of Object.keys(r)) if (!cols.includes(c)) cols.push(c);
  const place = cols.map((c) => ({ c, i: at(target(c)) }));
  out.noColumn = place.filter((p) => p.i < 0).map((p) => target(p.c));
  const body = (grid || []).slice(1);
  const where = new Map(); body.forEach((r, i) => { const k = norm(r?.[keyAt]); if (k && !where.has(k)) where.set(k, i + 1); });
  let last = 0; body.forEach((r, i) => { if ((r || []).some((c) => str(c).trim() !== '')) last = i + 1; });
  const changes = new Map(); // grid row index → array(width) of value|null
  const seen = new Set();
  for (const r of list0) {
    const ref = str(r[keyName]).trim(); const k = norm(ref);
    if (!k) { out.skipped.push({ key: '', why: `A row has nothing in "${keyName}".` }); continue; }
    if (seen.has(k)) { out.skipped.push({ key: ref, why: `"${ref}" is in the rows twice; the first one was used.` }); continue; }
    seen.add(k);
    const isNew = !where.has(k); const gi = isNew ? ++last : where.get(k);
    const now = isNew ? [] : (grid[gi] || []); const line = new Array(width).fill(null); let touched = false;
    for (const { c, i } of place) {
      if (i < 0) continue;
      const want = str(r[c]).trim(); const cur = str(now[i]).trim(); const mem = memory[memKey(ref, header[i])];
      const shown = str(text?.[gi]?.[i]).trim();
      if (same(cur, want) || (shown !== '' && (same(shown, want) || cellPrint(shown) === cellPrint(want)))) { if (want !== '') out.wrote.push({ ref, col: header[i], row: gi, i, cur }); continue; }
      if (!isNew && cur !== '' && (mem === undefined || !same(cur, mem))) { out.kept.push({ key: ref, column: header[i], has: cur, would: want }); continue; }
      if (want === '' && cur === '') continue;
      line[i] = want; touched = true; out.wrote.push({ ref, col: header[i], row: gi, i });
    }
    if (isNew) out.added++; else if (touched) out.updated++; else out.unchanged++;
    if (touched) changes.set(gi, line);
  }
  out.ok = true;
  if (!changes.size) return out;
  const idx = [...changes.keys()].sort((a, b) => a - b); const r0 = idx[0], r1 = idx[idx.length - 1];
  const values = []; for (let g = r0; g <= r1; g++) values.push(changes.get(g) || new Array(width).fill(null));
  out.patch = { address: `A${r0 + 1}:${colLetter(width)}${r1 + 1}`, firstRow: r0 + 1, values };
  return out;
}

/** After the write, the tab is read back: what it HOLDS now is what is remembered (Excel turns "11/12/26" into a date number). */
export function rememberFrom(plan, readBack, memory = {}) {
  const next = { ...memory }; const r0 = plan.patch ? plan.patch.firstRow - 1 : 0;
  for (const w of plan.wrote) {
    if (w.cur !== undefined) { next[memKey(w.ref, w.col)] = str(w.cur).trim(); continue; } // already read what was wanted
    const row = plan.patch ? readBack?.[w.row - r0] : null;
    if (row && row[w.i] !== undefined && row[w.i] !== null) next[memKey(w.ref, w.col)] = str(row[w.i]).trim();
  }
  return next;
}

/** A sharing link or a Google Sheets link → what the API needs. */
export const graphShareId = (url) => `u!${Buffer.from(str(url).trim()).toString('base64').replace(/=+$/, '').replace(/\//g, '_').replace(/\+/g, '-')}`;
export const googleSheetId = (url) => (/\/spreadsheets\/d\/([A-Za-z0-9_-]{20,})/.exec(str(url)) || /^([A-Za-z0-9_-]{30,})$/.exec(str(url).trim()) || [])[1] || '';
export const tabMatch = (names, wanted) => { const n = (s) => str(s).toLowerCase().replace(/[^a-z0-9]/g, ''); if (names.includes(wanted)) return wanted; const hits = names.filter((x) => n(x) === n(wanted)); return hits.length === 1 ? hits[0] : null; };
