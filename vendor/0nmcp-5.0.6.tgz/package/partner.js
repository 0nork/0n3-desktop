/**
 * PARTNER DOOR (2026-11-14) — how a marketplace app on the CRM gives EVERY installer their own 0n3 account.
 *
 * Mike: the public marketplace app ("0n3 Integration Connector", App Studio-built, hosted by the CRM) is the on-ramp to 0n3.
 * Until today it called 0n3 with ONE server secret, Mike's own key, so every installer would have worked in Mike's account.
 * Now the app's backend holds a PARTNER secret instead, and asks for a session per sub-account (location):
 *
 *   - a location seen before                     → its own 0n3 account; a fresh key, the previous one revoked
 *   - a new location, an email 0n3 has never seen → a new 0n3 account is made from the CRM email (the sign-up)
 *   - a new location, an email 0n3 already knows → NOT handed over: the person signs in to 0n3 once and links it
 *                                                   (having someone's email address must never be enough to act as them)
 *
 * One 0n3 account per LOCATION: a sub-account is one business, and everyone on its team works in the same 0n3 account.
 *
 * BILLING (Mike: "$0.10 per action, flat — tests, real runs, everything — billed to their CRM account"). 0n3 keeps the ONE
 * count it already keeps (usage.js, at the audit line); test runs add their steps to it for these accounts. The app's backend
 * drains what is due per location (GET usage), charges the CRM wallet through its marketplace billing meter with its own
 * token, and acknowledges (POST usage/ack), so a retry never bills twice. Only accounts this door CREATED are billed through
 * the CRM; an existing 0n3 account that links keeps its own 0n3 plan (no double billing).
 *
 * When the app also sends the CRM's encrypted SSO payload (`sso`) and ON3_PARTNER_CRM_SSO_KEY (the app's Shared Secret) is
 * set, the person and location are read from that payload, which only the CRM can produce — not from the body.
 */
import crypto from 'node:crypto';

export const PARTNER = 'crm_connector';
export const PRICE_PER_ACTION = 0.10;
const LINK_TTL_MS = 2 * 3600 * 1000;

export const normEmail = (e) => String(e || '').trim().toLowerCase();
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

/** Constant-time check of the partner secret header. */
export function partnerOk(req, env = process.env) {
  const want = env.ON3_PARTNER_CRM_SECRET || '';
  const got = String(req.headers?.['x-0n3-partner'] || '');
  if (!want || got.length !== want.length) return false;
  return crypto.timingSafeEqual(Buffer.from(got), Buffer.from(want));
}

/**
 * The CRM's SSO payload: CryptoJS AES with a passphrase (OpenSSL "Salted__" format, EVP_BytesToKey with MD5), passphrase =
 * the app's Shared Secret. Returns { userId, companyId, activeLocation, email, userName, role, type } or null.
 */
export function decryptSso(payload, sharedSecret) {
  try {
    const raw = Buffer.from(String(payload || ''), 'base64');
    if (raw.slice(0, 8).toString('latin1') !== 'Salted__') return null;
    const salt = raw.slice(8, 16); const data = raw.slice(16);
    const pass = Buffer.from(sharedSecret, 'utf8');
    let d = Buffer.alloc(0); let prev = Buffer.alloc(0);
    while (d.length < 48) { prev = crypto.createHash('md5').update(Buffer.concat([prev, pass, salt])).digest(); d = Buffer.concat([d, prev]); }
    const dec = crypto.createDecipheriv('aes-256-cbc', d.slice(0, 32), d.slice(32, 48));
    const j = JSON.parse(Buffer.concat([dec.update(data), dec.final()]).toString('utf8'));
    return j && typeof j === 'object' ? j : null;
  } catch { return null; }
}

/** Who and where, from the SSO payload when the deployment requires it, else from the body (partner secret only). */
export function sessionClaims(body = {}, env = process.env) {
  const key = env.ON3_PARTNER_CRM_SSO_KEY || '';
  if (key) {
    const s = decryptSso(body.sso, key);
    if (!s) return { error: 'The CRM sign-in payload (sso) is missing or could not be read.' };
    const locationId = s.activeLocation || body.locationId || '';
    if (!locationId) return { error: 'Open the app inside a sub-account.' };
    return { locationId: String(locationId), companyId: String(s.companyId || ''), email: normEmail(s.email), name: String(s.userName || '').slice(0, 120), verified: true };
  }
  const locationId = String(body.locationId || '').trim();
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(locationId)) return { error: 'locationId is required.' };
  return { locationId, companyId: String(body.companyId || '').slice(0, 64), email: normEmail(body.email), name: String(body.name || '').slice(0, 120), locationName: String(body.locationName || '').slice(0, 120), verified: false };
}

/** A short signed code for the "link your existing 0n3 account" page. */
export function signLinkCode(c, env = process.env) {
  const k = env.ON3_PARTNER_CRM_SECRET || env.ON3_VAULT_KEY || '';
  const body = Buffer.from(JSON.stringify({ l: c.locationId, c: c.companyId || '', e: c.email, n: c.locationName || '', x: Date.now() + LINK_TTL_MS })).toString('base64url');
  return `${body}.${crypto.createHmac('sha256', 'partner-link|' + k).update(body).digest('base64url').slice(0, 32)}`;
}
export function verifyLinkCode(code, env = process.env) {
  const k = env.ON3_PARTNER_CRM_SECRET || env.ON3_VAULT_KEY || '';
  const [body, mac] = String(code || '').split('.');
  if (!body || !mac || !k) return null;
  const want = crypto.createHmac('sha256', 'partner-link|' + k).update(body).digest('base64url').slice(0, 32);
  if (mac.length !== want.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(want))) return null;
  let p; try { p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); } catch { return null; }
  if (!p || !p.l || Date.now() > p.x) return null;
  return { locationId: p.l, companyId: p.c, email: p.e, locationName: p.n };
}

/** What is due on one link this month: units counted minus units already acknowledged as billed. */
export function dueOf(link, counted, month) {
  const billed = link.billed_month === month ? Number(link.billed_units || 0) : 0;
  const units = Math.max(0, Number(counted || 0));
  return { units, billed, due: Math.max(0, units - billed), amount: Math.round(Math.max(0, units - billed) * PRICE_PER_ACTION * 100) / 100 };
}

/**
 * The door itself. `rest` is the identity database (profiles, access_tokens, partner_links), `hub` mints/revokes keys,
 * `createUser(email, name)` makes a 0n3 sign-in and returns its account id.
 */
export function createPartner({ rest, hub, usage, createUser, base = 'https://0n3.app', env = process.env }) {
  const linkOf = async (locationId) => (await rest.select('partner_links', { partner: PARTNER, location_id: locationId }, '*'))[0] || null;

  async function freshKey(link, label) {
    const t = await hub.createToken(link.account_id, { name: `CRM app · ${label || link.location_id}`.slice(0, 80), level: 'full', scopes: ['mcp', 'partner:crm'] });
    const rows = await rest.select('access_tokens', { user_id: link.account_id }, 'id, name, created_at, metadata');
    const mine = rows.filter((r) => String(r.name || '').startsWith('CRM app · ')).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    // Keep the newest two (a page that is still open keeps working for one more session); revoke the rest.
    for (const r of mine.slice(2)) await hub.revokeToken(link.account_id, r.id).catch(() => {});
    return t.token;
  }

  async function session(body) {
    const c = sessionClaims(body, env);
    if (c.error) return { status: 400, error: c.error };
    const link = await linkOf(c.locationId);
    if (link && link.status === 'active') {
      const opened = Array.isArray(link.opened_by) ? link.opened_by : [];
      if (c.email && !opened.includes(c.email)) await rest.update('partner_links', { id: link.id }, { opened_by: [...opened, c.email].slice(-50), updated_at: new Date().toISOString() }).catch(() => {});
      return { status: 200, state: 'ready', account: link.account_id, created: !!link.created_account, billing: link.created_account ? 'crm' : '0n3', token: await freshKey(link, c.locationName) };
    }
    if (!c.email || !validEmail(c.email)) return { status: 400, error: 'The CRM did not say who is signed in (email), so no 0n3 account can be made.' };
    const existing = (await rest.select('profiles', { email: c.email }, 'id, email'))[0] || null;
    if (existing) {
      // Someone 0n3 already knows: they link it themselves, signed in. An email address alone never opens an account.
      return { status: 200, state: 'needs_link', email: c.email, linkUrl: `${base}/link/crm?c=${encodeURIComponent(signLinkCode(c, env))}`, say: 'This email already has a 0n3 account. Sign in to 0n3 once to link this sub-account to it.' };
    }
    const accountId = await createUser(c.email, c.name);
    const row = { partner: PARTNER, location_id: c.locationId, company_id: c.companyId || null, location_name: c.locationName || null, account_id: accountId, email: c.email, created_account: true, status: 'active', opened_by: [c.email], verified: !!c.verified };
    await rest.insert('partner_links', row);
    return { status: 200, state: 'ready', account: accountId, created: true, billing: 'crm', token: await freshKey(row, c.locationName) };
  }

  /** The signed-in 0n3 owner links the location in the code to their own account. */
  async function link(accountId, code) {
    const c = verifyLinkCode(code, env);
    if (!c) return { status: 400, error: 'This link has expired. Open the app in the CRM again for a fresh one.' };
    const cur = await linkOf(c.locationId);
    if (cur && cur.status === 'active' && cur.account_id !== accountId) return { status: 409, error: 'That sub-account is already linked to a different 0n3 account.' };
    if (cur) await rest.update('partner_links', { id: cur.id }, { account_id: accountId, status: 'active', updated_at: new Date().toISOString() });
    else await rest.insert('partner_links', { partner: PARTNER, location_id: c.locationId, company_id: c.companyId || null, location_name: c.locationName || null, account_id: accountId, email: c.email, created_account: false, status: 'active', opened_by: c.email ? [c.email] : [] });
    return { status: 200, ok: true, locationId: c.locationId, locationName: c.locationName || null };
  }

  /** What each CRM-billed location owes this month. */
  async function due(month) {
    const links = await rest.select('partner_links', { partner: PARTNER, status: 'active', created_account: true }, '*');
    const out = [];
    for (const l of links) { const m = await usage.month(l.account_id, month); const d = dueOf(l, m.units, month); out.push({ locationId: l.location_id, companyId: l.company_id, account: l.account_id, month, ...d }); }
    return out;
  }

  /** The app says it charged `units` (the running total for the month) for a location. Never moves backwards. */
  async function ack(locationId, month, units) {
    const l = await linkOf(locationId);
    if (!l) return { status: 404, error: 'No such location.' };
    const prev = l.billed_month === month ? Number(l.billed_units || 0) : 0;
    const next = Math.max(prev, Math.floor(Number(units) || 0));
    await rest.update('partner_links', { id: l.id }, { billed_month: month, billed_units: next, updated_at: new Date().toISOString() });
    return { status: 200, ok: true, locationId, month, billed: next };
  }

  /** Is this account billed through the CRM (so test runs count too)? Cached a minute. */
  const cache = new Map();
  async function crmBilled(accountId) {
    const hit = cache.get(accountId); if (hit && Date.now() - hit.at < 60000) return hit.v;
    let v = false; try { v = (await rest.select('partner_links', { account_id: accountId, status: 'active', created_account: true }, 'id')).length > 0; } catch { v = false; }
    cache.set(accountId, { at: Date.now(), v }); return v;
  }

  return { session, link, due, ack, crmBilled };
}
