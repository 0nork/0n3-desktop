/**
 * INSTALL 0n3 INTO ANY AI — connector, skill, add-on, plugin: whatever the AI
 * calls a connected app, this file knows its shape.
 *
 * Ruling (Mike, 2026-10-22): "build it so that 0n3 can simply be installed
 * directly into their AI of choice … all we need is its logic." The logic is
 * one endpoint (POST https://0n3.app/mcp, Streamable HTTP) and one identity
 * (a 0n_ token, or the OAuth 2.1 door for clients that cannot send a header).
 * Every artifact below is that same fact written in one client's dialect.
 *
 * Measured shapes (2026-10-22): Claude Code 2.1.302 `claude mcp add --transport
 * http … --header`; Gemini CLI 0.59.0 `gemini mcp add -t http … -H`; Codex
 * config.toml `[mcp_servers.x] url + bearer_token_env_var` (developers.openai.com/codex/mcp);
 * ChatGPT custom connectors take a URL + OAuth only, never a static header
 * (so they use the OAuth door, which already does dynamic registration).
 * Cursor / VS Code deeplinks and the JSON files are the documented ones.
 *
 * Nothing here stores anything. A client gets its own scoped token, named for
 * it, so one AI can be revoked without touching the rest.
 */
import { createRequire } from 'node:module';
const PKG_VERSION = createRequire(import.meta.url)('./package.json').version;

export const MCP_PATH = '/mcp';

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64');
const json = (o) => JSON.stringify(o, null, 2);
const H = (t) => ({ Authorization: `Bearer ${t}` });

/**
 * Every client 0n3 installs into. `kind` is the client's own word for a
 * connected app. `oauth: true` means the client signs in through the OAuth 2.1
 * door and needs no token at all.
 */
export const INSTALL_CLIENTS = [
  { key: 'claude_code', name: 'Claude Code', kind: 'MCP server + skill', family: 'terminal', what: 'Claude in your Terminal. Paste one line, and Claude can use every app you added.' },
  { key: 'claude', name: 'Claude (desktop & claude.ai)', kind: 'connector', family: 'chat', oauth: true, what: 'The Claude app or claude.ai. Add 0n3 in Settings and sign in once.' },
  { key: 'chatgpt', name: 'ChatGPT', kind: 'connector · GPT action', family: 'chat', oauth: true, what: 'Add 0n3 in ChatGPT\'s settings and sign in once.' },
  { key: 'grok_bot', name: 'Grok Bot (xAI)', kind: 'custom connector', family: 'chat', what: 'xAI\'s always-on Grok Bot. Add 0n3 as a custom connector once, and your Bot can use every app you added, around the clock.' },
  { key: 'codex', name: 'Codex CLI', kind: 'MCP server', family: 'terminal', what: 'OpenAI\'s helper in your Terminal. Paste two lines.' },
  { key: 'gemini_cli', name: 'Gemini CLI', kind: 'MCP server', family: 'terminal', what: 'Google\'s helper in your Terminal. Paste one line.' },
  { key: 'cursor', name: 'Cursor', kind: 'MCP server', family: 'editor', what: 'Click one button and Cursor adds 0n3.' },
  { key: 'vscode', name: 'VS Code (Copilot)', kind: 'MCP server', family: 'editor', what: 'Click one button and VS Code adds 0n3.' },
  { key: 'windsurf', name: 'Windsurf', kind: 'MCP server', family: 'editor', what: 'The mcp_config.json block.' },
  { key: 'cline', name: 'Cline', kind: 'MCP server', family: 'editor', what: 'The cline_mcp_settings.json block.' },
  { key: 'continue', name: 'Continue', kind: 'MCP server', family: 'editor', what: 'The config.yaml block.' },
  { key: 'openai_agents', name: 'OpenAI Agents / Responses API', kind: 'hosted MCP tool', family: 'code', what: 'Pass 0n3 as a hosted MCP tool to the Responses API or the Agents SDK.' },
  { key: 'rest', name: 'Any AI, any language', kind: 'REST + OpenAPI', family: 'code', what: 'Seven plain HTTP operations with a bearer token. The OpenAPI spec drives any agent framework\'s tool loader.' },
  { key: 'desk', name: 'Desk agent (this computer)', kind: 'desktop agent', family: 'terminal', what: 'A helper that lives on your computer. Send it a job from your phone, and your computer does it. If it is not sure, it asks you first. Paste one line to set it up.' },
];

export const installClient = (key) => INSTALL_CLIENTS.find((c) => c.key === key) || null;

/**
 * THE ONE SHAPE PER CLIENT (2026-11-09): what goes into each AI's settings so it can reach 0n3. The Install page prints it
 * (artifactsFor) and the desktop app's setup writes it (desk-setup.js planFor) — from here, so they can never disagree.
 *   root + entry  → a JSON settings file; argv → a command to run; toml / yaml → a text block; steps → for the person
 * Codex: the command path uses an env var (bearer_token_env_var); a settings file written FOR the person cannot set one, so
 * the toml here carries the header itself (http_headers).
 */
export function mcpEntry(key, { mcp, token, name = '0n3' }) {
  const t = token || '<your 0n token>'; const auth = `Authorization: Bearer ${t}`;
  switch (key) {
    case 'claude_code': return { argv: ['claude', 'mcp', 'add', '--transport', 'http', '--scope', 'user', name, mcp, '--header', auth] };
    case 'claude': return { root: 'mcpServers', entry: { command: 'npx', args: ['-y', 'mcp-remote', mcp, '--header', auth] }, steps: ['In Claude, open Settings. Click Connectors. Click Add custom connector.', `For the name, type ${name}. For the URL, type ${mcp}`, 'Click Connect. Sign in with your 0n3 email and password.'] };
    case 'chatgpt': return { steps: ['In ChatGPT, open Settings. Click Connectors (it may say Apps). Click Advanced. Turn on Developer mode.', `Click Create. For the name, type ${name}. For the MCP server URL, type ${mcp}. For Authentication, pick OAuth.`, 'Sign in with your 0n3 email and password.'] };
    case 'codex': return { toml: `[mcp_servers.${name}]\nurl = "${mcp}"\nhttp_headers = { "Authorization" = "Bearer ${t}" }\nstartup_timeout_sec = 15\ntool_timeout_sec = 120\n`, argv: ['codex', 'mcp', 'add', name, '--url', mcp, '--bearer-token-env-var', 'ON3_TOKEN'] };
    case 'gemini_cli': return { root: 'mcpServers', entry: { httpUrl: mcp, headers: H(t) }, argv: ['gemini', 'mcp', 'add', '--scope', 'user', '--transport', 'http', name, mcp, '-H', auth] };
    case 'cursor': return { root: 'mcpServers', entry: { url: mcp, headers: H(t) } };
    case 'vscode': return { root: 'servers', entry: { type: 'http', url: mcp, headers: H(t) } };
    case 'windsurf': return { root: 'mcpServers', entry: { serverUrl: mcp, headers: H(t) } };
    // Grok Bot (docs.x.ai/grok-bot/computer-and-apps): Connect apps → Add a custom connector → Type Remote HTTPS → Server URL + HTTP headers.
    case 'grok_bot': return { steps: ['Open Grok Bot on your computer. In the sidebar, click Connect apps.', 'At the bottom, click Add a custom connector.', `For Name, type ${name}. For Type, pick Remote HTTPS. For Server URL, type ${mcp}.`, `Under HTTP headers, add Authorization with the value Bearer ${t}`, 'Click Add plugin.'] };
    case 'cline': return { root: 'mcpServers', entry: { url: mcp, headers: H(t), disabled: false, alwaysAllow: [] } };
    case 'continue': return { yaml: `  - name: ${name}\n    type: streamable-http\n    url: ${mcp}\n    requestOptions:\n      headers:\n        Authorization: Bearer ${t}\n` };
    default: return {};
  }
}

/**
 * The artifacts for one client. `token` may be null for OAuth-only clients.
 * Each artifact: { label, kind: 'command'|'json'|'toml'|'yaml'|'link'|'steps'|'url'|'text', value, file?, note? }
 */
export function artifactsFor(key, { base, token, name = '0n3' }) {
  const mcp = `${base}${MCP_PATH}`;
  const t = token || '<your 0n token>';
  const E = (k) => mcpEntry(k, { mcp, token: t, name });
  const remote = E('cursor').entry;
  switch (key) {
    case 'claude_code': return [
      { label: 'Paste this in Terminal and press Enter', kind: 'command', value: `claude mcp add --transport http --scope user ${name} ${mcp} --header "Authorization: Bearer ${t}"` },
      { label: 'Then paste this too (it teaches Claude how 0n3 works)', kind: 'command', value: `f=~/.claude/skills/${name}/SKILL.md; mkdir -p "$(dirname "$f")"; if [ ! -s "$f" ] || grep -q 'as tools' "$f"; then curl -fsSL ${base}/api/install/skill -o "$f"; else echo "kept your own $f"; fi`, note: 'Now you can type /0n3 when you talk to Claude.' },
      { label: 'Check that it worked', kind: 'command', value: `claude mcp list`, note: `You should see ${name} with the word connected. Then start Claude and type "whoami". It will list your apps.` },
    ];
    case 'claude': return [
      { label: 'Claude desktop app and claude.ai', kind: 'steps', value: ['In Claude, open Settings. Click Connectors. Click Add custom connector.', `For the name, type ${name}. For the URL, type ${mcp}`, 'Click Connect. Sign in with your 0n3 email and password.', 'Start a new chat. Turn on 0n3 in the tools menu. Type: "whoami"'], note: 'You don\'t need to paste a key. You can turn this off any time in 0n3 under Tokens.' },
      { label: 'Claude Desktop config file (alternative, static token through mcp-remote)', kind: 'json', file: '~/Library/Application Support/Claude/claude_desktop_config.json', value: json({ mcpServers: { [name]: { command: 'npx', args: ['-y', 'mcp-remote', mcp, '--header', `Authorization: Bearer ${t}`] } } }) },
    ];
    case 'grok_bot': return [
      { label: 'Add 0n3 to Grok Bot (desktop app)', kind: 'steps', value: E('grok_bot').steps },
      { label: 'Server URL', kind: 'url', value: mcp },
      { label: 'HTTP header', kind: 'command', value: `Authorization: Bearer ${t}`, note: 'This key is for Grok Bot alone. Revoke it at 0n3.app/tokens any time and only Grok Bot loses access.' },
      { label: 'Then try it: send your Bot this', kind: 'steps', value: ['"Use 0n3: who am I, and which apps can you reach?"', '"Every weekday at 8, use 0n3 to list today\'s CRM appointments and new Stripe payments, and post a summary to me."'] },
      { label: 'Get Grok Bot', kind: 'link', value: 'https://x.ai/bot', note: 'Desktop app for macOS, Windows and Linux; iPhone, iPad and Android apps in the App Store and Google Play. Included with X Premium, Super and Ultra, SuperGrok, and paid Cursor plans.' },
    ];
    case 'chatgpt': return [
      { label: 'Add 0n3 to ChatGPT', kind: 'steps', value: ['In ChatGPT, open Settings. Click Connectors (it may say Apps). Click Advanced. Turn on Developer mode.', `Click Create. For the name, type ${name}. For the MCP server URL, type ${mcp}. For Authentication, pick OAuth.`, 'Sign in with your 0n3 email and password.', 'Start a new chat. Turn on 0n3. Type: "whoami"'], note: 'You don\'t need to paste a key. ChatGPT signs in to 0n3 by itself.' },
      { label: 'Custom GPT → Actions → Import from URL', kind: 'url', value: `${base}/api/install/openapi.json`, note: `Authentication: API key · Auth type Bearer · key = your 0n token. Seven operations: list services, describe one, call an endpoint, list apps, run an app, list connections, whoami.` },
    ];
    case 'codex': return [
      { label: 'First, paste this in Terminal and press Enter', kind: 'command', value: `export ON3_TOKEN="${t}"`, note: 'This tells your computer your 0n3 key.' },
      { label: 'Next, paste this and press Enter', kind: 'command', value: `codex mcp add ${name} --url ${mcp} --bearer-token-env-var ON3_TOKEN` },
      { label: 'Or write it yourself', kind: 'toml', file: '~/.codex/config.toml', value: `[mcp_servers.${name}]\nurl = "${mcp}"\nbearer_token_env_var = "ON3_TOKEN"\nstartup_timeout_sec = 15\ntool_timeout_sec = 120\n` },
    ];
    case 'gemini_cli': return [
      { label: 'Paste this in Terminal and press Enter', kind: 'command', value: `gemini mcp add --scope user --transport http ${name} ${mcp} -H "Authorization: Bearer ${t}"` },
      { label: 'Or write it yourself', kind: 'json', file: '~/.gemini/settings.json', value: json({ mcpServers: { [name]: E('gemini_cli').entry } }) },
    ];
    case 'cursor': return [
      { label: 'Click the button. Cursor opens and adds 0n3.', kind: 'link', value: `cursor://anysphere.cursor-deeplink/mcp/install?name=${encodeURIComponent(name)}&config=${encodeURIComponent(b64(remote))}` },
      { label: 'Or write it yourself', kind: 'json', file: '~/.cursor/mcp.json', value: json({ mcpServers: { [name]: remote } }) },
    ];
    case 'vscode': return [
      { label: 'Click the button. VS Code opens and adds 0n3.', kind: 'link', value: `vscode:mcp/install?${encodeURIComponent(JSON.stringify({ name, type: 'http', url: mcp, headers: H(t) }))}` },
      { label: 'Or write it yourself', kind: 'json', file: '.vscode/mcp.json', value: json({ servers: { [name]: E('vscode').entry } }) },
    ];
    case 'windsurf': return [
      { label: 'Write it yourself', kind: 'json', file: '~/.codeium/windsurf/mcp_config.json', value: json({ mcpServers: { [name]: E('windsurf').entry } }) },
    ];
    case 'cline': return [
      { label: 'Write it yourself', kind: 'json', file: 'cline_mcp_settings.json (Cline → MCP Servers → Configure)', value: json({ mcpServers: { [name]: E('cline').entry } }) },
    ];
    case 'continue': return [
      { label: 'Write it yourself', kind: 'yaml', file: '~/.continue/config.yaml', value: `mcpServers:\n${E('continue').yaml}` },
    ];
    case 'openai_agents': return [
      { label: 'Responses API — hosted MCP tool', kind: 'json', value: json({ model: 'gpt-4.1', tools: [{ type: 'mcp', server_label: name, server_url: mcp, headers: H(t), require_approval: 'never' }], input: 'List my connections with whoami.' }), note: 'POST https://api.openai.com/v1/responses with your OpenAI key.' },
      { label: 'Agents SDK (Python)', kind: 'text', value: `from agents import Agent, HostedMCPTool\nagent = Agent(name="${name}", tools=[HostedMCPTool(tool_config={"type": "mcp", "server_label": "${name}", "server_url": "${mcp}", "headers": {"Authorization": "Bearer ${t}"}, "require_approval": "never"})])` },
    ];
    case 'desk': return [
      { label: 'Open Terminal, paste this line and press Enter', kind: 'command', value: `curl -fsSL ${base}/desk.sh | sh -s -- ${t}`, note: 'How to open Terminal on a Mac: press Command and Space together, type Terminal, press Enter. The line installs Node.js and your AI if they are missing, then sets up the helper, signs your computer in, and keeps the helper running, even after you restart. Your key stays secret on your computer.' },
      { label: 'Or step by step', kind: 'command', value: `mkdir -p ~/.0n/desk/app && npm install --prefix ~/.0n/desk/app ${base}/dl/0n3-desk.tgz
~/.0n/desk/app/node_modules/.bin/0n3-desk desk login --token ${t}
~/.0n/desk/app/node_modules/.bin/0n3-desk desk install --browser
~/.0n/desk/app/node_modules/.bin/0n3-desk doctor`, note: '--browser also starts the Chrome link the 0n extension pairs with. 0n3 doctor checks every piece and prints the fix for anything missing.' },
      { label: 'Prove it', kind: 'command', value: `0n3-desk doctor`, note: `Checks the token against ${base}/api/x/whoami, then shows your desks, how many requests wait for this machine, and whether Chrome is paired. Then send a request from Alerts on your phone.` },
    ];
    case 'rest': return [
      { label: 'Who am I', kind: 'command', value: `curl -s ${base}/api/x/whoami -H "Authorization: Bearer ${t}"` },
      { label: 'Call any endpoint of any connected service', kind: 'command', value: `curl -s ${base}/api/x/call -H "Authorization: Bearer ${t}" -H "Content-Type: application/json" -d '{"service":"stripe","endpoint":"get_balance"}'` },
      { label: 'OpenAPI 3.1 for any tool loader', kind: 'url', value: `${base}/api/install/openapi.json` },
      { label: 'MCP, for anything that speaks it', kind: 'url', value: mcp, note: 'Streamable HTTP, stateless, Authorization: Bearer <token> on every request.' },
    ];
    default: return null;
  }
}

/** OpenAPI 3.1 for the REST facade (/api/x/*) — seven operations, bearer auth. Small on purpose: GPT Actions cap at 30. */
export function openapi(base) {
  const bearer = [{ bearer: [] }];
  const obj = (props, required = []) => ({ type: 'object', properties: props, required });
  const S = (d) => ({ type: 'string', description: d });
  const any = { description: 'JSON' };
  const resp = (d) => ({ 200: { description: d, content: { 'application/json': { schema: { type: 'object' } } } }, 401: { description: 'Missing or invalid 0n token' } });
  return {
    openapi: '3.1.0',
    info: { title: '0n3', version: PKG_VERSION, description: 'One identity, one vault, every connected app as a callable endpoint. Services are called with the account\'s own stored connections; the token never sees a provider secret.' },
    servers: [{ url: base }],
    components: { securitySchemes: { bearer: { type: 'http', scheme: 'bearer', description: 'A 0n_ token from 0n3.app/tokens' } } },
    security: bearer,
    paths: {
      '/api/x/whoami': { get: { operationId: 'whoami', summary: 'Which account this token is, and which services it has connected', responses: resp('account + connected services') } },
      '/api/x/connections': { get: { operationId: 'listConnections', summary: 'The connection records this account holds (never the secrets)', responses: resp('records') } },
      '/api/x/services': { get: { operationId: 'listServices', summary: 'Every service in the catalog, with whether this account has it connected', parameters: [{ name: 'connected_only', in: 'query', schema: { type: 'boolean' } }], responses: resp('services') } },
      '/api/x/services/{service}': { get: { operationId: 'describeService', summary: 'A service\'s endpoints and their params', parameters: [{ name: 'service', in: 'path', required: true, schema: { type: 'string' } }], responses: resp('endpoints') } },
      '/api/x/call': { post: { operationId: 'callEndpoint', summary: 'Call one endpoint of one service with this account\'s own connection', requestBody: { required: true, content: { 'application/json': { schema: obj({ service: S('Service key, e.g. stripe'), endpoint: S('Endpoint name from describeService'), params: { type: 'object', description: 'Path, query or body params', additionalProperties: true }, label: S('Which record when the account holds several') }, ['service', 'endpoint']) } } }, responses: resp('{ ok, status, data }') } },
      '/api/x/apps': { get: { operationId: 'listApps', summary: 'Mini-apps: whole jobs in one call, with what each needs connected', responses: resp('apps') } },
      '/api/x/apps/{app}/run': { post: { operationId: 'runApp', summary: 'Run a mini-app; returns a receipt of every step', parameters: [{ name: 'app', in: 'path', required: true, schema: { type: 'string' } }], requestBody: { content: { 'application/json': { schema: obj({ input: { type: 'object', additionalProperties: true, ...any }, label: S('Which connection record to use') }) } } }, responses: resp('receipt') } },
      '/api/x/approvals/{id}': { get: { operationId: 'getApproval', summary: 'Poll a change that is waiting for the person to approve (pending, done with result, declined, failed, expired)', parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }], responses: resp('approval status + result') } },
    },
  };
}

/** The skill file for Claude Code (and anything that reads SKILL.md). Plain, short, true. */
export function skillMarkdown(base) {
  return `---
name: 0n3
description: 0n3 — your 0n account as tools. Use whenever a task touches a connected service (Stripe, CRM, Google, eBay, Hostinger, WordPress, Mailchimp, …), a mini-app, or needs to know what the account has connected. Say /0n3.
---

# /0n3 — your connected apps, as tools

0n3 is connected to this session as the MCP server \`0n3\` (${base}${MCP_PATH}). Everything it can do runs with THIS account's own stored connections; you never handle a provider secret.

## The tools, and when to reach for each
- \`whoami\` — which account, which services are connected. Call it first when unsure.
- \`connections\` — the records held (labels, environments, key names). Never the secrets.
- \`services\` / \`service_info\` — the catalog (122 services, 1,800+ endpoints) and one service's endpoints with their params.
- \`api_call\` — call one endpoint: \`{ service, endpoint, params, label? }\`. \`label\` picks a record when the account holds several (a name, or a meta value such as a CRM location id).
- \`apps\` / \`app_info\` / \`app_run\` — mini-apps: a whole job in one call (set Google up for a domain, launch a site on Hostinger). Read \`app_info\` first; it says what must be connected.
- \`mcp_tools\` / \`mcp_call\` — tools of an MCP server the account connected.
- \`crm_*\` — the CRM tool factory. Pass \`location_id\` when the account holds more than one location.

## How to work
1. Look before you call: \`service_info\` for the endpoint name and params, \`app_info\` for what an app needs.
2. If a call is refused for a missing connection, say what to connect and where: ${base}/connect. Do not invent credentials.
3. Report what the provider said. A refusal names the fix; a receipt lists every step. Never say "done" for a step that was skipped.
4. Prefer a mini-app when one exists for the job; it is many calls with one receipt.
5. Anything that writes (charges, posts, DNS, emails) — confirm the target with the person first unless they already named it.

## Vocabulary
Say "CRM", never a vendor name. "Connection" = one stored record. "Workspace" = a board of apps on 0n3.app with its own front end.
`;
}
