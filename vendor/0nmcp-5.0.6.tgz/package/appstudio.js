/**
 * APPS — the CRM's AI app builder, inside the 0n3 dashboard (2026-11-14).
 *
 * Mike: "I want this capability to be available in 0n3.app's dashboard so we can build ANY APPLICATION we can dream of
 * and so can any of our users."
 *
 * The builder lives in the CRM (connector domain clientportal-ai) and is reached through the CRM's own MCP server. Its
 * project operations need a token with a USER behind it, for ONE sub-account (measured 2026-11-14: the builder sign-in for
 * the 0nCore location answered 401 "This location is not accessible from this token!" for any other location). So:
 *
 *   one sign-in per sub-account, made by a user of that sub-account, through the CRM's own consent screen
 *   (OAuth 2.1, dynamic client registration, PKCE) — stored in the person's 0n3 VAULT as a renewable CRM record
 *   (`via: 'appbuilder'`, with its refresh token), so it works on every device, from the phone and from any AI on 0n3.
 *
 * The same record also serves every other crm_* call for that location (it carries the CRM connector's full scope set),
 * and tokens.js renews it.
 *
 * The browser cannot send a bearer header on a redirect, so the dashboard first asks for a signed, ten-minute connect
 * link (POST /api/apps/link) and opens it; the account rides in that signature and in a sealed cookie, never in the URL
 * in the clear.
 *
 * Publishing and answering the builder's questions change what clients see: they pass only with confirm:true, which
 * the dashboard sends only from the button the person pressed. Building uses the sub-account's CRM AI credits.
 */
import crypto from 'node:crypto';
import { makeConnection } from './envelope.js';

export const CRM = 'https://services.leadconnectorhq.com';
export const MCP = `${CRM}/mcp/v2`;
const SCOPES = ['clientportal-ai.readonly', 'clientportal-ai.write', 'locations.readonly', 'contacts.readonly', 'objects/schema.readonly', 'brand-boards/design-kit.readonly'];
const FLOW = 'apps_flow';
const LINK_TTL = 10 * 60_000;

// Every builder operation the dashboard may run. Reads are free; WRITES build (AI credits); CONFIRM changes what clients see.
export const READS = new Set(['listTemplates', 'listProjects', 'getProject', 'getAgentRun', 'listAgentRunsForProject', 'getProjectPublishability', 'getProjectPublishJob', 'getAppCustomization', 'listProjectCustomDomains', 'cliGetProjectContext', 'cliSandboxView', 'cliSandboxSearch']);
export const WRITES = new Set(['createProject', 'submitAgentRun', 'updateProject', 'cliSandboxEdit', 'cliSandboxCheckpoint', 'cliSandboxRegisterExtensionRoute']);
export const CONFIRM = new Set(['answerAgentRunQuestionsBatch', 'promoteProjectToProduction', 'publishAppCustomization']);

const b64u = (b) => Buffer.from(b).toString('base64url');

export function createAppStudio({ store, env = process.env, fetchImpl = fetch, base = 'https://0n3.app' }) {
  const secret = () => { const k = env.APPBUILDER_SECRET || env.ON3_VAULT_KEY; if (!k) throw new Error('APPBUILDER_SECRET (or ON3_VAULT_KEY) is not set'); return k; };
  const key = () => crypto.createHash('sha256').update('apps|' + secret()).digest();
  const seal = (o) => { const iv = crypto.randomBytes(12); const c = crypto.createCipheriv('aes-256-gcm', key(), iv); const ct = Buffer.concat([c.update(JSON.stringify(o), 'utf8'), c.final()]); return b64u(Buffer.concat([iv, c.getAuthTag(), ct])); };
  const open = (s) => { try { const b = Buffer.from(String(s || ''), 'base64url'); const d = crypto.createDecipheriv('aes-256-gcm', key(), b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return JSON.parse(Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8')); } catch { return null; } };

  // One registered client per redirect URI, per warm instance (registration is open, RFC 7591).
  const clients = new Map();
  async function clientFor(redirectUri) {
    if (clients.has(redirectUri)) return clients.get(redirectUri);
    const r = await fetchImpl(`${CRM}/mcp/register`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ client_name: '0n3 Apps', redirect_uris: [redirectUri], grant_types: ['authorization_code', 'refresh_token'], response_types: ['code'], token_endpoint_auth_method: 'none' }) });
    const j = await r.json().catch(() => ({}));
    if (!j.client_id) throw new Error(`The CRM did not register 0n3 (${r.status}): ${j.error_description || j.error || ''}`.trim());
    clients.set(redirectUri, j.client_id); return j.client_id;
  }
  async function tokenCall(params) {
    const r = await fetchImpl(`${CRM}/mcp/token`, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ ...params, resource: MCP }) });
    const j = await r.json().catch(() => ({}));
    if (!j.access_token) throw new Error(`The CRM sign-in did not finish (${r.status}): ${j.error_description || j.error || 'no token'}`);
    return j;
  }

  let rpc = 0;
  async function mcp(accessToken, locationId, name, args) {
    const headers = { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', Accept: 'application/json, text/event-stream', 'MCP-Protocol-Version': '2025-06-18' };
    if (locationId) headers.locationId = locationId;
    const r = await fetchImpl(MCP, { method: 'POST', headers, body: JSON.stringify({ jsonrpc: '2.0', id: ++rpc, method: 'tools/call', params: { name, arguments: args } }) });
    const text = await r.text();
    if (r.status === 401) { const e = new Error('The app builder sign-in for this sub-account has expired. Connect it again.'); e.status = 401; throw e; }
    const line = text.split('\n').find((l) => l.startsWith('data:'));
    let msg; try { msg = JSON.parse(line ? line.slice(5) : text); } catch { const e = new Error(`The CRM answered ${r.status}: ${text.slice(0, 200)}`); e.status = 502; throw e; }
    if (msg.error) { const e = new Error(msg.error.message || 'The CRM connector refused this'); e.status = 502; throw e; }
    const content = msg.result?.content?.[0]?.text; let data; try { data = JSON.parse(content); } catch { data = content; }
    return { isError: !!msg.result?.isError, data };
  }

  /** The builder records on this account: one per sub-account. */
  async function records(accountId) {
    return (await store.list(accountId)).filter((r) => r.service === 'crm' && r.meta?.via === 'appbuilder' && r.meta?.location_id);
  }

  /** A live access token for one sub-account's builder record, renewed (and the rotated refresh token saved) when needed. */
  async function tokenFor(accountId, locationId) {
    const rec = (await records(accountId)).find((r) => r.meta.location_id === locationId);
    if (!rec) { const e = new Error('This sub-account is not connected to the app builder yet. Press Connect.'); e.status = 409; throw e; }
    const full = await store.get(accountId, 'crm', rec.$0n?.name);
    const c = full?.auth?.credentials || {};
    if (c.access_token && Number(c.expires_at || 0) - 60_000 > Date.now()) return c.access_token;
    if (!c.refresh_token || !c.client_id) { const e = new Error('The app builder sign-in for this sub-account has expired. Connect it again.'); e.status = 401; throw e; }
    const t = await tokenCall({ grant_type: 'refresh_token', refresh_token: c.refresh_token, client_id: c.client_id });
    const next = { ...c, access_token: t.access_token, refresh_token: t.refresh_token || c.refresh_token, expires_at: Date.now() + (Number(t.expires_in) || 3600) * 1000 };
    await store.put(accountId, makeConnection({ service: 'crm', name: rec.$0n?.name, authType: 'oauth', credentials: next, meta: rec.meta }), { actor: '0n3 apps (renew)' });
    return next.access_token;
  }

  return {
    /** A signed, ten-minute link that starts the CRM sign-in for this account. */
    link(accountId) {
      const code = seal({ a: accountId, x: Date.now() + LINK_TTL });
      return `${base}/api/apps/connect?c=${code}`;
    },

    /** GET /api/apps/connect?c= → { redirect, cookie } to the CRM's consent screen. */
    async begin(code) {
      const c = open(code);
      if (!c || !c.a || Date.now() > c.x) return { redirect: `${base}/apps?error=expired` };
      const redirectUri = `${base}/api/apps/callback`;
      const clientId = await clientFor(redirectUri);
      const verifier = b64u(crypto.randomBytes(32)), state = b64u(crypto.randomBytes(16));
      const a = new URL(`${CRM}/mcp/authorize`);
      for (const [k, v] of Object.entries({ response_type: 'code', client_id: clientId, redirect_uri: redirectUri, code_challenge: crypto.createHash('sha256').update(verifier).digest('base64url'), code_challenge_method: 'S256', state, scope: SCOPES.join(' '), resource: MCP })) a.searchParams.set(k, v);
      return { redirect: a.toString(), cookie: `${FLOW}=${seal({ a: c.a, v: verifier, st: state, c: clientId, ru: redirectUri, t: Date.now() })}; Path=/api/apps; HttpOnly; Secure; SameSite=Lax; Max-Age=900` };
    },

    /** GET /api/apps/callback → store the renewable builder record for the sub-account the person picked. */
    async finish(cookieHeader, query) {
      const clear = `${FLOW}=; Path=/api/apps; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
      const raw = String(cookieHeader || '').split(/;\s*/).find((p) => p.startsWith(FLOW + '='));
      const f = raw ? open(decodeURIComponent(raw.slice(FLOW.length + 1))) : null;
      if (!f || Date.now() - f.t > 900_000) return { redirect: `${base}/apps?error=expired`, cookie: clear };
      if (query.get('error')) return { redirect: `${base}/apps?error=${encodeURIComponent(query.get('error'))}`, cookie: clear };
      if (query.get('state') !== f.st) return { redirect: `${base}/apps?error=state`, cookie: clear };
      const t = await tokenCall({ grant_type: 'authorization_code', code: query.get('code') || '', redirect_uri: f.ru, client_id: f.c, code_verifier: f.v });
      // Which sub-account did they pick? The token may say; otherwise ask the connector.
      let locationId = t.locationId || t.location_id || '';
      let locationName = '';
      try {
        const r = await mcp(t.access_token, locationId || null, 'list_locations', {});
        const list = r.data?.locations || r.data?.results || r.data?.items || (Array.isArray(r.data) ? r.data : []);
        const hit = list.find((l) => (l.id || l.locationId || l._id) === locationId) || (list.length === 1 ? list[0] : null);
        if (hit) { locationId = locationId || hit.id || hit.locationId || hit._id; locationName = hit.name || hit.locationName || ''; }
      } catch { /* the location id from the token is enough */ }
      if (!locationId) return { redirect: `${base}/apps?error=no_location`, cookie: clear };
      const name = `App builder · ${locationName || locationId}`.slice(0, 80);
      // One record per sub-account: drop an older one under a different name first.
      for (const r of await records(f.a)) if (r.meta.location_id === locationId && r.$0n?.name !== name) await store.remove(f.a, 'crm', r.$0n?.name, { actor: '0n3 apps' }).catch(() => {});
      await store.put(f.a, makeConnection({ service: 'crm', name, authType: 'oauth',
        credentials: { access_token: t.access_token, refresh_token: t.refresh_token || '', client_id: f.c, location_id: locationId, expires_at: Date.now() + (Number(t.expires_in) || 3600) * 1000, via: 'appbuilder' },
        meta: { via: 'appbuilder', location_id: locationId, location_name: locationName || null, scope: t.scope || null } }), { actor: '0n3 apps' });
      return { redirect: `${base}/apps?connected=${encodeURIComponent(locationId)}`, cookie: clear };
    },

    /** The sub-accounts this account can build in: builder-connected ones, plus the CRM locations it knows that are not yet. */
    async list(accountId) {
      const all = await store.list(accountId);
      const connected = all.filter((r) => r.service === 'crm' && r.meta?.via === 'appbuilder' && r.meta?.location_id)
        .map((r) => ({ locationId: r.meta.location_id, name: r.meta.location_name || r.$0n?.name?.replace(/^App builder · /, '') || r.meta.location_id, connected: true, status: r.status }));
      const seen = new Set(connected.map((c) => c.locationId));
      const others = [];
      for (const r of all) {
        const id = r.service === 'crm' ? r.meta?.location_id : null;
        if (!id || seen.has(id)) continue; seen.add(id);
        others.push({ locationId: id, name: r.meta?.name || r.$0n?.name?.replace(/^CRM · /, '') || id, connected: false });
      }
      return { locations: [...connected, ...others] };
    },

    /** One allow-listed builder operation on one connected sub-account. */
    async op(accountId, b = {}) {
      const op = String(b.operationId || '');
      if (!READS.has(op) && !WRITES.has(op) && !CONFIRM.has(op)) return { status: 400, body: { error: `That is not something the app builder can do from here: ${op}` } };
      if (CONFIRM.has(op) && b.confirm !== true) return { status: 409, body: { error: 'confirm_required', message: 'This changes what your clients see. Press the button that says so.' } };
      const locationId = String(b.locationId || '');
      if (!locationId) return { status: 400, body: { error: 'Pick a sub-account first.' } };
      const access = await tokenFor(accountId, locationId);
      const args = { operationId: op, params: b.params || {}, locationId };
      if (!READS.has(op)) args.idempotencyKey = String(b.idempotencyKey || crypto.randomUUID()).slice(0, 200);
      if (b.reason) args.reason = String(b.reason).slice(0, 200);
      const r = await mcp(access, locationId, 'execute_operation', args);
      return { status: r.isError ? 502 : 200, body: r.data };
    },
  };
}
