/**
 * SIGN IN WITH 0n3 — the identity layer on top of 0n3's OAuth 2.1 server (2026-10-28).
 *
 * Any app can send a person to 0n3.app/oauth/authorize and get back:
 *   · who they are       (scopes openid · profile · email → a signed ID token and /oauth/userinfo)
 *   · the apps they allow (scope apps:<service> per app — e.g. apps:slack apps:google_sheets)
 * The app never receives a key. It calls 0n3 (/mcp or /api/x/call) with its token, and 0n3 uses the person's vault for
 * ONLY the apps they granted — enforced here, at the one place credentials are released (GrantResolver).
 *
 * Scopes:
 *   openid profile email   identity (OpenID Connect)
 *   offline_access         a refresh token
 *   mcp                    the whole account as an MCP tool (the original grant — claude.ai, ChatGPT; unchanged)
 *   apps:<service>         use that connected app through 0n3, nothing else
 */
import { createPrivateKey, createPublicKey, createSign, createHash } from 'node:crypto';
import { familyOf } from './tokens.js';

export const IDENTITY_SCOPES = ['openid', 'profile', 'email', 'offline_access'];
const SERVICE_RE = /^[a-z][a-z0-9_]{1,39}$/;

/** "openid email apps:slack apps:bad!!" → ['openid','email','apps:slack'] — unknown words are dropped, never trusted. */
export function parseScopes(str) {
  const out = [];
  for (const s of String(str || '').split(/[\s+]+/).filter(Boolean)) {
    if (IDENTITY_SCOPES.includes(s) || s === 'mcp') { if (!out.includes(s)) out.push(s); continue; }
    if (s.startsWith('apps:') && SERVICE_RE.test(s.slice(5)) && !out.includes(s)) out.push(s);
  }
  return out;
}
/** Is every requested scope inside what the client registered? `apps:*` on a client allows any single app scope. */
export function scopesAllowed(requested, allowed = []) {
  const a = new Set(allowed || []);
  return requested.every((s) => a.has(s) || (s.startsWith('apps:') && a.has('apps:*')));
}

/**
 * What a token may do. null = an unrestricted token (master, console tokens, legacy MCP grants) — behaviour unchanged.
 * Otherwise { apps, mcp, identityOnly } from the token's own scopes.
 */
export function grantOf(account) {
  const sc = account?.permissions?.scopes;
  if (!Array.isArray(sc) || !sc.some((s) => s.startsWith('apps:') || IDENTITY_SCOPES.includes(s))) return null;
  const apps = sc.filter((s) => s.startsWith('apps:')).map((s) => s.slice(5));
  return { scopes: sc, apps, mcp: sc.includes('mcp'), identityOnly: !apps.length && !sc.includes('mcp') };
}

/** The vault, narrowed to the granted apps. A service is released when it, or the family it signs in through, was granted. */
export class GrantResolver {
  constructor(inner, apps) { this.inner = inner; this.apps = new Set(apps || []); this.families = new Set([...this.apps].map((a) => familyOf(a))); }
  allowed(service) { return this.apps.has(service) || this.families.has(service) || this.apps.has(familyOf(service)); }
  async list() { return (await this.inner.list()).filter((e) => this.allowed(e.service)); }
  async get(service, label) { return this.allowed(service) ? this.inner.get(service, label) : null; }
  async save(envelope) { if (this.allowed(envelope?.service) && this.inner.save) return this.inner.save(envelope); }
}

// ── signing ───────────────────────────────────────────────────────────────────
let cached = null;
/** The signing key, from ON3_OIDC_PRIVATE_KEY (PEM). Without it 0n3 still runs OAuth, but issues no ID tokens and says so. */
export function signingKey(env = process.env) {
  const pem = String(env.ON3_OIDC_PRIVATE_KEY || '').replace(/\\n/g, '\n').trim();
  if (!pem) return null;
  if (cached && cached.pem === pem) return cached;
  const priv = createPrivateKey(pem); const jwk = createPublicKey(priv).export({ format: 'jwk' });
  const kid = createHash('sha256').update(`${jwk.n}.${jwk.e}`).digest('base64url').slice(0, 16);
  cached = { pem, priv, kid, jwk: { kty: 'RSA', use: 'sig', alg: 'RS256', kid, n: jwk.n, e: jwk.e } };
  return cached;
}
export function jwks(env) { const k = signingKey(env); return { keys: k ? [k.jwk] : [] }; }

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
export function signJwt(claims, env) {
  const k = signingKey(env); if (!k) return null;
  const head = b64({ alg: 'RS256', typ: 'JWT', kid: k.kid }); const body = b64(claims);
  const sig = createSign('RSA-SHA256').update(`${head}.${body}`).sign(k.priv).toString('base64url');
  return `${head}.${body}.${sig}`;
}

/** The person, as the granted scopes allow. `sub` is the 0n3 account id — stable across every app. */
export function userClaims(profile, scopes) {
  const c = { sub: profile.id };
  if (scopes.includes('email') && profile.email) { c.email = String(profile.email).toLowerCase(); c.email_verified = true; }
  if (scopes.includes('profile')) { if (profile.full_name) c.name = profile.full_name; if (profile.avatar_url) c.picture = profile.avatar_url; }
  return c;
}
export function idToken({ base, clientId, profile, scopes, nonce, authTime, env, ttl = 3600 }) {
  const now = Math.floor(Date.now() / 1000);
  return signJwt({ iss: base, aud: clientId, iat: now, exp: now + ttl, auth_time: authTime || now, ...(nonce ? { nonce } : {}), ...userClaims(profile, scopes) }, env);
}

export function openidConfiguration(base, env) {
  const signs = !!signingKey(env);
  return {
    issuer: base,
    authorization_endpoint: `${base}/oauth/authorize`,
    token_endpoint: `${base}/oauth/token`,
    userinfo_endpoint: `${base}/oauth/userinfo`,
    registration_endpoint: `${base}/oauth/register`,
    revocation_endpoint: `${base}/oauth/revoke`,
    jwks_uri: `${base}/.well-known/jwks.json`,
    response_types_supported: ['code'],
    grant_types_supported: ['authorization_code', 'refresh_token'],
    code_challenge_methods_supported: ['S256'],
    token_endpoint_auth_methods_supported: ['none', 'client_secret_post', 'client_secret_basic'],
    scopes_supported: [...IDENTITY_SCOPES, 'mcp', 'apps:<service>'],
    subject_types_supported: ['public'],
    id_token_signing_alg_values_supported: signs ? ['RS256'] : [],
    claims_supported: ['sub', 'email', 'email_verified', 'name', 'picture'],
    service_documentation: `${base}/developers`,
  };
}

/** Plain-language lines for the consent screen. */
export function describeScopes(scopes, nameOf = (k) => k) {
  const lines = [];
  if (scopes.includes('openid') || scopes.includes('profile') || scopes.includes('email')) lines.push({ kind: 'id', text: `Know who you are${scopes.includes('email') ? ' (your name and email)' : ''}` });
  for (const s of scopes.filter((x) => x.startsWith('apps:'))) lines.push({ kind: 'app', app: s.slice(5), text: `Use your ${nameOf(s.slice(5))} through 0n3` });
  if (scopes.includes('mcp')) lines.push({ kind: 'mcp', text: 'Use all of your connected apps as AI tools' });
  if (scopes.includes('offline_access')) lines.push({ kind: 'offline', text: 'Stay signed in until you remove it' });
  return lines;
}
