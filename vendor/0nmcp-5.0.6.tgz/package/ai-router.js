/**
 * AI ROUTER — every AI call in 0n3 goes through here (Mike, 2026-11-06: "allow the user to order their ai preferences in a
 * simple drag and drop top to bottom favorites or sort by tokens left or by other model strengths … allow our own testing
 * based on feedback for different tasks. our ai will be needed mainly for logic").
 *
 *   plan()      the person's connected AIs, in THEIR order — their drag-and-drop favourites, or sorted by tokens left today,
 *               or by measured strength at logic / json / tools / speed. A provider cooling down after a limit goes last.
 *   complete()  one answer: try the first, and on a limit, an error, a dead key or an empty answer, the next. The receipt says
 *               which one answered and why each before it was passed over — a Groq answer is never shown as Gemini's.
 *   chat()      the same for a tool-using chat turn — but once a tool has RUN it never retries on another provider, because a
 *               second provider would run the tool again (an email sent twice is worse than one error).
 *   feedback()  a thumbs up or down for a task, from a person or from test().
 *   test()      0n3's own check: five small logic and JSON problems with known answers, run on each connected AI; the results
 *               are feedback rows (source "test"), so the strength sort is measured, not guessed.
 *
 * Every key is the person's own, read from their vault (one account per person per provider — no shared key pools).
 * Anthropic is available like any other provider, only as the person's own key; 0n pays for no AI.
 */
import { PROVIDERS, providerOf, keyOf, complete as completeOnce, chatTurn } from './chat.js';

export const TASKS = ['logic', 'json', 'tools', 'speed'];
export const SORTS = ['favorites', 'tokens', ...TASKS];
const PRIOR = 6;            // how many votes the starting guess is worth
const FEEDBACK_ROWS = 400;  // most recent rows that count, per account

/** Providers 0n3's server can call (a local Ollama is only reachable from the person's own desk). */
export const routable = () => Object.entries(PROVIDERS).filter(([, p]) => !p.local).map(([k]) => k);

const today = (now) => new Date(now()).toISOString().slice(0, 10);
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : null; };

/** "2m59.56s" · "1.2s" · "300ms" · "17" (seconds) → ms. Groq/OpenAI write resets this way; Retry-After is plain seconds. */
export function durationMs(v) {
  if (v == null || v === '') return null;
  const s = String(v).trim();
  if (/^\d+(\.\d+)?$/.test(s)) return Math.round(Number(s) * 1000);
  const at = Date.parse(s); if (Number.isFinite(at) && /\d{4}-\d{2}/.test(s)) return Math.max(0, at - Date.now());
  let ms = 0, hit = false;
  for (const [, n, u] of s.matchAll(/(\d+(?:\.\d+)?)(ms|h|m|s)/g)) { hit = true; ms += Number(n) * (u === 'h' ? 3_600_000 : u === 'm' ? 60_000 : u === 's' ? 1000 : 1); }
  return hit ? Math.round(ms) : null;
}

/** The limits a provider reports on its own response headers (OpenAI-style, Groq, Cerebras, OpenRouter, Anthropic). */
export function limitsFrom(h) {
  const g = (k) => (h && typeof h.get === 'function' ? h.get(k) : h?.[k]) ?? null;
  return {
    remaining_requests: num(g('x-ratelimit-remaining-requests') ?? g('anthropic-ratelimit-requests-remaining') ?? g('x-ratelimit-remaining-requests-day') ?? g('x-ratelimit-remaining')),
    remaining_tokens: num(g('x-ratelimit-remaining-tokens') ?? g('anthropic-ratelimit-tokens-remaining') ?? g('x-ratelimit-remaining-tokens-day')),
    limit_requests: num(g('x-ratelimit-limit-requests') ?? g('anthropic-ratelimit-requests-limit') ?? g('x-ratelimit-limit-requests-day') ?? g('x-ratelimit-limit')),
    limit_tokens: num(g('x-ratelimit-limit-tokens') ?? g('anthropic-ratelimit-tokens-limit') ?? g('x-ratelimit-limit-tokens-day')),
    retry_ms: durationMs(g('retry-after')) ?? durationMs(g('x-ratelimit-reset-requests')) ?? durationMs(g('x-ratelimit-reset-tokens')),
  };
}

/** Tokens a response body says it used, in each dialect. */
export function tokensOf(d) {
  if (!d || typeof d !== 'object') return 0;
  if (d.usage?.total_tokens) return d.usage.total_tokens;
  if (d.usage && (d.usage.input_tokens || d.usage.output_tokens)) return (d.usage.input_tokens || 0) + (d.usage.output_tokens || 0);
  if (d.usageMetadata?.totalTokenCount) return d.usageMetadata.totalTokenCount;
  return 0;
}

/** HTTP status from chat.js's "<name> answered 429: …" errors; 0 = no answer at all (network, timeout). */
export const statusOf = (err) => { const m = /answered (\d{3})/.exec(String(err || '')); return m ? Number(m[1]) : 0; };

/** How long to leave a provider alone after a failure. */
export function cooldownMs(status, retryMs) {
  if (status === 429) return Math.min(Math.max(retryMs || 60_000, 5_000), 6 * 3_600_000);
  if (status === 401 || status === 403) return 3_600_000;  // a dead or unauthorised key: try again in an hour, not every call
  if (status === 402) return 6 * 3_600_000;                // out of credit
  if (status >= 500 || status === 0) return 30_000;
  return 0;
}

/** Measured strength: the starting guess blended with up/down votes (a vote for "up" counts as 1, "down" as 0). */
export function strength(base, ups = 0, downs = 0) { return (base * PRIOR + ups) / (PRIOR + ups + downs); }

/** The share of today's allowance still left, 0..1, from the provider's own headers; unknown = 0.5, cooling = 0. */
export function fuel(u, nowMs) {
  if (!u) return 0.5;
  if (u.cooldown_until && Date.parse(u.cooldown_until) > nowMs) return 0;
  const parts = [];
  if (u.remaining_requests != null && u.limit_requests) parts.push(u.remaining_requests / u.limit_requests);
  if (u.remaining_tokens != null && u.limit_tokens) parts.push(u.remaining_tokens / u.limit_tokens);
  return parts.length ? Math.max(0, Math.min(1, Math.min(...parts))) : 0.5;
}

/** Order candidates. Pure, so the order is testable without a database. */
export function orderCandidates(keys, { sort = 'favorites', order = [], prefer = null, task = 'logic', usage = {}, votes = {}, nowMs = Date.now() } = {}) {
  const score = (k, t) => { const v = votes[k]?.[t] || {}; return strength(PROVIDERS[k]?.strengths?.[t] ?? 0.5, v.up || 0, v.down || 0); };
  const rank = (k) => { const i = order.indexOf(k); return i === -1 ? 1e6 - score(k, task) : i; };
  const by = {
    favorites: (a, b) => rank(a) - rank(b),
    tokens: (a, b) => fuel(usage[b], nowMs) - fuel(usage[a], nowMs) || rank(a) - rank(b),
  };
  const cmp = by[sort] || ((a, b) => score(b, sort) - score(a, sort) || rank(a) - rank(b));
  const cooling = (k) => !!(usage[k]?.cooldown_until && Date.parse(usage[k].cooldown_until) > nowMs);
  const out = [...keys].sort((a, b) => (cooling(a) - cooling(b)) || cmp(a, b));
  if (prefer && out.includes(prefer) && !cooling(prefer)) { out.splice(out.indexOf(prefer), 1); out.unshift(prefer); }
  return out;
}

const parseJson = (t) => { const s = String(t || '').replace(/```(?:json)?/gi, ''); const a = s.indexOf('{'), b = s.lastIndexOf('}'); if (a < 0 || b <= a) return null; try { return JSON.parse(s.slice(a, b + 1)); } catch { return null; } };
const close = (a, b, eps = 0.01) => Math.abs(Number(a) - Number(b)) <= eps;

/** 0n3's own test: small problems with ONE right answer, weighted to logic (Mike: "mainly for logic"). */
export const TEST_SUITE = [
  { id: 'free-at', task: 'logic', ask: 'A truck leaves at 06:00 and drives 330 miles at a steady 55 mph with no stops. Unloading takes 2 hours. At what time is the driver free? Answer as JSON: {"free_at":"HH:MM"} (24-hour clock).', check: (j) => String(j?.free_at || '').replace(/^0/, '') === '14:00' },
  { id: 'best-loads', task: 'logic', ask: 'One driver can take loads that do not overlap in time. Load A pays $900, load B pays $1,400, load C pays $700. A and B overlap each other; C overlaps neither. Which loads earn the most, and what is the total? Answer as JSON: {"loads":["…"],"total":0}.', check: (j) => Array.isArray(j?.loads) && [...j.loads].map(String).sort().join() === 'B,C' && close(j.total, 2100) },
  { id: 'pay', task: 'logic', ask: 'A driver is paid $0.62 per mile for 1,240 miles plus $75 for each of 2 stops. What is the total pay in dollars? Answer as JSON: {"total":0}.', check: (j) => close(j?.total, 918.8) },
  { id: 'deadline-order', task: 'logic', ask: 'Order these jobs by due date, earliest first, and return their ids: x is due 2026-11-09, y is due 2026-11-07, z is due 2026-11-08. Answer as JSON: {"ids":["…"]}.', check: (j) => Array.isArray(j?.ids) && j.ids.join() === 'y,z,x' },
  { id: 'extract', task: 'json', ask: 'Pull the payer out of this line into JSON {"name":"","email":"","amount":0}: "Paid by Dana Ruiz (dana@example.com), $149.50 on Tuesday".', check: (j) => j?.name === 'Dana Ruiz' && String(j?.email).toLowerCase() === 'dana@example.com' && close(j?.amount, 149.5) },
];
const FAST_MS = 2500;

export class AiRouter {
  /** @param {{ store: any, rest?: any, fetchImpl?: typeof fetch, now?: () => number }} o */
  constructor({ store, rest = null, fetchImpl = fetch, now = Date.now }) { this.store = store; this.rest = rest; this.fetchImpl = fetchImpl; this.now = now; }

  async keyFor(accountId, k) {
    const p = providerOf(k); if (!p) return null; if (p.keyless) return '';
    for (const svc of [p.service, ...(p.aliases || [])]) { const env = await this.store.get(accountId, svc).catch(() => null); const key = env ? keyOf(env) : null; if (key) return key; }
    return null;
  }

  /** Every routable provider this account holds a key for: { key: apiKey }. */
  async keys(accountId) {
    const out = {};
    for (const k of routable()) { const key = await this.keyFor(accountId, k); if (key) out[k] = key; }
    return out;
  }

  async prefs(accountId) {
    const [row] = this.rest ? await this.rest.select('ai_prefs', { account_id: accountId }).catch(() => []) : [];
    return { sort: row?.sort || 'favorites', order: row?.order_keys || [], disabled: row?.disabled || [] };
  }

  async setPrefs(accountId, { sort, order, disabled } = {}) {
    if (!this.rest) throw new Error('Preferences need the database.');
    const cur = await this.prefs(accountId);
    const known = new Set(Object.keys(PROVIDERS));
    const clean = (a) => [...new Set((Array.isArray(a) ? a : []).map(String).filter((k) => known.has(k)))];
    const next = {
      sort: sort === undefined ? cur.sort : (SORTS.includes(sort) ? sort : (() => { throw new Error(`sort must be one of ${SORTS.join(', ')}`); })()),
      order: order === undefined ? cur.order : clean(order),
      disabled: disabled === undefined ? cur.disabled : clean(disabled),
    };
    await this.rest.upsert('ai_prefs', { account_id: accountId, sort: next.sort, order_keys: next.order, disabled: next.disabled, updated_at: new Date(this.now()).toISOString() }, 'account_id');
    return next;
  }

  async usage(accountId) {
    if (!this.rest) return {};
    const rows = await this.rest.select('ai_usage', { account_id: accountId, day: today(this.now) }).catch(() => []);
    return Object.fromEntries(rows.map((r) => [r.provider, r]));
  }

  async votes(accountId) {
    if (!this.rest) return {};
    const rows = (await this.rest.select('ai_feedback', { account_id: accountId }).catch(() => []))
      .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at))).slice(0, FEEDBACK_ROWS);
    const v = {};
    for (const r of rows) { const t = ((v[r.provider] ||= {})[r.task] ||= { up: 0, down: 0 }); if (r.score > 0) t.up++; else t.down++; }
    return v;
  }

  /** The order this account's AI calls will try, with the key for each. `prefer` (a board's chosen AI) goes first. */
  async plan(accountId, { task = 'logic', prefer = null } = {}) {
    const [keys, prefs, usage, votes] = await Promise.all([this.keys(accountId), this.prefs(accountId), this.usage(accountId), this.votes(accountId)]);
    const pool = Object.keys(keys).filter((k) => !prefs.disabled.includes(k) || k === prefer);
    const sort = SORTS.includes(prefs.sort) ? prefs.sort : 'favorites';
    return orderCandidates(pool, { sort, order: prefs.order, prefer, task: TASKS.includes(task) ? task : 'logic', usage, votes, nowMs: this.now() })
      .map((k) => ({ provider: k, apiKey: keys[k], model: PROVIDERS[k].model }));
  }

  /** A fetch that remembers the provider's limit headers and token use for this attempt. */
  meter(sink) {
    return async (url, init) => {
      const r = await this.fetchImpl(url, init);
      sink.status = r.status; sink.limits = limitsFrom(r.headers);
      if (typeof r.clone === 'function') sink.pending.push(r.clone().json().then((d) => { sink.tokens += tokensOf(d); }).catch(() => {}));
      return r;
    };
  }

  async record(accountId, provider, { ok, ms, sink, error }) {
    if (!this.rest) return;
    try {
      await Promise.all(sink.pending);
      const day = today(this.now);
      const [cur] = await this.rest.select('ai_usage', { account_id: accountId, provider, day }).catch(() => []);
      const l = sink.limits || {};
      const raw = ok ? 200 : (sink.status && sink.status >= 400 ? sink.status : statusOf(error));
      // "no credits" / "quota exceeded" arrive as 429 but will not clear in a minute: rest it like a 402.
      const status = !ok && raw === 429 && /credit|quota|billing|insufficient/i.test(String(error || '')) ? 402 : raw;
      const cool = ok ? 0 : cooldownMs(status, l.retry_ms);
      await this.rest.upsert('ai_usage', {
        account_id: accountId, provider, day,
        requests: (cur?.requests || 0) + 1, tokens: Number(cur?.tokens || 0) + (sink.tokens || 0), failures: (cur?.failures || 0) + (ok ? 0 : 1),
        remaining_requests: l.remaining_requests ?? cur?.remaining_requests ?? null, remaining_tokens: l.remaining_tokens ?? cur?.remaining_tokens ?? null,
        limit_requests: l.limit_requests ?? cur?.limit_requests ?? null, limit_tokens: l.limit_tokens ?? cur?.limit_tokens ?? null,
        cooldown_until: cool ? new Date(this.now() + cool).toISOString() : (ok ? null : cur?.cooldown_until ?? null),
        last_error: ok ? cur?.last_error ?? null : String(error || '').slice(0, 300), last_ms: ms, updated_at: new Date(this.now()).toISOString(),
      }, 'account_id,provider,day');
    } catch { /* metering never breaks an answer */ }
  }

  /**
   * One answer, with fallback. `args` = { system, user, maxTokens }. Returns { text, model, provider, tried } or
   * { error, tried, missing: 'ai' } when the account has no AI connected.
   */
  async complete(accountId, args, { task = 'logic', prefer = null, only = null } = {}) {
    const plan = only ? (await this.plan(accountId, { task, prefer: only })).filter((c) => c.provider === only) : await this.plan(accountId, { task, prefer });
    if (!plan.length) return { error: only ? `No ${providerOf(only)?.name || only} key is connected.` : 'No AI is connected yet. Add a free one (Groq, Gemini, Cerebras, Mistral, OpenRouter, NVIDIA) or your own OpenAI or Claude key under Connections → AI.', missing: 'ai', tried: [] };
    const tried = [];
    for (const c of plan) {
      const sink = { pending: [], tokens: 0, status: 0, limits: null }; const t0 = this.now();
      const out = await completeOnce({ provider: c.provider, apiKey: c.apiKey, model: c.model, system: args.system, user: args.user, maxTokens: args.maxTokens, fetchImpl: this.meter(sink) });
      const ms = this.now() - t0;
      const empty = !out.error && !String(out.text || '').trim();
      const error = out.error || (empty ? `${providerOf(c.provider).name} answered with nothing.` : null);
      await this.record(accountId, c.provider, { ok: !error, ms, sink, error });
      if (!error) return { ...out, provider: c.provider, ms, tried };
      tried.push({ provider: c.provider, error, ms });
    }
    return { error: `Every connected AI failed. Last: ${tried[tried.length - 1].error}`, tried };
  }

  /** One chat turn with tools, with fallback only while no tool has run yet. Same arguments as chat.js chatTurn. */
  async chat(accountId, ai, ctx, turn, { task = 'tools' } = {}) {
    const plan = await this.plan(accountId, { task, prefer: ai?.provider || null });
    if (!plan.length) { const want = providerOf(ai?.provider); return { error: want ? `No ${want.name} key is connected for you. Add one under "${want.service}" and try again.` : 'No AI is connected yet. Add one under Connections → AI.', missing: want ? want.service : 'ai', tried: [] }; }
    const tried = [];
    for (const c of plan) {
      const sink = { pending: [], tokens: 0, status: 0, limits: null }; const t0 = this.now();
      const out = await chatTurn({ provider: c.provider, model: c.provider === ai?.provider ? ai?.model || c.model : c.model, apiKey: c.apiKey, fetchImpl: this.meter(sink) }, ctx, turn);
      const ms = this.now() - t0;
      await this.record(accountId, c.provider, { ok: !out.error, ms, sink, error: out.error });
      if (!out.error) return { ...out, provider: c.provider, ms, tried };
      tried.push({ provider: c.provider, error: out.error, ms });
      if (out.trace?.length) return { ...out, provider: c.provider, tried, error: `${out.error} (not retried on another AI: a step had already run)` };
    }
    return { error: `Every connected AI failed. Last: ${tried[tried.length - 1].error}`, tried };
  }

  async feedback(accountId, { provider, model = null, task = 'logic', score, note = null, source = 'person', ms = null }) {
    if (!this.rest) throw new Error('Feedback needs the database.');
    if (!providerOf(provider)) throw new Error('Unknown AI.');
    const s = Number(score) > 0 ? 1 : Number(score) < 0 ? -1 : 0; if (!s) throw new Error('score must be 1 or -1.');
    await this.rest.insert('ai_feedback', { account_id: accountId, provider, model, task: TASKS.includes(task) ? task : 'logic', score: s, source: source === 'test' ? 'test' : 'person', note: note ? String(note).slice(0, 500) : null, ms });
    return { ok: true };
  }

  /** Run TEST_SUITE on each connected AI (or the ones named). Every result becomes feedback, so the strength sort learns. */
  async test(accountId, { providers = null } = {}) {
    const keys = await this.keys(accountId);
    const which = Object.keys(keys).filter((k) => !providers || providers.includes(k));
    const results = [];
    for (const k of which) {
      const row = { provider: k, name: PROVIDERS[k].name, passed: 0, total: TEST_SUITE.length, cases: [], ms: 0 };
      for (const t of TEST_SUITE) {
        const r = await this.complete(accountId, { system: 'Answer with JSON only, exactly the shape asked for. Think carefully; the numbers must be right.', user: t.ask, maxTokens: 800 }, { task: t.task, only: k });
        const ok = !r.error && !!t.check(parseJson(r.text));
        row.cases.push({ id: t.id, task: t.task, ok, ms: r.ms ?? null, error: r.error || null });
        if (ok) row.passed++; row.ms += r.ms || 0;
        if (!r.error || statusOf(r.error) === 0) {
          await this.feedback(accountId, { provider: k, model: PROVIDERS[k].model, task: t.task, score: ok ? 1 : -1, source: 'test', note: t.id, ms: r.ms ?? null }).catch(() => {});
          if (!r.error) await this.feedback(accountId, { provider: k, model: PROVIDERS[k].model, task: 'speed', score: r.ms <= FAST_MS ? 1 : -1, source: 'test', note: t.id, ms: r.ms }).catch(() => {});
        }
      }
      row.ms = Math.round(row.ms / TEST_SUITE.length);
      results.push(row);
    }
    return { ok: true, results };
  }

  /** Everything the AI page shows: each provider, connected or not, in this account's current order. */
  async status(accountId) {
    const [keys, prefs, usage, votes] = await Promise.all([this.keys(accountId), this.prefs(accountId), this.usage(accountId), this.votes(accountId)]);
    const nowMs = this.now();
    const order = orderCandidates(routable(), { sort: prefs.sort, order: prefs.order, usage, votes, nowMs });
    const connectedOrder = order.filter((k) => keys[k] && !prefs.disabled.includes(k));
    return {
      ok: true, sort: prefs.sort, sorts: SORTS, tasks: TASKS,
      providers: order.map((k) => {
        const p = PROVIDERS[k]; const u = usage[k] || null;
        return {
          key: k, name: p.name, short: p.short, domain: p.domain, model: p.model, free: !!p.free, get: p.get, service: p.service,
          connected: !!keys[k], enabled: !prefs.disabled.includes(k), turn: connectedOrder.indexOf(k) + 1 || null,
          fuel: fuel(u, nowMs), cooling: !!(u?.cooldown_until && Date.parse(u.cooldown_until) > nowMs), cooldown_until: u?.cooldown_until || null,
          today: u ? { requests: u.requests, tokens: Number(u.tokens || 0), failures: u.failures, remaining_requests: u.remaining_requests, remaining_tokens: u.remaining_tokens, limit_requests: u.limit_requests, limit_tokens: u.limit_tokens, last_error: u.last_error, last_ms: u.last_ms } : null,
          strengths: Object.fromEntries(TASKS.map((t) => { const v = votes[k]?.[t] || {}; return [t, { score: Math.round(strength(p.strengths?.[t] ?? 0.5, v.up || 0, v.down || 0) * 100), votes: (v.up || 0) + (v.down || 0) }]; })),
        };
      }),
    };
  }
}
