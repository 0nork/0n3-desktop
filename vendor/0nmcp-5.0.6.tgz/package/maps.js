/**
 * THE MAP BLOCKS (2026-11-12, Mike: "this should be part of the canvas … the map features and capabilities of both
 * GraphHopper and OpenStreetMap should be added into 0n3 in full").
 *
 * The catalog already reaches every endpoint (graphhopper, nominatim, overpass, openstreetmap). These are the same
 * capabilities as BLOCKS a person drops on the canvas, in plain words, each writing ONE receipt line:
 *
 *   find_places     names → coordinates                  OpenStreetMap search (no key) or GraphHopper
 *   name_points     coordinates → the place there        OpenStreetMap search (no key) or GraphHopper
 *   road_route      stops in order → miles, time, line   GraphHopper
 *   distance_table  every from → every to                GraphHopper matrix
 *   reach_area      how far in N minutes / miles         GraphHopper isochrone
 *   best_order      the shortest order to visit stops    GraphHopper route optimization
 *   group_places    places → territories                 GraphHopper clustering
 *   find_nearby     truck stops, low bridges, … near a place or along a line    Overpass (no key)
 *   map_note        tell OpenStreetMap the map is wrong  the signed-in OpenStreetMap account
 *   draw_map        everything the job found so far, as ONE map on the receipt (and on the board)
 *
 * Every block that learns a position adds it to ctx.__map, so "Draw a map" needs no wiring: it draws what the job knows.
 * A point is { name, lat, lon }. A line is [[lat, lon], …]. Pure except for the injected `api(service, endpoint, params)`.
 * Public-server manners are kept here, not left to the caller: OpenStreetMap search is asked once a second and at most
 * MAX_LOOKUPS times a step; Overpass queries are bounded and time-limited; lines are thinned before they are stored.
 */
import { parseCoord, thin, heightMetres } from './apps/truck-route-check.js';

const MI = 1609.344;
export const MAX_LOOKUPS = 12;
const LINE_POINTS = 240;
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
const r1 = (n) => Math.round(n * 10) / 10;
const num = (v, d, lo, hi) => { const n = Number(String(v ?? '').replace(/[^\d.-]/g, '')); return Number.isFinite(n) && String(v ?? '').trim() !== '' ? Math.min(hi, Math.max(lo, n)) : d; };
const yes = (v) => /^(y|yes|true|1|on)$/i.test(String(v ?? '').trim());
const PROFILES = ['car', 'truck', 'small_truck', 'bike', 'foot', 'scooter', 'racingbike', 'mtb', 'hike'];
export const profileOf = (v) => { const s = String(v || 'car').trim().toLowerCase().replace(/\s+/g, '_'); return PROFILES.includes(s) ? s : /truck|semi|lorry|hgv/.test(s) ? 'truck' : /walk/.test(s) ? 'foot' : /bi(ke|cycle)/.test(s) ? 'bike' : 'car'; };
const hoursText = (h) => (h < 1 ? `${Math.round(h * 60)} min` : `${Math.floor(h)} h ${String(Math.round((h % 1) * 60)).padStart(2, '0')} min`);

/** Anything a person or an earlier block can hand over → a list of { name, lat?, lon? }. Names with no position still need a lookup. */
export function readPlaces(value) {
  const out = [];
  const one = (x) => {
    if (x == null || x === '') return;
    if (Array.isArray(x)) { if (x.length === 2 && x.every((n) => typeof n === 'number')) out.push({ name: `${x[0]}, ${x[1]}`, lat: x[0], lon: x[1] }); else x.forEach(one); return; }
    if (typeof x === 'object') {
      if (Array.isArray(x.places)) { x.places.forEach(one); return; }
      const lat = Number(x.lat ?? x.latitude), lon = Number(x.lon ?? x.lng ?? x.longitude);
      if (Number.isFinite(lat) && Number.isFinite(lon) && (x.lat ?? x.latitude) !== '' ) out.push({ ...x, name: String(x.name || x.label || x.display_name || `${lat}, ${lon}`), lat, lon });
      else if (x.name || x.label || x.address) out.push({ name: String(x.name || x.label || x.address) });
      return;
    }
    const s = String(x).trim(); if (!s) return;
    if (s.startsWith('[') || s.startsWith('{')) { try { one(JSON.parse(s)); return; } catch { /* a place name that starts with a bracket */ } }
    for (const line of s.split(/\n|;/).map((t) => t.trim()).filter(Boolean)) { const c = parseCoord(line); out.push(c ? { name: line, lat: c[0], lon: c[1] } : { name: line }); }
  };
  one(value);
  return out;
}

/** A line handed over as [[lat, lon], …], or null when the value is not one. */
export function readLine(value) {
  let v = value; if (typeof v === 'string' && v.trim().startsWith('[')) { try { v = JSON.parse(v); } catch { return null; } }
  if (v && typeof v === 'object' && !Array.isArray(v) && Array.isArray(v.line)) v = v.line;
  return Array.isArray(v) && v.length >= 2 && v.every((p) => Array.isArray(p) && p.length === 2 && p.every((n) => typeof n === 'number')) ? v : null;
}

/** What "Find things near" can look for, in a person's words → Overpass filters. `r` = how far, as an Overpass around() clause. */
export const NEARBY = {
  'truck stops': (r) => `nwr${r}[amenity=fuel][hgv=yes];nwr${r}[highway=services];`,
  'rest areas': (r) => `nwr${r}[highway=rest_area];`,
  'weigh stations': (r) => `nwr${r}[amenity=weighbridge];`,
  'low bridges': (r) => `way${r}[maxheight];way${r}["maxheight:physical"];`,
  'weight limits': (r) => `way${r}[maxweight];`,
  'no-truck roads': (r) => `way${r}[hgv=no];`,
  fuel: (r) => `nwr${r}[amenity=fuel];`,
  food: (r) => `nwr${r}[amenity~"^(restaurant|fast_food|cafe)$"];`,
  hotels: (r) => `nwr${r}[tourism~"^(hotel|motel)$"];`,
  parking: (r) => `nwr${r}[amenity=parking][hgv~"^(yes|designated)$"];`,
  hospitals: (r) => `nwr${r}[amenity=hospital];`,
  'charging stations': (r) => `nwr${r}[amenity=charging_station];`,
  warehouses: (r) => `nwr${r}[building=warehouse][name];`,
};
export function nearbyQuery(what, coords, metres, { timeout = 25, limit = 80 } = {}) {
  const raw = String(what || '').trim();
  const around = `(around:${Math.round(metres)},${coords.map(([la, lo]) => `${la.toFixed(5)},${lo.toFixed(5)}`).join(',')})`;
  const kinds = raw.toLowerCase().split(/,| and /).map((s) => s.trim()).filter(Boolean);
  const known = kinds.filter((k) => NEARBY[k]);
  // A tag written the OpenStreetMap way (amenity=bank) is used as it is; anything else must be one of the plain names.
  const tags = kinds.filter((k) => !NEARBY[k] && /^[a-z_:]+(=|~)[^\s;\[\]()]+$/i.test(k));
  const unknown = kinds.filter((k) => !NEARBY[k] && !tags.includes(k));
  if (!kinds.length || unknown.length) return { error: `${unknown.length ? `“${unknown.join(', ')}” is not something this block knows how to look for. ` : ''}Pick from: ${Object.keys(NEARBY).join(', ')} — or write an OpenStreetMap tag like amenity=bank.` };
  const body = known.map((k) => NEARBY[k](around)).join('') + tags.map((t) => `nwr${around}[${t.replace(/^([^=~]+)([=~])(.*)$/, (_, k, op, val) => `"${k}"${op}"${val}"`)}];`).join('');
  return { query: `[out:json][timeout:${timeout}];(${body});out center tags ${limit};`, kinds: [...known, ...tags] };
}
const kindOf = (t = {}) => (t.amenity === 'fuel' ? (t.hgv === 'yes' ? 'Truck fuel' : 'Fuel') : t.highway === 'rest_area' ? 'Rest area' : t.highway === 'services' ? 'Service area' : t.amenity === 'weighbridge' ? 'Weigh station'
  : t.maxheight || t['maxheight:physical'] ? 'Posted height' : t.maxweight ? 'Weight limit' : t.hgv === 'no' ? 'No trucks' : (t.amenity || t.tourism || t.building || t.highway || 'Place').replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase()));

/** Add what a block learned to the job's map, so "Draw a map" draws it without being wired to every block. */
export function remember(ctx, { points = [], lines = [], areas = [] }) {
  const m = ctx.__map = ctx.__map || { points: [], lines: [], areas: [] };
  for (const p of points) if (Number.isFinite(p.lat) && Number.isFinite(p.lon) && m.points.length < 400 && !m.points.some((q) => q.lat === p.lat && q.lon === p.lon && q.name === p.name)) m.points.push({ name: String(p.name || '').slice(0, 80), lat: p.lat, lon: p.lon, ...(p.kind ? { kind: p.kind } : {}), ...(p.n ? { n: p.n } : {}) });
  for (const l of lines) if (m.lines.length < 40) m.lines.push({ name: String(l.name || '').slice(0, 80), pts: thin(l.pts, LINE_POINTS).map(([a, b]) => [Math.round(a * 1e5) / 1e5, Math.round(b * 1e5) / 1e5]), ...(l.dashed ? { dashed: true } : {}) });
  for (const a of areas) if (m.areas.length < 12) m.areas.push({ name: String(a.name || '').slice(0, 80), pts: thin(a.pts, LINE_POINTS).map(([x, y]) => [Math.round(x * 1e5) / 1e5, Math.round(y * 1e5) / 1e5]) });
}

/** The finished map: what was remembered, plus the box that holds it. */
export function drawMap(ctx, { title = '', extra = null } = {}) {
  if (extra) { const line = readLine(extra); if (line) remember(ctx, { lines: [{ name: '', pts: line }] }); else remember(ctx, { points: readPlaces(extra).filter((p) => p.lat != null) }); }
  const m = ctx.__map || { points: [], lines: [], areas: [] };
  const all = [...m.points.map((p) => [p.lat, p.lon]), ...m.lines.flatMap((l) => l.pts), ...m.areas.flatMap((a) => a.pts)];
  if (!all.length) return { ok: false, why: 'There is nothing to draw yet. Put “Find places” or “Road route” before this block.' };
  const box = [Math.min(...all.map((p) => p[0])), Math.min(...all.map((p) => p[1])), Math.max(...all.map((p) => p[0])), Math.max(...all.map((p) => p[1]))];
  return { ok: true, map: { title: String(title || '').slice(0, 120), box, points: m.points, lines: m.lines, areas: m.areas, credit: '© OpenStreetMap contributors' } };
}

/**
 * Run one map block. → { state: 'ok'|'failed'|'skipped', detail, out?, extra? }  (extra goes on the receipt line)
 * `api(service, endpoint, params)` → { ok, status, data, error, notConnected, usage }.
 */
export async function runMapBlock({ op, app, v, ctx, api, dry = false, wait = sleep }) {
  const notConn = (svc, r) => ({ state: r.notConnected ? 'skipped' : 'failed', detail: r.notConnected ? `${svc} is not in your vault — connect it first` : /minutely api limit/i.test(String(r.error)) ? `${svc} allows only a few requests a minute on your plan and this job reached that. Nothing is wrong with the block: run it again in a minute, or put a Wait before it.` : `${svc}: ${r.error}` });
  const credits = (r) => (r?.usage?.leftToday != null ? { credits: r.usage } : {});
  const creditText = (r) => (r?.usage?.leftToday != null ? ` · ${r.usage.leftToday} of ${r.usage.dailyLimit} GraphHopper credits left today` : '');
  ctx.__geo = ctx.__geo || {};
  let asked = 0;
  /** Names → positions. OpenStreetMap search by default (no key), GraphHopper when the block says so. Never guesses: a name that finds nothing fails the block. */
  const locate = async (list, { country = '', via = 'nominatim' } = {}) => {
    const out = [];
    for (const p of list) {
      if (p.lat != null) { out.push(p); continue; }
      const k = `${via}:${country}:${p.name.toLowerCase()}`;
      if (ctx.__geo[k]) { out.push({ ...ctx.__geo[k] }); continue; }
      if (asked >= MAX_LOOKUPS) return { error: `This step looked up ${MAX_LOOKUPS} place names, which is the most one step asks OpenStreetMap for. Give coordinates for the rest, or split the list over two blocks.` };
      let hit = null; let r;
      if (via === 'graphhopper') {
        r = await api('graphhopper', 'geocode', { q: p.name, limit: 1, ...(country ? { countrycode: country.split(',')[0] } : {}) });
        const h = r.ok ? r.data?.hits?.[0] : null; if (h) hit = { name: [h.name, h.state, h.country].filter(Boolean).join(', '), lat: h.point.lat, lon: h.point.lng };
      } else {
        if (asked) await wait(1100);
        r = await api('nominatim', 'search', { q: p.name, limit: 1, ...(country ? { countrycodes: country } : {}) });
        const h = r.ok && Array.isArray(r.data) ? r.data[0] : null; if (h) hit = { name: h.display_name, lat: Number(h.lat), lon: Number(h.lon) };
      }
      asked++;
      if (!r.ok) return { error: r.notConnected ? `${via === 'graphhopper' ? 'GraphHopper' : 'OpenStreetMap search'} is not in your vault — connect it first` : `Looking up “${p.name}”: ${r.error}`, skipped: r.notConnected };
      if (!hit) return { error: `No place called “${p.name}” was found. Write it like “Rhodes, MI” or give coordinates as “43.90, -84.17”.` };
      const found = { ...hit, asked: p.name }; ctx.__geo[k] = found; out.push({ ...found });
    }
    return { places: out };
  };
  const need = async (value, what, min = 1) => {
    const list = readPlaces(value);
    if (list.length < min) return { fail: { state: 'failed', detail: `This block needs ${min === 1 ? `a ${what}` : `at least ${min} ${what}`}. Write one per line, as a place (“Atlanta, GA”) or coordinates (“33.75, -84.39”).` } };
    const got = await locate(list, { country: String(v.country || '').trim().toLowerCase() });
    return got.error ? { fail: { state: got.skipped ? 'skipped' : 'failed', detail: got.error } } : { places: got.places };
  };
  const short = (p) => String(p.asked || p.name).split(',').slice(0, 2).join(',').slice(0, 40);

  if (op === 'find_places') {
    const list = readPlaces(v.places);
    if (!list.length) return { state: 'failed', detail: 'There is no place to find. Write one per line, like “Rhodes, MI”.' };
    const got = await locate(list, { country: String(v.country || '').trim().toLowerCase(), via: app === 'graphhopper' ? 'graphhopper' : 'nominatim' });
    if (got.error) return { state: got.skipped ? 'skipped' : 'failed', detail: got.error };
    remember(ctx, { points: got.places });
    return { state: 'ok', detail: `${got.places.length} place${got.places.length === 1 ? '' : 's'} found on OpenStreetMap`, out: { places: got.places, first: got.places[0], count: got.places.length }, extra: { list: got.places.slice(0, 12).map((p) => `${p.asked || p.name} → ${p.lat.toFixed(4)}, ${p.lon.toFixed(4)}${p.asked ? ` (${String(p.name).slice(0, 70)})` : ''}`) } };
  }

  if (op === 'name_points') {
    const list = readPlaces(v.points).filter((p) => p.lat != null).slice(0, MAX_LOOKUPS);
    if (!list.length) return { state: 'failed', detail: 'This block needs coordinates, one per line, like “43.90, -84.17”.' };
    const out = [];
    for (const [i, p] of list.entries()) {
      let r; let name = null;
      if (app === 'graphhopper') { r = await api('graphhopper', 'reverse_geocode', { point: `${p.lat},${p.lon}`, reverse: true, limit: 1 }); const h = r.ok ? r.data?.hits?.[0] : null; if (h) name = [h.name, h.city, h.state, h.country].filter(Boolean).join(', '); }
      else { if (i) await wait(1100); r = await api('nominatim', 'reverse', { lat: p.lat, lon: p.lon, zoom: num(v.detail, 16, 3, 18), addressdetails: 1 }); if (r.ok && r.data?.display_name) name = r.data.display_name; }
      if (!r.ok) return notConn(app === 'graphhopper' ? 'GraphHopper' : 'OpenStreetMap search', r);
      out.push({ name: name || 'Nothing named here', lat: p.lat, lon: p.lon, ...(r.data?.address ? { city: r.data.address.city || r.data.address.town || r.data.address.village || '', state: r.data.address.state || '', postcode: r.data.address.postcode || '' } : {}) });
    }
    remember(ctx, { points: out });
    return { state: 'ok', detail: `${out.length} point${out.length === 1 ? '' : 's'} named`, out: { places: out, first: out[0], count: out.length }, extra: { list: out.map((p) => `${p.lat.toFixed(4)}, ${p.lon.toFixed(4)} → ${String(p.name).slice(0, 90)}`) } };
  }

  if (op === 'road_route') {
    const g = await need(v.stops, 'stops', 2); if (g.fail) return g.fail;
    const profile = profileOf(v.vehicle);
    let r = await api('graphhopper', 'route', { points: g.places.map((p) => [p.lon, p.lat]), profile, calc_points: true, points_encoded: false, instructions: yes(v.directions) });
    let used = profile; let fellBack = '';
    // A plan that has no truck routing says so; the line is then a car route and the receipt SAYS it is, never a silent swap.
    if (!r.ok && !r.notConnected && profile !== 'car' && /profile|vehicle|not (allowed|supported|available)|upgrade|package/i.test(String(r.error))) { fellBack = String(r.error).slice(0, 140); r = await api('graphhopper', 'route', { points: g.places.map((p) => [p.lon, p.lat]), profile: 'car', calc_points: true, points_encoded: false, instructions: yes(v.directions) }); used = 'car'; }
    if (!r.ok) return notConn('GraphHopper', r);
    const path = r.data?.paths?.[0]; if (!path) return { state: 'failed', detail: 'GraphHopper found no road between those stops.' };
    const line = thin((path.points?.coordinates || []).map(([lo, la]) => [la, lo]), LINE_POINTS);
    const miles = r1(path.distance / MI), hours = Math.round(path.time / 36000) / 100;
    const name = `${short(g.places[0])} → ${short(g.places[g.places.length - 1])}`;
    remember(ctx, { points: g.places.map((p, i) => ({ ...p, n: i + 1 })), lines: [{ name, pts: line }] });
    const steps = yes(v.directions) ? (path.instructions || []).slice(0, 60).map((s) => `${s.text} · ${r1(s.distance / MI)} mi`) : [];
    return { state: 'ok', detail: `${name}: ${miles.toLocaleString('en-US')} miles, ${hoursText(hours)} by ${used.replace('_', ' ')}${fellBack ? ` — your GraphHopper plan refused the ${profile.replace('_', ' ')} route (“${fellBack}”), so this is a CAR route` : ''}${creditText(r)}`,
      out: { miles, hours, minutes: Math.round(hours * 60), vehicle: used, asked_vehicle: profile, line, stops: g.places, from: g.places[0], to: g.places[g.places.length - 1], ...(steps.length ? { directions: steps } : {}) }, extra: { ...credits(r), ...(steps.length ? { list: steps.slice(0, 20) } : {}) } };
  }

  if (op === 'distance_table') {
    const a = await need(v.from, 'starting place'); if (a.fail) return a.fail;
    const b = String(v.to ?? '').trim() === '' || (Array.isArray(v.to) && !v.to.length) ? { places: a.places } : await need(v.to, 'destination'); if (b.fail) return b.fail;
    if (a.places.length * b.places.length > 400) return { state: 'failed', detail: `That is ${a.places.length} × ${b.places.length} pairs. One block asks for at most 400; split the list.` };
    const r = await api('graphhopper', 'matrix', { from_points: a.places.map((p) => [p.lon, p.lat]), to_points: b.places.map((p) => [p.lon, p.lat]), out_arrays: ['distances', 'times'], profile: profileOf(v.vehicle), fail_fast: false });
    if (!r.ok) return notConn('GraphHopper', r);
    const rows = [];
    a.places.forEach((f, i) => b.places.forEach((t, j) => { const d = r.data?.distances?.[i]?.[j], s = r.data?.times?.[i]?.[j]; if (!(f.lat === t.lat && f.lon === t.lon)) rows.push({ from: short(f), to: short(t), miles: d == null ? null : r1(d / MI), hours: s == null ? null : Math.round(s / 36) / 100 }); }));
    remember(ctx, { points: [...a.places, ...b.places] });
    const near = [...rows].filter((x) => x.miles != null).sort((x, y) => x.miles - y.miles);
    return { state: 'ok', detail: `${rows.length} road distance${rows.length === 1 ? '' : 's'} between ${a.places.length} and ${b.places.length} places${near.length ? ` · shortest ${near[0].from} → ${near[0].to}, ${near[0].miles} mi` : ''}${creditText(r)}`,
      out: { rows, closest: near[0] || null, farthest: near[near.length - 1] || null, from: a.places, to: b.places }, extra: { ...credits(r), list: near.slice(0, 12).map((x) => `${x.from} → ${x.to}: ${x.miles} mi, ${hoursText(x.hours)}`) } };
  }

  if (op === 'reach_area') {
    const g = await need(v.from, 'starting place'); if (g.fail) return g.fail;
    const p = g.places[0]; const miles = num(v.miles, 0, 0, 500); const minutes = num(v.minutes, miles ? 0 : 30, 0, 600);
    const r = await api('graphhopper', 'isochrone', { point: `${p.lat},${p.lon}`, ...(miles ? { distance_limit: Math.round(miles * MI) } : { time_limit: Math.round(minutes * 60) }), profile: profileOf(v.vehicle), buckets: 1, ...(yes(v.toward) ? { reverse_flow: true } : {}) });
    if (!r.ok) return notConn('GraphHopper', r);
    const ring = r.data?.polygons?.[0]?.geometry?.coordinates?.[0]; if (!ring) return { state: 'failed', detail: 'GraphHopper returned no area for that place.' };
    const pts = thin(ring.map(([lo, la]) => [la, lo]), LINE_POINTS); const label = miles ? `${miles} miles` : `${minutes} minutes`;
    remember(ctx, { points: [p], areas: [{ name: `${label} from ${short(p)}`, pts }] });
    return { state: 'ok', detail: `The area within ${label} of ${short(p)} by ${profileOf(v.vehicle)}${creditText(r)}`, out: { areas: [pts], area: pts, from: p, minutes: miles ? null : minutes, miles: miles || null }, extra: credits(r) };
  }

  if (op === 'best_order') {
    const s = await need(v.start, 'starting place'); if (s.fail) return s.fail;
    const g = await need(v.stops, 'stops', 2); if (g.fail) return g.fail;
    const back = yes(v.back); const start = s.places[0];
    const r = await api('graphhopper', 'optimize', { vehicles: [{ vehicle_id: 'v1', type_id: 't1', start_address: { location_id: 'start', lon: start.lon, lat: start.lat }, return_to_depot: back }], vehicle_types: [{ type_id: 't1', profile: profileOf(v.vehicle) }],
      services: g.places.map((p, i) => ({ id: `s${i}`, name: short(p), address: { location_id: `s${i}`, lon: p.lon, lat: p.lat } })), objectives: [{ type: 'min', value: 'completion_time' }], configuration: { routing: { calc_points: true } } });
    if (!r.ok) return notConn('GraphHopper', r);
    const route = r.data?.solution?.routes?.[0]; if (!route) return { state: 'failed', detail: `GraphHopper could not order those stops${r.data?.message ? `: ${r.data.message}` : '.'}` };
    const order = route.activities.filter((a) => a.type === 'service').map((a) => g.places[Number(String(a.id).slice(1))]).filter(Boolean);
    const line = route.points ? route.points.flatMap((seg) => (seg.coordinates || []).map(([lo, la]) => [la, lo])) : [];
    const miles = r1((r.data.solution.distance || 0) / MI), hours = Math.round((r.data.solution.transport_time || 0) / 36) / 100;
    const left = (r.data.solution.unassigned?.services || []).length;
    remember(ctx, { points: [{ ...start, n: 0 }, ...order.map((p, i) => ({ ...p, n: i + 1 }))], lines: line.length > 1 ? [{ name: 'Best order', pts: line }] : [{ name: 'Best order', pts: [start, ...order, ...(back ? [start] : [])].map((p) => [p.lat, p.lon]), dashed: true }] });
    return { state: left ? 'failed' : 'ok', detail: `${order.length} stops put in the shortest order: ${miles.toLocaleString('en-US')} miles, ${hoursText(hours)} of driving${back ? ', back to the start' : ''}${left ? ` — ${left} stop(s) could not be reached` : ''}${creditText(r)}`,
      out: { stops: order, start, miles, hours, line: thin(line, LINE_POINTS), back }, extra: { ...credits(r), list: order.map((p, i) => `${i + 1}. ${p.asked || p.name}`) } };
  }

  if (op === 'group_places') {
    const g = await need(v.places, 'places', 2); if (g.fail) return g.fail;
    const k = Math.round(num(v.groups, 2, 2, 20)); if (k > g.places.length) return { state: 'failed', detail: `You asked for ${k} groups but gave ${g.places.length} places.` };
    const per = Math.ceil(g.places.length / k);
    const r = await api('graphhopper', 'cluster', { configuration: { response_type: 'json', routing: { profile: profileOf(v.vehicle), cost_per_second: 1 }, clustering: { num_clusters: k, max_quantity: per + Math.ceil(per / 2), min_quantity: 1 } }, customers: g.places.map((p, i) => ({ id: `c${i}`, address: { lon: p.lon, lat: p.lat }, quantity: 1 })) });
    if (!r.ok) return notConn('GraphHopper', r);
    const cl = r.data?.clusters || []; if (!cl.length) return { state: 'failed', detail: 'GraphHopper returned no groups.' };
    const groups = cl.map((c, i) => ({ group: i + 1, places: (c.ids || []).map((id) => g.places[Number(String(id).slice(1))]).filter(Boolean) }));
    remember(ctx, { points: groups.flatMap((x) => x.places.map((p) => ({ ...p, n: x.group, kind: `Group ${x.group}` }))) });
    return { state: 'ok', detail: `${g.places.length} places put into ${groups.length} groups by road distance${creditText(r)}`, out: { groups, count: groups.length }, extra: { ...credits(r), list: groups.map((x) => `Group ${x.group}: ${x.places.map(short).join(' · ')}`) } };
  }

  if (op === 'find_nearby') {
    const line = readLine(v.near); let coords; let where;
    if (line) { coords = thin(line, 60); where = 'along the route'; }
    else { const g = await need(v.near, 'place to look near'); if (g.fail) return g.fail; coords = [[g.places[0].lat, g.places[0].lon]]; where = `near ${short(g.places[0])}`; }
    const miles = num(v.miles, line ? 2 : 10, 0.1, line ? 10 : 50);
    const q = nearbyQuery(v.what, coords, miles * MI, { limit: Math.round(num(v.max, 60, 1, 200)) });
    if (q.error) return { state: 'failed', detail: q.error };
    let r = await api('overpass', 'query', { data: q.query });
    // The public query server sheds load with 429/502/504; one patient second try is its own advice, a loop is not.
    if (!r.ok && /429|502|503|504|busy|timeout|timed out/i.test(String(r.error))) { await wait(9000); r = await api('overpass', 'query', { data: q.query }); }
    if (!r.ok) return { state: 'failed', detail: `OpenStreetMap's query server: ${r.error}. It is a shared public server and is often busy; run the job again in a minute.` };
    if (r.data?.remark && !(r.data.elements || []).length) return { state: 'failed', detail: `OpenStreetMap's query server gave up: ${String(r.data.remark).slice(0, 160)}. Look within fewer miles.` };
    const seen = new Set(); const places = [];
    for (const e of r.data?.elements || []) { const lat = e.lat ?? e.center?.lat, lon = e.lon ?? e.center?.lon; if (lat == null || lon == null) continue; const t = e.tags || {}; const kind = kindOf(t); const k = `${kind}:${t.name || ''}:${lat.toFixed(3)},${lon.toFixed(3)}`; if (seen.has(k)) continue; seen.add(k);
      const h = heightMetres(t.maxheight ?? t['maxheight:physical']);
      places.push({ name: t.name || t.brand || t.ref || kind, kind, lat, lon, ...(h != null ? { height_m: h, height_ft: r1(h / 0.3048) } : {}), ...(t.maxweight ? { max_weight: t.maxweight } : {}), ...(t.opening_hours ? { hours: t.opening_hours } : {}), ...(t['addr:city'] ? { city: t['addr:city'] } : {}), osm: `${e.type}/${e.id}` }); }
    remember(ctx, { points: places });
    return { state: 'ok', detail: `${places.length} ${q.kinds.join(' and ')} found within ${miles} mile${miles === 1 ? '' : 's'} ${where}`, out: { places, count: places.length, first: places[0] || null }, extra: { list: places.slice(0, 14).map((p) => `${p.kind}: ${p.name}${p.height_ft ? ` · ${p.height_ft} ft` : ''}${p.max_weight ? ` · ${p.max_weight} t` : ''} (${p.lat.toFixed(4)}, ${p.lon.toFixed(4)})`) } };
  }

  if (op === 'map_note') {
    const g = await need(v.where, 'place the note is about'); if (g.fail) return g.fail;
    const text = String(v.text || '').trim(); if (text.length < 10) return { state: 'failed', detail: 'Write what is wrong on the map, in a sentence a local mapper can act on.' };
    const p = g.places[0];
    if (dry) return { state: 'ok', detail: `Dry run — would leave a public note on OpenStreetMap at ${p.lat.toFixed(5)}, ${p.lon.toFixed(5)}. Nothing was sent.`, out: { dry: true }, extra: { dry: true, would: { where: short(p), text: text.slice(0, 160) } } };
    const r = await api('openstreetmap', 'create_note', { lat: p.lat, lon: p.lon, text });
    if (!r.ok) return notConn('OpenStreetMap', r);
    const id = r.data?.properties?.id; remember(ctx, { points: [{ ...p, kind: 'Map note' }] });
    return { state: 'ok', detail: `Note ${id ? `#${id} ` : ''}left on OpenStreetMap at ${short(p)}. It is public and signed with your OpenStreetMap name.`, out: { id, url: id ? `https://www.openstreetmap.org/note/${id}` : null, where: p } };
  }
  return { state: 'failed', detail: `Unknown map block “${op}”.` };
}
