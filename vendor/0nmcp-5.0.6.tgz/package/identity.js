/**
 * IDENTITY — the 0n_ token is the account.
 *
 * Exactly the rule www.0nmcp.com applies (src/lib/token-auth.ts): a scoped
 * token in `access_tokens` (revocable, expiring) wins; otherwise the master
 * token on `profiles.access_token`. Both live on the 0nCore database, so a
 * token minted by 0nCore (`0n_live_…`) and one minted by 0nmcp.com resolve to
 * the same profile row here. Nothing else identifies a caller.
 */
import { createHash } from 'node:crypto';
export function bearerOf(req) {
  const h = req.headers?.authorization || req.headers?.Authorization || '';
  const m = /^Bearer\s+(.+)$/i.exec(String(h).trim());
  return m ? m[1].trim() : '';
}

export function looksLikeToken(t) {
  return typeof t === 'string' && t.startsWith('0n_') && t.length >= 16;
}

/**
 * @param {string} token
 * @param {{ select(table, filters, columns?): Promise<any[]> }} rest
 * @returns {Promise<null | { accountId: string, email: string|null, name: string|null, crmLocationId: string|null, scope: 'scoped'|'master', permissions: any }>}
 */
export async function resolveIdentity(token, rest) {
  if (!looksLikeToken(token)) return null;
  // access_tokens as it actually exists on the 0nCore database (measured 2026-09-13):
  // id, user_id, token, name, permission_level, scopes[], expires_at, is_active, revoked_at …
  // (www.0nmcp.com's token-auth.ts selects `label, permissions, is_revoked`, none of which exist.)
  // By HASH (2026-10-29): the table holds no readable tokens. Every row's token_hash is sha256(token), measured 26/26.
  const scoped = (await rest.select('access_tokens', { token_hash: createHash('sha256').update(String(token)).digest('hex') }, 'id, user_id, name, permission_level, scopes, expires_at, is_active, revoked_at, last_used_at, metadata'))[0];
  if (scoped) {
    if (scoped.is_active === false || scoped.revoked_at) return null;
    if (scoped.expires_at && new Date(scoped.expires_at) < new Date()) return null;
    // LAST USED (2026-11-24): never written before this, so all 161 of Mike's keys read "never used" and none could be
    // safely retired. Stamped at most every 10 minutes per key; fire-and-forget, a failed stamp never blocks a call.
    if (typeof rest.update === 'function' && (!scoped.last_used_at || Date.now() - new Date(scoped.last_used_at).getTime() > 600_000)) {
      Promise.resolve().then(() => rest.update('access_tokens', { id: scoped.id }, { last_used_at: new Date().toISOString() })).catch((e) => console.error('[identity] last_used_at', e.message));
    }
    const p = (await rest.select('profiles', { id: scoped.user_id }, 'id, email, full_name, crm_location_id'))[0];
    if (!p) return null;
    return { accountId: p.id, email: p.email || null, name: p.full_name || null, crmLocationId: p.crm_location_id || null, scope: 'scoped', permissions: { level: scoped.permission_level || null, scopes: scoped.scopes || [], tokenId: scoped.id, tokenName: scoped.name || null, client: scoped.metadata?.client_id ? { id: scoped.metadata.client_id, name: scoped.metadata.client_name || null } : null } };
  }
  const p = (await rest.select('profiles', { access_token: token }, 'id, email, full_name, crm_location_id'))[0];
  if (!p) return null;
  return { accountId: p.id, email: p.email || null, name: p.full_name || null, crmLocationId: p.crm_location_id || null, scope: 'master', permissions: null };
}
