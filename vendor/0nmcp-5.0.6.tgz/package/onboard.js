/**
 * ONBOARDING (2026-10-29) — Mike: "frictionless sign up, generate the account, build the CRM sub-account and get them
 * connected to Google as quick as possible … fluent and simple so anyone can follow."
 *
 *   1 sign up        Supabase (Google, or an email link) → /api/session makes the 0n3 account
 *   2 business       POST /api/onboard/business {name, website} → profile, CRM sub-account named after the business,
 *                    first workspace — all at once, results returned for the "we're building it" screen
 *   3 Google         POST /api/onboard/google {refresh_token} → the refresh token Supabase's Google sign-in returned
 *                    (same Google client as 0n3's door, so 0n3's minter refreshes it) is proven with Google and stored as
 *                    the account's `google` connection, exactly the shape the door writes
 *   4 first win      POST /api/onboard/finish {template} → that template's sequence in the workspace; onboarding done
 *   GET /api/onboard/state → where this account is, so a reload resumes, never restarts
 */
import { makeConnection } from './envelope.js';
import { provisionCrm } from './crm-provision.js';
import { splitTemplate } from './flow-defs.js';

const clean = (s, n) => String(s || '').trim().slice(0, n);
/** Scopes the Connect Google step asks for — the same set as 0n3's Google door. */
export const GOOGLE_SCOPES = ['openid', 'email', 'profile', 'https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/drive.file',
  'https://www.googleapis.com/auth/tasks', 'https://www.googleapis.com/auth/spreadsheets'];

export function createOnboarding({ rest, store, workspaces, env = process.env, fetchImpl = fetch }) {
  const profile = async (id) => (await rest.select('profiles', { id }, 'id, email, full_name, business_name, website, onboarding_step, onboarding_complete, crm_location_id, provisioning_error, created_at'))[0] || null;
  async function state(accountId) {
    const p = await profile(accountId); const recs = await store.list(accountId);
    const crm = recs.find((r) => r.service === 'crm'); const google = recs.find((r) => r.service === 'google');
    const ws = workspaces ? (await workspaces.list(accountId))[0] || null : null;
    return {
      fresh: !!p?.created_at && Date.now() - new Date(p.created_at).getTime() < 7 * 864e5,
      business: p?.business_name || null, website: p?.website || null, step: p?.onboarding_step || null, done: !!p?.onboarding_complete,
      crm: crm ? { ready: true, location: crm.meta?.location_id || null, tier: crm.meta?.tier || null } : { ready: false, reason: p?.provisioning_error || null },
      google: google ? { connected: true, email: google.meta?.email || null, scopes: String(google.meta?.scopes || '').split(/\s+/).filter(Boolean).length } : { connected: false },
      workspace: ws ? { id: ws.id, name: ws.name, slug: ws.slug, sequences: ws.sequences || 0 } : null,
    };
  }
  async function business(accountId, { name, website } = {}) {
    const bn = clean(name, 120); if (bn.length < 2) throw new Error('What is your business called?');
    const site = clean(website, 200).replace(/^https?:\/\//, '').replace(/\/.*$/, '') || null;
    await rest.update('profiles', { id: accountId }, { business_name: bn, ...(site ? { website: site } : {}), onboarding_step: 2 });
    const p = await profile(accountId);
    // The CRM sub-account, named after the business (skipped when the account already has a CRM of its own).
    let crm; try { crm = await provisionCrm({ profile: { ...p, business_name: bn }, store, rest, env, fetchImpl, timeoutMs: 20_000 }); } catch (e) { crm = { ok: false, reason: e.message }; }
    // The first workspace, named after the business.
    let ws = workspaces ? (await workspaces.list(accountId))[0] : null; let wsError = null;
    if (!ws && workspaces) { try { ws = await workspaces.create(accountId, { name: bn, tagline: site ? `${bn} · ${site}` : bn }); } catch (e) { wsError = e.message; } }
    return { account: true, crm: { ok: !!crm?.ok || !!crm?.skipped && !!crm?.locationId, created: !!crm?.created, reason: crm?.ok ? null : crm?.reason || null, test: /test address/.test(crm?.reason || '') }, workspace: ws ? { id: ws.id, name: ws.name, slug: ws.slug } : null, workspaceError: wsError, state: await state(accountId) };
  }
  async function google(accountId, { refresh_token } = {}) {
    const rt = String(refresh_token || ''); if (rt.length < 20) throw new Error('Google did not send a lasting connection — press Connect Google again.');
    if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) throw new Error('Google is not configured on this server.');
    // Prove it: a refresh only works for OUR Google client and a live grant. What comes back says which scopes were granted.
    const r = await fetchImpl('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: rt, client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET }).toString() });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.access_token) throw new Error(`Google did not accept that connection (${d.error_description || d.error || r.status}).`);
    const who = await (await fetchImpl('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: `Bearer ${d.access_token}` } })).json().catch(() => ({}));
    const env2 = makeConnection({ service: 'google', name: who.email ? `Google · ${who.email}` : 'Google', authType: 'oauth',
      credentials: { client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET, refresh_token: rt },
      meta: { email: who.email || null, scopes: d.scope || '', via: 'oauth', connected_during: 'onboarding' } });
    await store.put(accountId, env2, { actor: 'onboarding' });
    await rest.update('profiles', { id: accountId }, { onboarding_step: 4 }).catch(() => {});
    return { connected: true, email: who.email || null, scopes: String(d.scope || '').split(/\s+/).filter(Boolean) };
  }
  async function finish(accountId, { template } = {}) {
    const p = await profile(accountId);
    let ws = workspaces ? (await workspaces.list(accountId))[0] : null;
    if (!ws && workspaces) ws = await workspaces.create(accountId, { name: p?.business_name || 'My business' });
    let added = null;
    if (template && ws) {
      const t = splitTemplate(String(template), String(p?.business_name || 'Acme').split(' ')[0]);
      if (!t.sequence) throw new Error('Unknown starting point.');
      const got = await workspaces.getCanvas(accountId, ws.id); const cv = got && got.v === 2 ? { ...got, pages: got.pages || [], sequences: got.sequences || [], board: got.board || { items: [], links: [] } } : { v: 2, pages: [], sequences: [], board: { items: [], links: [] } };
      if (!cv.sequences.some((s) => s.name === t.sequence.name)) {
        await workspaces.setCanvas(accountId, ws.id, { ...cv, sequences: [...cv.sequences, t.sequence], board: { items: [...(cv.board?.items || []), { id: Math.random().toString(36).slice(2, 8), kind: 'seq', ref: t.sequence.id, x: 40 + (cv.board?.items || []).length * 300, y: 40 }], links: cv.board?.links || [] } });
      }
      added = { name: t.sequence.name, id: t.sequence.id };
    }
    await rest.update('profiles', { id: accountId }, { onboarding_step: 6, onboarding_complete: true, onboarding_completed: true }).catch(() => {});
    return { done: true, workspace: ws ? { id: ws.id, slug: ws.slug } : null, sequence: added };
  }
  return { state, business, google, finish };
}
