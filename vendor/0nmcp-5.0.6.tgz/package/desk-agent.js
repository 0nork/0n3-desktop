// SOURCE OF TRUTH: github.com/0nork/0n3-desk (private). Edit there, then `npm run sync` copies it into the 0n3 repo.
/**
 * THE DESK AGENT — the piece that runs on the person's own computer.
 *
 *   0n3 desk login            paste the token the Install page shows (or --token …); names this machine
 *   0n3 desk status           what is configured, whether the relay is paired, how many runs wait
 *   0n3 desk run              claim runs for this machine and work them, forever (--once: one pass;
 *                             --browser: also start the Chrome relay; --agent claude|codex|gemini)
 *   0n3 desk compute list | add <task> --cwd <folder> -- <cmd…> | remove <task>   math jobs this computer runs (no AI)
 *   0n3 desk install          keep it running: launchd (macOS) or a systemd user unit (Linux)
 *   0n3 desk projects …       the project keeper (projects.js): tidy, bring, open — runs daily on its own
 *   0n3 desk ask <run> "<q>" "<a|b>"   from inside a turn: pause and ask the phone, then END THE TURN
 *   0n3 desk note <run> "<text>"       progress note on the thread
 *   0n3 desk done <run> <reply.md> [--failed]
 *   0n3 browse <op> [args…]   drive the paired Chrome (open, goto, text, eval, click, type, shot, close)
 *
 * Nothing is pushed to this machine. It asks 0n3 for queued runs addressed to it (or to no machine),
 * claims one, writes the whole thread + any files into a run folder, and starts ONE headless turn of the
 * chosen agent in the desk's project folder with THE DESK CONTRACT. The agent ends its turn in one of
 * three states: done (receipt), question (the run waits; the phone answers; the next pass resumes it
 * with the full thread), or failed. One run at a time; a crashed turn never re-wakes forever because
 * the claim already moved the run out of `queued`.
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync, rmdirSync, rmSync, appendFileSync, chmodSync, realpathSync } from 'node:fs';
import { verifyFor } from './desk-sign.js';
import { join, dirname, resolve, sep } from 'node:path';
import { homedir, hostname, platform } from 'node:os';
import { spawn, spawnSync, execSync } from 'node:child_process';
import { loadRegistry, saveRegistry, machineCaps, canTake, computeReply, TASK_RE } from './desk-compute.js';
import { createRelay, sendBrowse, newCode, DEFAULT_PORT } from './browse-relay.js';
const PKG = (() => { try { return JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8')); } catch { return {}; } })();
const VERSION = PKG.version || '0';
export const PKG_NAME = PKG.name || '';

/** a > b for plain x.y.z versions. */
export function newer(a, b) { const pa = String(a).split('.').map(Number); const pb = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((pa[i] || 0) > (pb[i] || 0)) return true; if ((pa[i] || 0) < (pb[i] || 0)) return false; } return false; }
/**
 * SELF-UPDATE (the 0n3-desk package only — the copy inside 0nmcp / the desktop app never updates itself this way).
 * Reads <url>/dl/0n3-desk/latest.json; if newer and no job is running, installs it with the npm that sits next to this
 * Node, then exits so launchd/systemd starts the new version. Never mid-turn. ON3_DESK_NO_UPDATE=1 turns it off.
 */
export async function maybeUpdate(cfg, { force = false, log: say = () => {} } = {}) {
  if (PKG_NAME !== '0n3-desk' || process.env.ON3_DESK_NO_UPDATE === '1') return { skipped: 'not the 0n3-desk package' };
  if (!force && ACTIVE.size > 0) return { skipped: 'a job is running' };
  const base = (cfg && cfg.url) || 'https://0n3.app';
  let latest; try { latest = await (await fetch(`${base}/dl/0n3-desk/latest.json`, { signal: AbortSignal.timeout(15000) })).json(); } catch (e) { return { error: `could not reach ${base}: ${e.message}` }; }
  if (!latest?.version || !newer(latest.version, VERSION)) return { current: VERSION, latest: latest?.version || null, upToDate: true };
  const npm = join(dirname(process.execPath), platform() === 'win32' ? 'npm.cmd' : 'npm');
  const url = latest.url || `${base}/dl/0n3-desk-${latest.version}.tgz`;
  // installed by install.sh into its own folder (<prefix>/node_modules/0n3-desk) — update in place; a global install stays global
  const pkgDir = dirname(new URL(import.meta.url).pathname); const prefix = dirname(dirname(pkgDir));
  const where = prefix.endsWith(`${sep}lib`) ? ['-g', '--force'] : ['--prefix', prefix];
  const r = spawnSync(existsSync(npm) ? npm : 'npm', ['install', '--no-fund', '--no-audit', ...where, url], { encoding: 'utf8', env: { ...process.env, PATH: `${dirname(process.execPath)}:${process.env.PATH || ''}` } });
  if (r.status !== 0) return { error: `npm install failed: ${(r.stderr || r.stdout || '').trim().split('\n').slice(-3).join(' ')}` };
  say(`updated 0n3-desk ${VERSION} → ${latest.version}`);
  return { updated: true, from: VERSION, to: latest.version };
}

const HOME = homedir();
export const CONFIG = join(HOME, '.0n', 'desk.json');
export const ROOT = join(HOME, '.0n', 'desk');
const LOCK = join(ROOT, '.lock');
const LOG = join(ROOT, 'desk.log');
const log = (s) => { try { mkdirSync(ROOT, { recursive: true }); appendFileSync(LOG, `[${new Date().toISOString()}] ${s}\n`); } catch { /* */ } };

/**
 * THE PASS LOCK (2026-11-09). macOS has no flock, so a pass is guarded by `mkdir .lock`. A killed agent left the directory
 * behind and every later pass said "another pass is running" for 20 minutes while runs sat queued. The lock now names its
 * owner (pid + time); a lock whose owner is gone, or older than six hours, is stale and is taken over.
 */
const alive = (pid) => { if (!pid) return false; try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
export function takeLock(lock = LOCK) {
  mkdirSync(dirname(lock), { recursive: true });
  try { mkdirSync(lock); } catch {
    let owner = null; try { owner = JSON.parse(readFileSync(join(lock, 'owner.json'), 'utf8')); } catch { /* an old-style lock has no owner */ }
    const stale = !owner || !alive(owner.pid) || Date.now() - Date.parse(owner.at || 0) > 6 * 3600_000;
    if (!stale) return false;
    log(`stale pass lock (pid ${owner?.pid || '?'}, since ${owner?.at || 'unknown'}) taken over`);
    try { rmSync(lock, { recursive: true, force: true }); mkdirSync(lock); } catch { return false; }
  }
  writeFileSync(join(lock, 'owner.json'), JSON.stringify({ pid: process.pid, at: new Date().toISOString() }));
  return true;
}
export const releaseLock = (lock = LOCK) => { try { rmSync(lock, { recursive: true, force: true }); } catch { /* */ } };

/** Turns in flight on this machine: folder (or ask:<id>) → run id. One turn per folder; several folders at once. */
export const ACTIVE = new Map();
const PENDING = new Set();
const track = (key, id, p) => { ACTIVE.set(key, id); PENDING.add(p); p.finally(() => { ACTIVE.delete(key); PENDING.delete(p); }); return p; };
/** Wait for every turn in flight (one pass mode, tests). */
export const settle = () => Promise.all([...PENDING]);

/**
 * Run a child and collect its output WITHOUT blocking the loop (2026-11-09: spawnSync froze the agent for the whole turn, so
 * nothing polled, nothing heartbeated, and every page said the desk was offline during a long build). `heartbeat()` is
 * called every 30 s while the child runs.
 */
export function spawnCollect(bin, args, { cwd, env, timeoutMs = 3 * 3600_000, maxBuffer = 16 * 1024 * 1024, heartbeat = null } = {}) {
  return new Promise((done) => {
    let stdout = ''; let stderr = ''; let error = null; let timedOut = false;
    const child = spawn(bin, args, { cwd, env, stdio: ['ignore', 'pipe', 'pipe'] });
    const take = (which) => (d) => { const s = String(d); if (which === 'out') { if (stdout.length < maxBuffer) stdout += s; } else if (stderr.length < maxBuffer) stderr += s; };
    child.stdout.on('data', take('out')); child.stderr.on('data', take('err'));
    const t = setTimeout(() => { timedOut = true; try { child.kill('SIGTERM'); } catch { /* */ } }, timeoutMs);
    const hb = heartbeat ? setInterval(() => { Promise.resolve().then(heartbeat).catch(() => {}); }, 30_000) : null;
    child.on('error', (e) => { error = e; });
    child.on('close', (status) => { clearTimeout(t); if (hb) clearInterval(hb); done({ status: status ?? (error ? 1 : 0), stdout, stderr, error: error || (timedOut ? new Error(`timed out after ${timeoutMs / 1000} s`) : null) }); });
  });
}

export const AGENTS = {
  claude_code: { name: 'Claude Code', bins: ['claude'], args: (prompt) => ['-p', prompt, '--permission-mode', 'bypassPermissions'] },
  // Codex 0.170 removed --full-auto (2026-11-24): workspace-write sandbox, no approval prompts
  codex: { name: 'Codex CLI', bins: ['codex'], args: (prompt) => ['exec', '--skip-git-repo-check', '-s', 'workspace-write', '-c', 'approval_policy="never"', prompt] },
  gemini_cli: { name: 'Gemini CLI', bins: ['gemini'], args: (prompt) => ['-p', prompt, '--yolo'] },
};
const PATH_EXTRA = [`${HOME}/.0n/bin`, `${HOME}/.local/bin`, '/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin'];

/**
 * THIS COMPUTER'S ALLOW LIST (2026-10-28). The server says which folder a job is for; this file says which folders this
 * computer agrees to work in. A job for any other folder is refused and reported — the server cannot widen it. The first
 * run of this version trusts the folders the account already configured (so a working desk keeps working), then locks:
 * only `0n3 desk allow <folder>`, typed on this machine, adds one.
 */
export const ALLOW = join(HOME, '.0n', 'desk-allow.json');
const real = (p) => { const abs = resolve(String(p).replace(/^~(?=$|\/)/, HOME)); try { return realpathSync(abs); } catch { return abs; } };
export function loadAllow() { try { const j = JSON.parse(readFileSync(ALLOW, 'utf8')); return { folders: (j.folders || []).map(String), seededAt: j.seededAt || null }; } catch { return null; } }
export function saveAllow(a) { mkdirSync(dirname(ALLOW), { recursive: true }); writeFileSync(ALLOW, JSON.stringify({ ...a, note: 'Folders this computer lets 0n3 desk jobs work in. Edit with: 0n3 desk allow <folder> | 0n3 desk disallow <folder>' }, null, 2), { mode: 0o600 }); return a; }
/** Is `folder` one of the allowed folders, or inside one? Symlinks are resolved first, so a link cannot walk out. Home itself is never allowed. */
export const SITES = join(ROOT, 'sites');
/** Clone a GitHub repo (owner/name) into the desk's sites folder, or pull it if it is already there. */
export function cloneSite(repo) {
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)) return { error: `not a GitHub repo name: ${repo}` };
  const folder = join(SITES, repo.replace('/', '__'));
  try {
    mkdirSync(SITES, { recursive: true });
    if (!existsSync(join(folder, '.git'))) {
      const r = spawnSync('git', ['clone', '--depth', '50', `https://github.com/${repo}.git`, folder], { encoding: 'utf8', timeout: 180_000 });
      if (r.status !== 0) return { error: `git clone failed: ${(r.stderr || r.stdout || '').trim().split('\n').slice(-3).join(' ')}` };
      log(`cloned ${repo} into ${folder}`);
    } else {
      spawnSync('git', ['-C', folder, 'pull', '--ff-only'], { encoding: 'utf8', timeout: 120_000 });
    }
    return { folder };
  } catch (e) { return { error: e.message }; }
}
export function folderAllowed(folder, allow = loadAllow()) {
  if (!folder) return false;
  const f = real(folder); if (f === real(HOME) || f === sep) return false;
  if (f === real(SITES) || f.startsWith(real(SITES) + sep)) return true; // the desk's own clones
  if (!allow) return false;
  return allow.folders.some((a) => { const r = real(a); return r !== real(HOME) && (f === r || f.startsWith(r.endsWith(sep) ? r : r + sep)); });
}

/**
 * THE KEY THIS COMPUTER TRUSTS (2026-10-29). Pinned the first time the server offers one; after that every job and
 * config must carry a fresh signature from it (see desk-sign.js). `0n3 desk trust --reset` re-pins after a key rotation.
 */
export const TRUST = join(HOME, '.0n', 'desk-trust.json');
export function loadTrust() { try { const j = JSON.parse(readFileSync(TRUST, 'utf8')); return j.kid && j.x ? j : null; } catch { return null; } }
function saveTrust(t) { mkdirSync(dirname(TRUST), { recursive: true }); writeFileSync(TRUST, JSON.stringify({ ...t, note: 'The 0n3 key this computer trusts for desk jobs. Reset with: 0n3 desk trust --reset' }, null, 2), { mode: 0o600 }); return t; }
async function trustFor(api, cfg) {
  const have = loadTrust(); if (have) return have;
  const r = await api.call('/.well-known/0n3-desk-key.json').catch(() => null);
  const k = r?.keys?.[0]; if (!k?.kid || !k?.x) return null; // this server does not sign yet: nothing to pin
  log(`pinned the 0n3 desk key ${k.kid} from ${cfg.url || 'https://0n3.app'} — from now on only jobs it signed will run here`);
  return saveTrust({ kid: k.kid, x: k.x, url: cfg.url || 'https://0n3.app', pinnedAt: new Date().toISOString() });
}

export function loadConfig() { try { return JSON.parse(readFileSync(CONFIG, 'utf8')); } catch { return null; } }
export function saveConfig(c) { mkdirSync(dirname(CONFIG), { recursive: true }); writeFileSync(CONFIG, JSON.stringify(c, null, 2), { mode: 0o600 }); return c; }
const machineName = () => hostname().replace(/\.local$/, '').toLowerCase();

/** Talk to 0n3 with the desk token. Throws with the server's words. */
export function client(cfg) {
  const base = (cfg.url || 'https://0n3.app').replace(/\/$/, '');
  const H = { Authorization: `Bearer ${cfg.token}`, 'Content-Type': 'application/json' };
  const call = async (path, init = {}) => {
    const r = await fetch(base + path, { ...init, headers: { ...H, ...(init.headers || {}) } });
    if (init.raw) return r;
    const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = { error: t.slice(0, 200) }; }
    if (!r.ok) throw new Error(`${path} → ${r.status}: ${j.error || t.slice(0, 200)}`);
    return j;
  };
  return { base, call };
}

/** Where a run's files live on this machine. */
export const runDir = (id) => join(ROOT, 'runs', id);

/** thread.md: everything the turn needs to read, in order. Files are listed by name; they sit in the same folder. */
export function writeThread(dir, run, desk, machine) {
  const files = (run.source?.files || []).map((f) => f.name);
  const lines = [
    `# Desk run ${run.id} · ${run.project || ''} · state ${run.state}`,
    desk ? `Project folder: ${desk.folder || '(not set)'}\nRules: ${desk.rules || '(none)'}\nMachine: ${machine}` : `Machine: ${machine}`,
    files.length ? `Files in this folder: ${files.join(', ')} (open images and PDFs with your file reader)` : 'Files: none',
    '',
  ];
  // A canvas run: what the person selected and a text picture of the whole board, so the agent knows what is drawn.
  if (run.source?.kind === 'canvas') {
    const sel = run.source.selection || [];
    lines.push(`## THE BOARD (canvas ${run.source.boardId || ''})`, sel.length ? `Selected:\n${sel.map((e) => `- ${e.type}${e.x !== undefined ? ` at (${e.x}, ${e.y})${e.width !== undefined ? ` ${e.width}x${e.height}` : ''}` : ''}${e.text ? `: "${e.text}"` : ''}`).join('\n')}` : 'Nothing selected.', run.source.sceneText ? `Whole board:\n${run.source.sceneText}` : 'The board is empty.', `(also in ${join(dir, 'canvas.json')})`, '');
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'canvas.json'), JSON.stringify({ boardId: run.source.boardId || null, selection: sel, sceneText: run.source.sceneText || '' }, null, 2));
  }
  for (const t of run.thread || []) lines.push(`## ${String(t.role).toUpperCase()} · ${t.by || ''} · ${t.at}\n${t.text}${t.options?.length ? `\nOptions: ${t.options.join(' | ')}` : ''}\n`);
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'thread.md'), lines.join('\n'));
}

/** The contract every turn gets. `bin` is how the agent reaches this CLI from the shell. */
export function contract(runId, dir, bin = '0n3', run = null) {
  return `${run?.source?.kind === 'canvas' ? canvasContract(dir) : ''}THE DESK CONTRACT (0n3 run ${runId}): work in the project folder named in ${dir}/thread.md and read its CLAUDE.md (or README) first. Keep every rule in the desk's Rules. If anything is UNCLEAR or the request needs a choice the owner has not made, DO NOT ACT: run  ${bin} desk ask ${runId} "<one plain question>" "<option|option>"  and END YOUR TURN immediately — the answer re-queues this run and a new turn continues from ${dir}/thread.md. Anything outward-facing (deploy, send, charge, publish) needs a yes unless the request or the desk's Rules already gave it. Progress notes:  ${bin} desk note ${runId} "<what you found>" . A browser, when one is paired:  ${bin} browse open <url> | text | eval "<js>" | shot <file.png>  (see ${bin} browse --help). When finished, write a short plain-text report (built+verified / unverified / blocked) to ${dir}/reply.md and run  ${bin} desk done ${runId} ${dir}/reply.md  (add --failed if it did not finish). Never claim something is done that you did not verify.`;
}

/**
 * THE CANVAS CLAUSE (2026-10-31): a run asked from a 0n3 canvas board may draw back. The server lifts the block out of
 * the reply (canvas.js extractCanvas), keeps at most 200 elements and only the keys listed here, and the board draws them.
 */
export function canvasContract(dir) {
  return `THIS REQUEST CAME FROM A 0n3 CANVAS BOARD (an Excalidraw whiteboard the owner is drawing on while chatting with you). What is drawn and what they selected is in ${dir}/thread.md under THE BOARD and in ${dir}/canvas.json. Keep notes short — they stream live into the chat. You MAY draw on the board: in reply.md include ONE fenced block that starts with \`\`\`0n3-canvas and holds a JSON array of Excalidraw skeleton elements, e.g.\n\`\`\`0n3-canvas\n[{"type":"rectangle","id":"a","x":100,"y":100,"width":180,"height":80,"label":{"text":"Step 1"},"backgroundColor":"#ffd8a8"},{"type":"ellipse","id":"b","x":400,"y":100,"width":160,"height":80,"label":{"text":"Step 2"}},{"type":"arrow","x":280,"y":140,"width":120,"height":0,"start":{"id":"a"},"end":{"id":"b"}},{"type":"text","x":100,"y":220,"text":"A note"}]\n\`\`\`\nAllowed: type rectangle|ellipse|diamond|arrow|line|text, x, y (required), width, height, text (text only), label {text}, strokeColor, backgroundColor, fillStyle, strokeWidth, fontSize, id, start/end {id} for arrows, points for lines. At most 200 elements; place new shapes near the selection or in empty space. The block is removed from the text the owner reads. Two more fences the board understands (2026-11-09): a \`\`\`mermaid block (flowchart, sequenceDiagram or classDiagram; short quoted labels, no classDef/style) is converted and drawn as hand-drawn shapes — use it for any diagram or process; a \`\`\`0n3-sequence block holding {"name":"…","nodes":[{"type":"trigger|task|logic|data|ai","key":"<a key from the 0n3 builder vocabulary, flow-defs.js>","title":"…","app":"<service>","values":{…}}],"edges":[{"from":0,"to":1,"port":0,"wait":"2 days"}]} is drawn as 0n3 blocks and wires the owner can save into a workspace and RUN — use it when they ask for a sequence, an automation or a follow-up that happens over time. One block of each kind at most. `;
}

export function promptFor(kind, runId, dir, bin, run = null) {
  return kind === 'resume'
    ? `The owner ANSWERED your question on their phone. Read ${dir}/thread.md — it holds the original request, what you found, your question and the answer. Continue from there. ${contract(runId, dir, bin, run)}`
    : `A request arrived at the desk. The request, the whole thread and any attached files are in ${dir} — read ${dir}/thread.md first. ${contract(runId, dir, bin, run)}`;
}

export function findBin(names) {
  for (const n of names) {
    try { const p = execSync(`command -v ${n}`, { encoding: 'utf8', env: { ...process.env, PATH: [process.env.PATH, ...PATH_EXTRA].join(':') } }).trim(); if (p) return p; } catch { /* next */ }
  }
  return null;
}

/** One headless turn. Returns { status, log }. */
const turnEnv = () => ({ ...process.env, PATH: [dirname(process.execPath), ...PATH_EXTRA, process.env.PATH].join(':') });
export async function runTurn({ agent = 'claude_code', prompt, cwd, dir, timeoutMs = 3 * 3600_000, heartbeat = null }) {
  const a = AGENTS[agent] || AGENTS.claude_code;
  const bin = findBin(a.bins);
  if (!bin) return { status: 127, log: `${a.name} is not installed (looked for: ${a.bins.join(', ')}). Install it, then: 0n3 desk login --agent ${agent}` };
  log(`turn start ${dir} (${a.name})`);
  if (!cwd || !existsSync(cwd)) return { status: 2, log: `The project folder ${cwd || '(none)'} does not exist on this computer.` };
  const r = await spawnCollect(bin, a.args(prompt), { cwd, timeoutMs, heartbeat, env: turnEnv() });
  const out = `${r.stdout || ''}\n${r.stderr || ''}`;
  writeFileSync(join(dir, 'turn.log'), out);
  log(`turn end ${dir} exit ${r.status}${r.error ? ` error ${r.error.message}` : ''}`);
  return { status: r.status, log: out };
}

/** Download the run's files next to thread.md over the owner's token. */
async function fetchFiles(api, run, dir) {
  for (const f of run.source?.files || []) {
    const target = join(dir, f.name); if (existsSync(target)) continue;
    const r = await api.call(`/api/desk/runs/${run.id}/files/${encodeURIComponent(f.name)}`, { raw: true });
    if (!r.ok) { log(`file ${f.name} → ${r.status}`); continue; }
    writeFileSync(target, Buffer.from(await r.arrayBuffer()));
  }
}

/** One pass: claim up to `max` runs for this machine and work them in order. Returns what happened. */
export async function pass(cfg, { max = 3, bin = '0n3', parallel = Number(cfg.parallel) || 3 } = {}) {
  const api = client(cfg); const machine = cfg.machine || machineName();
  if (!takeLock()) return { skipped: 'another pass is running' };
  const worked = [];
  // the heartbeat a running turn sends, so a long build never reads as "offline" (the poll is the other heartbeat)
  const beat = () => api.call('/api/desk/hello', { method: 'POST', body: JSON.stringify({ machine, agent: cfg.agent || 'claude_code', version: VERSION, busy: ACTIVE.size, caps: machineCaps() }) }).catch(() => {});
  try {
    const { runs = [] } = await api.call(`/api/desk/next?machine=${encodeURIComponent(machine)}&agent=${encodeURIComponent(cfg.agent || 'claude_code')}&version=${encodeURIComponent(VERSION)}&compute=1`);
    const trust = runs.length ? await trustFor(api, cfg) : loadTrust();
    const conf = runs.length ? await api.call('/api/desk/config') : { desks: [] };
    // An idle pass fetches no config, so there is nothing to verify (it used to log a refusal every 30 s).
    const cv = runs.length ? verifyFor('config', conf.desks || [], conf.signature, trust) : { ok: true };
    if (!cv.ok) { log(`refused the desk config: ${cv.why}`); return { machine, worked, refused: `config: ${cv.why}` }; }
    const desks = conf.desks || [];
    if (runs.length && !loadAllow()) {
      const seed = [...new Set(desks.map((d) => d.folder).filter(Boolean).map(real))].filter((f) => f !== real(HOME));
      saveAllow({ folders: seed, seededAt: new Date().toISOString() });
      log(`allow list created from the account's desks (first run of this version): ${seed.join(', ') || '(none)'}`);
    }
    // Compute jobs and AI turns have their own room: a long AI turn must not hold back a plan being re-solved, and three
    // compute jobs must not hold back a person's request (measured 2026-11-10: one AI turn left a scenario queued).
    const computeMax = Number(cfg.computeParallel) || 3;
    const nCompute = () => [...ACTIVE.keys()].filter((k) => String(k).startsWith('compute:')).length;
    const ordered = [...runs.filter((r) => r.source?.kind === 'compute'), ...runs.filter((r) => r.source?.kind !== 'compute').slice(0, max)];
    for (const run of ordered) {
      if (run.source?.kind === 'compute' ? nCompute() >= computeMax : ACTIVE.size - nCompute() >= parallel) continue; // enough of this kind in flight; it stays queued for the next pass
      // Where would this run work? Decided BEFORE claiming, so a run for a folder that is busy stays queued (one turn per
      // folder — two agents editing one repo at once is how work gets lost) and other folders proceed in parallel.
      // A COMPUTE job (math, no AI): this computer takes it only if it registered the task and is big enough; otherwise it
      // stays queued for a machine that can. It never holds a folder's turn lock, so several run side by side.
      if (run.source?.kind === 'compute') {
        const reg = loadRegistry(); const take = canTake(run, reg, machineCaps(reg), { allowed: folderAllowed });
        if (!take.ok) continue;
        const cc = await api.call(`/api/desk/runs/${run.id}/claim`, { method: 'POST', body: JSON.stringify({ machine }) });
        if (!cc.run?.claimed) continue;
        const cs = verifyFor('claim', cc.run, cc.signature, trust);
        if (!cs.ok) { log(`refused ${run.id}: ${cs.why}`); await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `Refused on ${machine}: ${cs.why}. Nothing was run.` }) }).catch(() => {}); worked.push({ id: run.id, project: run.source?.task, exit: null, state: 'refused' }); continue; }
        // the SIGNED run decides the task and args — re-check it against the registry, not the unsigned listing
        const again = canTake(cc.run, reg, machineCaps(reg), { allowed: folderAllowed });
        if (!again.ok) { await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `Refused on ${machine}: ${again.why}. Nothing was run.` }) }).catch(() => {}); worked.push({ id: run.id, project: run.source?.task, exit: null, state: 'refused' }); continue; }
        track(`compute:${run.id}`, run.id, computeTurn(api, cc.run, machine, again.task, beat));
        worked.push({ id: run.id, project: cc.run.source.task, exit: null, state: 'started' });
        continue;
      }
      const siteFolderEarly = run.source?.folder || '';
      const deskEarly = desks.find((d) => d.workspace === run.workspaceId) || desks.find((d) => d.project && d.project === run.project) || (siteFolderEarly ? { folder: siteFolderEarly } : null);
      const folderKey = run.source?.kind === 'ask' ? `ask:${run.id}` : deskEarly?.folder ? real(deskEarly.folder) : (run.source?.repo ? `repo:${run.source.repo}` : null);
      if (folderKey && ACTIVE.has(folderKey)) continue;
      const c = await api.call(`/api/desk/runs/${run.id}/claim`, { method: 'POST', body: JSON.stringify({ machine }) });
      if (!c.run?.claimed) continue;
      // Only a job 0n3 signed, unchanged and fresh, runs on a computer that pinned the key.
      const sv = verifyFor('claim', c.run, c.signature, trust);
      if (!sv.ok) {
        log(`refused ${run.id}: ${sv.why}`);
        await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `Refused on ${machine}: ${sv.why}. Nothing was run.` }) }).catch(() => {});
        worked.push({ id: run.id, project: run.project, exit: null, state: 'refused' });
        continue;
      }
      if (c.run.source?.kind === 'ask') { track(`ask:${run.id}`, run.id, askTurn(api, c.run, machine, cfg, beat)); worked.push({ id: run.id, project: run.source?.app || 'ask', exit: null, state: 'started' }); continue; }
      // A canvas ask can name its SITE (project + folder) without a drawn desk. The folder still has to be on THIS
      // computer's allow list — the server names it, this machine decides (2026-11-03).
      // A site may live only on GitHub (nothing local): clone it once into the desk's own sites folder, then work there.
      // That folder is this computer's, under ~/.0n/desk/sites, so it is always allowed; private repos need git credentials
      // already set up on this machine (gh auth / credential helper) — the token never leaves the vault.
      const cloned = !run.source?.folder && run.source?.repo ? cloneSite(run.source.repo) : null;
      if (cloned?.error) {
        log(`refused ${run.id}: ${cloned.error}`);
        await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `Could not get ${run.source.repo} onto ${machine}: ${cloned.error}`, by: `desk@${machine}` }) }).catch(() => {});
        worked.push({ id: run.id, project: run.project, exit: null, state: 'refused' });
        continue;
      }
      const siteFolder = run.source?.folder || cloned?.folder || '';
      const desk = desks.find((d) => d.workspace === run.workspaceId) || desks.find((d) => d.project && d.project === run.project)
        || (siteFolder ? { project: run.source.site || run.project || null, folder: siteFolder, agent: cfg.agent || 'claude_code', rules: '' } : null);
      // This computer decides where work happens: no folder, or one not on the allow list, is refused — never run in home.
      if (!desk?.folder || !folderAllowed(desk.folder)) {
        const why = !desk?.folder ? 'this request names no project folder' : `${desk.folder} is not on this computer's allow list`;
        log(`refused ${run.id}: ${why}`);
        await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `Refused on ${machine}: ${why}. Nothing was run. To allow it, type this on that computer:\n  ${bin} desk allow ${desk?.folder || '<project folder>'}`, by: `desk@${machine}` }) }).catch(() => {});
        worked.push({ id: run.id, project: run.project, exit: null, state: 'refused' });
        continue;
      }
      const dir = runDir(run.id);
      writeThread(dir, c.run, desk, machine);
      await fetchFiles(api, c.run, dir);
      const resumed = (run.thread || []).some((t) => t.role === 'answer');
      const agent = (desk && desk.agent) || cfg.agent || 'claude_code';
      const cwd = real(desk.folder);
      log(`desk ${resumed ? 'resume' : 'start'} ${run.id} (${run.project || 'no project'}) in ${cwd} with ${agent}`);
      if (ACTIVE.has(cwd)) { /* claimed a moment ago for a folder another run just took: let it wait its turn in that folder */ }
      const work = (async () => {
        const t = await runTurn({ agent, prompt: promptFor(resumed ? 'resume' : 'start', run.id, dir, bin, c.run), cwd, dir, heartbeat: beat });
        // A turn that neither asked nor finished is a turn that walked off. Close it so the phone is not left waiting forever.
        const after = await api.call(`/api/desk/runs/${run.id}`).catch(() => null);
        if (after?.run && after.run.state === 'running') {
          await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `The agent's turn ended without asking or finishing (exit ${t.status}). Last lines:\n${t.log.trim().split('\n').slice(-12).join('\n')}`, by: `desk@${machine}` }) }).catch(() => {});
        }
        process.stdout.write(`${new Date().toLocaleTimeString()} finished ${run.id} (${run.project || '-'} → ${after?.run?.state || `exit ${t.status}`})\n`);
        return { id: run.id, project: run.project, exit: t.status, state: after?.run?.state };
      })();
      track(cwd, run.id, work);
      worked.push({ id: run.id, project: run.project, exit: null, state: 'started' });
    }
  } finally { releaseLock(); }
  return { machine, worked, active: ACTIVE.size };
}

/**
 * AN ASK (2026-11-08): an app hands this computer's AI a question + photos (CardFlow: "read these card fronts") and wants the
 * answer as DATA. It never touches a project: it runs in its own run folder, the agent may only READ (no edits, no shell, no
 * web), and its printed answer IS the reply — the app polls the run and parses it. JSON asks are checked before they are sent
 * back. Claude Code only for now (it reads images with its Read tool); `model: fast` → haiku, otherwise sonnet.
 */
export function askArgs(run) {
  const names = (run.source?.files || []).map((f) => f.name);
  const prompt = `${run.request}\n\nThe files are in the current folder: ${names.join(', ') || '(none)'}. Read each one with the Read tool. ${run.source?.want === 'json' ? 'Answer with ONLY the JSON — no prose, no code fence.' : 'Answer plainly.'}`;
  return ['-p', prompt, '--allowedTools', 'Read', '--model', run.source?.model === 'fast' ? 'haiku' : 'sonnet', '--output-format', 'text'];
}
/** The answer as sent back: JSON asks must parse (a fenced or chatty answer is cut down to the JSON inside it). */
export function askReply(stdout, want) {
  const text = String(stdout || '').trim();
  if (want !== 'json') return { ok: !!text, reply: text || 'The desktop AI answered nothing.' };
  const cut = text.replace(/^```(?:json)?\s*|\s*```$/g, '');
  const m = /[[{][\s\S]*[\]}]/.exec(cut);
  try { const v = JSON.parse(m ? m[0] : cut); return { ok: true, reply: JSON.stringify(v) }; }
  catch { return { ok: false, reply: `The desktop AI did not answer in JSON: ${text.slice(0, 400)}` }; }
}
async function askTurn(api, run, machine, cfg, heartbeat = null) {
  const by = `desk@${machine}`; const agent = cfg.agent || 'claude_code';
  if (agent !== 'claude_code' || !findBin(AGENTS.claude_code.bins)) {
    await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: false, reply: `${machine} runs ${AGENTS[agent]?.name || agent}; app asks need Claude Code on this computer.`, by }) }).catch(() => {});
    return { id: run.id, project: run.source?.app || 'ask', exit: null, state: 'failed' };
  }
  const dir = runDir(run.id); mkdirSync(dir, { recursive: true });
  await fetchFiles(api, run, dir);
  const t0 = Date.now();
  const r = await spawnCollect(findBin(AGENTS.claude_code.bins), askArgs(run), { cwd: dir, timeoutMs: 6 * 60_000, maxBuffer: 8 * 1024 * 1024, heartbeat, env: turnEnv() });
  const a = r.status === 0 ? askReply(r.stdout, run.source?.want) : { ok: false, reply: `The desktop AI stopped (${r.error?.message || `exit ${r.status}`}): ${String(r.stderr || r.stdout || '').trim().slice(-400)}` };
  log(`ask ${run.id} (${run.source?.app || '-'}, ${(run.source?.files || []).length} file(s)) → ${a.ok ? 'ok' : 'failed'} in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
  await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: a.ok, reply: a.reply, by }) }).catch((e) => log(`ask ${run.id} done failed: ${e.message}`));
  return { id: run.id, project: run.source?.app || 'ask', exit: r.status, state: a.ok ? 'done' : 'failed' };
}

/**
 * A COMPUTE JOB: run the command THIS computer registered for the task. No shell, no AI, no tokens. The job reads its
 * args from ON3_COMPUTE_ARGS (JSON) and may print a JSON receipt as its last line ({"ok":true,"summary":"…",…}).
 */
export async function computeTurn(api, run, machine, task, heartbeat = null) {
  const by = `compute@${machine}`; const src = run.source || {}; const t0 = Date.now();
  log(`compute start ${run.id} ${src.task} ${JSON.stringify(src.args || {})}`);
  const r = await spawnCollect(task.cmd[0], task.cmd.slice(1), { cwd: real(task.cwd), timeoutMs: Math.min(6 * 3600, Math.max(10, Number(task.timeoutSec) || 1800)) * 1000, maxBuffer: 8 * 1024 * 1024, heartbeat,
    env: { ...turnEnv(), ON3_COMPUTE_TASK: String(src.task), ON3_COMPUTE_ARGS: JSON.stringify(src.args || {}), ON3_RUN_ID: String(run.id), ON3_MACHINE: machine } });
  const a = r.error ? { ok: false, receipt: null, reply: `Could not run "${src.task}" on ${machine}: ${r.error.message}` } : computeReply(r.stdout, r.stderr, r.status);
  const seconds = Math.round((Date.now() - t0) / 100) / 10;
  log(`compute end ${run.id} ${src.task} → ${a.ok ? 'ok' : 'failed'} in ${seconds} s`);
  await api.call(`/api/desk/runs/${run.id}/done`, { method: 'POST', body: JSON.stringify({ ok: a.ok, reply: a.reply, by, receipt: { ...(a.receipt || {}), compute: { task: src.task, machine, seconds, exit: r.status ?? null } } }) }).catch((e) => log(`compute ${run.id} done failed: ${e.message}`));
  return { id: run.id, project: src.task, exit: r.status, state: a.ok ? 'done' : 'failed' };
}

/** The forever loop. `everyMs` between passes; a relay when --browser. */
export async function loop(cfg, { everyMs = 30_000, browser = false, bin = '0n3', once = false } = {}) {
  let relay = null;
  if (browser) {
    const code = cfg.browse?.code || newCode(); const port = cfg.browse?.port || DEFAULT_PORT;
    saveConfig({ ...cfg, browse: { code, port } });
    relay = createRelay({ code, port, log });
    await relay.listen();
    process.stdout.write(`Chrome relay on 127.0.0.1:${port} · pairing code ${code} — in Chrome: 0n extension → Desk browsing → enter the code → On\n`);
  }
  // the Desk Agent window (dashboard.js ships with the 0n3-desk package only; the copy inside 0nmcp runs without it)
  let dash = null; try { const { startDashboard } = await import('./dashboard.js'); dash = await startDashboard({ log: (m) => process.stdout.write(m + '\n') }); } catch { /* no window in this build, or the port is taken */ }
  let lastWork = 0; let lastUpdateCheck = 0;
  const updateTick = async () => {
    if (once || Date.now() - lastUpdateCheck < 6 * 3600_000) return; lastUpdateCheck = Date.now();
    const u = await maybeUpdate(cfg, { log: (m) => process.stdout.write(m + '\n') }).catch((e) => ({ error: e.message }));
    if (u.error) log(`update check: ${u.error}`);
    if (u.updated) { if (relay) await relay.close().catch(() => {}); if (dash) await dash.close().catch(() => {}); process.exit(0); } // the service manager restarts the new version
  };
  process.stdout.write(`desk agent "${cfg.machine || machineName()}" (${AGENTS[cfg.agent || 'claude_code'].name}) watching ${cfg.url || 'https://0n3.app'}${once ? ' · one pass' : ` · every ${everyMs / 1000}s`}\n`);
  // say what this computer is (cores, memory, registered compute tasks) once at start; every busy heartbeat repeats it
  client(cfg).call('/api/desk/hello', { method: 'POST', body: JSON.stringify({ machine: cfg.machine || machineName(), agent: cfg.agent || 'claude_code', version: VERSION, caps: machineCaps() }) }).catch(() => {});
  for (;;) {
    let busy = false;
    try { const r = await pass(cfg, { bin }); busy = !!r.worked?.length || ACTIVE.size > 0; if (busy) lastWork = Date.now(); if (r.worked?.length) process.stdout.write(`${new Date().toLocaleTimeString()} worked ${r.worked.map((w) => `${w.id} (${w.project || '-'} → ${w.state || `exit ${w.exit}`})`).join(', ')}\n`); }
    catch (e) { log(`pass failed: ${e.message}`); process.stdout.write(`pass failed: ${e.message}\n`); }
    if (once) { await settle(); break; }
    if (ACTIVE.size === 0) await updateTick();
    // while someone is working (an app sent asks in the last 3 minutes) look every 3 s; otherwise every everyMs
    await new Promise((r) => setTimeout(r, busy || Date.now() - lastWork < 180_000 ? 3_000 : everyMs));
  }
  if (relay) await relay.close();
}

/** launchd / systemd so the agent survives a reboot. Absolute interpreter paths: a scheduled job has no PATH. */
export function installService({ browser = false } = {}) {
  const node = process.execPath; const cli = new URL('./cli.js', import.meta.url).pathname;
  const args = ['desk', 'run', ...(browser ? ['--browser'] : [])];
  if (platform() === 'darwin') {
    const dir = join(HOME, 'Library', 'LaunchAgents'); mkdirSync(dir, { recursive: true });
    const plist = join(dir, 'com.0n3.desk.plist');
    writeFileSync(plist, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.0n3.desk</string>
  <key>ProgramArguments</key><array><string>${node}</string><string>${cli}</string>${args.map((a) => `<string>${a}</string>`).join('')}</array>
  <key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>${join(ROOT, 'desk.out')}</string><key>StandardErrorPath</key><string>${join(ROOT, 'desk.err')}</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>${[dirname(node), ...PATH_EXTRA].join(':')}</string><key>HOME</key><string>${HOME}</string></dict>
</dict></plist>
`);
    try { execSync(`launchctl unload "${plist}" 2>/dev/null; launchctl load "${plist}"`); } catch (e) { return { file: plist, loaded: false, error: e.message }; }
    return { file: plist, loaded: true };
  }
  if (platform() === 'linux') {
    const dir = join(HOME, '.config', 'systemd', 'user'); mkdirSync(dir, { recursive: true });
    const unit = join(dir, '0n3-desk.service');
    writeFileSync(unit, `[Unit]\nDescription=0n3 desk agent\nAfter=network-online.target\n\n[Service]\nExecStart=${node} ${cli} ${args.join(' ')}\nRestart=always\nRestartSec=10\nEnvironment=PATH=${[dirname(node), ...PATH_EXTRA].join(':')}\nEnvironment=HOME=${HOME}\n\n[Install]\nWantedBy=default.target\n`);
    try { execSync(`systemctl --user daemon-reload && systemctl --user enable --now 0n3-desk.service`); } catch (e) { return { file: unit, loaded: false, error: e.message }; }
    return { file: unit, loaded: true };
  }
  return { file: null, loaded: false, error: `No service installer for ${platform()} yet. Run "0n3 desk run" in a terminal you keep open, or add it to your login items.` };
}
export function uninstallService() {
  if (platform() === 'darwin') { const plist = join(HOME, 'Library', 'LaunchAgents', 'com.0n3.desk.plist'); try { execSync(`launchctl unload "${plist}"`); } catch { /* */ } return { file: plist }; }
  if (platform() === 'linux') { try { execSync('systemctl --user disable --now 0n3-desk.service'); } catch { /* */ } return { file: join(HOME, '.config', 'systemd', 'user', '0n3-desk.service') }; }
  return { file: null };
}

/** The `0n3 desk …` and `0n3 browse …` commands. `argv` starts after "desk" / "browse". Returns an exit code. */
export async function deskCommand(argv, { out = (s) => process.stdout.write((typeof s === 'string' ? s : JSON.stringify(s, null, 2)) + '\n'), bin = '0n3' } = {}) {
  const flag = (n) => { const i = argv.indexOf(`--${n}`); return i >= 0 ? argv[i + 1] : undefined; };
  const has = (n) => argv.includes(`--${n}`);
  const sub = argv[0];
  if (sub === 'allow' || sub === 'disallow') {
    const a = loadAllow() || { folders: [], seededAt: null };
    if (has('list') || !argv[1]) { out(a.folders.length ? `This computer lets desk jobs work in:\n${a.folders.map((f) => `  ${f}`).join('\n')}` : 'No folders allowed yet. Add one: 0n3 desk allow <folder>'); return 0; }
    const f = real(argv[1]);
    if (sub === 'allow') {
      if (f === real(HOME) || f === sep) { out('Your whole home folder (or the disk root) cannot be allowed — pick the project folder.'); return 1; }
      if (!existsSync(f)) { out(`${f} does not exist.`); return 1; }
      if (!a.folders.map(real).includes(f)) a.folders.push(f); saveAllow(a); out(`Allowed: ${f}`); return 0;
    }
    const before = a.folders.length; a.folders = a.folders.filter((x) => real(x) !== f); saveAllow(a); out(a.folders.length < before ? `Removed: ${f}` : `${f} was not on the list.`); return 0;
  }
  if (sub === 'compute') {
    const reg = loadRegistry(); const act = argv[1];
    if (!act || act === 'list') { const ks = Object.keys(reg.tasks); out(ks.length ? `Compute tasks this computer runs (no AI):\n${ks.map((k) => `  ${k}  →  ${reg.tasks[k].cmd.join(' ')}   (in ${reg.tasks[k].cwd})`).join('\n')}\nThis computer: ${JSON.stringify(machineCaps(reg))}` : 'No compute tasks yet. Add one: 0n3 desk compute add <task> --cwd <folder> -- <command …>'); return 0; }
    const name = argv[2];
    if (!TASK_RE.test(name || '')) { out('A task name is lower-case letters, digits, dots and dashes (e.g. atlo.plan).'); return 1; }
    if (act === 'remove') { const had = !!reg.tasks[name]; delete reg.tasks[name]; saveRegistry(reg); out(had ? `Removed: ${name}` : `${name} was not registered.`); return 0; }
    if (act === 'add') {
      const dd = argv.indexOf('--'); const cmd = dd >= 0 ? argv.slice(dd + 1) : [];
      const cwd = flag('cwd') ? real(flag('cwd')) : null;
      if (!cwd || !existsSync(cwd)) { out('Name the project folder: --cwd <folder>'); return 1; }
      if (!folderAllowed(cwd)) { out(`${cwd} is not on this computer's allow list. Allow it first: ${bin} desk allow ${cwd}`); return 1; }
      if (!cmd.length) { out('Give the command after "--", e.g.  -- /opt/homebrew/bin/node scripts/worker/plan.mjs'); return 1; }
      reg.tasks[name] = { cwd, cmd, timeoutSec: Number(flag('timeout')) || 1800, addedAt: new Date().toISOString() };
      saveRegistry(reg); out(`Registered: ${name}  →  ${cmd.join(' ')}   (in ${cwd})`); return 0;
    }
    out('usage: 0n3 desk compute list | add <task> --cwd <folder> [--timeout <sec>] -- <command …> | remove <task>'); return 1;
  }
  if (sub === 'trust') {
    if (has('reset')) { try { writeFileSync(TRUST, '{}', { mode: 0o600 }); } catch { /* */ } out('Forgot the pinned key. The next job pins the key 0n3 offers then.'); return 0; }
    const t = loadTrust(); out(t ? `This computer runs only jobs signed by 0n3 key ${t.kid} (pinned ${t.pinnedAt} from ${t.url}).` : 'No key pinned yet. The first job from a server that signs will pin its key.'); return 0;
  }
  if (sub === 'login') {
    const token = flag('token') || process.env.ON3_TOKEN || await ask(`Paste the desk token from ${flag('url') || 'https://0n3.app'}/install?client=desk : `);
    if (!/^0n_/.test(token || '')) { out('That is not an 0n token (they start with 0n_).'); return 1; }
    const cfg = { ...(loadConfig() || {}), url: flag('url') || loadConfig()?.url || 'https://0n3.app', token, machine: flag('machine') || loadConfig()?.machine || machineName(), agent: flag('agent') || loadConfig()?.agent || 'claude_code' };
    if (!AGENTS[cfg.agent]) { out(`agent must be one of ${Object.keys(AGENTS).join(', ')}`); return 1; }
    const me = await client(cfg).call('/api/x/whoami').catch((e) => ({ error: e.message }));
    if (me.error) { out(`0n3 did not accept that token: ${me.error}`); return 1; }
    saveConfig(cfg);
    await client(cfg).call('/api/desk/hello', { method: 'POST', body: JSON.stringify({ machine: cfg.machine, agent: cfg.agent, version: VERSION, caps: machineCaps() }) }).catch(() => {});
    out(`Signed in as ${me.account?.email || me.email || 'your account'} · machine "${cfg.machine}" · agent ${AGENTS[cfg.agent].name}${findBin(AGENTS[cfg.agent].bins) ? '' : ' (NOT installed on this machine yet)'} · config ${CONFIG}`);
    return 0;
  }
  if (sub === 'projects') { let m; try { m = await import('./projects.js'); } catch { out('The project keeper is not part of this install.'); return 1; } return m.projectsCommand(argv.slice(1), { out }); }
  const cfg = loadConfig();
  if (sub === 'browse-help' || (sub === undefined && argv.length === 0)) { out(HELP); return 0; }
  if (!cfg && sub !== undefined) { out('Not signed in. Run: 0n3 desk login'); return 1; }
  if (sub === 'status') {
    const api = client(cfg);
    const [cfgs, queued] = await Promise.all([api.call('/api/desk/config').catch((e) => ({ error: e.message })), api.call(`/api/desk/next?machine=${encodeURIComponent(cfg.machine)}&agent=${encodeURIComponent(cfg.agent || 'claude_code')}&version=${encodeURIComponent(VERSION)}`).catch((e) => ({ error: e.message }))]);
    let relay = null; try { relay = await (await fetch(`http://127.0.0.1:${cfg.browse?.port || DEFAULT_PORT}/status`)).json(); } catch { /* not running */ }
    out({ machine: cfg.machine, agent: cfg.agent, agentInstalled: !!findBin(AGENTS[cfg.agent].bins), url: cfg.url, desks: cfgs.desks ? cfgs.desks.map((d) => ({ project: d.project, folder: d.folder, machine: d.machine || 'any' })) : cfgs.error, waitingForThisMachine: queued.runs ? queued.runs.length : queued.error, browser: relay ? { running: true, paired: relay.paired, code: cfg.browse?.code } : { running: false, hint: '0n3 desk run --browser' } });
    return 0;
  }
  if (sub === 'run') { await loop(cfg, { everyMs: Number(flag('every') || 10) * 1000, browser: has('browser'), once: has('once'), bin }); return 0; }
  if (sub === 'install') { out(installService({ browser: has('browser') })); return 0; }
  if (sub === 'uninstall') { out(uninstallService()); return 0; }
  if (sub === 'ask' || sub === 'note' || sub === 'done') {
    const id = argv[1]; if (!id) { out(`usage: 0n3 desk ${sub} <runId> …`); return 1; }
    const api = client(cfg); const by = `${cfg.agent}@${cfg.machine}`;
    if (sub === 'ask') { const r = await api.call(`/api/desk/runs/${id}/ask`, { method: 'POST', body: JSON.stringify({ text: argv[2] || '', options: (argv[3] || '').split('|').map((x) => x.trim()).filter(Boolean), by }) }); out(`asked · run is waiting · pushed to ${r.pushed?.sent ?? 0} phone(s). END YOUR TURN NOW.`); return 0; }
    if (sub === 'note') { await api.call(`/api/desk/runs/${id}/note`, { method: 'POST', body: JSON.stringify({ text: argv[2] || '', by }) }); out('noted'); return 0; }
    const file = argv[2]; if (!file || !existsSync(file)) { out('usage: 0n3 desk done <runId> <reply.md> [--failed]'); return 1; }
    const r = await api.call(`/api/desk/runs/${id}/done`, { method: 'POST', body: JSON.stringify({ reply: readFileSync(file, 'utf8'), ok: !has('failed'), by }) });
    out(`done · run ${r.run.state}`); return 0;
  }
  out(HELP); return sub === 'help' ? 0 : 1;
}

export async function browseCommand(argv, { out = (s) => process.stdout.write(String(s) + '\n') } = {}) {
  const op = argv[0]; const cfg = loadConfig(); const port = cfg?.browse?.port || DEFAULT_PORT;
  if (!op || op === '--help' || op === 'help') { out(BROWSE_HELP); return 0; }
  const argsFor = {
    open: () => ({ url: argv[1] }), goto: () => ({ url: argv[1] }), text: () => ({ max: Number(argv[1] || 200000) }), html: () => ({ selector: argv[1] || 'html' }),
    eval: () => ({ js: argv[1], world: argv.includes('--main') ? 'MAIN' : 'ISOLATED' }), click: () => ({ selector: argv[1] }), type: () => ({ selector: argv[1], text: argv[2] || '' }),
    wait: () => ({ ms: Number(argv[1] || 1000) }), shot: () => ({}), tabs: () => ({}), close: () => ({}), ping: () => ({}),
  };
  if (!argsFor[op]) { out(BROWSE_HELP); return 1; }
  const r = await sendBrowse(op, argsFor[op](), { port });
  if (!r.ok) { out(`browse ${op} failed: ${r.error}`); return 1; }
  if (op === 'shot') { const file = argv[1] || `shot-${Date.now()}.png`; writeFileSync(file, Buffer.from(String(r.result || '').split(',').pop(), 'base64')); out(`wrote ${file}`); return 0; }
  out(typeof r.result === 'string' ? r.result : JSON.stringify(r.result, null, 2)); return 0;
}

function ask(q) { return new Promise((ok) => { process.stdout.write(q); process.stdin.setEncoding('utf8'); process.stdin.once('data', (d) => { ok(String(d).trim()); process.stdin.pause(); }); }); }

export const HELP = `0n3 desk — your desk, on this computer
  0n3 desk login [--token 0n_…] [--agent claude_code|codex|gemini_cli] [--machine name]
  0n3 desk status
  0n3 desk run [--once] [--every 30] [--browser]
  0n3 desk install [--browser] | uninstall
  0n3 desk projects [tidy|bring|open <name>|removed|install]   keep the code folder small and nothing unsaved
  inside a turn:  0n3 desk ask <run> "<question>" "<a|b>" · 0n3 desk note <run> "<text>" · 0n3 desk done <run> <reply.md> [--failed]
  0n3 browse --help  (drive the paired Chrome)`;
export const BROWSE_HELP = `0n3 browse — the paired Chrome, from the shell (needs: 0n3 desk run --browser, and the 0n extension turned on with the code)
  open <url>            open (or reuse) the 0n3 session window on that url, wait for load
  goto <url>            navigate the session tab
  text [max]            the page's visible text
  html [selector]       outerHTML of one element (default html)
  eval "<js>" [--main]  run JS in the page (isolated world by default: DOM + same-origin fetch; --main = the page's own world)
  click <selector>      click the first match
  type <selector> <text>
  wait <ms>
  shot [file.png]       screenshot of the visible tab
  tabs · close · ping`;
