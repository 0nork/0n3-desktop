/**
 * BROWSE RELAY — the desk agent's window into the person's own Chrome.
 *
 * Some work needs a real browser: a stats site behind a bot check, a page that only renders
 * client-side, a form. The agent on the machine should not need its own browser; the person
 * already has one, with their logins. So the 0n Chrome extension pairs with THIS relay and
 * carries commands into a dedicated "0n3 session" window, and the agent drives it from the
 * shell with `0n3 browse <op>`.
 *
 *   agent (CLI) ──POST /cmd──▶ relay (127.0.0.1:7474) ◀──GET /next (long-poll)── extension
 *                 ◀─ result ─┘                         └──POST /result ──────────▶
 *
 * Only loopback, only with the pairing code the extension was given, and nothing is pushed into
 * the browser: the extension asks for the next command. One command in flight at a time.
 */
import http from 'node:http';
import { randomBytes } from 'node:crypto';

export const DEFAULT_PORT = 7474;
export const OPS = ['open', 'goto', 'text', 'html', 'eval', 'click', 'type', 'wait', 'shot', 'tabs', 'close', 'ping'];
export const newCode = () => randomBytes(3).toString('hex').toUpperCase(); // 6 chars, typed once into the extension

export function createRelay({ code, port = DEFAULT_PORT, cmdTimeoutMs = 90_000, pollTimeoutMs = 25_000, log = () => {} } = {}) {
  if (!code) throw new Error('relay needs a pairing code');
  const queue = []; let inflight = null; let waiter = null; let lastSeen = 0; let seq = 0;
  const readJson = (req) => new Promise((ok, no) => { let s = ''; req.on('data', (c) => { s += c; if (s.length > 8e6) { no(new Error('body too large')); req.destroy(); } }); req.on('end', () => { try { ok(s ? JSON.parse(s) : {}); } catch (e) { no(e); } }); req.on('error', no); });
  const json = (res, status, body) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type' }); res.end(JSON.stringify(body)); };
  const paired = () => Date.now() - lastSeen < 60_000;
  const giveNext = () => { if (!waiter || inflight || !queue.length) return; const w = waiter; waiter = null; clearTimeout(w.timer); inflight = queue.shift(); inflight.sentAt = Date.now(); json(w.res, 200, { cmd: { id: inflight.id, op: inflight.op, args: inflight.args } }); };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    if (req.method === 'OPTIONS') return json(res, 204, {});
    try {
      if (url.pathname === '/status') return json(res, 200, { ok: true, paired: paired(), lastSeen: lastSeen || null, queued: queue.length, inflight: inflight ? inflight.op : null, port });
      // ── the extension's side ──
      if (url.pathname === '/next' || url.pathname === '/result') {
        if (url.searchParams.get('code') !== code) return json(res, 401, { error: 'wrong pairing code' });
        lastSeen = Date.now();
        if (url.pathname === '/next' && req.method === 'GET') {
          if (waiter) { clearTimeout(waiter.timer); json(waiter.res, 200, { cmd: null }); waiter = null; }
          waiter = { res, timer: setTimeout(() => { if (waiter && waiter.res === res) { waiter = null; json(res, 200, { cmd: null }); } }, pollTimeoutMs) };
          req.on('close', () => { if (waiter && waiter.res === res) { clearTimeout(waiter.timer); waiter = null; } });
          return giveNext();
        }
        if (url.pathname === '/result' && req.method === 'POST') {
          const b = await readJson(req);
          if (!inflight || b.id !== inflight.id) return json(res, 409, { error: 'no such command in flight' });
          const c = inflight; inflight = null;
          c.resolve(b.ok === false ? { ok: false, error: String(b.error || 'failed') } : { ok: true, result: b.result });
          json(res, 200, { ok: true }); return giveNext();
        }
      }
      // ── the agent's side (CLI) ──
      if (url.pathname === '/cmd' && req.method === 'POST') {
        const b = await readJson(req);
        if (!OPS.includes(b.op)) return json(res, 400, { error: `op must be one of ${OPS.join(', ')}` });
        if (!paired()) return json(res, 503, { error: `No browser is paired. In Chrome, open the 0n extension → Desk browsing, enter code ${code} and turn it on.` });
        const out = await new Promise((resolve) => {
          const c = { id: `c${++seq}`, op: b.op, args: b.args || {}, resolve };
          const t = setTimeout(() => { if (inflight === c) inflight = null; const i = queue.indexOf(c); if (i >= 0) queue.splice(i, 1); resolve({ ok: false, error: `the browser did not answer within ${cmdTimeoutMs / 1000}s` }); }, cmdTimeoutMs);
          c.resolve = (v) => { clearTimeout(t); resolve(v); };
          queue.push(c); giveNext();
        });
        log(`browse ${b.op} → ${out.ok ? 'ok' : out.error}`);
        return json(res, out.ok ? 200 : 502, out);
      }
      return json(res, 404, { error: 'no such route' });
    } catch (e) { return json(res, 500, { error: e.message }); }
  });
  return {
    server, code, port,
    listen: () => new Promise((ok, no) => { server.once('error', no); server.listen(port, '127.0.0.1', () => ok(server.address().port)); }),
    close: () => new Promise((ok) => server.close(() => ok())),
    paired,
  };
}

/** The CLI side: send one command to a running relay. */
export async function sendBrowse(op, args = {}, { port = DEFAULT_PORT, fetchImpl = fetch } = {}) {
  let r;
  try { r = await fetchImpl(`http://127.0.0.1:${port}/cmd`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ op, args }) }); }
  catch (e) { return { ok: false, error: `no relay on 127.0.0.1:${port} — start it with: 0n3 desk run --browser (${e.cause?.code || e.message})` }; }
  const j = await r.json().catch(() => ({ error: `relay answered ${r.status} without JSON` }));
  return j.ok === undefined ? { ok: r.ok && !j.error, ...j } : j;
}
