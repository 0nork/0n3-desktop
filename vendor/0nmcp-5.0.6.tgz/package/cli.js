#!/usr/bin/env node
/**
 * 0n3 CLI — the same runtime, three ways in.
 *
 *   0n3 stdio                 MCP over stdio for Claude Desktop / Cursor / Claude Code.
 *                             Reads ~/.0n/connections/*.0n (and, with ON3_TOKEN, your hosted vault).
 *   0n3 serve [--port 8787]   Hosted mode (needs ON3_VAULT_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY).
 *   0n3 vault list|push <service> [--label X]|pull|remove <service> [--label X]
 *                             Your hosted vault, over your 0n token (ON3_TOKEN, ON3_URL).
 *   0n3 doctor                Counts what is real: tools, services, local records.
 *   0n3 connect-mcp <service> Sign in to an OAuth MCP server once (Whatnot: 0n3 connect-mcp whatnot) and store it in the vault.
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { createRuntime, countTools, VERSION } from './runtime.js';
import { FileResolver, ChainResolver, DEFAULT_DIR } from './resolver.js';
import { listServices } from './catalog.js';
import { stripSecrets, labelOf } from './envelope.js';

const argv = process.argv.slice(2);
const cmd = argv[0] || 'stdio';
const flag = (name) => { const i = argv.indexOf(`--${name}`); return i >= 0 ? argv[i + 1] : undefined; };
const out = (v) => process.stdout.write((typeof v === 'string' ? v : JSON.stringify(v, null, 2)) + '\n');
const die = (m) => { process.stderr.write(`0n3: ${m}\n`); process.exit(1); };

const hosted = () => {
  const url = (process.env.ON3_URL || 'https://0n3.app').replace(/\/$/, '');
  const token = process.env.ON3_TOKEN || '';
  if (!url) die('ON3_URL is not set (the hosted 0n3 base URL).');
  if (!token) die('ON3_TOKEN is not set (your 0n_ token: https://0n3.app/tokens).');
  return { url, token, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } };
};

/** A remote resolver over the hosted vault, so stdio mode can see the same records the web does. */
class HostedResolver {
  constructor({ url, headers }) { this.url = url; this.headers = headers; }
  async list() { const r = await fetch(`${this.url}/vault`, { headers: this.headers }); if (!r.ok) return []; const d = await r.json(); return (d.records || []).map((e) => ({ ...e, source: 'hosted' })); }
  async get() { return null; } // secrets never travel to the CLI over this path; use `0n3 vault pull` to bring files down deliberately
}

if (cmd === 'stdio') {
  const { StdioServerTransport } = await import('@modelcontextprotocol/sdk/server/stdio.js');
  const resolvers = [new FileResolver()];
  if (process.env.ON3_URL && process.env.ON3_TOKEN) resolvers.push(new HostedResolver(hosted()));
  const server = createRuntime({ resolver: new ChainResolver(...resolvers), account: null });
  await server.connect(new StdioServerTransport());
} else if (cmd === 'serve') {
  const { createClient } = await import('@supabase/supabase-js');
  const { VaultStore, supabaseRest } = await import('./vault/store.js');
  const { listen } = await import('./http.js');
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY, master = process.env.ON3_VAULT_KEY;
  if (!url || !key || !master) die('serve needs SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY and ON3_VAULT_KEY.');
  const rest = supabaseRest(createClient(url, key, { auth: { persistSession: false } }));
  const port = Number(flag('port') || process.env.PORT || 8787);
  const { Hub } = await import('./hub.js');
  const store = new VaultStore({ rest, masterKeyHex: master });
  const hub = new Hub({ rest, store, supabase: { url, serviceKey: key }, internalSecret: process.env.ON3_INTERNAL_SECRET || '', baseUrl: process.env.ON3_PUBLIC_URL || `http://localhost:${port}` });
  await listen({ store, identityRest: rest, hub }, port);
  process.stderr.write(`0n3 ${VERSION} listening on :${port}\n`);
} else if (cmd === 'vault') {
  const sub = argv[1];
  const h = hosted();
  if (sub === 'list') {
    const r = await fetch(`${h.url}/vault`, { headers: h.headers }); const d = await r.json();
    if (!r.ok) die(d.error || `HTTP ${r.status}`);
    out(d.records.map((e) => ({ service: e.service, label: labelOf(e), kind: e.auth?.type, environment: e.environment, status: e.status, verified: e.last_verified_at })));
  } else if (sub === 'push') {
    const service = argv[2]; if (!service) die('usage: 0n3 vault push <service> [--file path] [--label name]');
    const file = flag('file') || join(DEFAULT_DIR, `${service}.0n`);
    if (!existsSync(file)) die(`no local record at ${file}`);
    const env = JSON.parse(readFileSync(file, 'utf8'));
    if (env.$0n?.sealed) die('that file is sealed to this machine; unseal it first (0nmcp vault open) or push an unsealed copy');
    if (flag('label')) env.$0n = { ...(env.$0n || {}), name: flag('label') };
    const r = await fetch(`${h.url}/vault/${encodeURIComponent(service)}`, { method: 'PUT', headers: h.headers, body: JSON.stringify(env) });
    const d = await r.json(); if (!r.ok) die(d.error || `HTTP ${r.status}`);
    out({ pushed: service, label: labelOf(d.record), credentialKeys: d.record.auth?.credentialKeys });
  } else if (sub === 'remove') {
    const service = argv[2]; if (!service) die('usage: 0n3 vault remove <service> [--label name]');
    const q = flag('label') ? `?label=${encodeURIComponent(flag('label'))}` : '';
    const r = await fetch(`${h.url}/vault/${encodeURIComponent(service)}${q}`, { method: 'DELETE', headers: h.headers });
    const d = await r.json(); if (!r.ok) die(d.error || `HTTP ${r.status}`); out(d);
  } else if (sub === 'pull') {
    die('pull is deliberately not implemented: secrets do not leave the vault over the API. Keep local .0n files for the CLI, push them to the vault for the web.');
  } else die('usage: 0n3 vault list | push <service> | remove <service>');
} else if (cmd === 'doctor') {
  const probe = createRuntime({ resolver: new FileResolver() });
  const local = await new FileResolver().list();
  out({ version: VERSION, tools: countTools(probe), crmTools: probe.__0n3.crmTools, services: listServices().length, localRecords: local.map((e) => ({ service: e.service, label: labelOf(e), sealed: !!e.sealed, file: e.source })), hosted: process.env.ON3_URL ? { url: process.env.ON3_URL, token: process.env.ON3_TOKEN ? 'set' : 'missing' } : 'not configured' });
} else if (cmd === 'new') {
  // 0n3 new <service> --key K=V [--key K=V] [--name label] [--meta k=v]  → writes ~/.0n/connections/<service>.0n
  const { makeConnection } = await import('./envelope.js');
  const service = argv[1]; if (!service) die('usage: 0n3 new <service> --key apiKey=… [--name label] [--meta location_id=…]');
  const creds = {}, meta = {};
  for (let i = 0; i < argv.length; i++) { if (argv[i] === '--key') { const [k, ...v] = String(argv[i + 1]).split('='); creds[k] = v.join('='); } if (argv[i] === '--meta') { const [k, ...v] = String(argv[i + 1]).split('='); meta[k] = v.join('='); } }
  if (!Object.keys(creds).length) die('at least one --key K=V is required');
  const env = makeConnection({ service, name: flag('name'), credentials: creds, meta });
  mkdirSync(DEFAULT_DIR, { recursive: true });
  const file = join(DEFAULT_DIR, `${flag('name') ? `${service}-${flag('name')}` : service}.0n`);
  writeFileSync(file, JSON.stringify(env, null, 2), { mode: 0o600 });
  out({ wrote: file, record: stripSecrets(env) });
} else if (cmd === 'connect-mcp') {
  // 0n3 connect-mcp <service> [--url https://…] [--client-id X] [--scope "a b"] [--port 8080] [--path /callback] [--label name] [--local]
  // Signs in to an OAuth-protected MCP server ONCE on this machine (PKCE, loopback callback — the only callback many public MCP
  // clients allow), then stores the record in the hosted vault (or ~/.0n/connections with --local). Hosted 0n3 refreshes the
  // token itself from then on (mcp-oauth.js). Known servers need only their name; any other takes --url.
  const { createServer } = await import('node:http');
  const { execFile } = await import('node:child_process');
  const { discover, clientFor, pkce, authorizeUrl, exchange } = await import('./mcp-oauth.js');
  const { makeConnection } = await import('./envelope.js');
  const KNOWN = {
    // https://developers.whatnot.com/getting-started/mcp — Whatnot's published public client; its callback is localhost:8080 only.
    whatnot: { url: 'https://mcp.whatnot.com', clientId: 'bb1bf1ca-0452-4737-ad8f-81175f1601b8', port: 8080, path: '/callback', name: 'Whatnot (seller)' },
  };
  const service = argv[1]; if (!service) die(`usage: 0n3 connect-mcp <service> [--url https://…] [--client-id X] [--scope "…"] [--port N] [--label name] [--local]\nknown: ${Object.keys(KNOWN).join(', ')}`);
  const k = KNOWN[service] || {};
  const url = flag('url') || k.url; if (!url) die(`no --url for "${service}" (known servers: ${Object.keys(KNOWN).join(', ')})`);
  const port = Number(flag('port') || k.port || 8080), path = flag('path') || k.path || '/callback';
  const redirectUri = `http://localhost:${port}${path}`;
  const d = await discover(url);
  const client = await clientFor(d, { clientId: flag('client-id') || k.clientId, clientSecret: flag('client-secret'), redirectUri });
  const scope = flag('scope') ?? d.scopes.join(' ');
  const p = pkce();
  const authUrl = authorizeUrl(d, { client_id: client.client_id, redirectUri, scope, challenge: p.challenge, state: p.state });
  const code = await new Promise((resolve, reject) => {
    const srv = createServer((req, res) => {
      const u = new URL(req.url, redirectUri);
      if (u.pathname !== path) { res.writeHead(404).end(); return; }
      const err = u.searchParams.get('error'), c = u.searchParams.get('code'), st = u.searchParams.get('state');
      const done = (msg, ok) => { res.writeHead(ok ? 200 : 400, { 'content-type': 'text/html' }).end(`<body style="font:16px system-ui;padding:40px">${msg}</body>`); srv.close(); };
      if (err) { done(`Sign-in failed: ${err}`, false); reject(new Error(`${err}: ${u.searchParams.get('error_description') || ''}`)); return; }
      if (!c || st !== p.state) { done('Sign-in failed: the reply did not match this request.', false); reject(new Error('state mismatch or no code')); return; }
      done(`Connected ${service} to 0n3 — you can close this tab.`, true); resolve(c);
    });
    srv.on('error', (e) => reject(new Error(`could not listen on ${redirectUri}: ${e.message}`)));
    srv.listen(port, '127.0.0.1', () => {
      process.stderr.write(`\nSign in to ${k.name || service} in your browser.\nIf it does not open, visit:\n${authUrl}\n\n`);
      const opener = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'explorer' : 'xdg-open';
      execFile(opener, [authUrl], () => {});
    });
    const waitMin = Number(flag('wait') || 20);
    setTimeout(() => { srv.close(); reject(new Error(`timed out after ${waitMin} minutes waiting for the sign-in — run it again`)); }, waitMin * 60_000).unref();
  });
  const creds = await exchange(d, client, { code, verifier: p.verifier, redirectUri });
  const env = makeConnection({ service, name: flag('label') || k.name || service, credentials: creds, authType: 'oauth', options: { mcp: { url, transport: 'streamable-http', timeoutMs: 20000 } }, meta: { issuer: d.issuer, scopes: scope } });
  if (flag('local') !== undefined || argv.includes('--local') || !process.env.ON3_TOKEN) {
    mkdirSync(DEFAULT_DIR, { recursive: true });
    const file = join(DEFAULT_DIR, `${service}.0n`); writeFileSync(file, JSON.stringify(env, null, 2), { mode: 0o600 });
    out({ connected: service, wrote: file, refresh: !!creds.refresh_token, expires_at: creds.expires_at, note: process.env.ON3_TOKEN ? undefined : 'ON3_TOKEN not set — saved locally only; push with: 0n3 vault push ' + service });
  } else {
    const h = hosted();
    const r = await fetch(`${h.url}/vault/${encodeURIComponent(service)}`, { method: 'PUT', headers: h.headers, body: JSON.stringify(env) });
    const j = await r.json().catch(() => ({})); if (!r.ok) die(j.error || `vault: HTTP ${r.status}`);
    out({ connected: service, vault: h.url, label: labelOf(j.record), refresh: !!creds.refresh_token, expires_at: creds.expires_at, next: `mcp_tools { service: "${service}" }` });
  }
} else if (cmd === 'desk') {
  // The desk agent: this computer claims requests from the phone or mailbox and runs the chosen agent in the project folder.
  const { deskCommand } = await import('./desk-agent.js');
  process.exit(await deskCommand(argv.slice(1), { bin: process.argv[1]?.endsWith('cli.js') ? `node ${process.argv[1]}` : '0n3' }));
} else if (cmd === 'browse') {
  const { browseCommand } = await import('./desk-agent.js');
  process.exit(await browseCommand(argv.slice(1)));
} else {
  die(`unknown command "${cmd}". Try: stdio | serve | vault | doctor | new | desk | browse`);
}
