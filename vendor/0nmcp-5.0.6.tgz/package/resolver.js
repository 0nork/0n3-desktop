/**
 * THE RESOLVER — the one seam between a tool and a credential.
 *
 *   resolver.get(service, label?)  → full .0n envelope (with credentials) or null
 *   resolver.list()                → non-secret envelopes
 *
 * The runtime never reads a file, an env var or a table itself. In stdio mode
 * it is given a FileResolver over ~/.0n/connections; in hosted mode a
 * VaultResolver bound to the account the bearer token resolved to; either can
 * be chained. That is the whole multi-tenant story: the account is chosen
 * once per request, the resolver carries it, every tool asks the resolver.
 */
import { readdirSync, readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { stripSecrets, labelOf } from './envelope.js';

export const DEFAULT_DIR = join(homedir(), '.0n', 'connections');

const matchLabel = (env, label) => {
  if (!label) return true;
  const l = String(label).trim();
  if (labelOf(env) === l) return true;
  return Object.values(env.meta || {}).some((v) => String(v) === l);
};

export class FileResolver {
  constructor(dir = DEFAULT_DIR) { this.dir = dir; }
  _read() {
    if (!existsSync(this.dir)) return [];
    const out = [];
    for (const f of readdirSync(this.dir)) {
      if (!f.endsWith('.0n') && !f.endsWith('.0n.json')) continue;
      try {
        const d = JSON.parse(readFileSync(join(this.dir, f), 'utf8'));
        if (d?.$0n?.type !== 'connection' || !d.service) continue;
        out.push({ file: f, env: d });
      } catch { /* not ours */ }
    }
    return out;
  }
  async list() {
    return this._read().map(({ file, env }) => ({ ...stripSecrets(env), sealed: !!env.$0n?.sealed, source: file }));
  }
  async get(service, label) {
    const hit = this._read().find(({ env }) => env.service === service && !env.$0n?.sealed && matchLabel(env, label));
    return hit ? hit.env : null;
  }
}

export class VaultResolver {
  /** @param {import('./vault/store.js').VaultStore} store */
  constructor(store, accountId) { this.store = store; this.accountId = accountId; }
  async list() { return (await this.store.list(this.accountId)).map((e) => ({ ...e, source: 'vault' })); }
  async get(service, label) { return this.store.get(this.accountId, service, label); }
  /** Write a record back (an OAuth MCP refresh that rotated its refresh token — mcp-oauth.js). */
  async save(envelope) { return this.store.put(this.accountId, envelope, { actor: 'oauth-refresh' }); }
}

export class ChainResolver {
  constructor(...resolvers) { this.resolvers = resolvers.filter(Boolean); }
  async list() {
    const seen = new Set(); const out = [];
    for (const r of this.resolvers) for (const e of await r.list()) { const k = `${e.service}::${labelOf(e)}`; if (seen.has(k)) continue; seen.add(k); out.push(e); }
    return out;
  }
  async get(service, label) {
    for (const r of this.resolvers) { const e = await r.get(service, label); if (e) return e; }
    return null;
  }
}

export class NullResolver {
  async list() { return []; }
  async get() { return null; }
}
