// COMPUTE JOBS (2026-11-10) — a desk run that is MATH, not an AI turn.
//
// Mike: "what does 0n3 need to connect to tap into the power?" A desk run with source.kind "compute" names a TASK
// ("atlo.plan") and small ARGS. The owner's computer runs the command IT registered for that task — never a command the
// server sent — with the args in an environment variable, no shell, in a folder already on its allow list. No AI starts,
// no tokens are spent, and several compute jobs run side by side (they do not hold the one-turn-per-folder lock an AI
// turn holds). A machine that has not registered the task, or is too small for it, leaves the job queued for one that can.
//
// The registry lives on the machine: ~/.0n/desk-compute.json
//   { "tasks": { "atlo.plan": { "cwd": "/abs/project", "cmd": ["/abs/node", "scripts/worker/plan.mjs"], "timeoutSec": 1800 } } }
// Add one with:  0n3 desk compute add <task> --cwd <folder> -- <command …>
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { homedir, cpus, totalmem, platform, arch } from 'node:os';

export const TASK_RE = /^[a-z0-9][a-z0-9._-]{1,39}$/;
const REG = () => join(process.env.ON3_HOME || join(homedir(), '.0n'), 'desk-compute.json');

/** What a compute source may carry: a task name, flat primitive args (≤ 2 KB) and what the machine must have. */
export function cleanComputeSource(s = {}) {
  const task = TASK_RE.test(String(s.task || '')) ? String(s.task) : undefined;
  const args = {};
  if (s.args && typeof s.args === 'object' && !Array.isArray(s.args)) {
    for (const [k, v] of Object.entries(s.args).slice(0, 24)) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,31}$/.test(k)) continue;
      if (typeof v === 'string') args[k] = v.slice(0, 300); else if (typeof v === 'number' && Number.isFinite(v)) args[k] = v; else if (typeof v === 'boolean') args[k] = v;
    }
  }
  const n = s.needs && typeof s.needs === 'object' ? s.needs : {};
  const needs = {};
  if (Number.isFinite(Number(n.minCores)) && Number(n.minCores) > 0) needs.minCores = Math.min(256, Math.floor(Number(n.minCores)));
  if (Number.isFinite(Number(n.minMemGb)) && Number(n.minMemGb) > 0) needs.minMemGb = Math.min(4096, Math.floor(Number(n.minMemGb)));
  return { task, args: JSON.stringify(args).length <= 2048 ? args : {}, needs: Object.keys(needs).length ? needs : undefined, key: s.key ? String(s.key).slice(0, 80) : undefined };
}

export function loadRegistry(file = REG()) {
  try { const j = JSON.parse(readFileSync(file, 'utf8')); return j && typeof j.tasks === 'object' && j.tasks ? j : { tasks: {} }; } catch { return { tasks: {} }; }
}
export function saveRegistry(reg, file = REG()) { mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, JSON.stringify(reg, null, 2), { mode: 0o600 }); }

/** What this computer is: cores, memory, and the tasks it will run. Sent with the heartbeat. */
export function machineCaps(reg = loadRegistry()) {
  return { cores: cpus().length, memGb: Math.round(totalmem() / 2 ** 30), os: platform(), arch: arch(), tasks: Object.keys(reg.tasks || {}).filter((t) => TASK_RE.test(t)).slice(0, 40) };
}
export function cleanCaps(c) {
  if (!c || typeof c !== 'object') return null;
  const cores = Number(c.cores), memGb = Number(c.memGb);
  return { cores: Number.isFinite(cores) && cores > 0 ? Math.min(1024, Math.floor(cores)) : null, memGb: Number.isFinite(memGb) && memGb > 0 ? Math.min(65536, Math.floor(memGb)) : null,
    os: c.os ? String(c.os).slice(0, 20) : null, arch: c.arch ? String(c.arch).slice(0, 20) : null, tasks: Array.isArray(c.tasks) ? c.tasks.map(String).filter((t) => TASK_RE.test(t)).slice(0, 40) : [] };
}

/** May THIS machine take this compute run? Decided before claiming, so a job it cannot do stays queued for another machine. */
export function canTake(run, reg, caps, { allowed = () => true } = {}) {
  const src = run?.source || {};
  if (src.kind !== 'compute') return { ok: false, why: 'not a compute run' };
  const t = src.task && reg.tasks?.[src.task];
  if (!t) return { ok: false, why: `this computer has no task "${src.task || '?'}" registered` };
  if (!Array.isArray(t.cmd) || !t.cmd.length || !t.cmd.every((x) => typeof x === 'string' && x)) return { ok: false, why: `task "${src.task}" has no command` };
  if (!t.cwd || !existsSync(t.cwd)) return { ok: false, why: `task "${src.task}" names a folder that is not on this computer` };
  if (!allowed(t.cwd)) return { ok: false, why: `${t.cwd} is not on this computer's allow list` };
  const n = src.needs || {};
  if (n.minCores && (caps.cores || 0) < n.minCores) return { ok: false, why: `needs ${n.minCores} cores, this computer has ${caps.cores}` };
  if (n.minMemGb && (caps.memGb || 0) < n.minMemGb) return { ok: false, why: `needs ${n.minMemGb} GB, this computer has ${caps.memGb}` };
  return { ok: true, task: t };
}

/** The job's own last line may be a JSON receipt ({"ok":true,…}); everything else is its log. */
export function computeReply(stdout = '', stderr = '', status = 0) {
  const lines = String(stdout).trim().split('\n').filter(Boolean);
  let receipt = null;
  for (let i = lines.length - 1; i >= 0 && i >= lines.length - 3; i--) { const l = lines[i].trim(); if (l.startsWith('{') && l.endsWith('}')) { try { receipt = JSON.parse(l); lines.splice(i, 1); break; } catch { /* a log line */ } } }
  const ok = status === 0 && receipt?.ok !== false;
  const tail = (ok ? lines : [...lines, ...String(stderr).trim().split('\n').filter(Boolean)]).slice(-12).join('\n').slice(-1800);
  return { ok, receipt: receipt && typeof receipt === 'object' ? receipt : null, reply: (receipt?.summary ? String(receipt.summary).slice(0, 600) : tail) || (ok ? 'done' : `exit ${status}`) };
}
