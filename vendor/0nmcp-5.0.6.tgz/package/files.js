/**
 * DESK FILES — the photos and documents a request carries.
 *
 * A request from the phone is "here is a picture of the rink board, update the site". The picture
 * has to reach the owner's machine, so it is stored once (Supabase Storage, private bucket
 * `desk-files`, path `<account>/<run>/<name>`) and the run records only the metadata. The machine
 * downloads each file over the owner's own token before the agent's turn starts; nothing is ever
 * public. Tests pass `memoryFiles()`; production passes `storageFiles()` over the service key.
 */
const BUCKET = 'desk-files';
export const MAX_FILES = 6;
export const MAX_FILE_BYTES = 8 * 1024 * 1024;
const TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic', 'application/pdf', 'text/plain', 'text/csv', 'application/json']);

export const safeName = (n) => String(n || 'file').replace(/[^\w.-]+/g, '_').replace(/^_+/, '').slice(0, 120) || 'file';

/** Validate and decode what the client posted: [{ name, type, data (base64) }]. Throws with the reason. */
export function decodeUploads(files, max = MAX_FILES) {
  if (!Array.isArray(files)) return [];
  if (files.length > max) throw new Error(`At most ${max} files per request.`);
  return files.map((f, i) => {
    const type = String(f?.type || 'application/octet-stream').toLowerCase().split(';')[0];
    if (!TYPES.has(type)) throw new Error(`File ${i + 1}: ${type} is not an accepted type (photos, PDF, text, CSV, JSON).`);
    const data = Buffer.from(String(f?.data || ''), 'base64');
    if (!data.length) throw new Error(`File ${i + 1} is empty.`);
    if (data.length > MAX_FILE_BYTES) throw new Error(`File ${i + 1} is ${(data.length / 1048576).toFixed(1)} MB; the limit is ${MAX_FILE_BYTES / 1048576} MB. Phones should downscale photos before sending.`);
    return { name: safeName(f?.name || `file-${i + 1}`), type, data };
  });
}

/** Supabase Storage over its REST API. `fetchImpl` is a seam for tests. */
export function storageFiles({ url, serviceKey, bucket = BUCKET, fetchImpl = fetch }) {
  if (!url || !serviceKey) return null;
  const base = `${url.replace(/\/$/, '')}/storage/v1/object/${bucket}`;
  const H = { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` };
  return {
    bucket,
    async put(path, buffer, type) {
      const r = await fetchImpl(`${base}/${path}`, { method: 'POST', headers: { ...H, 'Content-Type': type, 'x-upsert': 'true' }, body: buffer });
      if (!r.ok) throw new Error(`storage put ${r.status}: ${(await r.text()).slice(0, 200)}`);
      return { path, size: buffer.length, type };
    },
    async get(path) {
      const r = await fetchImpl(`${base}/${path}`, { headers: H });
      // Supabase Storage answers a missing object with 400 + {"error":"not_found"} (or 404); both mean "no such file".
      if (r.status === 404) return null;
      if (!r.ok) { const t = (await r.text()).slice(0, 200); if (r.status === 400 && /not_found|NoSuchKey/i.test(t)) return null; throw new Error(`storage get ${r.status}: ${t}`); }
      return { buffer: Buffer.from(await r.arrayBuffer()), type: r.headers.get('content-type') || 'application/octet-stream' };
    },
  };
}

/** The same seam in memory. */
export function memoryFiles() {
  const m = new Map();
  return {
    bucket: 'memory', store: m,
    async put(path, buffer, type) { m.set(path, { buffer: Buffer.from(buffer), type }); return { path, size: buffer.length, type }; },
    async get(path) { return m.get(path) || null; },
  };
}
