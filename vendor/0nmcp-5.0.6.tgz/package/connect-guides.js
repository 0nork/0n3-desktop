/**
 * WHERE THE KEY LIVES — one short, true, click-by-click guide per connectable 0n3 service.
 *
 * Shared by the web app (web/src/connect-guides.js re-exports it for the connect modal) and the server
 * (GET /api/connect/guides, read by the 0n Chrome extension). No secrets live here — only where a key is made.
 *
 * Shape, per catalog service key:
 *   url        the exact page the key/token is created on (deep link). `unverified: true` when we could not
 *              confirm the page from the provider's own docs or a live fetch — never a guess presented as fact.
 *   where      the menu path to that page inside the provider's app
 *   looks      what a real key looks like (prefix / length) so a paste can be sanity-checked locally
 *   steps      3–5 short click steps naming the provider's real button labels
 *   scopes     the permissions to tick so every 0n3 catalog endpoint for the service works
 *   fields     { credentialKey: { label, where? } } — the plain label for each vault field (catalog.js credentialKeys)
 *   pattern    a RegExp SOURCE (no slashes) that matches a freshly created key on the provider's page. Only where
 *              the format is distinctive; precision over recall. `patternField` names the credentialKey it fills
 *              (default: the first credentialKey).
 *   door       the OAuth door (hub.js) that signs the person in instead of a pasted key, where one exists
 *   note       one extra line that saves a failed connect
 *
 * Services whose catalog authType is "none" (rdap, substack, ollama, shadcn) need no key; ollama keeps a guide
 * because it still needs a base URL.
 */

import { PLAIN } from './connect-guides-plain.js';
import { AI_PROVIDER_GUIDES } from './connect-guides-ai.js';

const GOOGLE_STEPS = (what) => ['Press Sign in with Google.', `Pick the Google account that ${what} and press Allow on every permission.`, 'You come straight back here, connected. Every Google service reads the same Google record.'];
const ON_TOKEN = {
  url: 'https://0ncore.com/dashboard/config', where: '0nCore → Dashboard → Config → 0n token', looks: '0n_live_ + 8 hex + _ + 16 letters/digits + _ + 4 hex (38 characters)',
  steps: ['Sign in at 0ncore.com and open Dashboard → Config.', 'Copy your 0n token (press Generate if none is shown yet).', 'Paste it below. The same token opens every 0nCore engine.'],
  scopes: ['One 0n token covers every 0nCore engine; there is nothing to tick.'],
  fields: { onToken: { label: '0n token', where: '0nCore → Dashboard → Config' } },
  pattern: '0n_live_[a-f0-9]{8}_[A-Za-z0-9]{16}_[a-f0-9]{4}',
};
const META_STEPS = (product) => ['Open your app at developers.facebook.com/apps (create a Business app if you have none).', 'Open business.facebook.com → Settings → Users → System users, add a System user and press Generate new token.', `Pick the app, set the token to never expire, tick the permissions listed below, and press Generate token.`, `Copy the token (starts EAA) and the ${product}, and paste both below.`];

export const GUIDES = {
  // ── payments + commerce ──────────────────────────────────────────────
  stripe: {
    url: 'https://dashboard.stripe.com/apikeys', where: 'Developers → API keys', looks: 'sk_live_… or rk_live_… (sk_test_… / rk_test_… in test mode)',
    steps: ['Open Developers → API keys in your Stripe dashboard.', 'Either press Reveal live key on the Secret key, or press Create restricted key for a narrower one.', 'For a restricted key, set the permissions below to Write, press Create key, then copy it.', 'Paste it below.'],
    scopes: ['Customers: Write', 'Charges and Refunds: Write', 'PaymentIntents: Read', 'Invoices: Write', 'Subscriptions: Write', 'Products: Write', 'Prices: Write', 'Balance: Read', 'Webhook Endpoints: Write', 'Events: Read'],
    fields: { apiKey: { label: 'Secret or restricted key' } },
    pattern: '(sk|rk)_(live|test)_[A-Za-z0-9]{20,}',
  },
  square: {
    url: 'https://developer.squareup.com/apps', where: 'Developer Console → your application → Credentials', looks: 'EAAA… (64 characters)',
    steps: ['Open the Developer Console and press + to create an application (or open yours).', 'Switch the top toggle to Production and open Credentials.', 'Press Show next to Production Access token and copy it.', 'Paste it below.'],
    scopes: ['A personal Production access token carries every permission of the seller account; nothing to tick.'],
    fields: { accessToken: { label: 'Production access token' } },
    pattern: 'EAAA[A-Za-z0-9_-]{56,}',
  },
  shopify: {
    url: 'https://admin.shopify.com/settings/apps/development', where: 'Settings → Apps and sales channels → Develop apps', looks: 'shpat_ + 32 hex, and your-store.myshopify.com',
    steps: ['In Shopify admin open Settings → Apps and sales channels → Develop apps (press Allow custom app development the first time).', 'Press Create an app, name it 0n3, then Configure Admin API scopes and tick the scopes below.', 'Press Save, then Install app, then Reveal token once under Admin API access token.', 'Paste the token and your store name below.'],
    scopes: ['read_products, write_products', 'read_orders, write_orders', 'read_customers, write_customers'],
    fields: { accessToken: { label: 'Admin API access token' }, store: { label: 'Store name', where: 'the part before .myshopify.com in your admin URL' } },
    pattern: 'shpat_[a-f0-9]{32}', patternField: 'accessToken',
    note: 'Shopify is moving new custom apps to the Dev Dashboard; if Develop apps is gone in your admin, create the app at dev.shopify.com and install it on the store.',
  },
  woocommerce: {
    url: 'https://woocommerce.com/document/woocommerce-rest-api/', urlFor: { template: 'https://{siteUrl}/wp-admin/admin.php?page=wc-settings&tab=advanced&section=keys', ask: 'Your store address (like shop.example.com)', key: 'siteUrl' }, where: 'WP Admin → WooCommerce → Settings → Advanced → REST API', looks: 'ck_ + 40 hex, cs_ + 40 hex, and your site address',
    steps: ['In WordPress open WooCommerce → Settings → Advanced → REST API and press Add key.', 'Describe it as 0n3, pick your user, set Permissions to Read/Write, press Generate API key.', 'Copy the Consumer key and Consumer secret (shown once).', 'Paste both with your site address below.'],
    scopes: ['Permissions: Read/Write'],
    fields: { siteUrl: { label: 'Site address', where: 'your store domain, e.g. shop.example.com (no https://)' }, consumerKey: { label: 'Consumer key' }, consumerSecret: { label: 'Consumer secret' } },
    pattern: 'ck_[a-f0-9]{40}', patternField: 'consumerKey',
  },
  bigcommerce: {
    url: 'https://login.bigcommerce.com/deep-links/settings/api-accounts', where: 'Settings → Store-level API accounts', looks: 'an access token (about 31 characters) and the store hash',
    steps: ['Open Settings → Store-level API accounts and press Create API account → Create V2/V3 API token.', 'Name it 0n3 and set the OAuth scopes below.', 'Press Save; copy the Access token and note the store hash in the API path (stores/<hash>/v3).', 'Paste both below.'],
    scopes: ['Products: modify', 'Orders: modify', 'Customers: modify', 'Information & settings: read-only'],
    fields: { accessToken: { label: 'Access token' }, storeHash: { label: 'Store hash', where: 'API path shown with the token: api.bigcommerce.com/stores/<this>/v3' } },
  },
  plaid: {
    url: 'https://dashboard.plaid.com/developers/keys', where: 'Dashboard → Developers → Keys', looks: 'client_id (24 hex) + secret (30 hex)',
    steps: ['Open dashboard.plaid.com → Developers → Keys.', 'Copy the client_id and the Production secret (Production access must be approved on your team).', 'Paste both below.'],
    scopes: ['Products enabled on your team: Auth, Transactions, Identity, Balance'],
    fields: { clientId: { label: 'client_id' }, secret: { label: 'Production secret' } },
  },
  quickbooks: {
    door: 'quickbooks', url: 'https://developer.intuit.com/app/developer/dashboard', where: 'Intuit Developer → My apps → your app → Keys & credentials', looks: 'an OAuth access token + the company (realm) id',
    steps: ['Open My apps at developer.intuit.com and create an app for QuickBooks Online (Accounting).', 'Open the OAuth 2.0 Playground (developer.intuit.com/app/developer/playground), pick the app and the com.intuit.quickbooks.accounting scope, then Get authorization code and Get tokens.', 'Copy the access token and the realm id it shows.', 'Paste both below.'],
    scopes: ['com.intuit.quickbooks.accounting'],
    fields: { access_token: { label: 'Access token' }, realmId: { label: 'Company (realm) id', where: 'shown in the Playground, or QuickBooks → Gear → Account and settings → Billing & subscription' } },
    note: 'Sign in with QuickBooks keeps you connected. A pasted access token lasts one hour.',
  },
  xero: {
    door: 'xero', url: 'https://developer.xero.com/app/manage', where: 'Xero Developer → My Apps', looks: 'an OAuth access token + the tenant id',
    steps: ['Open My Apps at developer.xero.com and press New app (Custom connection or Web app).', 'Authorise it against your organisation with the scopes below.', 'Copy the access token and call GET https://api.xero.com/connections for the tenantId.', 'Paste both below.'],
    scopes: ['accounting.transactions', 'accounting.contacts', 'accounting.settings.read'],
    fields: { accessToken: { label: 'Access token' }, tenantId: { label: 'Tenant id', where: 'GET api.xero.com/connections → tenantId' } },
    note: 'Sign in with Xero keeps you connected and fills the tenant id. A pasted access token lasts 30 minutes.',
  },
  wave: {
    url: 'https://developer.waveapps.com/hc/en-us/articles/360019493652-Create-an-app', where: 'Wave → Developer portal → Manage applications', looks: 'a full-access token', unverified: true,
    steps: ['Sign in to Wave, then open the developer portal’s Manage applications page.', 'Create an application and press Create token under Full Access Tokens.', 'Copy the token and paste it below.'],
    scopes: ['Full access token: no scopes to pick'],
    fields: { accessToken: { label: 'Full access token' } },
  },
  ebay: { door: 'ebay', url: 'https://developer.ebay.com/my/keys', where: 'eBay Developers → Application Keys', looks: 'signed in by eBay', steps: ['Press Sign in with eBay.', 'Sign in to the seller account and press Agree to allow access.', 'You come straight back here, connected.'], scopes: ['sell.inventory, sell.account, sell.fulfillment, sell.marketing, sell.finances, sell.analytics.readonly, commerce.identity.readonly (asked for by the door)'], fields: { access_token: { label: 'Access token (filled by Sign in with eBay)' } } },

  // ── email ────────────────────────────────────────────────────────────
  resend: {
    url: 'https://resend.com/api-keys', where: 'API Keys → Create API Key', looks: 're_ + about 32 letters/digits',
    steps: ['Open API Keys in Resend and press Create API Key.', 'Name it 0n3 and set Permission to Full access (Sending access cannot manage domains, audiences or templates).', 'Press Add, copy the key (shown once) and paste it below.'],
    scopes: ['Permission: Full access', 'Domain: All domains'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 're_[A-Za-z0-9_]{16,}',
    note: 'Sending from your own domain needs that domain verified in Resend → Domains.',
  },
  sendgrid: {
    url: 'https://app.sendgrid.com/settings/api_keys', where: 'Settings → API Keys', looks: 'SG. + 22 characters + . + 43 characters',
    steps: ['Open Settings → API Keys and press Create API Key.', 'Name it 0n3 and pick Restricted Access, then set the permissions below.', 'Press Create & View, copy the key (shown once) and paste it below.'],
    scopes: ['Mail Send: Full Access', 'Marketing → Contacts: Full Access', 'Template Engine: Read Access'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 'SG\\.[A-Za-z0-9_-]{22}\\.[A-Za-z0-9_-]{43}',
  },
  postmark: {
    url: 'https://account.postmarkapp.com/servers', where: 'Servers → your server → API Tokens', looks: 'a 36-character server token (UUID shape)',
    steps: ['Open Servers and pick the server you send from.', 'Open the API Tokens tab.', 'Copy the Server API token and paste it below.'],
    scopes: ['A Server API token covers sending, templates, bounces and stats for that server.'],
    fields: { serverToken: { label: 'Server API token' } },
  },
  mailgun: {
    url: 'https://app.mailgun.com/settings/api_security', where: 'Settings → API Security', looks: '32 hex - 8 hex - 8 hex',
    steps: ['Open Settings → API Security and press Add new key.', 'Name it 0n3, press Create Key and copy it (shown once).', 'Paste it below with your sending domain (Send → Sending → Domains).'],
    scopes: ['Account-level API key (not a domain Sending key) so domains, events, stats and validation work.'],
    fields: { apiKey: { label: 'API key' }, domain: { label: 'Sending domain', where: 'Send → Sending → Domains, e.g. mg.example.com' } },
    pattern: '[a-f0-9]{32}-[a-f0-9]{8}-[a-f0-9]{8}', patternField: 'apiKey',
    note: 'EU accounts use api.eu.mailgun.net; 0n3 calls the US region.',
  },
  brevo: {
    url: 'https://app.brevo.com/settings/keys/api', where: 'Settings → SMTP & API → API Keys', looks: 'xkeysib- + 64 hex + - + 16 characters',
    steps: ['Open SMTP & API → API Keys and press Generate a new API key.', 'Name it 0n3 and press Generate.', 'Copy the key (shown once) and paste it below.'],
    scopes: ['API keys carry full account access; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 'xkeysib-[a-f0-9]{64}-[A-Za-z0-9]{16}',
  },
  mailchimp: {
    url: 'https://admin.mailchimp.com/account/api/', where: 'Profile → Extras → API keys', looks: '32 hex + -us21 (the suffix is your data centre)',
    steps: ['Open Profile → Extras → API keys.', 'Press Create A Key, name it 0n3 and press Generate Key.', 'Copy the key (shown once) and paste it below.'],
    scopes: ['API keys carry full account access; nothing to tick.'],
    fields: { apiKey: { label: 'API key (with the -usNN suffix)' } },
    pattern: '[a-f0-9]{32}-us[0-9]{1,2}',
  },
  convertkit: {
    url: 'https://app.kit.com/account_settings/developer_settings', where: 'Settings → Developer', looks: 'a 43-character API secret',
    steps: ['Open Settings → Developer in Kit (formerly ConvertKit).', 'Under v3 API, press Show next to API Secret and copy it.', 'Paste it below.'],
    scopes: ['The v3 API secret has full account access; nothing to tick.'],
    fields: { apiSecret: { label: 'v3 API secret' } },
  },
  activecampaign: {
    url: 'https://www.activecampaign.com/login', urlFor: { template: 'https://{accountName}.activehosted.com/app/settings/developer', ask: 'Your account name (the NAME in NAME.api-us1.com)', key: 'accountName' }, where: 'Settings → Developer', looks: 'API URL https://NAME.api-us1.com + a 72-character key',
    steps: ['Sign in and open Settings (gear, bottom left) → Developer.', 'Copy the API Key, and note the account name in the URL (https://NAME.api-us1.com).', 'Paste both below.'],
    scopes: ['The developer key acts as your user; nothing to tick.'],
    fields: { apiKey: { label: 'API key' }, accountName: { label: 'Account name', where: 'the NAME in your API URL https://NAME.api-us1.com' } },
  },
  lemlist: {
    url: 'https://app.lemlist.com/settings/integrations', where: 'Settings → Integrations → API', looks: 'a 32-character key', unverified: true,
    steps: ['Open Settings → Integrations in lemlist.', 'Find API and press Generate (or copy the existing key).', 'Paste it below.'],
    scopes: ['The API key has full team access; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
  },
  smartlead: {
    url: 'https://app.smartlead.ai/app/settings/profile', where: 'Settings → Profile → API Key', looks: 'a UUID-shaped key with an underscore suffix', unverified: true,
    steps: ['Open Settings in Smartlead.', 'Copy the API Key from the profile section (press Generate if none).', 'Paste it below.'],
    scopes: ['The API key has full account access; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
  },
  gmail: { door: 'google', url: 'https://myaccount.google.com/permissions', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('sends and reads the mail'), scopes: ['https://www.googleapis.com/auth/gmail.modify', 'https://www.googleapis.com/auth/gmail.send'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } }, note: 'Connecting Gmail asks Google for mail permission on top of what you already gave. If Google shows a warning page first, press Advanced, then Go to 0n3.' },

  // ── messaging ────────────────────────────────────────────────────────
  slack: {
    door: 'slack', url: 'https://api.slack.com/apps', where: 'Your app → OAuth & Permissions → Bot User OAuth Token', looks: 'xoxb-…',
    steps: ['Press Sign in with Slack and pick the workspace; or', 'at api.slack.com/apps press Create New App → From scratch, then open OAuth & Permissions and add the Bot Token Scopes below.', 'Press Install to Workspace → Allow, then copy the Bot User OAuth Token.', 'Paste the token below.'],
    scopes: ['chat:write, chat:write.public', 'channels:read, channels:manage, channels:history, channels:join, groups:read', 'users:read, users:read.email, users.profile:read', 'files:read, files:write', 'reactions:read, reactions:write', 'pins:read, pins:write', 'bookmarks:read, bookmarks:write', 'reminders:read, reminders:write', 'canvases:write', 'team:read', 'search:read and users.profile:write need a user token (xoxp-); bots cannot search or set status'],
    fields: { botToken: { label: 'Bot User OAuth Token' } },
    pattern: 'xox[bp]-[0-9]+-[0-9]+(-[0-9]+)?-[A-Za-z0-9]+',
  },
  discord: {
    url: 'https://discord.com/developers/applications', where: 'Your application → Bot → Token', looks: 'three dot-separated parts, about 72 characters',
    steps: ['Open the Developer Portal, press New Application (or open yours), then Bot.', 'Press Reset Token, confirm, and copy the token (shown once).', 'Open OAuth2 → URL Generator, tick bot plus the permissions below, open the link and add the bot to your server.', 'Paste the token below.'],
    scopes: ['OAuth2 scope: bot', 'Bot permissions: View Channels, Send Messages, Read Message History'],
    fields: { botToken: { label: 'Bot token' } },
    pattern: '[A-Za-z0-9_-]{24,28}\\.[A-Za-z0-9_-]{6}\\.[A-Za-z0-9_-]{27,38}',
  },
  telegram: {
    url: 'https://t.me/BotFather', where: 'BotFather → /newbot', looks: '8–10 digits : AA + 33 characters',
    steps: ['Open @BotFather in Telegram and send /newbot (or /token for a bot you already have).', 'Answer the name and username questions.', 'Copy the token it replies with and paste it below.'],
    scopes: ['A bot token has every Bot API permission; add the bot to a group or channel as admin for it to post there.'],
    fields: { botToken: { label: 'Bot token' } },
    pattern: '[0-9]{8,10}:AA[A-Za-z0-9_-]{33}',
  },
  twilio: {
    url: 'https://console.twilio.com/', where: 'Console home → Account Info', looks: 'Account SID AC + 32 hex, Auth Token 32 hex',
    steps: ['Open the Twilio Console home page.', 'In Account Info copy the Account SID, then press Show and copy the Auth Token.', 'Paste both below.'],
    scopes: ['The Auth Token has full account access (send SMS, list messages, place calls).'],
    fields: { accountSid: { label: 'Account SID', where: 'Console home → Account Info' }, authToken: { label: 'Auth Token', where: 'Console home → Account Info → Show' } },
    pattern: 'AC[a-f0-9]{32}', patternField: 'accountSid',
  },
  whatsapp: {
    url: 'https://developers.facebook.com/apps', where: 'Meta app → WhatsApp → API Setup', looks: 'EAA… access token + a numeric phone number id',
    steps: META_STEPS('Phone number ID from WhatsApp → API Setup'),
    scopes: ['whatsapp_business_messaging', 'whatsapp_business_management'],
    fields: { accessToken: { label: 'System user access token' }, phoneNumberId: { label: 'Phone number ID', where: 'App → WhatsApp → API Setup → From' } },
    pattern: 'EAA[A-Za-z0-9]{100,}', patternField: 'accessToken',
  },
  microsoft: { door: 'microsoft', url: 'https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade', where: 'Sign in with Microsoft 365', looks: 'signed in by Microsoft', steps: ['Press Sign in with Microsoft 365.', 'Pick your work or personal account and press Accept.', 'You come straight back here, connected.'], scopes: ['User.Read, Mail.ReadWrite, Mail.Send, Calendars.ReadWrite, Files.ReadWrite.All, Team.ReadBasic.All, Channel.ReadBasic.All, ChannelMessage.Send, offline_access (asked for by the door)'], fields: { access_token: { label: 'Access token (filled by Sign in with Microsoft)' } }, note: 'A work account may need an admin to approve the app the first time.' },

  // ── CRM + sales ──────────────────────────────────────────────────────
  crm: {
    url: 'https://app.rocketclients.com/', where: 'Sub-account → Settings → Private Integrations', looks: 'pit- + a UUID, plus the location id',
    steps: ['Sign in to your CRM, switch into the sub-account, and open Settings → Private Integrations.', 'Press Create new Integration, name it 0n3 and tick the scopes below.', 'Press Create, copy the token (shown once) and paste it below.', 'The location id is in Settings → Business Profile (or the URL after /location/).'],
    scopes: ['contacts.readonly, contacts.write', 'conversations.readonly, conversations.write, conversations/message.write', 'opportunities.readonly, opportunities.write', 'locations.readonly, locations/tags.readonly, locations/tags.write', 'locations/customValues.readonly, locations/customValues.write', 'workflows.readonly', 'calendars.readonly, calendars/events.write', 'campaigns.readonly'],
    fields: { access_token: { label: 'Private Integration token' }, location_id: { label: 'Location id', where: 'Settings → Business Profile, or the id after /location/ in the CRM URL' } },
    pattern: 'pit-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}', patternField: 'access_token',
    note: 'Use the sub-account’s own token: an agency token is refused on a location it was not issued for.',
  },
  hubspot: {
    url: 'https://app.hubspot.com/l/private-apps', unverified: true, where: 'Development → Legacy apps → Create legacy app → Private', looks: 'pat-na1- (or pat-eu1-) + a UUID',
    steps: ['As a super admin, open Development → Legacy apps in HubSpot and press Create legacy app, then pick Private.', 'Name it 0n3, open Scopes and tick the scopes below, then press Create app.', 'Open the Auth tab, press Show token, then Copy.', 'Paste it below.'],
    scopes: ['crm.objects.contacts.read, crm.objects.contacts.write', 'crm.objects.companies.read, crm.objects.companies.write', 'crm.objects.deals.read, crm.objects.deals.write'],
    fields: { accessToken: { label: 'Private app access token' } },
    pattern: 'pat-(na|eu|ap)[0-9]-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}',
  },
  pipedrive: {
    url: 'https://app.pipedrive.com/settings/api', where: 'Avatar → Personal preferences → API', looks: '40 hex characters',
    steps: ['Open your avatar (top right) → Personal preferences → API.', 'Copy Your personal API token (press Generate new token if empty).', 'Paste it below.'],
    scopes: ['The personal token acts as you; your user needs access to the deals, people and pipelines 0n3 should touch.', 'Pipedrive is retiring personal-token connections. Prefer signing in: run 0n3 connect-mcp pipedrive_mcp for the official Pipedrive MCP server, which covers deals, people, leads, activities, products, projects and mail.'],
    fields: { apiKey: { label: 'Personal API token' } },
  },
  grok_bot: {
    url: 'https://grok.com', where: 'Grok Bot → the routine → Webhook (desktop)', looks: 'a POST to URL and a key',
    steps: ['In Grok Bot, ask: "Add a webhook trigger to the <name> routine."', 'Open that routine on the desktop app and find the Webhook section.', 'Copy POST to (the URL) and key (the secret) into the two fields below. Name this connection after the routine.', 'Optional, so the Bot can work in your apps and report back: ask Grok Bot to add a custom MCP connection to https://0n3.app/mcp and sign in with 0n3.'],
    scopes: ['One connection per routine. 0n3 starts it; the answer appears in the Bot\'s chat.', 'Grok Bot runs each routine up to 200 times an hour, and 300 an hour across all routines.'],
    fields: { webhook_url: { label: 'POST to (webhook URL)' }, key: { label: 'key' } },
  },
  intercom: {
    url: 'https://app.intercom.com/a/apps/_/developer-hub', where: 'Settings → Integrations → Developer Hub → your app → Authentication', looks: 'dG9rOi… (about 60 characters)',
    steps: ['Open the Developer Hub and press New app; name it 0n3 and pick your workspace.', 'Open Authentication and copy the Access token.', 'Paste it below.'],
    scopes: ['Read and write users and companies', 'Read and write conversations', 'Read and write tags', 'Read and write articles'],
    fields: { accessToken: { label: 'Access token' } },
    pattern: 'dG9rO[A-Za-z0-9+/=_-]{40,}',
  },
  zendesk: {
    url: 'https://support.zendesk.com/hc/en-us/articles/4408889192858-Managing-API-token-access-to-the-Zendesk-API', urlFor: { template: 'https://{subdomain}.zendesk.com/admin/apps-integrations/apis/zendesk-api/settings/tokens', ask: 'Your Zendesk name (the part before .zendesk.com)', key: 'subdomain' }, where: 'Admin Center → Apps and integrations → APIs → API tokens', looks: '40-character token + your agent email + your subdomain',
    steps: ['Open Admin Center → Apps and integrations → APIs → API tokens (at https://YOURNAME.zendesk.com/admin).', 'Press Add API token, describe it as 0n3, press Save and copy the token (shown once).', 'Paste the token, your agent email and your subdomain below.'],
    scopes: ['Token access acts as the agent whose email you use; use an admin for users, organizations and macros.'],
    fields: { email: { label: 'Agent email' }, apiToken: { label: 'API token' }, subdomain: { label: 'Subdomain', where: 'the NAME in NAME.zendesk.com' } },
  },
  freshdesk: {
    url: 'https://support.freshdesk.com/support/solutions/articles/215517-how-to-find-your-api-key', urlFor: { template: 'https://{domain}.freshdesk.com/a/', ask: 'Your helpdesk name (the part before .freshdesk.com)', key: 'domain' }, where: 'Profile picture → Profile settings → View API key', looks: '20 characters + your helpdesk domain',
    steps: ['Open your helpdesk, press your profile picture (top right) → Profile settings.', 'Press View API key, pass the captcha and copy it.', 'Paste it below with your helpdesk name.'],
    scopes: ['The key acts as your agent; an admin agent sees every ticket and contact.'],
    fields: { apiKey: { label: 'API key' }, domain: { label: 'Helpdesk name', where: 'the NAME in NAME.freshdesk.com' } },
  },

  // ── productivity + project tools ─────────────────────────────────────
  ontask: {
    url: 'https://app.0ntask.com/', where: '0nTask → Settings (gear, top right) → Keys → API keys', looks: '0nt_live_…',
    steps: ['Open app.0ntask.com and press the gear (top right) for Settings.', 'Open the Keys tab, find API keys and press New key; name it 0n3 and copy it (shown once).', 'Paste it below. This also lights up Projects and Clients in the workspace menu.'],
    scopes: ['One key covers tasks, projects, clients and the AI queue for your account.'],
    fields: { token: { label: '0nTask API key' } },
    pattern: '0nt_live_[A-Za-z0-9_-]{16,}',
  },
  airtable: {
    url: 'https://airtable.com/create/tokens', where: 'Builder hub → Personal access tokens', looks: 'pat + 14 characters + . + 64 hex',
    steps: ['Open airtable.com/create/tokens and press + Create new token.', 'Name it 0n3, press + Add a scope for each scope below, then + Add a base (or All current and future bases).', 'Press Create token, copy it (shown once) and paste it below.'],
    scopes: ['data.records:read', 'data.records:write', 'schema.bases:read'],
    fields: { apiKey: { label: 'Personal access token' } },
    pattern: 'pat[A-Za-z0-9]{14}\\.[a-f0-9]{64}',
  },
  notion: {
    url: 'https://www.notion.so/profile/integrations', where: 'Settings → Connections → Develop or manage integrations', looks: 'ntn_… (older: secret_…)',
    steps: ['Open notion.so/profile/integrations and press + New integration (Internal).', 'Pick the workspace, press Save, then copy the Internal Integration Secret.', 'Under Capabilities tick the ones below and Save.', 'In each page or database, press ••• → Connections → add 0n3, then paste the secret below.'],
    scopes: ['Read content', 'Update content', 'Insert content'],
    fields: { apiKey: { label: 'Internal Integration Secret' } },
    pattern: '(ntn_[A-Za-z0-9]{40,}|secret_[A-Za-z0-9]{43})',
  },
  asana: {
    url: 'https://app.asana.com/0/my-apps', where: 'Profile → My settings → Apps → Developer console', looks: '2/… numbers …:32 hex',
    steps: ['Open app.asana.com/0/my-apps.', 'Press + Create new token, name it 0n3, agree to the terms and press Create token.', 'Copy the token (shown once) and paste it below.'],
    scopes: ['A personal access token acts as you across every workspace you belong to.'],
    fields: { token: { label: 'Personal access token' } },
    pattern: '[0-9]/[0-9]{10,}(/[0-9]{10,})?:[a-f0-9]{32}',
  },
  trello: {
    url: 'https://trello.com/power-ups/admin', where: 'Power-Up admin → your Power-Up → API key', looks: 'API key (32 hex) + token (ATTA…)',
    steps: ['Open trello.com/power-ups/admin and press New to create a Power-Up (name 0n3, any workspace).', 'Open API key → Generate a new API key and copy the key.', 'Press the Token link next to it, press Allow, and copy the token.', 'Paste both below.'],
    scopes: ['The token link asks for read,write on your account; press Allow.'],
    fields: { apiKey: { label: 'API key' }, apiToken: { label: 'Token', where: 'the Token link next to the API key' } },
    pattern: 'ATTA[A-Za-z0-9]{60,}', patternField: 'apiToken',
  },
  monday: {
    url: 'https://auth.monday.com/login', urlFor: { template: 'https://{account}.monday.com/apps/manage/tokens', ask: 'Your monday.com name (the part before .monday.com)', key: 'account' }, unverified: true, where: 'Avatar → Developers → My access tokens', looks: 'a long JWT (eyJ…)',
    steps: ['Press your profile picture (top right) → Developers; the Developer Center opens in a new tab.', 'Open My access tokens and press Show (Regenerate expires the old one).', 'Copy the token and paste it below.'],
    scopes: ['The personal token acts as you; it reaches every board you can see.'],
    fields: { apiKey: { label: 'Personal API token' } },
  },
  linear: {
    url: 'https://linear.app/settings/account/security', where: 'Settings → Account → Security & access → Personal API keys', looks: 'lin_api_ + 40 characters',
    steps: ['Open Settings → Account → Security & access.', 'Under Personal API keys press New API key, name it 0n3 and pick Full access (or Read + Write).', 'Copy the key and paste it below.'],
    scopes: ['Read', 'Write (or Full access)', 'Teams: all teams'],
    fields: { apiKey: { label: 'Personal API key' } },
    pattern: 'lin_api_[A-Za-z0-9]{40}',
  },
  jira: {
    url: 'https://id.atlassian.com/manage-profile/security/api-tokens', where: 'Atlassian account → Security → API tokens', looks: 'ATATT3… (about 190 characters) + your email + your site',
    steps: ['Open id.atlassian.com → Security → API tokens and press Create API token.', 'Name it 0n3, pick an expiry and press Create, then Copy.', 'Paste the token, the email you sign in with, and your site name below.'],
    scopes: ['A classic API token acts as you; your user needs Browse, Create, Edit, Transition and Comment on the projects.'],
    fields: { email: { label: 'Atlassian email' }, apiToken: { label: 'API token' }, domain: { label: 'Site name', where: 'the NAME in NAME.atlassian.net' } },
    pattern: 'ATATT3[A-Za-z0-9_=-]{100,}', patternField: 'apiToken',
  },
  ticktick: {
    door: 'ticktick', url: 'https://developer.ticktick.com/manage', where: 'TickTick Developer → Manage Apps', looks: 'an OAuth access token (UUID shape)', unverified: true,
    steps: ['Open developer.ticktick.com → Manage Apps and press + App Name.', 'Copy the Client ID and Client Secret, and set the OAuth redirect URL.', 'Run the OAuth flow with the scopes below and copy the access_token it returns.', 'Paste it below.'],
    scopes: ['tasks:read', 'tasks:write'],
    fields: { access_token: { label: 'Access token' } },
  },
  typeform: {
    url: 'https://admin.typeform.com/user/tokens', where: 'Account → Your settings → Personal tokens', looks: 'tfp_…',
    steps: ['Open admin.typeform.com/user/tokens and press Generate a new token.', 'Name it 0n3 and pick the scopes below (or Full access).', 'Press Generate token, copy it (shown once) and paste it below.'],
    scopes: ['forms:read, forms:write', 'responses:read', 'webhooks:read, webhooks:write', 'workspaces:read'],
    fields: { accessToken: { label: 'Personal access token' } },
    pattern: 'tfp_[A-Za-z0-9_-]{30,}',
  },
  docusign: {
    door: 'docusign', url: 'https://developers.docusign.com/docs/esign-rest-api/esign101/auth/', where: 'Admin → Integrations → Apps and Keys', looks: 'an OAuth access token + an account id (UUID)', unverified: true,
    steps: ['Open Admin → Integrations → Apps and Keys and press Add App and Integration Key.', 'Note the API Account ID at the top of Apps and Keys.', 'Get an access token with the signature scope (Authorization Code or JWT Grant) and copy it.', 'Paste the token and the API Account ID below.'],
    scopes: ['signature'],
    fields: { accessToken: { label: 'Access token' }, accountId: { label: 'API Account ID', where: 'Admin → Apps and Keys → My Account Information' } },
    note: 'Sign in with DocuSign finds your account and its server and keeps you connected. A pasted token lasts about 8 hours and reaches only the demo (developer) environment.',
  },
  zoom: {
    door: 'zoom', url: 'https://marketplace.zoom.us/user/build', where: 'App Marketplace → Develop → Build App → Server-to-Server OAuth', looks: 'an OAuth access token (eyJ…)',
    steps: ['Open marketplace.zoom.us → Develop → Build App and pick Server-to-Server OAuth App.', 'Copy the Account ID, Client ID and Client Secret; under Scopes add the scopes below; press Activate.', 'Mint a token: POST https://zoom.us/oauth/token?grant_type=account_credentials&account_id=… with Basic client_id:client_secret.', 'Paste the access_token below.'],
    scopes: ['meeting:read:admin, meeting:write:admin', 'recording:read:admin, recording:write:admin', 'user:read:admin'],
    fields: { access_token: { label: 'Access token' } },
    note: 'Sign in with Zoom keeps you connected. A pasted Server-to-Server token lasts one hour.',
  },
  calendly: {
    url: 'https://calendly.com/integrations/api_webhooks', where: 'Integrations → API & Webhooks → Personal access tokens', looks: 'a long JWT (eyJ…)',
    steps: ['Open Integrations → API & Webhooks.', 'Press Generate new token, name it 0n3 and press Create token.', 'Copy it (shown once) and paste it below.'],
    scopes: ['A personal access token acts as you; nothing to tick.'],
    fields: { apiKey: { label: 'Personal access token' } },
  },
  loom: {
    warn: 'Loom does not give keys to regular accounts, so most people cannot connect Loom yet. If Loom gave your company API access, use the steps below.',
    url: 'https://dev.loom.com/', where: 'Loom developer portal', looks: 'an access token', unverified: true,
    steps: ['Loom’s public API is limited to its recordSDK and embed; there is no self-serve key page for listing videos.', 'If Loom granted your workspace API access, copy the access token they issued.', 'Paste it below.'],
    scopes: ['videos:read, videos:write (as granted by Loom)'],
    fields: { accessToken: { label: 'Access token' } },
  },
  whimsical: {
    url: 'https://whimsical.com/', where: 'Workspace settings → API', looks: 'an access token', unverified: true,
    steps: ['Whimsical’s API is offered to Business and Enterprise workspaces.', 'An admin opens workspace settings and creates an API token (or contacts Whimsical to enable it).', 'Copy the token and paste it below.'],
    scopes: ['Boards and docs: read and write', 'SCIM endpoints need an Enterprise SCIM token'],
    fields: { accessToken: { label: 'Access token' } },
  },
  figma: {
    url: 'https://www.figma.com/settings', where: 'Avatar → Settings → Security → Personal access tokens', looks: 'figd_…',
    steps: ['Open Settings (avatar menu) → Security.', 'Under Personal access tokens press Generate new token, name it 0n3 and set the scopes below.', 'Press Generate token, copy it (shown once) and paste it below.'],
    scopes: ['File content: Read-only', 'File metadata and versions: Read-only', 'Comments: Write', 'Library assets and content: Read-only', 'Team library content: Read-only', 'Variables: Write (Enterprise)', 'Webhooks: Write', 'Dev resources: Write', 'Projects: Read-only'],
    fields: { personalAccessToken: { label: 'Personal access token' } },
    pattern: 'figd_[A-Za-z0-9_-]{40,}',
  },

  // ── automation ───────────────────────────────────────────────────────
  zapier: {
    retired: 'Zapier does not give personal keys. Use Zapier MCP instead: open mcp.zapier.com, make a server, copy its web address, then come back to Connect and choose Add an MCP server.',
    url: 'https://developer.zapier.com/', where: 'Zapier Developer Platform', looks: 'a bearer token', unverified: true,
    steps: ['Zapier does not offer a personal key for listing or toggling Zaps; access is granted to partner integrations.', 'If you have a Partner API or Zapier MCP token, copy it from the developer platform.', 'Paste it below.'],
    scopes: ['zap:read, zap:write (partner access)'],
    fields: { apiKey: { label: 'Bearer token' } },
  },
  make: {
    url: 'https://developers.make.com/api-documentation/authentication/create-authentication-token', where: 'Profile → API → Add token', looks: 'a UUID-shaped token',
    steps: ['In Make press Profile, open the API tab and press Add token.', 'Name it 0n3 and tick the scopes below.', 'Press Save, copy the token (shown once) and paste it below.'],
    scopes: ['scenarios:read, scenarios:write, scenarios:run', 'connections:read, connections:write', 'datastores:read', 'organizations:read'],
    fields: { apiToken: { label: 'API token' } },
    note: '0n3 calls the us1 zone; an account on eu1/eu2/us2 needs its own zone.',
  },
  n8n: {
    url: 'https://docs.n8n.io/connect/n8n-api/authentication', where: 'Your n8n → Settings → n8n API', looks: 'a long JWT (eyJ…) + your instance URL',
    steps: ['In your n8n open Settings → n8n API and press Create an API key.', 'Name it 0n3, pick an expiry, press Save and copy the key.', 'Paste it with your instance URL below.'],
    scopes: ['Full access (or, on Enterprise, workflow, execution and credential scopes)'],
    fields: { apiKey: { label: 'API key' }, baseUrl: { label: 'Instance URL', where: 'e.g. https://you.app.n8n.cloud/api/v1' } },
  },
  pabbly: {
    url: 'https://connect.pabbly.com/', where: 'Pabbly Connect → Settings → API', looks: 'an API token', unverified: true,
    steps: ['Sign in to Pabbly Connect and open Settings (or Integrations → API).', 'Copy the API token.', 'Paste it below.'],
    scopes: ['The token has full account access.'],
    fields: { apiKey: { label: 'API token' } },
  },
  mulesoft: {
    door: 'mulesoft', url: 'https://anypoint.mulesoft.com/accounts/connectedApps', where: 'Anypoint Platform → Access Management → Connected Apps', looks: 'a bearer access token (UUID)',
    steps: ['Open Access Management → Connected Apps and press Create app → App acts on its own behalf (client credentials).', 'Add the scopes below to your business group and environments, then Save and copy the ID and Secret.', 'POST https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token with grant_type=client_credentials and copy access_token.', 'Paste it below.'],
    scopes: ['View Organization', 'View Environment', 'Manage APIs Configuration', 'Read Applications, Create Applications (Runtime Manager)'],
    fields: { token: { label: 'Access token' } },
  },
  crewai: {
    url: 'https://app.crewai.com/', where: 'CrewAI AMP → your deployed crew → Status/Overview', looks: 'a bearer token + the crew name',
    steps: ['Open your deployed crew in CrewAI AMP.', 'Copy the Bearer Token shown on the crew’s overview, and note the crew URL name.', 'Paste both below.'],
    scopes: ['The crew token can kickoff, read status and resume that crew.'],
    fields: { bearerToken: { label: 'Bearer token' }, crewName: { label: 'Crew name', where: 'the subdomain of the crew URL' } },
    unverified: true,
  },

  // ── developer + hosting ──────────────────────────────────────────────
  github: {
    door: 'github', url: 'https://github.com/settings/personal-access-tokens/new', where: 'Settings → Developer settings → Personal access tokens → Fine-grained tokens', looks: 'github_pat_… (classic: ghp_…)',
    steps: ['Press Sign in with GitHub; or', 'open the link, name the token 0n3, pick the repositories, and set the repository permissions below.', 'Press Generate token, copy it (shown once) and paste it below.'],
    scopes: ['Contents: Read', 'Issues: Read and write', 'Pull requests: Read and write', 'Metadata: Read (automatic)', 'Classic token instead: repo'],
    fields: { token: { label: 'Personal access token' } },
    pattern: '(github_pat_[A-Za-z0-9_]{82}|ghp_[A-Za-z0-9]{36})',
  },
  npm: {
    url: 'https://www.npmjs.com/settings/~/tokens', where: 'Avatar → Access Tokens → Generate New Token', looks: 'npm_ + 36 characters',
    steps: ['Open npmjs.com → avatar → Access Tokens and press Generate New Token.', 'Name it 0n3, set Packages and scopes to Read and write (for publish), tick Bypass two-factor authentication if your packages need 2FA to publish.', 'Press Generate token, copy it (shown once) and paste it below.'],
    scopes: ['Packages and scopes: Read and write', 'Bypass 2FA (publish only)'],
    fields: { token: { label: 'Access token' } },
    pattern: 'npm_[A-Za-z0-9]{36}',
  },
  vercel: {
    url: 'https://vercel.com/account/settings/tokens', where: 'Account Settings → Tokens', looks: '24 letters and digits',
    steps: ['Open vercel.com/account/settings/tokens.', 'Name it 0n3, set Scope to your team and pick an expiration, press Create.', 'Copy the token (shown once) and paste it below with the team id.'],
    scopes: ['Scope: the team that owns the projects (Full Account covers your personal projects only)'],
    fields: { apiKey: { label: 'Access token' }, teamId: { label: 'Team id', where: 'Team Settings → General → Team ID (team_…)' } },
  },
  netlify: {
    url: 'https://app.netlify.com/user/applications#personal-access-tokens', where: 'User settings → Applications → Personal access tokens', looks: 'nfp_…',
    steps: ['Open User settings → Applications → Personal access tokens.', 'Press New access token, describe it as 0n3, pick an expiration and press Generate token.', 'Copy it (shown once) and paste it below.'],
    scopes: ['A personal access token acts as you on every team you belong to.'],
    fields: { accessToken: { label: 'Personal access token' } },
    pattern: 'nfp_[A-Za-z0-9]{36,}',
  },
  cloudflare: {
    url: 'https://dash.cloudflare.com/profile/api-tokens', where: 'My Profile → API Tokens → Create Token → Create Custom Token', looks: '40 letters, digits, _ and -',
    steps: ['Open My Profile → API Tokens and press Create Token, then Create Custom Token → Get started.', 'Name it 0n3 and add the permission rows below, one row each.', 'Under Zone Resources pick Include → All zones (Account Resources: your account), press Continue to summary → Create Token.', 'Copy the token (shown once) and paste it below. Copy the Account ID from any domain’s Overview page (right-hand column, API section).'],
    scopes: ['Zone → Zone → Edit', 'Zone → DNS → Edit', 'Account → Registrar Domains → Edit (or Read to look only)', 'Account → Account Settings → Read', 'Zone Resources: Include → All zones', 'Workers / KV / R2 / D1 / Pages work too if you add Account → Workers Scripts, Workers KV Storage, Workers R2 Storage, D1 and Cloudflare Pages → Edit', 'Workers AI (hosted models) works if you add Account → Workers AI → Read and Edit'],
    fields: { apiToken: { label: 'API token' }, accountId: { label: 'Account ID', where: 'any domain → Overview → API section (right column), or the 32-hex id in the dashboard URL' } },
  },
  openstreetmap: {
    door: 'openstreetmap', url: 'https://www.openstreetmap.org/oauth2/applications', where: 'OpenStreetMap → My Settings → OAuth 2 Applications', looks: 'an OAuth access token',
    steps: ['Press Sign in with OpenStreetMap on this page and approve.', 'No button? Open openstreetmap.org → your name → My Settings → OAuth 2 Applications → Register new application (redirect URI: urn:ietf:wg:oauth:2.0:oob).', 'Tick the permissions below, authorize it for your own account and copy the access token.', 'Paste it below.'],
    scopes: ['read_prefs — who you are', 'read_gpx / write_gpx — your GPS traces', 'write_notes — leave a note where the map is wrong'],
    fields: { access_token: { label: 'Access token' } },
    note: 'Looking places up (Nominatim) and asking the map questions (Overpass) need no sign-in at all.',
  },
  graphhopper: {
    url: 'https://graphhopper.com/dashboard/#/apikeys', where: 'GraphHopper dashboard → API Keys', looks: 'a key like 1a2b3c4d-…-…-…-… (a UUID)',
    steps: ['Open graphhopper.com/dashboard and sign in.', 'Open API Keys and press Add API key (or copy the default one).', 'Paste the key here.'],
    scopes: ['The free plan covers car routing, small matrices and geocoding; truck profiles and large matrices need a paid plan'],
    fields: { apiKey: { label: 'API key' } },
  },
  godaddy: {
    url: 'https://developer.godaddy.com/keys', where: 'Developer portal → API Keys (Production) — or → Personal Access Tokens', looks: 'key + secret, or one scoped token (a Personal Access Token)',
    steps: ['Open developer.godaddy.com/keys, sign in and press Create New API Key.', 'Name it 0n3 and pick Production (OTE keys only work on GoDaddy’s test environment), press Next.', 'Copy the Key and the Secret (the secret is shown once) and paste both below — or paste KEY:SECRET in the key field.', 'Or make one scoped token instead: developer.godaddy.com/personal-access-token → Generate Token, tick the scopes below, Create Token, and paste it alone in the key field (0n3 sends it as Bearer).'],
    scopes: ['Production environment (key + secret)', 'Personal Access Token: Domains & DNS — domains.domain:read, domains.domain:update, domains.dns:update, domains.nameserver:update', 'GoDaddy limits the Domains API on key + secret to accounts with 10+ domains or a Discount Domain Club plan'],
    fields: { apiKey: { label: 'API key (or KEY:SECRET, or a single scoped token)' }, apiSecret: { label: 'API secret', where: 'shown once next to the key; leave empty for a single scoped token' } },
    note: 'GoDaddy is retiring classic keys for the Domains API through 2026; a Personal Access Token is the long-term choice.',
  },
  hostinger: {
    url: 'https://hpanel.hostinger.com/profile/api', where: 'hPanel → Account → API', looks: 'a long token',
    steps: ['Open hPanel → your profile → API.', 'Press Generate token (or New token), name it 0n3, pick an expiry and press Generate.', 'Copy it (shown once) and paste it below.'],
    scopes: ['An API token has full account access (hosting, domains, DNS, VPS, billing).'],
    fields: { apiKey: { label: 'API token' } },
  },
  instawp: {
    url: 'https://docs.instawp.com/account/create-an-api-token', where: 'Profile icon → My Account → API Tokens', looks: 'a long token',
    steps: ['In app.instawp.io press the profile icon (top right) → My Account, then API Tokens.', 'Press Create, name it 0n3, set Permission to Read-write and press CREATE.', 'Copy it (shown once) and paste it below.'],
    scopes: ['Permission: Read-write (read-only cannot create sites)'],
    fields: { apiKey: { label: 'API token' } },
  },
  webflow: {
    url: 'https://developers.webflow.com/data/reference/authentication/site-token', where: 'Site settings → Apps & integrations → API access', looks: '64 hex characters',
    steps: ['Open the site, then Site settings → Apps & integrations, scroll to API access.', 'Press Generate API token, name it 0n3 and set the scopes below.', 'Press Generate token, copy it (shown once) and paste it below.'],
    scopes: ['Sites: Read and write', 'CMS: Read and write', 'Forms: Read-only', 'Ecommerce: Read-only'],
    fields: { accessToken: { label: 'Site API token' } },
  },
  wordpress: {
    url: 'https://make.wordpress.org/core/2020/11/05/application-passwords-integration-guide/', where: 'WP Admin → Users → Profile → Application Passwords', looks: 'xxxx xxxx xxxx xxxx xxxx xxxx + username + site address',
    steps: ['In WordPress open Users → Profile and scroll to Application Passwords.', 'Type 0n3 as the name and press Add New Application Password.', 'Copy the password (shown once) and paste it below with your username and site address.'],
    scopes: ['Use an Administrator or Editor user so posts, pages, media and users all work.'],
    fields: { siteUrl: { label: 'Site address', where: 'e.g. example.com (no https://)' }, username: { label: 'WordPress username' }, applicationPassword: { label: 'Application password' } },
    pattern: '[A-Za-z0-9]{4}( [A-Za-z0-9]{4}){5}', patternField: 'applicationPassword',
  },
  supabase: {
    url: 'https://supabase.com/dashboard/project/_/settings/api-keys', where: 'Project → Project Settings → API Keys', looks: 'sb_secret_… (legacy: service_role eyJ…) + the project ref',
    steps: ['Open your project, then Project Settings → API Keys.', 'Copy a Secret key (sb_secret_…; press Create new secret key if none) — or the legacy service_role key.', 'Copy the project ref from Project Settings → General → Project ID.', 'Paste both below. Server-side only: it bypasses Row Level Security.'],
    scopes: ['Secret / service_role key: full access, bypasses RLS'],
    fields: { apiKey: { label: 'Secret (service_role) key' }, projectRef: { label: 'Project ref', where: 'Project Settings → General → Project ID (the xxxx in xxxx.supabase.co)' } },
    pattern: 'sb_secret_[A-Za-z0-9_-]{20,}', patternField: 'apiKey',
  },
  neon: {
    url: 'https://console.neon.tech/app/settings/api-keys', where: 'Account settings → API keys', looks: 'napi_ + about 60 characters',
    steps: ['Open Account settings → API keys (or Organization settings → API keys).', 'Press Create new API key, name it 0n3 and press Create.', 'Copy it (shown once) and paste it below.'],
    scopes: ['A personal or organization key has full access to its projects.'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 'napi_[A-Za-z0-9]{60,}',
  },
  planetscale: {
    url: 'https://app.planetscale.com/', where: 'Organization → Settings → Service tokens', looks: 'a token + the organization name',
    steps: ['Open your organization → Settings → Service tokens and press New service token.', 'Name it 0n3, press Create, copy the token id and token.', 'Press Edit permissions and grant the permissions below.', 'Paste the token and the organization name below.'],
    scopes: ['Organization: create_databases, read_databases, delete_databases', 'Database: read_branches, create_branch, read_deploy_requests'],
    fields: { accessToken: { label: 'Token' }, organizationId: { label: 'Organization name', where: 'the name in app.planetscale.com/<name>' } },
    pattern: 'pscale_tkn_[A-Za-z0-9_-]{30,}', patternField: 'accessToken',
    note: 'Service tokens authenticate as “TOKEN_ID:TOKEN”; paste them joined by a colon.',
  },
  turso: {
    url: 'https://app.turso.tech/', where: 'Account → Settings → API Tokens', looks: 'a long JWT (eyJ…) + your organization name',
    steps: ['Open app.turso.tech → your avatar → Settings → API Tokens (or run turso auth api-tokens mint 0n3).', 'Press Create API Token, name it 0n3 and copy it.', 'Paste it with your organization slug below.'],
    scopes: ['Platform API tokens have full access to the organization.'],
    fields: { apiToken: { label: 'Platform API token' }, organizationName: { label: 'Organization slug', where: 'top-left org switcher, or turso org list' } },
  },
  cockroachdb: {
    url: 'https://cockroachlabs.cloud/access/serviceaccounts', where: 'Organization → Access Management → Service Accounts', looks: 'CCDB1_ + about 40 characters',
    steps: ['Open Access Management → Service Accounts and press Create Service Account.', 'Name it 0n3, grant the role below, then press Create API key and copy it (shown once).', 'Paste it below.'],
    scopes: ['Role: Cluster Admin (or Cluster Creator to create and list only)'],
    fields: { apiKey: { label: 'Service account API key' } },
    pattern: 'CCDB1_[A-Za-z0-9_]{20,}',
  },
  railway: {
    url: 'https://railway.com/account/tokens', where: 'Account Settings → Tokens', looks: 'a UUID-shaped token',
    steps: ['Open railway.com/account/tokens.', 'Name the token 0n3, pick the workspace (or No workspace for personal), press Create.', 'Copy it and paste it below.'],
    scopes: ['An account token reaches every project in the chosen workspace.'],
    fields: { apiToken: { label: 'API token' } },
  },
  render: {
    url: 'https://dashboard.render.com/u/settings#api-keys', where: 'Account Settings → API Keys', looks: 'rnd_ + about 28 characters',
    steps: ['Open Account Settings → API Keys.', 'Press Create API Key, name it 0n3 and press Create.', 'Copy it (shown once) and paste it below.'],
    scopes: ['An API key has full access to every workspace you belong to.'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 'rnd_[A-Za-z0-9]{20,}',
  },
  aws: {
    url: 'https://console.aws.amazon.com/iam/home#/users', where: 'IAM → Users → your user → Security credentials → Create access key', looks: 'AKIA + 16 capitals/digits, a 40-character secret, a region',
    steps: ['Open IAM → Users, create a user named 0n3 and attach the policy below.', 'Open the user → Security credentials → Create access key → Application running outside AWS → Next → Create access key.', 'Copy the Access key and the Secret access key (shown once).', 'Paste both with your region (e.g. us-east-1) below.'],
    scopes: ['AmazonS3FullAccess (or a policy allowing s3:ListAllMyBuckets, s3:ListBucket, s3:GetObject, s3:PutObject, s3:DeleteObject on your buckets)'],
    fields: { accessKeyId: { label: 'Access key ID' }, secretAccessKey: { label: 'Secret access key' }, region: { label: 'Region', where: 'top-right region menu, e.g. us-east-1' } },
    pattern: 'AKIA[0-9A-Z]{16}', patternField: 'accessKeyId',
  },
  azure: { door: 'azure', url: 'https://portal.azure.com/#view/Microsoft_Azure_Billing/SubscriptionsBladeV2', where: 'Sign in with Microsoft Azure', looks: 'signed in by Microsoft', steps: ['Press Sign in with Microsoft Azure.', 'Pick the account that owns the subscription and press Accept.', 'You come straight back here, connected; the first subscription is picked for you.'], scopes: ['https://management.azure.com/user_impersonation (asked for by the door); your user needs Contributor on the subscription'], fields: { access_token: { label: 'Access token (filled by Sign in with Azure)' }, subscriptionId: { label: 'Subscription ID', where: 'Azure portal → Subscriptions' } } },
  gcloud: {
    door: 'google', afterDoor: ['projectId'], doorSteps: ['Press the black Sign in with Google button. Pick the account that owns the Google Cloud project. Press Allow.', 'Open this window again. Find your project ID in the project picker at the top of console.cloud.google.com.', 'Paste the project ID below and press Connect. Done!'],
    url: 'https://console.cloud.google.com/iam-admin/serviceaccounts', where: 'Google Cloud console → IAM & Admin → Service Accounts', looks: 'an access token (ya29.…) + project id',
    steps: ['Open IAM & Admin → Service Accounts and press + Create service account; grant it the role below.', 'Open the account → Keys → Add key → Create new key → JSON (0n3 mints tokens from it when saved as the Google record).', 'Or run gcloud auth print-access-token for a one-hour token.', 'Paste the token and the project id below.'],
    scopes: ['Storage Object Admin (roles/storage.objectAdmin)', 'Storage Admin to list buckets'],
    fields: { accessToken: { label: 'Access token' }, projectId: { label: 'Project ID', where: 'console project picker' } },
    pattern: 'ya29\\.[A-Za-z0-9_-]{50,}', patternField: 'accessToken',
  },
  cloudconvert: {
    url: 'https://cloudconvert.com/dashboard/api/v2/keys', where: 'Dashboard → Authorization → API Keys', looks: 'a long JWT (eyJ…)',
    steps: ['Open Dashboard → Authorization → API Keys and press Create New API Key.', 'Name it 0n3 and tick the scopes below.', 'Press Create, copy the key (shown once) and paste it below.'],
    scopes: ['user.read', 'task.read', 'task.write', 'webhook.read', 'webhook.write'],
    fields: { apiKey: { label: 'API key' } },
  },
  mongodb: {
    retired: 'MongoDB turned off its Data API on 30 September 2025, so 0n3 cannot reach MongoDB this way anymore. Nothing to do here.',
    url: 'https://www.mongodb.com/docs/atlas/app-services/data-api/', where: 'Atlas → App Services → your app → HTTPS Endpoints → Data API', looks: 'an API key + the App ID', unverified: true,
    steps: ['MongoDB retired the Atlas Data API on 30 Sep 2025; existing apps no longer answer.', 'If your app still serves it, copy the App ID and create an API key under App Users → Authentication → API Keys.', 'Paste both below.'],
    scopes: ['Data API rules: read and write on the collections'],
    fields: { apiKey: { label: 'API key' }, appId: { label: 'App ID', where: 'App Services → your app (top-left)' } },
  },

  // ── AI ───────────────────────────────────────────────────────────────
  openai: {
    url: 'https://platform.openai.com/api-keys', where: 'Dashboard → API keys → Create new secret key', looks: 'sk-proj-… (older: sk-…)',
    steps: ['Open platform.openai.com/api-keys and press + Create new secret key.', 'Name it 0n3, pick the project, set Permissions (All, or Restricted with the rows below).', 'Press Create secret key, copy it (shown once) and paste it below.'],
    scopes: ['Model capabilities: Write (chat completions, images, embeddings, audio)', 'Or Permissions: All'],
    fields: { apiKey: { label: 'Secret key' } },
    pattern: 'sk-(proj-|svcacct-)?[A-Za-z0-9_-]{20,}',
  },
  groq: {
    url: 'https://console.groq.com/keys', where: 'Console → API Keys', looks: 'gsk_ + 52 characters',
    steps: ['Open console.groq.com/keys and press Create API Key.', 'Name it 0n3 and press Submit.', 'Copy it (shown once) and paste it below.'],
    scopes: ['Keys have full access to the organization; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 'gsk_[A-Za-z0-9]{52}',
  },
  mistral: {
    url: 'https://console.mistral.ai/api-keys', where: 'La Plateforme → API Keys', looks: '32 letters and digits',
    steps: ['Open console.mistral.ai/api-keys and press Create new key.', 'Name it 0n3, pick an expiry and press Create new key.', 'Copy it (shown once) and paste it below.'],
    scopes: ['Keys have full access to the workspace; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
  },
  cohere: {
    url: 'https://dashboard.cohere.com/api-keys', where: 'Dashboard → API Keys', looks: '40 letters and digits',
    steps: ['Open dashboard.cohere.com/api-keys.', 'Press New Production key (or use the Trial key), name it 0n3 and press Generate.', 'Copy it and paste it below.'],
    scopes: ['Keys have full access; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
  },
  replicate: {
    url: 'https://replicate.com/account/api-tokens', where: 'Account → API tokens', looks: 'r8_ + 37 characters',
    steps: ['Open replicate.com/account/api-tokens.', 'Name the token 0n3 and press Create token.', 'Copy it and paste it below.'],
    scopes: ['Tokens have full account access; nothing to tick.'],
    fields: { apiKey: { label: 'API token' } },
    pattern: 'r8_[A-Za-z0-9]{37}',
  },
  stability: {
    url: 'https://platform.stability.ai/account/keys', where: 'Account → API Keys', looks: 'sk- + 48 characters',
    steps: ['Open platform.stability.ai/account/keys.', 'Press Create API Key (or copy the default key).', 'Paste it below.'],
    scopes: ['Keys have full account access; nothing to tick.'],
    fields: { apiKey: { label: 'API key' } },
  },
  elevenlabs: {
    url: 'https://elevenlabs.io/app/developers/api-keys', where: 'Developers → API Keys', looks: 'sk_ + 48 hex',
    steps: ['Open elevenlabs.io/app/developers/api-keys and press Create API Key.', 'Name it 0n3 and set the permissions below (or leave Restrict key off).', 'Press Create, copy it (shown once) and paste it below.'],
    scopes: ['Text to Speech: Access', 'Voices: Read and Write', 'Models: Read', 'History: Read', 'User: Read'],
    fields: { apiKey: { label: 'API key' } },
    pattern: 'sk_[a-f0-9]{48}',
  },
  deepgram: {
    url: 'https://console.deepgram.com/', where: 'Console → your project → API Keys', looks: '40 hex characters',
    steps: ['Open the Deepgram console and pick your project, then API Keys (Settings → API Keys).', 'Press Create a New API Key, name it 0n3 and pick the role below.', 'Press Create Key, copy it (shown once) and paste it below.'],
    scopes: ['Role: Admin (Member can transcribe only; Admin is needed for keys, usage and balances)'],
    fields: { apiKey: { label: 'API key' } },
  },
  ollama: { url: 'https://ollama.com/download', where: 'Runs on your own machine', looks: 'http://localhost:11434 (no key)', steps: ['Install Ollama and pull a model (ollama pull llama3).', 'Leave it running; the base URL is http://localhost:11434.', 'Paste the URL below (a remote Ollama works the same).'], scopes: ['No key and no permissions.'], fields: { baseUrl: { label: 'Base URL' } } },

  // ── social + ads ─────────────────────────────────────────────────────
  twitter: {
    door: 'twitter', url: 'https://developer.x.com/en/portal/dashboard', where: 'Developer Portal → Projects & Apps → your app → Keys and tokens', looks: 'Bearer token: AAAAAAAAAAAAAAAAAAAAA… (about 110 characters)',
    steps: ['Open the Developer Portal and pick your app under Projects & Apps.', 'Open Keys and tokens and press Generate (or Regenerate) next to Bearer Token.', 'Copy it (shown once) and paste it below.'],
    scopes: ['Bearer token: read-only (search, users, timelines)', 'Posting, likes, DMs and lists need a user-context OAuth 2.0 token with tweet.write, like.write, dm.write, list.write, users.read, offline.access'],
    fields: { bearerToken: { label: 'Bearer token' } },
    pattern: 'AAAAAAAAAAAAAAAAAAAAA[A-Za-z0-9%]{40,}',
  },
  linkedin: {
    url: 'https://www.linkedin.com/developers/tools/oauth/token-generator', where: 'LinkedIn Developers → Tools → OAuth Token Generator', looks: 'AQ… (an OAuth access token, about 350 characters)',
    steps: ['Create an app at linkedin.com/developers/apps and add the products below (Share on LinkedIn, Sign In with OpenID Connect, Community Management).', 'Open the OAuth Token Generator, pick the app and tick the scopes below.', 'Press Request access token, sign in, and copy the token.', 'Paste it below. Tokens last 60 days.'],
    scopes: ['openid, profile, email', 'w_member_social', 'r_organization_social, w_organization_social, rw_organization_admin (Community Management)', 'r_ads, rw_ads, r_ads_reporting (Advertising API)'],
    fields: { access_token: { label: 'Access token' } },
  },
  linkedin_ads: {
    url: 'https://www.linkedin.com/developers/tools/oauth/token-generator', where: 'LinkedIn Developers → Tools → OAuth Token Generator', looks: 'an OAuth access token + an ad account id',
    steps: ['Create an app at linkedin.com/developers/apps and request the Advertising API product.', 'Open the OAuth Token Generator, pick the app, tick the scopes below and press Request access token.', 'Copy the token, and the ad account id from Campaign Manager (next to the account name).', 'Paste both below.'],
    scopes: ['r_ads', 'rw_ads', 'r_ads_reporting'],
    fields: { access_token: { label: 'Access token' }, adAccountId: { label: 'Ad account ID', where: 'Campaign Manager → account list' } },
  },
  instagram: {
    door: 'instagram', doorSteps: ['Your Instagram must be a Business or Creator account, linked to a Facebook Page.', 'Press the black Sign in with Instagram button. Facebook opens. Sign in.', 'Tick the Facebook Page that goes with your Instagram. Press Continue, then Save. You come right back, connected!'], url: 'https://developers.facebook.com/apps', where: 'Meta app → Instagram → API setup with Facebook login', looks: 'EAA… access token + Instagram user id',
    steps: META_STEPS('Instagram business account ID (GET /me/accounts?fields=instagram_business_account)'),
    scopes: ['instagram_basic', 'instagram_content_publish', 'instagram_manage_comments', 'instagram_manage_insights', 'pages_show_list', 'pages_read_engagement', 'business_management'],
    fields: { accessToken: { label: 'Access token' }, igUserId: { label: 'Instagram user id', where: 'GET /me/accounts?fields=instagram_business_account in Graph API Explorer' } },
    pattern: 'EAA[A-Za-z0-9]{100,}', patternField: 'accessToken',
  },
  facebook_ads: {
    url: 'https://business.facebook.com/settings/system-users', where: 'Business settings → Users → System users → Generate new token', looks: 'EAA… access token + act_… ad account id',
    steps: META_STEPS('ad account id (act_… in Ads Manager → account dropdown)'),
    scopes: ['ads_management', 'ads_read', 'business_management'],
    fields: { accessToken: { label: 'System user access token' }, adAccountId: { label: 'Ad account ID', where: 'Ads Manager → account dropdown (act_…)' } },
    pattern: 'EAA[A-Za-z0-9]{100,}', patternField: 'accessToken',
  },
  facebook_marketplace: {
    url: 'https://business.facebook.com/settings/system-users', where: 'Business settings → Users → System users → Generate new token (assign the product catalog to that system user first)', looks: 'EAA… access token + numeric catalog id',
    steps: META_STEPS('product catalog id (Commerce Manager → the catalog → Settings, or Business settings → Data sources → Catalogs)'),
    scopes: ['catalog_management', 'business_management'],
    fields: { accessToken: { label: 'System user access token' }, catalogId: { label: 'Product catalog ID', where: 'Commerce Manager → catalog → Settings' } },
    pattern: 'EAA[A-Za-z0-9]{100,}', patternField: 'accessToken',
    note: 'Marketplace listing needs Meta to approve the business as a Marketplace partner; until then the catalog calls work and listings are not distributed on Marketplace.',
  },
  instagram_ads: {
    url: 'https://business.facebook.com/settings/system-users', where: 'Business settings → Users → System users → Generate new token', looks: 'EAA… access token + act_… ad account id',
    steps: META_STEPS('ad account id (act_… in Ads Manager → account dropdown)'),
    scopes: ['ads_management', 'ads_read', 'instagram_basic', 'business_management'],
    fields: { accessToken: { label: 'System user access token' }, adAccountId: { label: 'Ad account ID', where: 'Ads Manager → account dropdown (act_…)' } },
    pattern: 'EAA[A-Za-z0-9]{100,}', patternField: 'accessToken',
  },
  tiktok: {
    door: 'tiktok', doorSteps: ['Press the black Sign in with TikTok for Business button.', 'Sign in to TikTok for Business. Tick your ad account. Press Confirm.', 'You come right back here, connected. 0n3 fills in your advertiser ID for you.'], url: 'https://business-api.tiktok.com/portal/apps', where: 'TikTok API for Business → My Apps', looks: 'a 40-character access token + advertiser id',
    steps: ['Register as a developer at business-api.tiktok.com and press Create an app; tick the permissions below.', 'Once approved, open the app’s Advertiser authorization URL, authorise your advertiser account and copy the auth_code.', 'Exchange it at /oauth2/access_token/ for a long-term access token and copy it with the advertiser id.', 'Paste both below.'],
    scopes: ['Ad Account Management', 'Ads Management', 'Reporting', 'Audience Management', 'TikTok Creator / video read (for list_videos)'],
    fields: { accessToken: { label: 'Access token' }, advertiserId: { label: 'Advertiser ID', where: 'TikTok Ads Manager → account menu' } },
  },
  tiktok_ads: {
    door: 'tiktok', doorSteps: ['Press the black Sign in with TikTok for Business button.', 'Sign in to TikTok for Business. Tick your ad account. Press Confirm.', 'You come right back here, connected. 0n3 fills in your advertiser ID for you.'], url: 'https://business-api.tiktok.com/portal/apps', where: 'TikTok API for Business → My Apps', looks: 'a 40-character access token + advertiser id',
    steps: ['Register as a developer at business-api.tiktok.com and press Create an app; tick the permissions below.', 'Once approved, open the app’s Advertiser authorization URL, authorise your advertiser account and copy the auth_code.', 'Exchange it at /oauth2/access_token/ for a long-term access token and copy it with the advertiser id.', 'Paste both below.'],
    scopes: ['Ad Account Management', 'Ads Management', 'Reporting', 'Audience Management'],
    fields: { accessToken: { label: 'Access token' }, advertiserId: { label: 'Advertiser ID', where: 'TikTok Ads Manager → account menu' } },
  },
  x_ads: {
    url: 'https://developer.x.com/en/portal/dashboard', where: 'Developer Portal → your app (with Ads API access)', looks: 'an OAuth access token + the ads account id',
    steps: ['Apply for Ads API access for your developer app (ads.x.com → Tools → Ads API).', 'Once approved, open the app’s Keys and tokens and generate the user Access Token for the ads account owner.', 'Copy it, and the ads account id from ads.x.com (in the URL).', 'Paste both below.'],
    scopes: ['Ads API access approved on the app', 'App permissions: Read and write'],
    fields: { access_token: { label: 'Access token' }, accountId: { label: 'Ads account ID', where: 'ads.x.com URL after /campaigns/' } },
    unverified: true,
  },
  google_ads: {
    door: 'google', url: 'https://ads.google.com/aw/apicenter', where: 'Google Ads (manager account) → Admin → API Center', looks: 'developer token (22 characters) + a customer id 123-456-7890',
    steps: ['Press Sign in with Google for the account that runs the ads.', 'In a Google Ads manager account open Admin → API Center and copy the Developer token (apply for Basic access if needed).', 'Copy the customer id from the top of Google Ads (digits only).', 'Paste the developer token and customer id below.'],
    scopes: ['https://www.googleapis.com/auth/adwords', 'Developer token access level: Basic or Standard'],
    fields: { access_token: { label: 'Access token (filled by Sign in with Google)' }, developerToken: { label: 'Developer token', where: 'manager account → Admin → API Center' }, customerId: { label: 'Customer ID', where: 'top of Google Ads, digits only' } },
    afterDoor: ['developerToken', 'customerId'],
    doorSteps: ['Press the black Sign in with Google button. Pick the account that runs the ads. Press Allow.', 'Open this window again. In a Google Ads manager account, open Admin → API Center. Copy the Developer token.', 'Copy your Customer ID from the top of Google Ads (only the numbers). Paste both below and press Connect.'],
    note: 'Google Ads needs two things: your Google sign-in AND a developer token from a manager account.',
  },
  pinterest: {
    url: 'https://developers.pinterest.com/apps/', where: 'Pinterest Developers → My apps → your app → Generate token', looks: 'pina_ + about 100 characters',
    steps: ['Open developers.pinterest.com/apps and press Connect app (or open yours).', 'Under Generate access token tick the scopes below and press Generate token.', 'Copy it and paste it below.'],
    scopes: ['boards:read, boards:write', 'pins:read, pins:write', 'user_accounts:read'],
    fields: { accessToken: { label: 'Access token' } },
    pattern: 'pina_[A-Za-z0-9]{40,}',
  },
  reddit: {
    door: 'reddit', url: 'https://www.reddit.com/prefs/apps', where: 'Preferences → Apps → create another app (script)', looks: 'client id (about 22 characters) + secret + an OAuth token',
    steps: ['Open reddit.com/prefs/apps and press create another app…; pick script, redirect http://localhost:8080.', 'Copy the client id (under the app name) and the secret.', 'Get a token: POST https://www.reddit.com/api/v1/access_token with grant_type=password and your username/password (Basic client_id:secret).', 'Paste the token, the client id, secret and username below.'],
    scopes: ['identity, read, submit, edit, history, mysubreddits, privatemessages, vote'],
    fields: { accessToken: { label: 'Access token' }, refreshToken: { label: 'Refresh token (optional)' }, clientId: { label: 'Client id', where: 'under the app name at reddit.com/prefs/apps' }, clientSecret: { label: 'Client secret' }, username: { label: 'Reddit username' } },
  },
  youtube: { door: 'google', url: 'https://console.cloud.google.com/apis/credentials', where: 'Sign in with Google, or Google Cloud → APIs & Services → Credentials', looks: 'an API key AIza… (search and public data)', steps: ['Press Sign in with Google; or', 'open Google Cloud → APIs & Services → Credentials, press + Create credentials → API key, and enable YouTube Data API v3.', 'Paste the API key below for public data.'], scopes: ['https://www.googleapis.com/auth/youtube.readonly (for your own channel)', 'YouTube Data API v3 enabled on the project'], fields: { accessToken: { label: 'Access token (filled by Sign in with Google)' }, apiKey: { label: 'API key', where: 'Google Cloud → APIs & Services → Credentials' } }, pattern: 'AIza[0-9A-Za-z_-]{35}', patternField: 'apiKey' },
  twitch: {
    door: 'twitch', url: 'https://dev.twitch.tv/console/apps', where: 'Twitch Developers → Console → Applications', looks: 'a 30-character access token + a 30-character client id',
    steps: ['Open dev.twitch.tv/console/apps and press Register Your Application (redirect http://localhost).', 'Press Manage, copy the Client ID and press New Secret.', 'Get an app token: POST https://id.twitch.tv/oauth2/token with client_credentials, then copy access_token.', 'Paste the token and client id below.'],
    scopes: ['App token covers streams, users, channels, clips and games', 'create_clip needs a user token with clips:edit'],
    fields: { accessToken: { label: 'Access token' }, clientId: { label: 'Client ID' } },
  },

  // ── Google (the door) ────────────────────────────────────────────────
  google_sheets: { door: 'google', url: 'https://myaccount.google.com/permissions', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('owns the sheets'), scopes: ['https://www.googleapis.com/auth/spreadsheets'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  google_drive: { door: 'google', url: 'https://myaccount.google.com/permissions', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('owns the Drive'), scopes: ['https://www.googleapis.com/auth/drive.file (files 0n3 made or you opened with it)'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  google_calendar: { door: 'google', url: 'https://myaccount.google.com/permissions', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('owns the calendar'), scopes: ['https://www.googleapis.com/auth/calendar'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  search_console: { door: 'google', url: 'https://search.google.com/search-console', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('owns the Search Console properties'), scopes: ['https://www.googleapis.com/auth/webmasters'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  site_verification: { door: 'google', url: 'https://search.google.com/search-console', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('will own the verified sites'), scopes: ['https://www.googleapis.com/auth/siteverification'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  google_analytics_admin: { door: 'google', url: 'https://analytics.google.com/analytics/web/', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('has Editor on the GA4 account'), scopes: ['https://www.googleapis.com/auth/analytics.edit'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  google_analytics: { door: 'google', url: 'https://analytics.google.com/analytics/web/', where: 'Sign in with Google', looks: 'signed in by Google', steps: GOOGLE_STEPS('can read the GA4 property'), scopes: ['https://www.googleapis.com/auth/analytics.readonly'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } } },
  google_apps_script: { door: 'google', url: 'https://script.google.com/home/usersettings', where: 'Apps Script → Settings → Google Apps Script API', looks: 'signed in by Google', steps: ['Open script.google.com/home/usersettings and turn Google Apps Script API On.', 'Press Sign in with Google with the account that owns the scripts.', 'You come straight back here, connected.'], scopes: ['https://www.googleapis.com/auth/script.projects', 'https://www.googleapis.com/auth/script.deployments'], fields: { access_token: { label: 'Access token (filled by Sign in with Google)' } }, doorSteps: ['Open script.google.com/home/usersettings. Turn Google Apps Script API On.', 'Come back here. Press the black Sign in with Google button below.', 'Pick the Google account that owns the scripts. Press Allow. You come right back, connected!'], note: 'If the Apps Script API is Off, Google says no (403) even after you sign in. Turn it On first.' },

  // ── storage ──────────────────────────────────────────────────────────
  dropbox: {
    door: 'dropbox', url: 'https://www.dropbox.com/developers/apps', where: 'App Console → your app → Settings → Generated access token', looks: 'sl. + about 140 characters',
    steps: ['Open the App Console and press Create app (Scoped access, Full Dropbox or App folder).', 'Open Permissions, tick the scopes below and press Submit.', 'Back on Settings press Generate under Generated access token and copy it.', 'Paste it below.'],
    scopes: ['files.metadata.read, files.metadata.write', 'files.content.read, files.content.write', 'sharing.read, sharing.write'],
    fields: { access_token: { label: 'Access token' } },
    pattern: 'sl\\.[A-Za-z0-9._-]{100,}',
    note: 'Sign in with Dropbox keeps you connected. A generated token lasts about four hours.',
  },

  // ── 0n + first-party products ────────────────────────────────────────
  cro9: {
    url: 'https://www.cro9.com/api-keys', where: 'CRO9 dashboard → API Keys', looks: 'cro9_sk_ + 32 characters',
    steps: ['Sign in at cro9.com and open API Keys.', 'Press Create key, name it 0n3 and copy it (shown once; CRO9 keeps only a SHA-256 of it).', 'Paste it below.'],
    scopes: ['One key covers sites, scores, briefs, scans and AI visibility; 100 free calls a month.'],
    fields: { apiKey: { label: 'CRO9 API key' } },
    pattern: 'cro9_sk_[A-Za-z0-9_-]{32}',
  },
  sxo: {
    url: 'https://sxowebsite.com/', where: 'sxowebsite.com admin → CRO9 keys (per site)', looks: 'cro9_live_…', unverified: true,
    steps: ['Per-site keys are minted by a sxowebsite.com admin (POST /api/v1/cro9/keys); there is no self-serve page yet.', 'Ask the admin for the site’s cro9_live_ key, or use the one CRO9 showed when the site was linked.', 'Paste it below.'],
    scopes: ['The key is scoped to one site: metrics, pages and A/B results.'],
    fields: { apiKey: { label: 'Site key (cro9_live_…)' } },
    pattern: 'cro9_live_[A-Za-z0-9_-]{16,}',
  },
  cardflow: {
    url: 'https://cardflow.mykidcard.com/', where: 'CardFlow owner settings', looks: 'the owner’s internal API secret', unverified: true,
    steps: ['CardFlow’s /api/v1 accepts the owner’s internal secret today; per-family keys are not built yet.', 'The owner copies CARDFLOW_INTERNAL_SECRET from the CardFlow deployment’s environment.', 'Paste it below.'],
    scopes: ['Owner access: cards, scans, orders, packing, shipping and thank-yous.'],
    fields: { apiKey: { label: 'CardFlow API key' } },
  },
  ucp: { ...ON_TOKEN },
  marketplace: { ...ON_TOKEN },
  course_builder: { ...ON_TOKEN },
  lead_magnet: { ...ON_TOKEN },
  automation_builder: { ...ON_TOKEN },
  saas_factory: { ...ON_TOKEN },
  app_builder: { ...ON_TOKEN },
  website_builder: { ...ON_TOKEN },
  agentic_automation: { ...ON_TOKEN },
  detect_and_refine: {
    hide: 'owner',
    url: 'https://supabase.com/dashboard/project/_/settings/api-keys', where: '0nCore Supabase project → Project Settings → API Keys', looks: 'sb_secret_… (legacy: service_role eyJ…)',
    steps: ['Owner only: open the 0nCore Supabase project → Project Settings → API Keys.', 'Copy a Secret key (or the legacy service_role key).', 'Paste it below. It bypasses Row Level Security — never share it.'],
    scopes: ['Service role: full database access'],
    fields: { oncore_supabase_service_key: { label: '0nCore Supabase secret key' } },
    pattern: 'sb_secret_[A-Za-z0-9_-]{20,}',
  },
  rocket_convert: {
    hide: 'owner',
    url: 'https://supabase.com/dashboard/project/_/settings/api-keys', where: '0nCore Supabase project → Project Settings → API Keys, plus console.groq.com/keys', looks: 'sb_secret_… + gsk_…',
    steps: ['Owner only: open the 0nCore Supabase project → Project Settings → API Keys and copy a Secret key.', 'Open console.groq.com/keys, press Create API Key and copy it.', 'Paste both below.'],
    scopes: ['Service role: full database access', 'Groq: any key'],
    fields: { oncore_supabase_service_key: { label: '0nCore Supabase secret key' }, groq_api_key: { label: 'Groq API key', where: 'console.groq.com/keys' } },
    pattern: 'sb_secret_[A-Za-z0-9_-]{20,}', patternField: 'oncore_supabase_service_key',
  },
};

// THE AIs (2026-11-23): every AI provider is a catalog service now (catalog-ai.js), so its guide is an ordinary GUIDES
// entry from connect-guides-ai.js — including the five that used to live apart here as My-AI-only guides (anthropic,
// gemini, cerebras, openrouter, nvidia). One guide per key; the My AI page reads the same one through guideFor().
for (const [k, g] of Object.entries(AI_PROVIDER_GUIDES)) {
  if (GUIDES[k]) throw new Error(`connect-guides: ${k} is guided twice (GUIDES and connect-guides-ai.js)`);
  GUIDES[k] = g;
}
// Kept so older imports keep working; empty because every AI guide is in GUIDES.
export const AI_GUIDES = {};

// THE PLAIN WALKTHROUGHS (2026-11-06, Mike: "every step understood by a 4th-5th grader … walk-throughs are key").
// connect-guides-plain.js holds what people READ for every app: `what` (what connecting it lets 0n3 do), `steps`,
// `note`, `scopesIntro`. They were written FROM the click paths above and must keep every fact in them; the original
// provider-terms steps stay on each guide as `facts`, the record the plain words answer to. url, where, looks, scopes,
// fields, pattern and door are untouched by the overlay.
for (const [k, v] of Object.entries(PLAIN)) {
  const g = GUIDES[k]; if (!g || !Array.isArray(v.steps) || !v.steps.length) continue;
  GUIDES[k] = { ...g, facts: g.steps || [], steps: v.steps, what: v.what || g.what || null, note: v.note === undefined ? g.note : (v.note || g.note || null), scopesIntro: v.scopesIntro || null };
}

export const guideFor = (key) => GUIDES[key] || AI_GUIDES[key] || null;

/**
 * The public guide map for GET /api/connect/guides and the Chrome extension: every guided service with its
 * catalog name and credential fields. `catalog` is SERVICE_CATALOG (passed in so the web bundle never imports it).
 */
export function publicGuides(catalog) {
  const out = {};
  for (const [key, g] of Object.entries(GUIDES)) {
    const svc = catalog[key];
    if (!svc) continue;
    out[key] = {
      name: svc.name, authType: svc.authType, credentialKeys: svc.credentialKeys || [],
      url: g.url || null, where: g.where || null, looks: g.looks || null, steps: g.steps || [], scopes: g.scopes || [],
      fields: g.fields || {}, pattern: g.pattern || null, patternField: g.pattern ? (g.patternField || (svc.credentialKeys || [])[0] || null) : null,
      door: g.door || null, note: g.note || null, unverified: !!g.unverified, what: g.what || null, scopesIntro: g.scopesIntro || null,
      doorSteps: g.doorSteps || null, afterDoor: g.afterDoor || null, urlFor: g.urlFor || null, retired: g.retired || null, warn: g.warn || null, hide: g.hide || null,
    };
  }
  return out;
}
