/**
 * PLANS + BILLING (2026-10-29). Mike: "a small monthly fee for the service. 3 plans. Simple pricing. Feature locked upgrades."
 *
 * ONE place says what each plan includes; every gate reads `limitsFor(plan)`. Free stays as the sign-up tier — Sign in with
 * 0n3 must never require paying. Stripe runs on the PLATFORM account: its key is read from the platform owner's own 0n3
 * vault (ON3_PLATFORM_ACCOUNT), so no Stripe secret is copied into another place. Prices are found by lookup_key and created
 * once if missing. The webhook sets the plan on the shared profile (plan, plan_status, plan_renews_at, stripe_customer_id)
 * and moves the managed CRM record to the plan's CRM tier.
 */
import { createHmac, timingSafeEqual } from 'node:crypto';
import { yhlStripeEvent, yhlEvent } from './yhl-crm.js';

export const PLANS = {
  free:     { key: 'free',     name: 'Free',     price: 0,  crm: 'base',      blurb: 'Sign in everywhere with one account, and try the builder.' },
  starter:  { key: 'starter',  name: 'Starter',  price: 9,  crm: 'messaging', blurb: 'Your apps connected, a workspace live, email and texting from the CRM.' },
  pro:      { key: 'pro',      name: 'Pro',      price: 29, crm: 'full',      blurb: 'The full CRM, your own domains, the desk agent and developer apps.' },
  command:  { key: 'command',  name: 'Command',  price: 39, crm: 'full',      blurb: 'Pro plus 0nTask Command: team seats, flows and the AI teammate, one bill for both.' },
  business: { key: 'business', name: 'Business', price: 79, crm: 'full',      blurb: 'Room for a whole business: more of everything.' },
};
export const PAID = ['starter', 'pro', 'command', 'business'];
const U = Infinity;
const LIMITS = {
  free:     { workspaces: 1,  sequences: 3,   connections: 5,  runsPerMonth: 100,    domains: 0,  devApps: 0,  desk: false, whiteLabel: false, share: false },
  starter:  { workspaces: 3,  sequences: 15,  connections: 25, runsPerMonth: 2000,   domains: 1,  devApps: 1,  desk: true,  whiteLabel: true,  share: true },
  pro:      { workspaces: 10, sequences: 100, connections: U,  runsPerMonth: 20000,  domains: 5,  devApps: 5,  desk: true,  whiteLabel: true,  share: true },
  command:  { workspaces: 15, sequences: 250, connections: U,  runsPerMonth: 40000,  domains: 10, devApps: 10, desk: true,  whiteLabel: true,  share: true, seats: 3 },
  business: { workspaces: U,  sequences: U,   connections: U,  runsPerMonth: 100000, domains: 25, devApps: 25, desk: true,  whiteLabel: true,  share: true, seats: 3 },
};
/** Plans written before this existed (Mike's penthouse, enterprise/founder/operator grants) map to the nearest plan. */
export function planOf(raw) {
  const p = String(raw || 'free').toLowerCase();
  if (PLANS[p]) return p;
  if (['penthouse', 'enterprise', 'founder', 'agency'].includes(p)) return 'business';
  if (['operator', 'growth'].includes(p)) return 'pro';
  return 'free';
}
/**
 * ADD-ONS (2026-11-23, Mike: "add some add-ons that are only available with specific plans"). One list, read by the
 * checkout summary (/api/billing/plans → addons) and by checkout() (each chosen add-on is one more line on the SAME
 * subscription, so one invoice, one cancel). `plans` = the plans that may buy it; `live: false` keeps it off the page
 * until Mike sets the name and price. Stripe product + price are created on first sale (lookup_key 0n3_addon_<key>_v<price>).
 * Every price here is Mike's to set: never invent one.
 */
export const ADDONS = {
  // example shape (not live):
  // desk_seat: { key: 'desk_seat', name: 'Extra Desk Agent computer', price: 0, blurb: 'Run Desk Agent on one more computer.', plans: ['pro', 'command', 'business'], live: false },
};
export const addonList = (plan) => Object.values(ADDONS).filter((a) => a.live && a.price > 0 && (!plan || a.plans.includes(plan)))
  .map(({ key, name, price, blurb, plans }) => ({ key, name, price, blurb, plans }));

/** Metered usage (usage.js): one ACTION = one unit. Each paid plan's runsPerMonth is its included allowance; past it,
 *  unitCents each, billed by Stripe from the meter on the same subscription. Free has no card, so its allowance is a cap. */
export const USAGE = { meterEvent: '0n3_action', unitCents: 10 };
/** THE PRICE OF ONE ACTION FOR ONE ACCOUNT, in cents (Mike, 2026-11-14: "10 cents PER ACTION across the board"; VIP accounts
 *  pay nothing; test accounts pay 1 cent). One column on the shared profile, read by 0n3 AND 0nCore:
 *  is_vip → 0 · profiles.action_rate_cents when set · otherwise the standard 10. The Stripe meter counts CENTS, so one price
 *  ($0.01 per unit) bills every rate exactly. */
export const rateCents = (p) => (p && p.is_vip ? 0 : (p && p.action_rate_cents != null ? Math.max(0, Number(p.action_rate_cents) || 0) : USAGE.unitCents));
export const limitsFor = (raw) => ({ plan: planOf(raw), ...LIMITS[planOf(raw)] });
const nextUp = (p) => PAID.find((x) => PLANS[x].price > PLANS[planOf(p)].price) || null;
/** The refusal every gate returns: what is used, the limit, and the plan that lifts it. HTTP 402. */
export function overLimit(raw, what, used, limit) {
  const up = nextUp(raw);
  return { error: 'plan_limit', what, used, limit, plan: planOf(raw), upgrade: up ? { plan: up, name: PLANS[up].name, price: PLANS[up].price, url: '/billing' } : null,
    message: `Your ${PLANS[planOf(raw)].name} plan includes ${limit === 0 ? 'no' : limit} ${limit === 1 ? String(what).replace(/s( this month)?$/, '$1').replace(/apps$/, 'app') : what}.${up ? ` ${PLANS[up].name} ($${PLANS[up].price}/month) ${limit === 0 ? 'turns it on' : 'raises it'}.` : ''}` };
}
/** The public price list: what the pricing page and the phone show. */
export const priceList = () => ['free', ...PAID].map((k) => {
  const L = LIMITS[k]; const n = (v) => (v === U ? 'Unlimited' : v.toLocaleString('en-US'));
  return { ...PLANS[k], features: [
    `${n(L.workspaces)} workspace${L.workspaces === 1 ? '' : 's'}`, `${n(L.sequences)} sequences`, `${n(L.connections)} connected apps`, `${n(L.runsPerMonth)} actions a month included${k === 'free' ? '' : `, then $${(USAGE.unitCents / 100).toFixed(2)} each`}`,
    k === 'free' ? 'CRM: contacts, forms, surveys' : k === 'starter' ? 'CRM: + email, texting, conversations' : 'CRM: everything — voicemail drops, calendars, pipelines, invoices',
    ...(L.domains ? [`${n(L.domains)} custom domain${L.domains === 1 ? '' : 's'}`] : []), ...(L.desk ? ['Desk Agent: your AI runs jobs on your computer and in your Chrome'] : []),
    ...(L.seats ? [`0nTask Command with ${L.seats} team seats`] : []),
    ...(L.devApps ? [`${n(L.devApps)} developer app${L.devApps === 1 ? '' : 's'} (Sign in with 0n3)`] : []), ...(L.share ? ['Share your apps: anyone with the link can run them'] : ['Apps run for you only']), ...(L.whiteLabel ? ['White-label apps and pages (no 0n3 badge)'] : []),
    'Sign in with 0n3 everywhere',
  ] };
});

// ── Stripe on the platform account ────────────────────────────────────────────────────────────────────────────────────
export function createBilling({ store, rest, env = process.env, fetchImpl = fetch, base = 'https://0n3.app' }) {
  const platform = env.ON3_PLATFORM_ACCOUNT || '';
  let key = null;
  const stripeKey = async () => {
    if (key) return key;
    if (env.STRIPE_SECRET_KEY) return (key = env.STRIPE_SECRET_KEY);
    if (!platform) throw new Error('Billing is not configured: ON3_PLATFORM_ACCOUNT is not set.');
    const recs = (await store.list(platform)).filter((r) => r.service === 'stripe');
    for (const r of recs) { const e = await store.get(platform, 'stripe', r.$0n?.name); const k = e?.auth?.credentials?.apiKey || e?.auth?.credentials?.secretKey || e?.auth?.credentials?.secret_key; if (k && /^(sk|rk)_live_/.test(k)) return (key = k); }
    throw new Error('Billing is not configured: no live Stripe key in the platform vault.');
  };
  const form = (o, p = '') => Object.entries(o).flatMap(([k, v]) => { const kk = p ? `${p}[${k}]` : k; if (v === undefined || v === null) return []; if (typeof v === 'object') return form(v, kk); return [[kk, String(v)]]; });
  const stripe = async (path, params = null, method = params ? 'POST' : 'GET') => {
    const r = await fetchImpl(`https://api.stripe.com/v1${path}`, { method, headers: { Authorization: `Bearer ${await stripeKey()}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: params ? new URLSearchParams(form(params)).toString() : undefined });
    const j = await r.json(); if (!r.ok) throw new Error(`Stripe: ${j.error?.message || r.status}`); return j;
  };
  const prices = new Map();
  async function priceFor(plan) {
    if (prices.has(plan)) return prices.get(plan);
    const lk = `0n3_${plan}_monthly`;
    const found = await stripe(`/prices?active=true&lookup_keys[]=${lk}`);
    let id = found.data?.[0]?.id;
    if (!id) {
      const prod = await stripe('/products', { name: `0n3 ${PLANS[plan].name}`, description: PLANS[plan].blurb, metadata: { app: '0n3', plan } });
      id = (await stripe('/prices', { product: prod.id, currency: 'usd', unit_amount: PLANS[plan].price * 100, recurring: { interval: 'month' }, lookup_key: lk, metadata: { app: '0n3', plan } })).id;
    }
    prices.set(plan, id); return id;
  }
  async function addonPriceFor(key) {
    const ad = ADDONS[key]; const k = `addon:${key}`; if (prices.has(k)) return prices.get(k);
    const lk = `0n3_addon_${key}_v${ad.price}`;
    let id = (await stripe(`/prices?active=true&lookup_keys[]=${lk}`)).data?.[0]?.id;
    if (!id) {
      const prod = await stripe('/products', { name: `0n3 add-on: ${ad.name}`, description: ad.blurb, metadata: { app: '0n3', addon: key } });
      id = (await stripe('/prices', { product: prod.id, currency: 'usd', unit_amount: Math.round(ad.price * 100), recurring: { interval: 'month' }, lookup_key: lk, metadata: { app: '0n3', addon: key } })).id;
    }
    prices.set(k, id); return id;
  }
  /** The Stripe meter every paid plan's usage price reads (event `0n3_action`, summed per customer). Created once. */
  let meter = null;
  async function meterId() {
    if (meter) return meter;
    const list = await stripe('/billing/meters?limit=100&status=active');
    const found = (list.data || []).find((m) => m.event_name === USAGE.meterEvent);
    meter = found?.id || (await stripe('/billing/meters', { display_name: '0n3 actions', event_name: USAGE.meterEvent, 'default_aggregation[formula]': 'sum',
      'customer_mapping[event_payload_key]': 'stripe_customer_id', 'customer_mapping[type]': 'by_id', 'value_settings[event_payload_key]': 'value' })).id;
    return meter;
  }
  /** The plan's usage price, metered in CENTS: its allowance (included actions × the standard rate) at $0, then $0.01 per cent.
   *  lookup_key 0n3_<plan>_usage_cents. (The older 0n3_<plan>_usage prices counted actions at $0.01; nobody was on them.) */
  async function usagePriceFor(plan) {
    const k = `usage:${plan}`; if (prices.has(k)) return prices.get(k);
    const lk = `0n3_${plan}_usage_cents`;
    let id = (await stripe(`/prices?active=true&lookup_keys[]=${lk}`)).data?.[0]?.id;
    if (!id) {
      const m = await meterId(); const free = LIMITS[plan].runsPerMonth;
      const prod = await stripe('/products', { name: `0n3 ${PLANS[plan].name} — actions`, description: `${free.toLocaleString('en-US')} actions a month included, then $${(USAGE.unitCents / 100).toFixed(2)} each.`, metadata: { app: '0n3', plan, kind: 'usage' } });
      id = (await stripe('/prices', { product: prod.id, currency: 'usd', 'recurring[interval]': 'month', 'recurring[usage_type]': 'metered', 'recurring[meter]': m,
        billing_scheme: 'tiered', tiers_mode: 'graduated', 'tiers[0][up_to]': free * USAGE.unitCents, 'tiers[0][unit_amount]': 0, 'tiers[1][up_to]': 'inf', 'tiers[1][unit_amount]': 1,
        lookup_key: lk, metadata: { app: '0n3', plan, kind: 'usage' } })).id;
    }
    prices.set(k, id); return id;
  }
  const profile = async (id) => (await rest.select('profiles', { id }, 'id, email, plan, plan_status, plan_renews_at, stripe_customer_id, is_vip, action_rate_cents'))[0] || null;

  /** flow 'checkout' = the public /checkout page (returns to /checkout/done, never the dashboard); default = /billing in HQ. */
  async function checkout(account, plan, { flow, addons = [] } = {}) {
    if (!PAID.includes(plan)) throw new Error('Choose Starter, Pro, Command or Business.');
    const wanted = [...new Set((Array.isArray(addons) ? addons : []).map(String))];
    for (const k of wanted) { const ad = ADDONS[k]; if (!ad || !ad.live || !(ad.price > 0)) throw new Error(`Unknown add-on: ${k}`); if (!ad.plans.includes(plan)) throw new Error(`${ad.name} comes with ${ad.plans.map((x) => PLANS[x].name).join(', ')} only.`); }
    const p = await profile(account.accountId);
    const params = { mode: 'subscription', 'line_items[0][price]': await priceFor(plan), 'line_items[0][quantity]': 1, 'line_items[1][price]': await usagePriceFor(plan), ...Object.fromEntries((await Promise.all(wanted.map(addonPriceFor))).flatMap((id, i) => [[`line_items[${i + 2}][price]`, id], [`line_items[${i + 2}][quantity]`, 1]])), success_url: flow === 'checkout' ? `${base}/checkout/done?session_id={CHECKOUT_SESSION_ID}` : `${base}/billing?ok=1&session_id={CHECKOUT_SESSION_ID}`, cancel_url: flow === 'checkout' ? `${base}/checkout?plan=${plan}&canceled=1` : `${base}/billing`,
      client_reference_id: account.accountId, allow_promotion_codes: true, metadata: { app: '0n3', plan, account: account.accountId, addons: wanted.join(',') }, subscription_data: { metadata: { app: '0n3', plan, account: account.accountId, addons: wanted.join(',') } } };
    if (p?.stripe_customer_id) params.customer = p.stripe_customer_id; else params.customer_email = (p?.email || account.email || '').trim().toLowerCase();
    const s = await stripe('/checkout/sessions', params);
    return { url: s.url };
  }
  async function portal(account) {
    const p = await profile(account.accountId);
    if (!p?.stripe_customer_id) throw new Error('No subscription yet — choose a plan first.');
    return { url: (await stripe('/billing_portal/sessions', { customer: p.stripe_customer_id, return_url: `${base}/billing` })).url };
  }
  /** Stripe's signature scheme: t=<ts>,v1=<hmac-sha256(secret, `${t}.${raw}`)>, within 5 minutes. */
  function verify(raw, header) {
    const secret = env.STRIPE_BILLING_WEBHOOK_SECRET || ''; if (!secret) return false;
    const parts = Object.fromEntries(String(header || '').split(',').map((x) => x.split('=')));
    const t = Number(parts.t); if (!t || Math.abs(Date.now() / 1000 - t) > 300) return false;
    const want = Buffer.from(createHmac('sha256', secret).update(`${t}.${raw}`).digest('hex'));
    return String(header).split(',').filter((x) => x.startsWith('v1=')).some((x) => { const got = Buffer.from(x.slice(3)); return got.length === want.length && timingSafeEqual(got, want); });
  }
  async function setPlan(accountId, plan, { status = 'active', renews = null, customer = null } = {}) {
    const patch = { plan, plan_status: status, ...(renews ? { plan_renews_at: new Date(renews * 1000).toISOString() } : {}), ...(customer ? { stripe_customer_id: customer } : {}) };
    await rest.update('profiles', { id: accountId }, patch);
    // The managed CRM follows the plan: base → messaging → full.
    try {
      for (const r of (await store.list(accountId)).filter((x) => x.service === 'crm' && x.meta?.via === '0ncore-bridge')) {
        const e = await store.get(accountId, 'crm', r.$0n?.name); if (!e) continue;
        e.meta = { ...(e.meta || {}), tier: PLANS[plan]?.crm || 'base' }; await store.put(accountId, e, { actor: 'billing' });
      }
      await rest.update('profiles', { id: accountId }, { crm_tier: PLANS[plan]?.crm || 'base' }).catch(() => {});
    } catch (e) { console.error('[0n3 billing] crm tier:', e.message); }
    await syncOntask(accountId, plan, { status, renews, customer }).catch((e) => console.error('[0n3 billing] 0nTask entitlement:', e.message));
  }
  /**
   * ONE BILL FOR BOTH: Command and Business on 0n3 carry 0nTask Command. 0nTask reads its tier from the shared
   * ontask_entitlements row by EMAIL (Rule 0-SSO), so 0n3 writes that row. It never touches a row another source wrote
   * (a 0ntask.com purchase, a Founders or beta grant) — it only creates or updates rows with source '0n3'.
   */
  async function syncOntask(accountId, plan, { status = 'active', renews = null, customer = null } = {}) {
    const p = await profile(accountId); const email = String(p?.email || '').trim().toLowerCase(); if (!email) return;
    const [cur] = await rest.select('ontask_entitlements', { email }, 'email, source, tier, status').catch(() => []);
    if (cur && cur.source !== '0n3') return;
    const carries = plan === 'command' || plan === 'business';
    if (!carries && !cur) return;
    const live = carries && ['active', 'trialing', 'past_due'].includes(status);
    await rest.upsert('ontask_entitlements', { email, tier: live ? 'command' : 'solo', status: live ? status : 'canceled', seats: live ? (LIMITS[plan].seats || 3) : 1, source: '0n3',
      ...(customer ? { stripe_customer: customer } : {}), ...(renews ? { period_end: new Date(renews * 1000).toISOString() } : {}), updated_at: new Date().toISOString() }, 'email');
  }
  async function webhook(raw, sig) {
    if (!verify(raw, sig)) return { status: 400, body: { error: 'bad signature' } };
    const ev = JSON.parse(raw); const o = ev.data?.object || {};
    const meta = o.metadata || {};
    // YHL Positioning Trainer purchases ride this endpoint (RocketOpp's webhook slots are full): copy to the Kid-Cards CRM.
    const y = yhlStripeEvent(ev);
    if (y) {
      if (!y.email && y.customer) { try { y.email = String((await stripe(`/customers/${y.customer}`, null, 'GET')).email || '').trim().toLowerCase() || null; } catch (e) { console.error('[0n3 billing] yhl customer:', e.message); } }
      const r = await yhlEvent(y.kind, y);
      return { status: 200, body: { ok: true, yhl: y.kind, crm: r.ok } };
    }
    if (meta.app === 'yhl-positioning') return { status: 200, body: { ignored: true } };
    if (meta.app !== '0n3' && ev.type !== 'checkout.session.completed') return { status: 200, body: { ignored: true } };
    if (ev.type === 'checkout.session.completed' && o.metadata?.app === '0n3') {
      const acct = o.client_reference_id || meta.account; if (acct && PAID.includes(meta.plan)) await setPlan(acct, meta.plan, { customer: o.customer });
    } else if (ev.type === 'customer.subscription.updated' || ev.type === 'customer.subscription.created') {
      const live = ['active', 'trialing', 'past_due'].includes(o.status);
      if (meta.account) await setPlan(meta.account, live && PAID.includes(meta.plan) ? meta.plan : 'free', { status: o.status, renews: o.current_period_end || o.items?.data?.[0]?.current_period_end, customer: o.customer });
    } else if (ev.type === 'customer.subscription.deleted') {
      if (meta.account) await setPlan(meta.account, 'free', { status: 'canceled', customer: o.customer });
    }
    return { status: 200, body: { ok: true } };
  }
  async function me(accountId) {
    const p = await profile(accountId); const L = limitsFor(p?.plan);
    return { plan: L.plan, name: PLANS[L.plan].name, status: p?.plan_status || (L.plan === 'free' ? null : 'active'), renews_at: p?.plan_renews_at || null, limits: { ...L, connections: L.connections === U ? null : L.connections, workspaces: L.workspaces === U ? null : L.workspaces, sequences: L.sequences === U ? null : L.sequences }, manage: !!p?.stripe_customer_id, usage: await usageOf(accountId, L, p) };
  }
  /** This month's actions against the allowance, and what the overage comes to so far (Stripe bills it; this is the preview). */
  async function usageOf(accountId, L, p = null) {
    const month = new Date().toISOString().slice(0, 7);
    const [r] = await rest.select('usage_counts', { account_id: accountId, month }, 'units, reported').catch(() => []);
    const units = Number(r?.units || 0); const included = L.runsPerMonth; const over = Math.max(0, units - included);
    const rate = rateCents(p);
    return { month, units, included, over, unit_cents: rate, metered: L.plan !== 'free', over_cents: L.plan === 'free' ? 0 : over * rate };
  }
  /** The buyer is back from Checkout: read the session from Stripe (never trust the browser) and set the plan now. */
  async function confirm(account, sessionId) {
    if (!/^cs_(live|test)_[A-Za-z0-9]+$/.test(String(sessionId || ''))) throw new Error('No checkout session.');
    const cs = await stripe(`/checkout/sessions/${sessionId}?expand[]=subscription`);
    if (cs.client_reference_id !== account.accountId) throw new Error('That checkout belongs to another account.');
    if (cs.status !== 'complete' || !['paid', 'no_payment_required'].includes(cs.payment_status)) return { plan: null, status: cs.status };
    const plan = cs.metadata?.plan; if (!PAID.includes(plan)) throw new Error('Unknown plan on that checkout.');
    const sub = cs.subscription || {};
    await setPlan(account.accountId, plan, { status: sub.status || 'active', renews: sub.current_period_end || sub.items?.data?.[0]?.current_period_end, customer: cs.customer });
    return { plan, status: sub.status || 'active' };
  }
  /** Every 15 minutes: every 0n3 subscription in Stripe decides its account's plan (renewals, failed payments, cancels). */
  async function reconcile() {
    let page = null; let n = 0; const changed = [];
    do {
      const r = await stripe(`/subscriptions/search?limit=100&query=${encodeURIComponent("metadata['app']:'0n3'")}${page ? `&page=${page}` : ''}`);
      for (const sub of r.data || []) {
        n++; const acct = sub.metadata?.account; const plan = sub.metadata?.plan; if (!acct || !PAID.includes(plan)) continue;
        const live = ['active', 'trialing', 'past_due'].includes(sub.status);
        const p = await profile(acct); if (!p) continue;
        const want = live ? plan : 'free';
        // Only move a plan 0n3 billing set (or free): a hand-granted plan (penthouse, enterprise…) is never downgraded here.
        if (p.plan === want && p.plan_status === sub.status) continue;
        if (!live && planOf(p.plan) !== plan && p.plan !== plan) continue;
        if (live || p.plan === plan) { await setPlan(acct, want, { status: sub.status, renews: sub.current_period_end || sub.items?.data?.[0]?.current_period_end, customer: sub.customer }); changed.push({ acct: acct.slice(0, 8), plan: want, status: sub.status }); }
      }
      page = r.has_more ? r.next_page : null;
    } while (page);
    return { subscriptions: n, changed };
  }
  /** One-time setup, admin only: the three prices, the webhook endpoint, and its secret saved into the deploy's env. */
  async function setup({ vercelToken = env.VERCEL_TOKEN, projectId = env.VERCEL_PROJECT_ID || 'prj_bHnnt6tHnuVfFzKPi2fbcElW6Eo3', teamId = env.VERCEL_TEAM_ID || 'team_VtbfSzhDgB6OwglLfuPDFcd2' } = {}) {
    const out = { prices: {} };
    for (const p of PAID) out.prices[p] = await priceFor(p);
    out.meter = await meterId(); out.usage_prices = {};
    for (const p of PAID) out.usage_prices[p] = await usagePriceFor(p);
    out.attached = await attachUsage();
    const url = `${base}/api/billing/webhook`;
    const list = await stripe('/webhook_endpoints?limit=100');
    const existing = (list.data || []).find((w) => w.url === url && w.status === 'enabled');
    if (existing && env.STRIPE_BILLING_WEBHOOK_SECRET) { out.webhook = { id: existing.id, reused: true }; return out; }
    if (existing) await stripe(`/webhook_endpoints/${existing.id}`, null, 'DELETE'); // its secret is not readable again; replace it
    const ep = await stripe('/webhook_endpoints', { url, description: '0n3 plans', 'enabled_events[0]': 'checkout.session.completed', 'enabled_events[1]': 'customer.subscription.created', 'enabled_events[2]': 'customer.subscription.updated', 'enabled_events[3]': 'customer.subscription.deleted' });
    if (!vercelToken) throw new Error('VERCEL_TOKEN is not set, so the webhook secret cannot be saved.');
    const r = await fetchImpl(`https://api.vercel.com/v10/projects/${projectId}/env?teamId=${teamId}&upsert=true`, { method: 'POST', headers: { Authorization: `Bearer ${vercelToken}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ key: 'STRIPE_BILLING_WEBHOOK_SECRET', value: ep.secret, type: 'sensitive', target: ['production', 'preview'] }) });
    out.webhook = { id: ep.id, created: true, secretSaved: r.ok, note: 'Redeploy so the new secret is read.' };
    return out;
  }
  /** Subscriptions sold before metering existed get their plan's usage price added (idempotent: skips any that have one). */
  async function attachUsage() {
    const done = []; let page = null;
    do {
      const r = await stripe(`/subscriptions/search?limit=100&query=${encodeURIComponent("metadata['app']:'0n3' AND status:'active'")}${page ? `&page=${page}` : ''}`);
      for (const sub of r.data || []) {
        const plan = sub.metadata?.plan; if (!PAID.includes(plan)) continue;
        const want = await usagePriceFor(plan);
        if ((sub.items?.data || []).some((i) => i.price?.id === want || i.price?.recurring?.usage_type === 'metered')) continue;
        await stripe('/subscription_items', { subscription: sub.id, price: want }); done.push(sub.id);
      }
      page = r.has_more ? r.next_page : null;
    } while (page);
    return done;
  }
  return { checkout, portal, webhook, me, setPlan, priceFor, usagePriceFor, meterId, attachUsage, stripe, setup, confirm, reconcile };
}
