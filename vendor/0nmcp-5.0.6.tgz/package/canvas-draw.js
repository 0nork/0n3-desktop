/**
 * 0nCANVAS — the sequence, drawn (2026-11-09, Mike: "use Excalidraw as the backbone and drop our sequence building right
 * into it"). Excalidraw is the drawing surface; flow-defs.js is the vocabulary; flows.js runs it. The join is Excalidraw's
 * own `customData` slot on every element: a rectangle whose customData.on3 names a block IS that block, an arrow bound
 * between two such rectangles IS the wire between them, and the words on the arrow ("2 days") are its wait. So the
 * drawing is the one source of truth and the sequence document is DERIVED from it (sceneToSequence) — the engine, the
 * waits, the automations and the test run read the same { nodes, edges } they always did.
 *
 * Pure and shared: the server lifts sequences out of AI replies with it; the web app draws and reads boards with it.
 */
import { TYPE_OF, mkNode, nameOf, parseWait, uid } from './flow-defs.js';

export const BLOCK = { w: 232, h: 88 };
/** Hand-drawn palette, one tint per block family (the builder's categories, in Excalidraw's own pastel range). */
export const TINT = {
  trigger: { bg: '#d3f9d8', stroke: '#2b8a3e' }, task: { bg: '#ffffff', stroke: '#1e1e1e' }, logic: { bg: '#fff3bf', stroke: '#e67700' },
  data: { bg: '#d0ebff', stroke: '#1971c2' }, ai: { bg: '#e5dbff', stroke: '#6741d9' }, terminal: { bg: '#ffe8cc', stroke: '#d9480f' }, action: { bg: '#f1f3f5', stroke: '#495057' },
};
const tint = (t) => TINT[t] || TINT.task;
const firstLine = (s) => String(s || '').split('\n')[0].trim();
const stripPos = (n) => { const { x, y, ...rest } = n; return rest; }; // position belongs to the element, not the block
/** What a block says on the board: its title, then the app that does it. */
export const blockLabel = (n) => `${n.title || nameOf(n.key)}${n.hasApp !== false && n.app ? `\n${nameOf(n.app)}` : ''}`;

/** A 0n3 sequence as Excalidraw skeleton elements: one rounded box per block, one bound arrow per wire, waits as arrow labels. */
export function sequenceToSkeletons(seq) {
  const nodes = (seq?.nodes || []).filter((n) => n && n.type !== 'shape');
  const out = []; const at = new Map();
  for (const n of nodes) {
    const c = tint(n.type); const x = Number(n.x) || 0; const y = Number(n.y) || 0; at.set(n.id, { x, y });
    out.push({ type: 'rectangle', id: `n_${n.id}`, x, y, width: BLOCK.w, height: BLOCK.h, roundness: { type: 3 }, backgroundColor: c.bg, strokeColor: c.stroke, fillStyle: 'solid', strokeWidth: 2, label: { text: blockLabel(n), fontSize: 16 }, customData: { on3: { kind: 'node', node: stripPos(n) } } });
  }
  for (const e of seq?.edges || []) {
    const a = at.get(e.from); const b = at.get(e.to); if (!a || !b) continue;
    const port = Number(e.port) || 0; const sx = a.x + BLOCK.w; const sy = a.y + BLOCK.h / 2; const ex = b.x; const ey = b.y + BLOCK.h / 2;
    const text = e.wait ? String(e.wait) : (port === 1 ? 'No' : '');
    out.push({ type: 'arrow', id: `e_${e.from}_${e.to}_${port}`, x: sx, y: sy, width: ex - sx, height: ey - sy, strokeColor: '#1e1e1e', strokeWidth: 2, start: { id: `n_${e.from}` }, end: { id: `n_${e.to}` }, ...(text ? { label: { text, fontSize: 14 } } : {}), customData: { on3: { kind: 'edge', edge: { from: e.from, to: e.to, port, ...(e.wait ? { wait: String(e.wait) } : {}) } } } });
  }
  return out;
}

/**
 * The sequence a board holds. Every rectangle carrying customData.on3.node is a block (its title follows the words typed
 * into it, so renaming a box renames the step); every arrow BOUND at both ends to such blocks is a wire — the ones the AI
 * drew and the ones the person drew by hand alike; words on an arrow that are a length of time are its wait, "No" is the
 * second port. A block whose vocabulary no longer exists is dropped, never invented back. null when nothing is drawn.
 */
export function sceneToSequence(elements, { name = 'Drawn sequence' } = {}) {
  const live = (elements || []).filter((e) => e && !e.isDeleted);
  const textIn = (id) => { const t = live.find((e) => e.type === 'text' && e.containerId === id); return t ? String(t.originalText || t.text || '') : ''; };
  const byEl = new Map(); const nodes = []; const used = new Set();
  for (const el of live) {
    const d = el.customData?.on3; if (!d || d.kind !== 'node' || !d.node) continue;
    const base = d.node; const def = base.type === 'action' ? true : (TYPE_OF[base.type] || {})[base.key];
    if (!def) continue;
    let id = String(base.id || '').slice(0, 24) || el.id.slice(0, 8); if (used.has(id)) id = el.id.slice(0, 8); used.add(id);
    nodes.push({ ...base, id, title: firstLine(textIn(el.id)) || base.title, x: Math.round(el.x), y: Math.round(el.y) }); byEl.set(el.id, id);
  }
  if (!nodes.length) return null;
  const edges = []; const seen = new Set();
  for (const el of live) {
    if (el.type !== 'arrow') continue;
    const from = byEl.get(el.startBinding?.elementId); const to = byEl.get(el.endBinding?.elementId);
    if (!from || !to || from === to) continue;
    const d = el.customData?.on3?.edge || {}; const words = firstLine(textIn(el.id));
    const port = words.toLowerCase() === 'no' ? 1 : (Number(d.port) || 0);
    const wait = parseWait(words) ? words.slice(0, 40) : (d.wait && parseWait(d.wait) ? String(d.wait).slice(0, 40) : undefined);
    const k = `${from}>${to}:${port}`; if (seen.has(k)) continue; seen.add(k);
    edges.push({ from, to, port, ...(wait ? { wait } : {}) });
  }
  if (!nodes.some((n) => n.type === 'trigger')) {
    const first = nodes.find((n) => !edges.some((e) => e.to === n.id)) || nodes[0];
    const t = mkNode('trigger', 'page_button', first.x - 340, first.y, { values: { name } });
    nodes.unshift(t); edges.unshift({ from: t.id, to: first.id, port: 0 });
  }
  return { id: uid(), name: String(name || 'Drawn sequence').slice(0, 120), nodes, edges };
}

/** A builder page as a wireframe: the section as a dashed frame, every element as a labelled box, notes as loose text. */
export function pageToSkeletons(page) {
  const out = [];
  for (const n of (page?.nodes || []).filter((n) => n && n.type === 'shape')) {
    const x = Number(n.x) || 0; const y = Number(n.y) || 0; const w = Number(n.w) || 160; const h = Number(n.h) || 48;
    const v = n.values || {}; const words = String(v.title || v.text || v.label || v.placeholder || '').slice(0, 60);
    if (n.key === 'sticky') { out.push({ type: 'text', id: `s_${n.id}`, x, y, text: String(v.text || '').slice(0, 600), fontSize: 14, strokeColor: '#9c6500' }); continue; }
    const sec = n.key === 'section'; const btn = n.key === 'button';
    out.push({ type: 'rectangle', id: `s_${n.id}`, x, y, width: w, height: h, roundness: { type: 3 }, backgroundColor: sec ? '#f8f9fa' : btn ? '#1e1e1e' : '#ffffff', strokeColor: sec ? '#adb5bd' : '#1e1e1e', strokeStyle: sec ? 'dashed' : 'solid', fillStyle: 'solid', strokeWidth: sec ? 1 : 2, label: { text: sec ? (words || String(page?.name || '')) : `${nameOf(n.key)}${words ? `: ${words}` : ''}`, fontSize: sec ? 20 : 14, ...(sec ? { verticalAlign: 'top' } : {}), ...(btn ? { strokeColor: '#ffffff' } : {}) }, customData: { on3: { kind: 'shape', node: stripPos(n) } } });
  }
  return out;
}
