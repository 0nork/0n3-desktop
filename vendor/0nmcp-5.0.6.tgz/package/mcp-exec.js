/**
 * MCP-EXEC — the outbound MCP client. The sibling of `catalog-exec.js`.
 *
 *   catalog-exec.js   buildRequest() / executeEndpoint()      → REST services
 *   mcp-exec.js       listRemoteTools() / callRemoteTool()    → MCP servers
 *
 * 0n3 has always been an MCP *server*. This is the first code that makes it an
 * MCP *client*, so a connected third-party MCP server becomes reachable through
 * the same vault, the same account and the same 0n token as an API key.
 *
 * ═══ THE NEW RISK, AND WHY HALF THIS FILE IS ABOUT IT ═══
 *
 * Until now 0n3 only ever called URLs from a static catalog shipped in the
 * repo. From here it calls URLs that USERS TYPE. That is a server-side request
 * forgery primitive handed to anyone with an account: "fetch this for me, from
 * inside your own network, with your own egress." The cloud metadata endpoint
 * at 169.254.169.254 is the classic target and it answers without credentials.
 *
 * So every request — including every redirect hop — is validated against
 * `assertSafeUrl()` before it leaves, the hostname is resolved and each
 * resulting address checked, and redirects are followed MANUALLY so a public
 * host cannot 302 us into private space. None of that is optional and none of
 * it is configurable per record.
 */
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StreamableHTTPClientTransport } from '@modelcontextprotocol/sdk/client/streamableHttp.js';
import { liveToken, refreshable } from './mcp-oauth.js';

export const DEFAULT_TIMEOUT_MS = 20_000;
export const DEFAULT_CALL_TIMEOUT_MS = 45_000;
export const MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
export const MAX_REDIRECTS = 3;

/** IPv4 ranges that must never be reachable from a user-supplied URL. */
const V4_BLOCKED = [
  ['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10], ['127.0.0.0', 8],
  ['169.254.0.0', 16],  // link-local — cloud metadata lives here
  ['172.16.0.0', 12], ['192.0.0.0', 24], ['192.168.0.0', 16],
  ['198.18.0.0', 15], ['224.0.0.0', 4], ['240.0.0.0', 4],
];

const v4ToInt = (ip) => ip.split('.').reduce((a, o) => (a << 8 >>> 0) + Number(o), 0) >>> 0;

function v4Blocked(ip) {
  const n = v4ToInt(ip);
  return V4_BLOCKED.some(([base, bits]) => {
    const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
    return (n & mask) === (v4ToInt(base) & mask);
  });
}

function v6Blocked(ip) {
  const a = ip.toLowerCase();
  if (a === '::1' || a === '::') return true;
  if (a.startsWith('fe80')) return true;                 // link-local
  const first = parseInt(a.split(':')[0] || '0', 16);
  if ((first & 0xfe00) === 0xfc00) return true;          // fc00::/7 unique-local
  const m = a.match(/::ffff:(\d+\.\d+\.\d+\.\d+)$/);     // IPv4-mapped
  if (m) return v4Blocked(m[1]);
  return false;
}

export function addressBlocked(ip) {
  const v = isIP(ip);
  if (v === 4) return v4Blocked(ip);
  if (v === 6) return v6Blocked(ip);
  return true; // not an address we understand → refuse
}

/**
 * Refuse anything that is not a public HTTPS endpoint.
 *
 * Throws rather than returning false: a caller that forgets to check a boolean
 * is a caller that makes the request anyway.
 */
export async function assertSafeUrl(raw) {
  let u;
  try { u = new URL(String(raw)); } catch { throw new Error('not a valid URL'); }
  if (u.protocol !== 'https:') throw new Error('only https:// MCP endpoints are allowed');
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (/\.(local|internal|localhost)$/i.test(host) || host === 'localhost') {
    throw new Error(`refusing internal hostname: ${host}`);
  }
  // Literal address, or resolve the name and check EVERY answer — a name with
  // one public and one private A record is still a way in.
  const addrs = isIP(host) ? [{ address: host }] : await lookup(host, { all: true }).catch(() => []);
  if (!addrs.length) throw new Error(`cannot resolve host: ${host}`);
  for (const a of addrs) {
    if (addressBlocked(a.address)) throw new Error(`refusing private or reserved address for ${host} (${a.address})`);
  }
  return u;
}

/** Remove anything secret from text on its way back to a caller. */
export function redact(text, creds = {}) {
  let s = String(text ?? '');
  for (const v of Object.values(creds)) {
    if (typeof v === 'string' && v.length >= 8) s = s.split(v).join('«redacted»');
  }
  return s.replace(/(bearer\s+)[A-Za-z0-9._~+/-]{8,}/gi, '$1«redacted»');
}

/**
 * A fetch that re-validates on every hop and caps the body.
 *
 * Redirects are followed by hand (`redirect: 'manual'`) because the danger is
 * precisely the hop: a public URL that 302s to 169.254.169.254 passes any
 * check done only on the URL the user typed.
 */
export function makeGuardedFetch(baseFetch = fetch) {
  return async function guardedFetch(input, init = {}) {
    let url = typeof input === 'string' ? input : input?.url || String(input);
    let opts = { ...init, redirect: 'manual' };
    for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
      await assertSafeUrl(url);
      const res = await baseFetch(url, opts);
      if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
        if (hop === MAX_REDIRECTS) throw new Error('too many redirects');
        url = new URL(res.headers.get('location'), url).toString();
        // A redirect after a POST becomes a GET without a body, per fetch semantics.
        if (res.status === 303) opts = { ...opts, method: 'GET', body: undefined };
        continue;
      }
      const len = Number(res.headers.get('content-length') || 0);
      if (len > MAX_RESPONSE_BYTES) throw new Error(`response too large (${len} bytes)`);
      return res;
    }
    throw new Error('too many redirects');
  };
}

/**
 * The `options.mcp` block of a connection envelope, with defaults.
 *
 * It lives in `options` and NOT at the top level because `stripSecrets()` —
 * the one function that produces the safe view — keeps `$0n/service/
 * environment/auth/options/meta` and drops everything else. A top-level
 * `transport` key would vanish from `connections` and `vault_record` without
 * a word, which is the kind of silent omission this codebase keeps paying for.
 */
export function mcpConfigOf(env) {
  const m = env?.options?.mcp;
  if (!m || !m.url) return null;
  return {
    url: m.url,
    transport: m.transport || 'streamable-http',
    timeoutMs: Number(m.timeoutMs) > 0 ? Number(m.timeoutMs) : DEFAULT_TIMEOUT_MS,
    toolAllowlist: Array.isArray(m.toolAllowlist) && m.toolAllowlist.length ? m.toolAllowlist : null,
    federate: m.federate === true,
    headerName: m.headerName || null,
  };
}

/** Auth headers for the remote, from the record's own credentials. */
function authHeaders(env, cfg) {
  const type = env?.auth?.type || 'none';
  const creds = env?.auth?.credentials || {};
  if (type === 'none' || !Object.keys(creds).length) return {};
  const token = creds.token || creds.access_token || creds.apiKey || creds.api_key;
  if (type === 'headers') {
    // Every credential key becomes a header, verbatim. For servers that want
    // X-Api-Key rather than Authorization.
    return Object.fromEntries(Object.entries(creds).map(([k, v]) => [k, String(v)]));
  }
  if (cfg.headerName && token) return { [cfg.headerName]: String(token) };
  if (token) return { Authorization: `Bearer ${token}` };
  return {};
}

/**
 * An OAuth MCP record (mcp-oauth.js — Whatnot and every other server that follows the MCP authorization spec) carries a refresh
 * token: mint a live access token before connecting, and hand a rotated refresh token back to the vault through `persist`.
 * Every other record keeps the static header path above.
 */
async function oauthHeaders(env, cfg, { fetchImpl, persist }) {
  const creds = env?.auth?.credentials || {};
  if (!refreshable(creds)) return authHeaders(env, cfg);
  const token = await liveToken(creds, { fetchImpl, persist: persist ? (next) => persist({ ...env, auth: { ...env.auth, credentials: next } }) : null });
  return token ? { [cfg.headerName || 'Authorization']: cfg.headerName ? token : `Bearer ${token}` } : {};
}

/** Open a client, run one operation, always close. Never pooled across accounts. */
async function withRemote(env, { fetchImpl = fetch, timeoutMs, persist = null } = {}, fn) {
  const cfg = mcpConfigOf(env);
  if (!cfg) throw new Error('this connection has no options.mcp.url — it is not an MCP server record');
  if (cfg.transport !== 'streamable-http') {
    throw new Error(`unsupported transport "${cfg.transport}" (hosted 0n3 speaks streamable-http; stdio needs the local CLI)`);
  }
  const url = await assertSafeUrl(cfg.url);
  const client = new Client({ name: '0n3', version: '1' }, { capabilities: {} });
  const transport = new StreamableHTTPClientTransport(url, {
    fetch: makeGuardedFetch(fetchImpl),
    requestInit: { headers: await oauthHeaders(env, cfg, { fetchImpl, persist }) },
  });
  const budget = timeoutMs || cfg.timeoutMs;
  const timer = new Promise((_, rej) => setTimeout(() => rej(new Error(`remote MCP timed out after ${budget}ms`)), budget));
  try {
    await Promise.race([client.connect(transport), timer]);
    return await Promise.race([fn(client, cfg), timer]);
  } finally {
    try { await client.close(); } catch { /* the remote's problem, not ours */ }
  }
}

/** The remote's tools, filtered by the record's allowlist. */
export async function listRemoteTools(env, opts = {}) {
  return withRemote(env, opts, async (client, cfg) => {
    const res = await client.listTools();
    let tools = (res?.tools || []).map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema }));
    const total = tools.length;
    if (cfg.toolAllowlist) tools = tools.filter((t) => cfg.toolAllowlist.includes(t.name));
    return { tools, total, allowlisted: !!cfg.toolAllowlist };
  });
}

/** Call one tool on the remote. */
export async function callRemoteTool(env, tool, args = {}, opts = {}) {
  // ALLOWLIST FIRST, BEFORE ANY NETWORK. The first version checked this inside
  // the connected session, which meant a tool the user had explicitly forbidden
  // still caused us to dial the remote — slower, noisier, and a request made on
  // behalf of a user who said no. A refusal should cost nothing.
  const pre = mcpConfigOf(env);
  if (pre?.toolAllowlist && !pre.toolAllowlist.includes(tool)) {
    const e = new Error(`"${tool}" is not on this connection's allowlist (${pre.toolAllowlist.join(', ')})`);
    e.blocked = true;
    throw e;
  }
  return withRemote(env, { ...opts, timeoutMs: opts.timeoutMs || DEFAULT_CALL_TIMEOUT_MS }, async (client) => {
    const res = await client.callTool({ name: tool, arguments: args || {} });
    return { isError: !!res?.isError, content: res?.content || [], structuredContent: res?.structuredContent };
  });
}
