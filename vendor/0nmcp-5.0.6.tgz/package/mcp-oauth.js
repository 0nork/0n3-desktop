/**
 * MCP-OAUTH — connect any OAuth-protected remote MCP server to the vault (Mike, 2026-11-05: "connect Whatnot MCP into 0n3 — I
 * will be working to connect a BUNCH of new applications").
 *
 * The MCP authorization spec is the same for every server, so this is one module, not one door per vendor:
 *
 *   1. discover()   GET <server>/.well-known/oauth-protected-resource   → resource, authorization_servers, scopes
 *                   GET <as-origin>/.well-known/oauth-authorization-server<as-path>  (RFC 8414 path insertion, then the
 *                   appended form) → authorize / token / registration endpoints
 *   2. authorize    PKCE S256 + state + the RFC 8707 `resource`, with the vendor's public client id (Whatnot publishes
 *                   bb1bf1ca-…) or one registered dynamically when the server offers registration
 *   3. exchange()   code → access + refresh token
 *   4. refresh()    hosted 0n3 mints a fresh access token from the refresh token on every call that needs one — a refresh
 *                   needs no redirect, so a server whose public client only allows a LOOPBACK callback (Whatnot: localhost
 *                   only; https://0n3.app/... is refused with invalid_request, measured 2026-11-05) still works from 0n3.app
 *                   once `0n3 connect-mcp` has signed in on the person's own machine.
 *
 * The record it writes is an ordinary MCP connection (options.mcp.url) with auth.type "oauth" and credentials
 * { access_token, refresh_token, expires_at, client_id, client_secret?, token_endpoint, resource, scope }. Nothing else in 0n3
 * needs to know a vendor's name.
 */
import { createHash, randomBytes } from 'node:crypto';

const b64url = (buf) => Buffer.from(buf).toString('base64url');
export function pkce() {
  const verifier = b64url(randomBytes(48));
  return { verifier, challenge: b64url(createHash('sha256').update(verifier).digest()), state: b64url(randomBytes(16)) };
}

async function getJson(url, fetchImpl) {
  const r = await fetchImpl(url, { headers: { accept: 'application/json' } });
  if (!r.ok) return null;
  return r.json().catch(() => null);
}

/** Where to sign in for an MCP server, from its own published metadata. Throws in the server's words when it publishes none. */
export async function discover(mcpUrl, { fetchImpl = fetch } = {}) {
  const u = new URL(mcpUrl);
  const prm = (await getJson(`${u.origin}/.well-known/oauth-protected-resource${u.pathname === '/' ? '' : u.pathname}`, fetchImpl))
    || (await getJson(`${u.origin}/.well-known/oauth-protected-resource`, fetchImpl));
  const asUrl = prm?.authorization_servers?.[0] || u.origin;
  const a = new URL(asUrl);
  const path = a.pathname === '/' ? '' : a.pathname.replace(/\/$/, '');
  const meta = (await getJson(`${a.origin}/.well-known/oauth-authorization-server${path}`, fetchImpl))
    || (await getJson(`${a.origin}${path}/.well-known/oauth-authorization-server`, fetchImpl))
    || (await getJson(`${a.origin}/.well-known/openid-configuration${path}`, fetchImpl));
  if (!meta?.authorization_endpoint || !meta?.token_endpoint) throw new Error(`${mcpUrl} publishes no OAuth authorization server metadata (looked at ${asUrl})`);
  return {
    resource: prm?.resource || `${u.origin}${u.pathname}`,
    scopes: prm?.scopes_supported || meta.scopes_supported || [],
    authorization_endpoint: meta.authorization_endpoint,
    token_endpoint: meta.token_endpoint,
    registration_endpoint: meta.registration_endpoint || null,
    issuer: meta.issuer || asUrl,
  };
}

/** A client for this server: the vendor's public id when given, else dynamic registration (RFC 7591) for `redirectUri`. */
export async function clientFor(d, { clientId, clientSecret, redirectUri, name = '0n3', fetchImpl = fetch } = {}) {
  if (clientId) return { client_id: clientId, ...(clientSecret ? { client_secret: clientSecret } : {}) };
  if (!d.registration_endpoint) throw new Error('this server offers no client registration — pass the vendor\'s client id (--client-id)');
  const r = await fetchImpl(d.registration_endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ client_name: name, redirect_uris: [redirectUri], grant_types: ['authorization_code', 'refresh_token'], response_types: ['code'], token_endpoint_auth_method: 'none' }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.client_id) throw new Error(`client registration failed: ${j.error_description || j.error || `HTTP ${r.status}`}`);
  return { client_id: j.client_id, ...(j.client_secret ? { client_secret: j.client_secret } : {}) };
}

export function authorizeUrl(d, { client_id, redirectUri, scope, challenge, state }) {
  const q = new URLSearchParams({ response_type: 'code', client_id, redirect_uri: redirectUri, state, code_challenge: challenge, code_challenge_method: 'S256', resource: d.resource });
  if (scope) q.set('scope', scope);
  return `${d.authorization_endpoint}${d.authorization_endpoint.includes('?') ? '&' : '?'}${q}`;
}

async function tokenCall(endpoint, body, fetchImpl) {
  const r = await fetchImpl(endpoint, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' }, body: new URLSearchParams(body).toString() });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.access_token) throw new Error(`token endpoint: ${j.error_description || j.error || `HTTP ${r.status}`}`);
  return j;
}
const stamp = (j, now) => (j.expires_in ? new Date(now() + Number(j.expires_in) * 1000).toISOString() : null);

/** code → the credentials the vault keeps. */
export async function exchange(d, client, { code, verifier, redirectUri, fetchImpl = fetch, now = Date.now }) {
  const j = await tokenCall(d.token_endpoint, { grant_type: 'authorization_code', code, redirect_uri: redirectUri, code_verifier: verifier, client_id: client.client_id, resource: d.resource, ...(client.client_secret ? { client_secret: client.client_secret } : {}) }, fetchImpl);
  return { access_token: j.access_token, ...(j.refresh_token ? { refresh_token: j.refresh_token } : {}), expires_at: stamp(j, now), scope: j.scope || null, client_id: client.client_id, ...(client.client_secret ? { client_secret: client.client_secret } : {}), token_endpoint: d.token_endpoint, resource: d.resource };
}

/** Is this an OAuth MCP credential set that can be refreshed? */
export const refreshable = (c) => !!(c && c.refresh_token && c.token_endpoint && c.client_id);

const cache = new Map(); // refresh_token hash → { token, exp, refresh_token }
const keyOf = (c) => createHash('sha256').update(String(c.refresh_token)).digest('hex').slice(0, 24);

/**
 * A live access token for an OAuth MCP record. Uses the stored token while it has a minute left, else refreshes. When the server
 * ROTATES the refresh token, `persist(newCreds)` is called so the vault keeps the one that still works — a rotated token that is
 * not saved locks the connection out on the next refresh.
 */
export async function liveToken(creds, { fetchImpl = fetch, now = Date.now, persist = null } = {}) {
  const exp = creds.expires_at ? Date.parse(creds.expires_at) : 0;
  if (creds.access_token && exp - 60_000 > now()) return creds.access_token;
  if (!refreshable(creds)) return creds.access_token || null;
  const k = keyOf(creds); const hit = cache.get(k);
  if (hit && hit.exp - 60_000 > now()) return hit.token;
  const j = await tokenCall(creds.token_endpoint, { grant_type: 'refresh_token', refresh_token: creds.refresh_token, client_id: creds.client_id, ...(creds.resource ? { resource: creds.resource } : {}), ...(creds.client_secret ? { client_secret: creds.client_secret } : {}) }, fetchImpl);
  const next = { ...creds, access_token: j.access_token, expires_at: stamp(j, now) || new Date(now() + 3600_000).toISOString(), ...(j.refresh_token ? { refresh_token: j.refresh_token } : {}) };
  cache.set(k, { token: j.access_token, exp: Date.parse(next.expires_at) });
  if (persist) { try { await persist(next); } catch { /* the call still works this time; the next refresh says why */ } }
  return j.access_token;
}
