/**
 * EVERY SIGNIFICANT AI PROVIDER (2026-11-23, Mike: customers are never stuck with one AI).
 *
 * Spread into SERVICE_CATALOG by catalog.js, so each entry is an ordinary catalog service: api_call, service_info,
 * the Connect page and the vault all treat it like Stripe or Groq. Connect guides: connect-guides-ai.js.
 *
 * Keys match chat.js PROVIDERS where a provider is already on "My AI" (anthropic, gemini, cerebras, openrouter, nvidia),
 * so the ONE vault record a person saves there is the same record api_call reads. Never a second key store.
 *
 * Every base URL, header and path below was read from the provider's own API docs (2026-11-23); nothing is inferred.
 * Most hosts speak the OpenAI dialect (GET /models, POST /chat/completions), so `openaiCompatible()` builds those.
 * `aggregator: true` marks a "master API": one key, many models from many labs.
 */

const bearer = (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" });
/** A per-account host typed by the person (Azure resource, LiteLLM proxy): https only, no path tricks, no trailing slash. */
const httpsBase = (v) => { const s = String(v || "").trim().replace(/\/+$/, ""); return /^https:\/\/[a-z0-9.-]+(:\d+)?(\/[A-Za-z0-9._~\/-]*)?$/i.test(s) && !s.includes("..") ? s : null; };

const CHAT_CAPS = [
  { name: "chat", actions: ["complete"], description: "Chat completions" },
  { name: "models", actions: ["list"], description: "List available models" },
];

/**
 * An OpenAI-compatible provider: list_models + chat_completion (+ whatever `extra` endpoints it also has).
 * `prefix` is the path in front of /models and /chat/completions when the base URL stops short of it.
 * `noModelList` where the provider's docs do not name a model-list route — an endpoint we could not confirm is left out.
 */
function openaiCompatible({ name, description, baseUrl, model, prefix = "", extra = {}, caps = [], aggregator = false, noModelList = false, authHeader = bearer, credentialKeys = ["apiKey"], ...rest }) {
  return {
    name, type: "ai", description, baseUrl, authType: "api_key", credentialKeys,
    ...(aggregator ? { aggregator: true } : {}),
    capabilities: [...(noModelList ? CHAT_CAPS.filter((c) => c.name !== "models") : CHAT_CAPS), ...caps],
    endpoints: {
      ...(noModelList ? {} : { list_models: { method: "GET", path: `${prefix}/models` } }),
      chat_completion: { method: "POST", path: `${prefix}/chat/completions`, body: { model, messages: [] } },
      ...extra,
    },
    authHeader,
    ...rest,
  };
}

export const AI_PROVIDERS = {
  // ═══ FRONTIER LABS ═══════════════════════════════════════════════════════════════════════════════════════════════
  anthropic: {
    name: "Anthropic (Claude)",
    type: "ai",
    description: "Claude models (Opus, Sonnet, Haiku) — the Messages API with tools, vision and long context; list models; count tokens.",
    baseUrl: "https://api.anthropic.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "chat", actions: ["complete"], description: "Messages (chat, tools, vision)" },
      { name: "models", actions: ["list"], description: "List available models" },
    ],
    endpoints: {
      list_models:   { method: "GET",  path: "/v1/models" },
      create_message:{ method: "POST", path: "/v1/messages", body: { model: "claude-sonnet-5-5", max_tokens: 1024, messages: [] } },
      count_tokens:  { method: "POST", path: "/v1/messages/count_tokens", body: { model: "claude-sonnet-5-5", messages: [] } },
    },
    // 2023-06-01 is the version chat.js speaks and is still supported; the newer 2026-10-21 refuses temperature/top_p/top_k.
    authHeader: (creds) => ({ "x-api-key": creds.apiKey, "anthropic-version": "2023-06-01", "Content-Type": "application/json" }),
  },
  gemini: {
    name: "Google Gemini API",
    type: "ai",
    aliases: ["google_ai"],
    description: "Google's Gemini models through AI Studio's API key — generateContent, embeddings, token counting, list models. Free tier with a daily limit.",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "chat", actions: ["complete"], description: "Generate content (text, vision, tools)" },
      { name: "embed", actions: ["create"], description: "Text embeddings" },
      { name: "models", actions: ["list"], description: "List available models" },
    ],
    endpoints: {
      list_models:      { method: "GET",  path: "/models", query: ["pageSize", "pageToken"] },
      generate_content: { method: "POST", path: "/models/{model}:generateContent", body: { model: "gemini-2.5-flash", contents: [{ parts: [{ text: "" }] }] } },
      count_tokens:     { method: "POST", path: "/models/{model}:countTokens", body: { model: "gemini-2.5-flash", contents: [] } },
      embed_content:    { method: "POST", path: "/models/{model}:embedContent", body: { model: "gemini-embedding-001", content: { parts: [{ text: "" }] } } },
    },
    authHeader: (creds) => ({ "x-goog-api-key": creds.apiKey, "Content-Type": "application/json" }),
  },
  xai: openaiCompatible({
    name: "xAI (Grok API)",
    description: "Grok models from xAI — chat, the Responses API, and Grok Imagine image generation. (Grok Bot routines are the separate grok_bot service.)",
    baseUrl: "https://api.x.ai/v1",
    model: "grok-4.7",
    caps: [{ name: "generate_image", actions: ["create"], description: "Image generation" }],
    extra: {
      list_language_models: { method: "GET",  path: "/language-models" },
      create_response:      { method: "POST", path: "/responses", body: { model: "grok-4.7", input: "" } },
      create_image:         { method: "POST", path: "/images/generations", body: { model: "grok-imagine-image-2.0", prompt: "" } },
    },
  }),
  deepseek: openaiCompatible({
    name: "DeepSeek",
    description: "DeepSeek's own API — strong, low-cost reasoning and chat models, OpenAI-compatible.",
    baseUrl: "https://api.deepseek.com",
    model: "deepseek-flash",
  }),
  ai21: openaiCompatible({
    name: "AI21 Labs (Jamba)",
    description: "Jamba long-context models from AI21 Labs, OpenAI-style chat.",
    baseUrl: "https://api.ai21.com/studio/v1",
    model: "jamba-large",
  }),
  reka: openaiCompatible({
    name: "Reka",
    description: "Reka's multimodal models (text, image, video, audio in), OpenAI-compatible chat.",
    baseUrl: "https://api.reka.ai/v1",
    model: "reka-flash-3",
  }),
  moonshot: openaiCompatible({
    name: "Moonshot AI (Kimi)",
    description: "Kimi models from Moonshot AI (international platform) — long context and agentic coding, OpenAI-compatible.",
    baseUrl: "https://api.moonshot.ai/v1",
    model: "kimi-k3",
  }),
  zai: openaiCompatible({
    name: "Z.ai (GLM)",
    description: "GLM models from Zhipu / Z.ai (international) — chat and image generation, OpenAI-style.",
    baseUrl: "https://api.z.ai/api/paas/v4",
    model: "glm-5.3",
    caps: [{ name: "generate_image", actions: ["create"], description: "Image generation" }],
    extra: { create_image: { method: "POST", path: "/images/generations", body: { model: "", prompt: "" } } },
  }),
  qwen: openaiCompatible({
    name: "Alibaba Qwen (Model Studio)",
    description: "Qwen models from Alibaba Cloud Model Studio (international, Singapore) — chat and embeddings, OpenAI-compatible. A workspace id moves you to the newer per-workspace host.",
    baseUrl: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    baseUrlFor: (creds) => { const w = String(creds?.workspaceId || "").trim().toLowerCase(); return /^[a-z0-9-]{4,64}$/.test(w) ? `https://${w}.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1` : null; },
    credentialKeys: ["apiKey", "workspaceId"],
    model: "qwen-plus",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: { create_embedding: { method: "POST", path: "/embeddings", body: { model: "text-embedding-v4", input: "" } } },
  }),
  minimax: openaiCompatible({
    name: "MiniMax",
    description: "MiniMax models (international) — fast agentic chat, OpenAI-compatible plus MiniMax's own chatcompletion_v2.",
    baseUrl: "https://api.minimax.io/v1",
    model: "MiniMax-M3",
    extra: { chatcompletion_v2: { method: "POST", path: "/text/chatcompletion_v2", body: { model: "MiniMax-M3", messages: [] } } },
  }),
  perplexity: {
    name: "Perplexity",
    type: "ai",
    description: "Answers grounded in live web search, with citations — Sonar models and the newer Agent API.",
    baseUrl: "https://api.perplexity.ai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "search_answer", actions: ["complete"], description: "Web-grounded answers with citations" }],
    endpoints: {
      // Perplexity says Sonar chat completions are being moved onto the Agent API (from 2026-09-27); both are listed.
      chat_completion: { method: "POST", path: "/chat/completions", body: { model: "sonar-pro", messages: [] } },
      sonar:           { method: "POST", path: "/v1/sonar", body: { model: "sonar-pro", messages: [] } },
      agent:           { method: "POST", path: "/v1/agent", body: { input: "", effort: "fast" } },
    },
    authHeader: bearer,
  },

  // ═══ AGGREGATORS — "master APIs": one key, many models from many labs ═══════════════════════════════════════════
  openrouter: openaiCompatible({
    name: "OpenRouter",
    description: "AI aggregator — one key, hundreds of models (OpenAI, Anthropic, Google, Meta, Mistral, DeepSeek, xAI…) through one OpenAI-style API, including free models. Model ids are provider/model.",
    aggregator: true,
    baseUrl: "https://openrouter.ai/api/v1",
    model: "openai/gpt-4o",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: {
      list_my_models:        { method: "GET",  path: "/models/user" },
      list_embedding_models: { method: "GET",  path: "/embeddings/models" },
      create_embedding:      { method: "POST", path: "/embeddings", body: { model: "openai/text-embedding-3-small", input: "" } },
      create_response:       { method: "POST", path: "/responses", body: { model: "openai/gpt-4o", input: "" } },
    },
  }),
  requesty: openaiCompatible({
    name: "Requesty",
    description: "AI aggregator — one key, models from every major lab with managed failover between providers. Model ids: a bare name, provider/model, or policy/<your routing policy>.",
    aggregator: true,
    baseUrl: "https://router.requesty.ai/v1",
    model: "openai/gpt-4o",
  }),
  eden_ai: openaiCompatible({
    name: "Eden AI",
    description: "AI aggregator — one key for LLMs from many providers (v3 unified API, provider/model ids) plus OCR, speech and vision APIs.",
    aggregator: true,
    baseUrl: "https://api.edenai.run/v3",
    model: "openai/gpt-latest",
  }),
  aimlapi: openaiCompatible({
    name: "AI/ML API",
    description: "AI aggregator — one key, hundreds of chat, image, video and embedding models behind one OpenAI-compatible API.",
    aggregator: true,
    baseUrl: "https://api.aimlapi.com/v1",
    model: "gpt-4o",
  }),
  vercel_ai_gateway: openaiCompatible({
    name: "Vercel AI Gateway",
    description: "AI aggregator — one AI Gateway key, hundreds of models (provider/model ids) with unified billing or your own provider keys, OpenAI-compatible.",
    aggregator: true,
    baseUrl: "https://ai-gateway.vercel.sh/v1",
    model: "anthropic/claude-sonnet-4.5",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: {
      get_model:        { method: "GET",  path: "/models/{model}" },
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "openai/text-embedding-3-small", input: "" } },
      create_response:  { method: "POST", path: "/responses", body: { model: "openai/gpt-5", input: "" } },
    },
  }),
  cloudflare_ai_gateway: {
    name: "Cloudflare AI Gateway",
    type: "ai",
    aggregator: true,
    description: "AI aggregator — Cloudflare's gateway in front of OpenAI, Anthropic, Google AI Studio, Workers AI and more; one OpenAI-style endpoint with provider/model ids, keys stored in the gateway. (Workers AI itself is on the cloudflare service.)",
    baseUrl: "https://gateway.ai.cloudflare.com/v1",
    baseUrlFor: (creds) => {
      const a = String(creds?.accountId || "").trim(), g = String(creds?.gatewayId || "default").trim();
      return /^[a-f0-9]{32}$/i.test(a) && /^[A-Za-z0-9_-]{1,64}$/.test(g) ? `https://gateway.ai.cloudflare.com/v1/${a}/${g}/compat` : null;
    },
    authType: "api_key",
    credentialKeys: ["apiToken", "accountId", "gatewayId"],
    capabilities: [{ name: "chat", actions: ["complete"], description: "Chat completions through the gateway (provider/model ids)" }],
    endpoints: {
      chat_completion: { method: "POST", path: "/chat/completions", body: { model: "openai/gpt-5-mini", messages: [] } },
    },
    authHeader: (creds) => ({ "cf-aig-authorization": `Bearer ${creds.apiToken}`, "Content-Type": "application/json" }),
  },
  portkey: openaiCompatible({
    name: "Portkey",
    description: "AI aggregator — gateway in front of 250+ providers. One Portkey key; pick the model as @your-provider-slug/model from your Model Catalog (or pass x-portkey-config).",
    aggregator: true,
    baseUrl: "https://api.portkey.ai/v1",
    model: "@openai/gpt-4o",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: { create_embedding: { method: "POST", path: "/embeddings", body: { model: "@openai/text-embedding-3-small", input: "" } } },
    authHeader: (creds) => ({ "x-portkey-api-key": creds.apiKey, ...(creds.config ? { "x-portkey-config": creds.config } : {}), "Content-Type": "application/json" }),
  }),
  litellm: openaiCompatible({
    name: "LiteLLM Proxy",
    description: "AI aggregator you host — your own LiteLLM proxy in front of 100+ providers, one master or virtual key, OpenAI-compatible. Needs your proxy's https URL.",
    aggregator: true,
    baseUrl: "https://litellm-proxy.invalid", // never a real host: with no https baseUrl on the record the call fails instead of sending the key anywhere
    baseUrlFor: (creds) => httpsBase(creds?.baseUrl),
    credentialKeys: ["apiKey", "baseUrl"],
    prefix: "/v1",
    model: "gpt-4o",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: { create_embedding: { method: "POST", path: "/v1/embeddings", body: { model: "", input: "" } } },
  }),
  huggingface: openaiCompatible({
    name: "Hugging Face Inference Providers",
    description: "AI aggregator — one Hugging Face token routes chat to many inference providers (Together, Fireworks, Novita, SambaNova…). Add :fastest, :cheapest or :<provider> to the model id. Chat only on this router.",
    aggregator: true,
    baseUrl: "https://router.huggingface.co/v1",
    model: "deepseek-ai/DeepSeek-V3.1:fastest",
  }),

  // ═══ FAST INFERENCE HOSTS — open models served fast and cheap (OpenAI dialect) ═══════════════════════════════════
  together_ai: openaiCompatible({
    name: "Together AI",
    description: "Open-model inference — 200+ models (Llama, DeepSeek, Qwen, gpt-oss, FLUX images), OpenAI-compatible.",
    baseUrl: "https://api.together.ai/v1",
    model: "openai/gpt-oss-120b",
    caps: [{ name: "generate_image", actions: ["create"], description: "Image generation (FLUX and others)" }],
    extra: {
      create_image:     { method: "POST", path: "/images/generations", body: { model: "black-forest-labs/FLUX.1-schnell", prompt: "" } },
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "", input: "" } },
    },
  }),
  fireworks_ai: openaiCompatible({
    name: "Fireworks AI",
    description: "Fast open-model inference — DeepSeek, Kimi, Qwen, Llama, gpt-oss and embeddings, OpenAI-compatible.",
    baseUrl: "https://api.fireworks.ai/inference/v1",
    model: "accounts/fireworks/models/kimi-k2-instruct-0905",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: {
      // Fireworks lists models per ACCOUNT, outside the inference base: pass account_id (fireworks for the public catalogue).
      list_models:      { method: "GET", baseUrl: "https://api.fireworks.ai/v1", path: "/accounts/{account_id}/models" },
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "nomic-ai/nomic-embed-text-v1.5", input: "" } },
    },
  }),
  deepinfra: openaiCompatible({
    name: "DeepInfra",
    description: "Low-cost open-model inference — DeepSeek, Llama, Qwen, Mistral and embeddings, OpenAI-compatible.",
    baseUrl: "https://api.deepinfra.com/v1/openai",
    model: "meta-llama/Llama-3.3-70B-Instruct",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: {
      // The model list and embeddings live outside /openai on DeepInfra's own API.
      list_models:      { method: "GET",  baseUrl: "https://api.deepinfra.com/v1", path: "/models" },
      create_embedding: { method: "POST", baseUrl: "https://api.deepinfra.com/v1", path: "/embeddings", body: { model: "thenlper/gte-large", input: [] } },
    },
  }),
  sambanova: openaiCompatible({
    name: "SambaNova Cloud",
    description: "Very fast inference on SambaNova chips — DeepSeek, Llama, Qwen, gpt-oss; chat, embeddings and transcription, OpenAI-compatible.",
    baseUrl: "https://api.sambanova.ai/v1",
    model: "Meta-Llama-3.3-70B-Instruct",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings" }],
    extra: {
      get_model:        { method: "GET",  path: "/models/{model_id}" },
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "", input: "" } },
    },
  }),
  hyperbolic: openaiCompatible({
    noModelList: true,
    name: "Hyperbolic",
    description: "Low-cost open-model inference on a GPU marketplace — DeepSeek, Qwen, Llama, GLM, OpenAI-compatible chat.",
    baseUrl: "https://api.hyperbolic.ai/inference/v1",
    model: "deepseek-ai/DeepSeek-V3",
  }),
  novita: openaiCompatible({
    noModelList: true,
    name: "Novita AI",
    description: "Open-model inference — DeepSeek, Qwen, Llama, GLM, Kimi and more, OpenAI-compatible chat.",
    baseUrl: "https://api.novita.ai/openai",
    prefix: "/v1",
    model: "deepseek/deepseek-v3-0324",
  }),
  nebius: openaiCompatible({
    noModelList: true,
    name: "Nebius Token Factory",
    description: "Open-model inference from Nebius (formerly AI Studio) — DeepSeek, Qwen, Llama, gpt-oss, OpenAI-compatible.",
    baseUrl: "https://api.tokenfactory.nebius.com/v1",
    model: "deepseek-ai/DeepSeek-R1-0528",
  }),
  baseten: openaiCompatible({
    name: "Baseten Model APIs",
    description: "Hosted frontier open models (DeepSeek, Kimi, GLM, gpt-oss) on Baseten, OpenAI-compatible.",
    baseUrl: "https://inference.baseten.co/v1",
    model: "openai/gpt-oss-120b",
    extra: { create_response: { method: "POST", path: "/responses", body: { model: "openai/gpt-oss-120b", input: "" } } },
  }),
  cerebras: openaiCompatible({
    name: "Cerebras Inference",
    description: "The fastest inference there is (wafer-scale chips) — gpt-oss, Llama, Qwen, GLM, OpenAI-compatible. Free tier with a daily limit.",
    baseUrl: "https://api.cerebras.ai/v1",
    model: "gpt-oss-120b",
  }),
  nvidia: openaiCompatible({
    name: "NVIDIA NIM",
    description: "NVIDIA-hosted NIM models from build.nvidia.com — Llama, Nemotron, DeepSeek, Qwen, Mistral, OpenAI-compatible. Free credits to start.",
    baseUrl: "https://integrate.api.nvidia.com/v1",
    model: "meta/llama-3.3-70b-instruct",
  }),
  azure_openai: openaiCompatible({
    noModelList: true,
    name: "Azure OpenAI",
    description: "OpenAI models in your own Azure resource (Microsoft Foundry) — the v1 API, where model = your deployment name. Needs the resource name.",
    baseUrl: "https://azure-openai.invalid/openai/v1", // never a real host: with no resource on the record the call fails instead of sending the key anywhere
    baseUrlFor: (creds) => { const r = String(creds?.resource || "").trim().toLowerCase(); return /^[a-z0-9][a-z0-9-]{1,62}$/.test(r) ? `https://${r}.openai.azure.com/openai/v1` : null; },
    credentialKeys: ["apiKey", "resource"],
    model: "",
    caps: [{ name: "embed", actions: ["create"], description: "Text embeddings (an embedding deployment)" }],
    extra: {
      create_response:  { method: "POST", path: "/responses", body: { model: "", input: "" } },
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "", input: "" } },
    },
    authHeader: (creds) => ({ "api-key": creds.apiKey, "Content-Type": "application/json" }),
  }),

  // ═══ MEDIA, VOICE, EMBEDDINGS ═══════════════════════════════════════════════════════════════════════════════════
  fal_ai: {
    name: "fal.ai",
    type: "ai",
    aggregator: true,
    description: "Media model aggregator — one key runs 600+ image, video, audio and 3D models (FLUX, Kling, Veo, Wan…) through a queue: submit, poll status, fetch result.",
    baseUrl: "https://queue.fal.run",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "run_model", actions: ["submit", "status", "result", "cancel"], description: "Queue a model run and collect the result" },
    ],
    endpoints: {
      // model_id is the full id (fal-ai/flux/schnell); status/result/cancel take only owner/app (fal-ai/flux) — or use the URLs the submit returns.
      submit:     { method: "POST", path: "/{model_id}", body: { prompt: "" } },
      get_status: { method: "GET",  path: "/{app_id}/requests/{request_id}/status", query: ["logs"] },
      get_result: { method: "GET",  path: "/{app_id}/requests/{request_id}" },
      cancel:     { method: "PUT",  path: "/{app_id}/requests/{request_id}/cancel" },
    },
    authHeader: (creds) => ({ "Authorization": `Key ${creds.apiKey}`, "Content-Type": "application/json" }),
  },
  runway: {
    name: "Runway",
    type: "ai",
    description: "AI video and images — Gen-4 image-to-video and text-to-image; tasks run async, poll get_task.",
    baseUrl: "https://api.dev.runwayml.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "generate_video", actions: ["create"], description: "Image to video" },
      { name: "generate_image", actions: ["create"], description: "Text to image" },
      { name: "tasks", actions: ["get", "cancel"], description: "Check or cancel a generation" },
    ],
    endpoints: {
      image_to_video: { method: "POST", path: "/v1/image_to_video", body: { model: "gen4_turbo", promptImage: "", promptText: "", ratio: "1280:720" } },
      text_to_image:  { method: "POST", path: "/v1/text_to_image", body: { model: "gen4_image", promptText: "", ratio: "1920:1080" } },
      get_task:       { method: "GET",  path: "/v1/tasks/{id}" },
      cancel_task:    { method: "DELETE", path: "/v1/tasks/{id}" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "X-Runway-Version": "2024-11-06", "Content-Type": "application/json" }),
  },
  luma: {
    name: "Luma AI",
    type: "ai",
    description: "Dream Machine video generation (Ray 2) — create a generation, then poll it until completed.",
    baseUrl: "https://api.lumalabs.ai/dream-machine/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "generate_video", actions: ["create", "get"], description: "Text or image to video" }],
    endpoints: {
      create_video:   { method: "POST", path: "/generations/video", body: { model: "ray-2", prompt: "" } },
      get_generation: { method: "GET",  path: "/generations/{id}" },
    },
    authHeader: bearer,
  },
  ideogram: {
    name: "Ideogram",
    type: "ai",
    description: "Image generation that gets text in pictures right (logos, posters) — Ideogram 3; returns image URLs that expire.",
    baseUrl: "https://api.ideogram.ai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "generate_image", actions: ["create"], description: "Text to image" }],
    endpoints: {
      generate_image: { method: "POST", path: "/v2/image/generate/{model}", body: { model: "ideogram-3", prompt: "" } },
    },
    authHeader: (creds) => ({ "Api-Key": creds.apiKey, "Content-Type": "application/json" }),
  },
  leonardo: {
    name: "Leonardo.ai",
    type: "ai",
    description: "Image generation with Leonardo's models (Phoenix, Lucid, FLUX) — create a generation, poll it, list models. Needs API credits.",
    baseUrl: "https://cloud.leonardo.ai/api/rest/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "generate_image", actions: ["create", "get"], description: "Text to image" }, { name: "models", actions: ["list"], description: "List models" }],
    endpoints: {
      create_generation: { method: "POST", path: "/generations", body: { prompt: "", modelId: "", width: 1024, height: 1024, num_images: 1 } },
      get_generation:    { method: "GET",  path: "/generations/{id}" },
      list_models:       { method: "GET",  baseUrl: "https://cloud.leonardo.ai/api/rest/v2", path: "/models" },
    },
    authHeader: bearer,
  },
  bfl: {
    name: "Black Forest Labs (FLUX)",
    type: "ai",
    description: "FLUX image generation from the people who make it — submit returns an id and a polling_url to read the result from.",
    baseUrl: "https://api.bfl.ai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "generate_image", actions: ["create"], description: "Text to image (FLUX.2)" }],
    endpoints: {
      // The model is the path: flux-2-pro, flux-2-pro-preview, flux-kontext-pro … Read the result from the polling_url it returns.
      generate_image: { method: "POST", path: "/v1/{model}", body: { model: "flux-2-pro-preview", prompt: "", width: 1024, height: 1024 } },
    },
    authHeader: (creds) => ({ "x-key": creds.apiKey, "Content-Type": "application/json" }),
  },
  assemblyai: {
    name: "AssemblyAI",
    type: "ai",
    description: "Speech to text — transcribe a recording from a URL (speakers, summaries, PII redaction), then poll the transcript.",
    baseUrl: "https://api.assemblyai.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "transcribe", actions: ["create", "get", "list", "delete"], description: "Transcribe audio" }],
    endpoints: {
      create_transcript: { method: "POST", path: "/v2/transcript", body: { audio_url: "" } },
      get_transcript:    { method: "GET",  path: "/v2/transcript/{transcript_id}" },
      list_transcripts:  { method: "GET",  path: "/v2/transcript", query: ["limit", "status"] },
      delete_transcript: { method: "DELETE", path: "/v2/transcript/{transcript_id}" },
    },
    authHeader: (creds) => ({ "Authorization": creds.apiKey, "Content-Type": "application/json" }),
  },
  cartesia: {
    name: "Cartesia",
    type: "ai",
    description: "Realtime text to speech (Sonic) — speak text in any voice; list voices. Returns audio bytes.",
    baseUrl: "https://api.cartesia.ai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "text_to_speech", actions: ["create"], description: "Text to speech" }, { name: "voices", actions: ["list"], description: "List voices" }],
    endpoints: {
      text_to_speech: { method: "POST", path: "/tts/bytes", body: { model_id: "sonic-3", transcript: "", voice: { mode: "id", id: "" }, output_format: { container: "wav", encoding: "pcm_s16le", sample_rate: 44100 } } },
      list_voices:    { method: "GET",  path: "/voices" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Cartesia-Version": "2026-08-14", "Content-Type": "application/json" }),
  },
  voyage: {
    name: "Voyage AI",
    type: "ai",
    description: "Top-ranked embeddings and rerankers for search and RAG (voyage-4, voyage-code-3, rerank-2.5).",
    baseUrl: "https://api.voyageai.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "embed", actions: ["create"], description: "Text embeddings" }, { name: "rerank", actions: ["rerank"], description: "Rerank documents" }],
    endpoints: {
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "voyage-4", input: [] } },
      rerank:           { method: "POST", path: "/rerank", body: { model: "rerank-2.5", query: "", documents: [] } },
    },
    authHeader: bearer,
  },
  jina: {
    name: "Jina AI",
    type: "ai",
    description: "Search foundation models — multilingual and multimodal embeddings, rerankers, and the Reader (any URL → clean markdown). One key for all.",
    baseUrl: "https://api.jina.ai/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [{ name: "embed", actions: ["create"], description: "Embeddings" }, { name: "rerank", actions: ["rerank"], description: "Rerank documents" }, { name: "read", actions: ["get"], description: "Read a web page as markdown" }],
    endpoints: {
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "jina-embeddings-v3", input: [] } },
      rerank:           { method: "POST", path: "/rerank", body: { model: "jina-reranker-v2-base-multilingual", query: "", documents: [], top_n: 3 } },
      // The target page is one whole segment so its own slashes and query survive: r.jina.ai/https://example.com/x
      read_url:         { method: "GET",  baseUrl: "https://r.jina.ai", path: "/{url}", wholeSegment: ["url"] },
    },
    authHeader: bearer,
  },
};
