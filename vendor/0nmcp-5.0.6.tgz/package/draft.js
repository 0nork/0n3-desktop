/**
 * DRAFT — the builder's "Describe it": the person says what the product, page or sequence is for, the AI they
 * connected (their own key, never ours) answers with a spec in the builder's vocabulary, and this module turns the
 * spec into real documents: pages of elements, sequences of blocks, and the board that links them.
 *
 * The model only ever names things that exist (SHAPES, TASKS, TRIGGERS, LOGIC, DATA, AI keys and the apps each task
 * allows); anything else is dropped, never invented. Layout is ours: elements stack inside a section, blocks are
 * laid out by wire order. The result is what the builder would have made by hand, so every downstream reader
 * (engine, live page, build plan) is unchanged.
 */
import { SHAPES, TASKS, TRIGGERS, LOGIC, DATA, AI, mkNode, tidy, uid, nameOf, parseWait } from './flow-defs.js';
import { complete } from './chat.js';

const MAX_ELS = 24; const MAX_BLOCKS = 16;
const list = (map) => Object.entries(map).map(([k, d]) => `${k}${d.apps ? ` (apps: ${d.apps.join(', ')}; default ${d.rec})` : ''}${d.fields?.length ? ` · fields: ${d.fields.map((f) => f[0]).join(', ')}` : ''}`).join('\n');

export function draftSystemPrompt(kind) {
  const common = `You draft for the 0n3 visual builder. Answer with ONE JSON object and nothing else. Use only the keys listed; never invent keys, apps or fields. Short, plain, sentence-case copy. No emoji.

PAGE ELEMENTS (type "shape"), key · fields:
${Object.entries(SHAPES).filter(([k]) => k !== 'box').map(([k, d]) => `${k} · ${d.fields.map((f) => f[0]).join(', ') || '(none)'}${d.apps ? ` · apps: ${d.apps.join(', ')}` : ''}`).join('\n')}
A page element: { "type": "shape", "key": "<key>", "values": { ...fields }, "access": { "<app>": ["read"|"create"|"update"|"delete"] } (only on button/chat/input/datetime/textarea), "w": <px optional>, "h": <px optional> }.
A page needs one "section" first, then a "heading", then the rest; a "button" that starts a sequence must carry values.runs = the sequence name; a "sticky" is a note for the AI, not shown to customers.

FLOW BLOCKS:
triggers (type "trigger"): ${list(TRIGGERS)}
tasks (type "task"): ${list(TASKS)}
logic (type "logic"): ${list(LOGIC)}
data (type "data"): ${list(DATA)}
ai (type "ai"): ${list(AI)}
A block: { "type": "<trigger|task|logic|data|ai>", "key": "<key>", "title": "<short>", "app": "<one of the allowed apps>", "values": { ...fields, templates like {{trigger.email}} allowed } }.
A sequence starts with exactly one trigger; a sequence a page button fires starts with trigger "page_button" whose values.name is the button's values.runs. Edges: { "from": <block index>, "to": <block index>, "port": 0 } (ifelse port 1 = No). When the next step should happen LATER (a follow-up in 2 days, a reminder a week on), put the time on that edge: { "from": 1, "to": 2, "port": 0, "wait": "2 days" } (minutes, hours, days or weeks). A sequence can run over weeks this way; do not use a separate Wait block for it.`;
  if (kind === 'page') return `${common}\n\nReturn: { "name": "<page name>", "nodes": [ ...page elements ] }`;
  if (kind === 'sequence') return `${common}\n\nReturn: { "name": "<sequence name>", "nodes": [ ...blocks ], "edges": [ ... ] }`;
  return `${common}\n\nReturn the whole product: { "name": "<workspace name>", "pages": [ { "name", "nodes": [ ...page elements ] } ], "sequences": [ { "name", "nodes": [ ...blocks ], "edges": [ ... ] } ], "notes": [ "<a note for the AI about the build>" ] }. Two or three pages and the sequences their buttons fire is a good product; every button's values.runs must name one of the sequences.`;
}

const str = (v, max = 400) => (v === undefined || v === null ? '' : String(v).slice(0, max));
const cleanValues = (v) => (v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).slice(0, 16).map(([k, x]) => [str(k, 40), typeof x === 'string' ? str(x, 2000) : x])) : {});
const cleanAccess = (a) => (a && typeof a === 'object' ? Object.fromEntries(Object.entries(a).slice(0, 12).map(([k, sc]) => [str(k, 40), Array.isArray(sc) ? sc.map(String).filter((x) => ['read', 'create', 'update', 'delete', 'run'].includes(x)) : []])) : undefined);

/** Page elements from a spec: a section band, the rest stacked in two columns (chat on the right), notes outside. */
export function buildPage(spec, fallbackName = 'New page') {
  const raw = Array.isArray(spec?.nodes) ? spec.nodes.filter((n) => n && n.type === 'shape' && SHAPES[n.key]).slice(0, MAX_ELS) : [];
  const name = str(spec?.name, 80) || fallbackName;
  const els = raw.filter((n) => n.key !== 'section' && n.key !== 'sticky' && n.key !== 'chat');
  const chat = raw.find((n) => n.key === 'chat'); const notes = raw.filter((n) => n.key === 'sticky');
  const secSpec = raw.find((n) => n.key === 'section');
  const nodes = []; let y = 96; const left = 64; const colW = 400;
  for (const n of els) { const d = SHAPES[n.key]; const w = Math.min(colW, Number(n.w) || d.w); const h = Number(n.h) || d.h; nodes.push(mkNode('shape', n.key, left, y, { w, h, values: cleanValues(n.values), access: cleanAccess(n.access) })); y += h + 16; }
  if (chat) nodes.push(mkNode('shape', 'chat', 496, 96, { w: 272, h: Math.max(360, Math.min(560, y - 96)), values: cleanValues(chat.values), access: cleanAccess(chat.access), app: AI.ai.apps.includes(chat.app) ? chat.app : undefined }));
  const secH = Math.max(y + 16, chat ? 96 + Math.max(360, Math.min(560, y - 96)) + 32 : 0, 240);
  const sec = mkNode('shape', 'section', 32, 32, { w: 768, h: secH, values: { title: str(secSpec?.values?.title, 80) || name } });
  notes.forEach((n, i) => nodes.push(mkNode('shape', 'sticky', 840, 40 + i * 190, { values: { text: str(n.values?.text, 600) } })));
  return { id: uid(), name, nodes: [sec, ...nodes], edges: [] };
}

/** Flow blocks from a spec: valid types and keys only, allowed app or the default, wires by index, then laid out. */
export function buildSequence(spec, fallbackName = 'New sequence') {
  const TYPE = { trigger: TRIGGERS, task: TASKS, logic: LOGIC, data: DATA, ai: AI };
  const raw = Array.isArray(spec?.nodes) ? spec.nodes : [];
  const made = []; const index = new Map();
  raw.slice(0, MAX_BLOCKS).forEach((n, i) => {
    if (!n || !TYPE[n.type] || !TYPE[n.type][n.key]) return;
    const d = TYPE[n.type][n.key];
    const app = d.apps && d.apps.includes(n.app) ? n.app : (d.apps ? d.rec : undefined);
    const node = mkNode(n.type, n.key, 40 + made.length * 340, 160, { title: str(n.title, 80) || undefined, app, values: cleanValues(n.values) });
    index.set(i, node.id); made.push(node);
  });
  if (!made.length) return null;
  if (!made.some((n) => n.type === 'trigger')) { const t = mkNode('trigger', 'page_button', 40, 160, { values: { name: str(spec?.name, 80) || fallbackName } }); made.unshift(t); for (const k of [...index.keys()]) index.set(k, index.get(k)); index.set(-1, t.id); }
  const edges = (Array.isArray(spec?.edges) ? spec.edges : []).map((e) => ({ from: index.get(Number(e.from)), to: index.get(Number(e.to)), port: Number(e.port) || 0, ...(parseWait(e.wait) ? { wait: String(e.wait).trim().slice(0, 40) } : {}) })).filter((e) => e.from && e.to && e.from !== e.to);
  // No wires given: chain them in order.
  if (!edges.length && made.length > 1) for (let i = 0; i < made.length - 1; i++) edges.push({ from: made[i].id, to: made[i + 1].id, port: 0 });
  // A trigger that was added in front gets a wire into the first real block.
  if (index.has(-1) && made.length > 1 && !edges.some((e) => e.from === made[0].id)) edges.unshift({ from: made[0].id, to: made[1].id, port: 0 });
  return { id: uid(), name: str(spec?.name, 80) || fallbackName, nodes: tidy(made, edges), edges };
}

/** A whole board: pages, sequences, items laid out in two columns, links from each button to the sequence it names, notes. */
export function buildBoard(spec, fallbackName = 'New workspace') {
  const pages = (Array.isArray(spec?.pages) ? spec.pages : []).slice(0, 6).map((p, i) => buildPage(p, `Page ${i + 1}`));
  const sequences = (Array.isArray(spec?.sequences) ? spec.sequences : []).slice(0, 8).map((q, i) => buildSequence(q, `Sequence ${i + 1}`)).filter(Boolean);
  const items = []; const links = [];
  items.push({ id: uid(), kind: 'heading', x: 64, y: 32, w: 420, h: 40, text: str(spec?.name, 80) || fallbackName });
  pages.forEach((p, i) => items.push({ id: uid(), kind: 'page', ref: p.id, x: 64, y: 96 + i * 336, w: 320, h: 280 }));
  sequences.forEach((q, i) => items.push({ id: uid(), kind: 'seq', ref: q.id, x: 576, y: 128 + i * 248, w: 336, h: 200 }));
  (Array.isArray(spec?.notes) ? spec.notes : []).slice(0, 4).forEach((t, i) => items.push({ id: uid(), kind: 'note', x: 992, y: 96 + i * 208, w: 224, h: 176, text: str(t, 600) }));
  for (const p of pages) {
    const pi = items.find((it) => it.kind === 'page' && it.ref === p.id);
    for (const b of p.nodes.filter((n) => n.key === 'button')) {
      const want = str(b.values?.runs, 80).trim().toLowerCase(); if (!want) continue;
      const q = sequences.find((x) => x.name.trim().toLowerCase() === want || x.nodes.some((n) => n.key === 'page_button' && str(n.values?.name, 80).trim().toLowerCase() === want));
      const si = q && items.find((it) => it.kind === 'seq' && it.ref === q.id);
      if (si) links.push({ id: uid(), from: pi.id, el: b.id, to: si.id });
    }
  }
  return { name: str(spec?.name, 80) || fallbackName, pages, sequences, board: { items, links } };
}

export function parseSpec(text) {
  const t = String(text || '').trim();
  const body = t.startsWith('{') ? t : (t.match(/\{[\s\S]*\}/) || [''])[0];
  try { const v = JSON.parse(body); return v && typeof v === 'object' ? normaliseKeys(v) : null; } catch { return null; }
}
/** Models number what they repeat ("section1", "heading_2", "button 3"); the vocabulary has no numbers. Measured 2026-11-04 on
 *  openai/gpt-oss-120b: every element of a four-element page was dropped and the page shipped as one empty section. */
const KEY_SUFFIX = /[\s_\-]*\d+$/;
const normKey = (k) => String(k || '').trim().toLowerCase().replace(KEY_SUFFIX, '').replace(/[\s\-]+/g, '_');
function normaliseKeys(v) {
  const fix = (n) => (n && typeof n === 'object' && typeof n.key === 'string' ? { ...n, key: normKey(n.key) } : n);
  const doc = (d) => (d && typeof d === 'object' && Array.isArray(d.nodes) ? { ...d, nodes: d.nodes.map(fix) } : d);
  const out = doc(v);
  if (Array.isArray(out.pages)) out.pages = out.pages.map(doc);
  if (Array.isArray(out.sequences)) out.sequences = out.sequences.map(doc);
  return out;
}

/**
 * @param {{ kind: 'board'|'page'|'sequence', prompt: string, brand?: string, ai: { provider: string, apiKey: string|null, model?: string }, fetchImpl?: typeof fetch }} o
 */
export async function draft({ kind, prompt, brand = 'Acme', ai, fetchImpl = fetch, sequences = [] }) {
  const k = ['board', 'page', 'sequence'].includes(kind) ? kind : 'board';
  const have = (Array.isArray(sequences) ? sequences : []).map((x) => String(x || '').trim()).filter(Boolean).slice(0, 20);
  const user = `Brand: ${brand}.\nWhat it is for: ${String(prompt || '').slice(0, 2000)}${have.length && k !== 'sequence' ? `\nSequences that already exist in this workspace (a button's values.runs must be one of these names, exactly): ${have.map((x) => JSON.stringify(x)).join(', ')}` : ''}`;
  // ai.run = the AI router (fallback across the person's AIs, their order); without it, the one provider named.
  const ask = () => (ai.run ? ai.run({ system: draftSystemPrompt(k), user }) : complete({ provider: ai.provider, apiKey: ai.apiKey, model: ai.model, system: draftSystemPrompt(k), user, fetchImpl }));
  let out = await ask();
  if (out.error) return { error: out.error, missing: out.missing };
  let spec = parseSpec(out.text);
  // Reasoning models (gpt-oss on Groq) sometimes spend the whole turn in `reasoning` and hand back an EMPTY content string with
  // finish_reason stop (measured 2026-11-04, 1 in ~3 board drafts). One more ask is cheaper than telling the person to retry.
  if (!spec) { out = await ask(); if (out.error) return { error: out.error, missing: out.missing }; spec = parseSpec(out.text); }
  if (!spec) return { error: `${nameOf(out.provider || ai.provider)} did not answer with a usable spec. Try again, or say it more plainly.`, raw: String(out.text || '').slice(0, 400) };
  const result = k === 'page' ? { page: buildPage(spec) } : k === 'sequence' ? { sequence: buildSequence(spec) } : { board: buildBoard(spec, brand) };
  if (k === 'sequence' && !result.sequence) return { error: 'The answer had no usable blocks.' };
  return { ok: true, kind: k, model: out.model, ...(out.provider ? { provider: out.provider, tried: out.tried } : {}), ...result };
}
