/**
 * HQ — the account side of 0n3.app: session exchange, the 0n token, scoped
 * tokens, connect flows, support. Everything the vault page and the token
 * page need, on the same server that runs the tools.
 *
 * Two kinds of bearer:
 *   • a Supabase session JWT (from the browser after sign-in) — accepted ONLY
 *     by POST /api/session, which turns it into the account's 0n token
 *   • the 0n token — everything else, resolved by identity.js like /mcp
 *
 * The master token format is 0nCore's (`0n_live_<8 hash>_<16 random>_<4 check>`)
 * and every mint is also registered in api_tokens (channel 'profile'), so the
 * extension exchange on 0nCore keeps working. Scoped tokens are rows in
 * access_tokens with the columns that table actually has.
 */
import { createHash, randomBytes, createHmac, timingSafeEqual } from 'node:crypto';
import { listServices, getService } from './catalog.js';
import { makeConnection } from './envelope.js';
import { provisionCrm } from './crm-provision.js';
import { listRemoteTools, assertSafeUrl, redact } from './mcp-exec.js';
import { parseScopes, scopesAllowed, openidConfiguration, idToken, userClaims } from './oidc.js';
import { MORE_DOORS, GOOGLE_EXTRA } from './oauth-doors.js';
import { guideFor } from './connect-guides.js';

const ALPHANUM = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
const sha256 = (s) => createHash('sha256').update(s).digest('hex');

export function buildMasterToken(userId) {
  const userHash = sha256(userId).slice(0, 8);
  const buf = randomBytes(16); let rnd = '';
  for (let i = 0; i < 16; i++) rnd += ALPHANUM[buf[i] % ALPHANUM.length];
  const check = sha256(`0n_live_${userHash}_${rnd}`).slice(-4);
  return `0n_live_${userHash}_${rnd}_${check}`;
}
export const maskToken = (t) => (t ? `${t.slice(0, 12)}…${t.slice(-4)}` : null);
/**
 * TOKENS ARE STORED ONLY AS HASHES (2026-10-29). access_tokens.token is NOT NULL + UNIQUE in the shared schema, so it
 * carries `h:<sha256>` — unique, and useless to anyone who reads the table. Lookups go by token_hash. The masked form a
 * person sees in their token list is kept in metadata.mask at creation, because it cannot be rebuilt from a hash.
 */
export const storedToken = (raw) => ({ token: `h:${sha256(raw)}`, token_hash: sha256(raw) });
const maskOf = (r) => r?.metadata?.mask || (r?.token && !String(r.token).startsWith('h:') ? maskToken(r.token) : '0n_…');

/** Verify a Supabase session JWT against the auth server. Returns the auth user or null. */
export async function supabaseUser(jwt, { url, serviceKey, fetchImpl = fetch }) {
  if (!jwt || !url || !serviceKey) return null;
  const r = await fetchImpl(`${url.replace(/\/$/, '')}/auth/v1/user`, { headers: { apikey: serviceKey, Authorization: `Bearer ${jwt}` } });
  if (!r.ok) return null;
  const u = await r.json().catch(() => null);
  return u && u.id ? u : null;
}


// ── OAuth doors, declared not coded ─────────────────────────────────────────
// Adding a provider that speaks standard OAuth2 = one entry here + two env vars
// + the redirect URI registered on the provider's side. See docs/OAUTH-DOOR-PROTOCOL.md.
const MS_AUTH = 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize';
const MS_TOKEN = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
// What a CardFlow parent grants: list + manage inventory, offers and orders, marketing, finances, identity.
export const EBAY_SCOPES = [
  'https://api.ebay.com/oauth/api_scope',
  // list + price + ship
  'https://api.ebay.com/oauth/api_scope/sell.inventory',
  'https://api.ebay.com/oauth/api_scope/sell.inventory.readonly',
  'https://api.ebay.com/oauth/api_scope/sell.account',
  'https://api.ebay.com/oauth/api_scope/sell.account.readonly',
  'https://api.ebay.com/oauth/api_scope/sell.fulfillment',
  'https://api.ebay.com/oauth/api_scope/sell.fulfillment.readonly',
  // best offers + negotiations (Tier B BINs auto-accept at a floor)
  'https://api.ebay.com/oauth/api_scope/sell.offer',
  // promoted listings
  'https://api.ebay.com/oauth/api_scope/sell.marketing',
  'https://api.ebay.com/oauth/api_scope/sell.marketing.readonly',
  // P&L: payouts, fees, performance, feedback
  'https://api.ebay.com/oauth/api_scope/sell.finances',
  'https://api.ebay.com/oauth/api_scope/sell.analytics.readonly',
  'https://api.ebay.com/oauth/api_scope/sell.reputation.readonly',
  // sold / returned / cancelled / disputed — pushed to us instead of polled
  'https://api.ebay.com/oauth/api_scope/commerce.notification.subscription',
  'https://api.ebay.com/oauth/api_scope/commerce.notification.subscription.readonly',
  'https://api.ebay.com/oauth/api_scope/sell.return.read',
  'https://api.ebay.com/oauth/api_scope/sell.cancellation.read',
  'https://api.ebay.com/oauth/api_scope/sell.payment.dispute',
  // buyer questions
  'https://api.ebay.com/oauth/api_scope/commerce.message',
  // who this record is
  'https://api.ebay.com/oauth/api_scope/commerce.identity.readonly',
];
export const OAUTH_DOORS = {
  // eBay speaks OAuth2 with two quirks, declared here rather than special-cased in the flow:
  //   • redirect_uri is the RuName (eBay's name for the registered redirect), not the callback URL
  //   • the token endpoint wants HTTP Basic client_id:client_secret, and refuses them in the body
  // Refresh tokens live 18 months; access tokens 2 h — tokens.js mints per call.
  ebay: {
    service: 'ebay', authType: 'oauth',
    clientId: (e) => e.EBAY_CLIENT_ID, clientSecret: (e) => e.EBAY_CLIENT_SECRET,
    authorizeUrl: (e) => (e.EBAY_ENV === 'SANDBOX' ? 'https://auth.sandbox.ebay.com/oauth2/authorize' : 'https://auth.ebay.com/oauth2/authorize'),
    tokenUrl: (e) => (e.EBAY_ENV === 'SANDBOX' ? 'https://api.sandbox.ebay.com/identity/v1/oauth2/token' : 'https://api.ebay.com/identity/v1/oauth2/token'),
    redirectValue: (e) => e.EBAY_RUNAME,
    tokenAuth: 'basic',
    scope: EBAY_SCOPES.join(' '),
    identity: async (fetchImpl, accessToken, e = {}) => {
      const host = e.EBAY_ENV === 'SANDBOX' ? 'https://apiz.sandbox.ebay.com' : 'https://apiz.ebay.com';
      const me = await (await fetchImpl(`${host}/commerce/identity/v1/user/`, { headers: { Authorization: `Bearer ${accessToken}` } })).json().catch(() => ({}));
      return { name: me.username ? `eBay · ${me.username}` : 'eBay', meta: { username: me.username || null, user_id: me.userId || null, account_type: me.accountType || null, registration_marketplace: me.registrationMarketplaceId || null, env: e.EBAY_ENV || 'PRODUCTION' }, credentials: { env: e.EBAY_ENV || 'PRODUCTION', marketplace_id: e.EBAY_MARKETPLACE_ID || 'EBAY_US' } };
    },
  },
  microsoft: {
    service: 'microsoft', authType: 'oauth',
    clientId: (e) => e.MICROSOFT_CLIENT_ID, clientSecret: (e) => e.MICROSOFT_CLIENT_SECRET,
    authorizeUrl: MS_AUTH, tokenUrl: MS_TOKEN,
    scope: 'openid profile email offline_access User.Read Mail.ReadWrite Mail.Send Calendars.ReadWrite Files.ReadWrite.All Team.ReadBasic.All Channel.ReadBasic.All ChannelMessage.Send',
    extra: { response_mode: 'query', prompt: 'select_account' },
    // What the record is named and what goes in meta, from a first call with the fresh token.
    identity: async (fetchImpl, accessToken) => {
      const me = await (await fetchImpl('https://graph.microsoft.com/v1.0/me', { headers: { Authorization: `Bearer ${accessToken}` } })).json().catch(() => ({}));
      const email = me.mail || me.userPrincipalName || null;
      return { name: email ? `Microsoft 365 · ${email}` : 'Microsoft 365', meta: { email, display_name: me.displayName || null, tenant: me.id ? undefined : undefined } };
    },
  },
  azure: {
    service: 'azure', authType: 'oauth',
    clientId: (e) => e.MICROSOFT_CLIENT_ID, clientSecret: (e) => e.MICROSOFT_CLIENT_SECRET,
    authorizeUrl: MS_AUTH, tokenUrl: MS_TOKEN,
    scope: 'openid profile email offline_access https://management.azure.com/user_impersonation',
    extra: { response_mode: 'query', prompt: 'select_account' },
    identity: async (fetchImpl, accessToken) => {
      const subs = await (await fetchImpl('https://management.azure.com/subscriptions?api-version=2022-12-01', { headers: { Authorization: `Bearer ${accessToken}` } })).json().catch(() => ({}));
      const list = (subs.value || []).map((x) => ({ id: x.subscriptionId, name: x.displayName, state: x.state }));
      const first = list[0];
      return { name: first ? `Azure · ${first.name}` : 'Azure', meta: { subscriptions: list }, credentials: first ? { subscriptionId: first.id } : {} };
    },
  },  ...MORE_DOORS,
};

/**
 * YOUR 0n3 BOT (2026-11-23, Mike: "personalize your 0n3 Bot"). One per account, read by every place the bot talks: the
 * HQ chat (/api/bot/chat), the terminal (`0n3`), and desk runs. Plain fields, bounded, never instructions to bypass rules.
 */
export const BOT_TONES = ['friendly', 'direct', 'professional', 'playful'];
export function cleanBot(b = {}) {
  const t = (v, n) => String(v ?? '').replace(/\s+$/g, '').slice(0, n);
  return { name: t(b.name, 40).trim() || '0n3 Bot', tone: BOT_TONES.includes(b.tone) ? b.tone : 'friendly', about: t(b.about, 2000), always: t(b.always, 2000), ask: t(b.ask, 2000), never: t(b.never, 2000) };
}

export class Hub {
  /** @param {{ rest: any, store: any, supabase: { url: string, serviceKey: string }, internalSecret: string, baseUrl: string, env?: Record<string,string|undefined>, fetchImpl?: typeof fetch }} o */
  constructor({ rest, store, supabase, internalSecret, baseUrl, env = process.env, fetchImpl = fetch }) {
    this.rest = rest; this.store = store; this.sb = supabase; this.secret = internalSecret || ''; this.base = baseUrl.replace(/\/$/, ''); this.env = env; this.fetch = fetchImpl;
  }

  // ── identity ────────────────────────────────────────────────────────────
  async profileOf(userId) {
    return (await this.rest.select('profiles', { id: userId }, 'id, email, full_name, crm_location_id, access_token, created_at'))[0] || null;
  }

  async ensureProfile(authUser) {
    let p = await this.profileOf(authUser.id);
    if (p) return p;
    await this.rest.insert('profiles', { id: authUser.id, email: authUser.email || null, full_name: authUser.user_metadata?.full_name || authUser.user_metadata?.name || null, created_at: new Date().toISOString() });
    p = await this.profileOf(authUser.id);
    // EVERY NEW ACCOUNT GETS ITS 0ncore CRM (base tier). Sign-in never waits on a failure: the result lands on the profile and the next session retries.
    if (p) { try { const r = await provisionCrm({ profile: p, store: this.store, rest: this.rest, env: this.env, fetchImpl: this.fetch }); console.log('[hub] crm provision', p.email, JSON.stringify(r).slice(0, 200)); } catch (e) { console.error('[hub] crm provision threw:', e.message); } }
    return p;
  }
  /** The same step on demand (an older account, a retry): idempotent. */
  async provisionCrmFor(userId) { const p = await this.profileOf(userId); if (!p) return { ok: false, reason: 'no profile' }; const full = (await this.rest.select('profiles', { id: userId }, 'id, email, full_name, business_name, crm_location_id'))[0] || p; return provisionCrm({ profile: full, store: this.store, rest: this.rest, env: this.env, fetchImpl: this.fetch }); }

  async mintMaster(userId, locationId = '') {
    const raw = buildMasterToken(userId);
    const now = new Date().toISOString();
    await this.rest.update('profiles', { id: userId }, { access_token: raw, token_created_at: now, access_token_rotated_at: now });
    try {
      await this.rest.update('api_tokens', { user_id: userId, channel: 'profile', revoked: false }, { revoked: true, revoked_at: now });
      await this.rest.insert('api_tokens', { user_id: userId, location_id: locationId || '', name: 'Universal 0n key', token_prefix: raw.slice(0, 16), token_hash: sha256(raw), channel: 'profile', revoked: false });
    } catch (e) { console.error('[hub] api_tokens registration failed:', e.message); }
    return raw;
  }

  /** POST /api/session — Supabase JWT → account + 0n token (minted on first visit). */
  async session(jwt) {
    const u = await supabaseUser(jwt, { url: this.sb.url, serviceKey: this.sb.serviceKey, fetchImpl: this.fetch });
    if (!u) return { status: 401, body: { error: 'Sign in first.' } };
    const p = await this.ensureProfile(u);
    if (!p) return { status: 500, body: { error: 'Could not load your account.' } };
    const token = p.access_token || (await this.mintMaster(p.id, p.crm_location_id || ''));
    let records = await this.store.list(p.id);
    // EVERY ACCOUNT GETS ITS CRM (2026-10-29 fix): the sign-up trigger creates the profile before 0n3 ever sees it, so the
    // create-time call above never fired — 21 sign-ups in a week, 0 provisioned, 0 errors. Any sign-in without a CRM asks now.
    // A brand-new account goes through onboarding, which names the CRM after the business; give it an hour before the
    // safety net provisions one named after the email.
    // A 0nCore sign-up already HAS its sub-account (0nCore made it at the email click), so it links on the first sign-in, no wait.
    const fresh = !p.crm_location_id && p.created_at && Date.now() - new Date(p.created_at).getTime() < 3600e3;
    if (!records.some((r) => r.service === 'crm') && !fresh) {
      try { const r = await provisionCrm({ profile: p, store: this.store, rest: this.rest, env: this.env, fetchImpl: this.fetch, timeoutMs: 12_000 }); console.log('[hub] crm provision (session)', p.email, JSON.stringify(r).slice(0, 200)); if (r.ok && !r.skipped) records = await this.store.list(p.id); } catch (e) { console.error('[hub] crm provision (session)', e.message); }
    }
    return { status: 200, body: { account: { id: p.id, email: p.email || u.email || null, name: p.full_name || null, since: p.created_at || null, crmLocationId: p.crm_location_id || null }, token, connected: [...new Set(records.map((r) => r.service))], records: records.length } };
  }

  // ── tokens ──────────────────────────────────────────────────────────────
  async listTokens(accountId) {
    const rows = await this.rest.select('access_tokens', { user_id: accountId }, 'id, token, name, permission_level, scopes, source, expires_at, is_active, revoked_at, last_used_at, created_at, metadata');
    return rows.map((r) => ({ id: r.id, name: r.name, level: r.permission_level, scopes: r.scopes || [], source: r.source, prefix: maskOf(r), expiresAt: r.expires_at, active: r.is_active !== false && !r.revoked_at, lastUsedAt: r.last_used_at, createdAt: r.created_at }))
      .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  }
  async createToken(accountId, { name, level = 'full', expiresInDays = null, scopes = ['mcp'] }) {
    const lvl = ['simple', 'full', 'admin', 'temporary'].includes(level) ? level : 'full';
    const raw = `0n_${randomBytes(24).toString('hex')}`;
    const expires = expiresInDays ? new Date(Date.now() + Number(expiresInDays) * 86400000).toISOString() : null;
    await this.rest.insert('access_tokens', { user_id: accountId, ...storedToken(raw), name: String(name || 'Token').slice(0, 80), permission_level: lvl, scopes, source: 'console', expires_at: expires, is_active: true, metadata: { mask: maskToken(raw) } });
    return { token: raw, name, level: lvl, expiresAt: expires };
  }
  /**
   * ONE LIVE KEY PER PROGRAM, NOT ONE PER VISIT (2026-11-24). /get re-ran its AI setup on every visit and minted a fresh key
   * for each AI it found: Mike had 107 "Claude Code" keys. After a new install key, older keys for the same program are
   * retired when they were not used in 30 days. A key never used at all is retired after 2 days, but only once
   * last_used_at has been recorded for 3 days (it was never written before 2026-11-24), so a key in daily use elsewhere
   * has had time to show it. The 3 newest are always kept.
   */
  async retireStaleInstallKeys(accountId, clientName) {
    const base = `${clientName} · `; const now = Date.now(); const trackingOn = now > Date.parse('2026-11-27T00:00:00Z');
    const rows = (await this.rest.select('access_tokens', { user_id: accountId, source: 'console' }, 'id, name, is_active, revoked_at, last_used_at, created_at'))
      .filter((r) => r.is_active !== false && !r.revoked_at && String(r.name || '').startsWith(base))
      .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at))).slice(3);
    const at = new Date().toISOString(); let n = 0;
    for (const r of rows) {
      const used = r.last_used_at ? Date.parse(r.last_used_at) : 0; const made = Date.parse(r.created_at) || now;
      const stale = used ? now - used > 30 * 86400000 : trackingOn && now - made > 2 * 86400000;
      if (stale) { await this.rest.update('access_tokens', { id: r.id }, { is_active: false, revoked_at: at, revoked_reason: `replaced by a newer ${clientName} key` }); n += 1; }
    }
    return n;
  }
  async revokeToken(accountId, id) {
    await this.rest.update('access_tokens', { id, user_id: accountId }, { is_active: false, revoked_at: new Date().toISOString(), revoked_reason: 'revoked from 0n3 HQ' });
  }


  // ── OAuth 2.1 authorization server for MCP clients ─────────────────────
  // claude.ai, ChatGPT and other hosted clients cannot send a static bearer;
  // they discover /.well-known/oauth-authorization-server, register
  // themselves, send the user to /oauth/authorize and exchange the code at
  // /oauth/token. The access token they receive IS a scoped 0n token (an
  // access_tokens row, level full, scope mcp, 90 days), so /mcp needs no
  // second identity path. PKCE S256 is required; codes and refresh tokens
  // are stored hashed.
  oauthMetadata() { return openidConfiguration(this.base, this.env); }
  openidConfiguration() { return openidConfiguration(this.base, this.env); }
  protectedResource() {
    return { resource: `${this.base}/mcp`, authorization_servers: [this.base], bearer_methods_supported: ['header'], scopes_supported: ['mcp', 'apps:<service>'], resource_name: '0n3' };
  }
  async registerClient(body, { owner = null } = {}) {
    const uris = Array.isArray(body?.redirect_uris) ? body.redirect_uris.map(String) : [];
    const bad = uris.find((u) => !/^https:\/\/[^/]+/.test(u) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?(\/|$)/.test(u));
    if (!uris.length || bad) return { status: 400, body: { error: 'invalid_redirect_uri', error_description: 'redirect_uris must be https URLs (or http://localhost for local clients).' } };
    const client_id = `0n3c_${randomBytes(12).toString('hex')}`;
    const client_name = String(body?.client_name || 'MCP client').slice(0, 80);
    const method = body?.token_endpoint_auth_method === 'client_secret_post' ? 'client_secret_post' : 'none';
    const secret = method === 'client_secret_post' ? `0n3s_${randomBytes(24).toString('hex')}` : null;
    // Shared registry with the 0nmcp.com identity provider: client_secret holds sha256(secret) or null for public PKCE clients.
    // What the client may ask for. A self-registered client (an MCP host or any app) may ask for identity, mcp and single
    // apps; the person still approves every request on the consent screen.
    const raw = String(body?.scope || ''); const asked = parseScopes(raw);
    const wildcard = /(^|\s)apps:\*(\s|$)/.test(raw) || asked.some((x) => x.startsWith('apps:'));
    const allowed_scopes = asked.length || wildcard ? [...new Set([...asked, ...(wildcard ? ['apps:*'] : [])])] : ['mcp', 'openid', 'profile', 'email', 'offline_access', 'apps:*'];
    await this.rest.insert('oauth_clients', { client_id, client_secret: secret ? sha256(secret) : null, name: client_name, redirect_uris: uris, allowed_scopes, ...(owner ? { owner_account: owner } : {}), ...(body?.logo_uri ? { logo_url: String(body.logo_uri).slice(0, 400) } : {}), ...(body?.client_uri ? { homepage: String(body.client_uri).slice(0, 400) } : {}) });
    return { status: 201, body: { client_id, client_name, redirect_uris: uris, token_endpoint_auth_method: method, grant_types: ['authorization_code', 'refresh_token'], response_types: ['code'], client_id_issued_at: Math.floor(Date.now() / 1000), ...(secret ? { client_secret: secret } : {}) } };
  }
  async oauthClient(clientId) { return clientId ? (await this.rest.select('oauth_clients', { client_id: String(clientId) }, '*'))[0] || null : null; }
  async authorizeCheck(q) {
    const client = await this.oauthClient(q.client_id);
    if (!client) return { error: 'Unknown client_id. The client has to register first (POST /oauth/register).' };
    if (!q.redirect_uri || !(client.redirect_uris || []).includes(q.redirect_uri)) return { error: 'That redirect_uri is not registered for this client.' };
    if ((q.response_type || 'code') !== 'code') return { error: 'response_type must be "code".' };
    if (!q.code_challenge || (q.code_challenge_method || 'S256') !== 'S256') return { error: 'PKCE is required: send code_challenge with code_challenge_method=S256.' };
    const scopes = parseScopes(q.scope || 'mcp');
    if (!scopes.length) return { error: 'No recognised scope. Use openid profile email offline_access, mcp, or apps:<service>.' };
    if (!scopesAllowed(scopes, client.allowed_scopes || ['mcp'])) return { error: `This app is not registered to ask for: ${scopes.filter((x) => !scopesAllowed([x], client.allowed_scopes || ['mcp'])).join(' ')}.` };
    return { client, scopes };
  }
  async issueCode({ clientId, userId, redirectUri, codeChallenge, scopes, nonce }) {
    const code = `0n3a_${randomBytes(24).toString('hex')}`;
    await this.rest.insert('oauth_codes', { code, client_id: clientId, user_id: userId, redirect_uri: redirectUri, code_challenge: codeChallenge, scopes: scopes && scopes.length ? scopes : ['mcp'], used: false, expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(), ...(nonce ? { nonce: String(nonce).slice(0, 200) } : {}) });
    return code;
  }
  async mintAccess(userId, client, scopes = ['mcp'], { nonce = null } = {}) {
    const legacy = scopes.length === 1 && scopes[0] === 'mcp';
    const ttl = legacy ? 90 * 86400 : 3600; // the original MCP grant keeps its 90 days; app grants live an hour and refresh
    const raw = `0n_${randomBytes(24).toString('hex')}`;
    await this.rest.insert('access_tokens', { user_id: userId, ...storedToken(raw), name: `${legacy ? 'MCP' : 'App'} · ${client.name || client.client_id}`.slice(0, 80), permission_level: 'full', scopes, source: 'oauth', expires_at: new Date(Date.now() + ttl * 1000).toISOString(), is_active: true, metadata: { client_id: client.client_id, client_name: client.name || null , mask: maskToken(raw) } });
    const row = (await this.rest.select('access_tokens', { token_hash: sha256(raw) }, 'id'))[0];
    const out = { access_token: raw, token_type: 'Bearer', expires_in: ttl, scope: scopes.join(' ') };
    if (legacy || scopes.includes('offline_access')) {
      const refresh = `0n3r_${randomBytes(24).toString('hex')}`;
      await this.rest.insert('oauth_refresh_tokens', { token_hash: sha256(refresh), client_id: client.client_id, user_id: userId, access_token_id: row?.id || null, expires_at: new Date(Date.now() + 180 * 86400000).toISOString() });
      out.refresh_token = refresh;
    }
    if (scopes.includes('openid')) {
      const p = (await this.rest.select('profiles', { id: userId }, 'id, email, full_name, avatar_url'))[0];
      const t = p && idToken({ base: this.base, clientId: client.client_id, profile: p, scopes, nonce, env: this.env });
      if (t) out.id_token = t;
    }
    return out;
  }
  /** GET /oauth/userinfo — the person, as their grant allows. */
  async userinfo(account) {
    const scopes = account?.permissions?.scopes || [];
    if (account?.scope === 'scoped' && !scopes.includes('openid') && !scopes.includes('mcp')) return { status: 403, body: { error: 'insufficient_scope', error_description: 'This token was not granted openid.' } };
    const p = (await this.rest.select('profiles', { id: account.accountId }, 'id, email, full_name, avatar_url'))[0];
    if (!p) return { status: 404, body: { error: 'not_found' } };
    return { status: 200, body: userClaims(p, account.scope === 'master' || scopes.includes('mcp') ? ['openid', 'profile', 'email'] : scopes) };
  }
  /** POST /oauth/revoke (RFC 7009) — a client drops a token it holds. Always 200, per the spec. */
  async revoke(body) {
    const t = String(body?.token || ''); if (!t) return;
    const now = new Date().toISOString();
    if (t.startsWith('0n3r_')) { await this.rest.update('oauth_refresh_tokens', { token_hash: sha256(t) }, { revoked_at: now }); return; }
    await this.rest.update('access_tokens', { token_hash: sha256(t), source: 'oauth' }, { is_active: false, revoked_at: now, revoked_reason: 'revoked by the app' });
  }

  // ── approvals: what an app wants to change waits for the person's OK ──
  async holdCall(account, { service, endpoint, method, params, summary }) {
    const c = account?.permissions?.client || {};
    const row = { account_id: account.accountId, client_id: c.id || account?.permissions?.tokenId || 'unknown', client_name: c.name || account?.permissions?.tokenName || null, service, endpoint, method, params: params || {}, summary: String(summary || '').slice(0, 300) };
    await this.rest.insert('grant_approvals', row);
    return (await this.rest.select('grant_approvals', { account_id: account.accountId, client_id: row.client_id, status: 'pending' }, 'id, created_at')).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0];
  }
  async approval(id, { accountId, clientId = null } = {}) {
    const r = (await this.rest.select('grant_approvals', { id }, '*'))[0];
    if (!r || r.account_id !== accountId || (clientId && r.client_id !== clientId)) return null;
    if (r.status === 'pending' && new Date(r.expires_at).getTime() < Date.now()) { await this.rest.update('grant_approvals', { id }, { status: 'expired' }); r.status = 'expired'; }
    return r;
  }
  async pendingApprovals(accountId) {
    const rows = await this.rest.select('grant_approvals', { account_id: accountId, status: 'pending' }, 'id, client_id, client_name, service, endpoint, method, summary, created_at, expires_at');
    return rows.filter((r) => new Date(r.expires_at).getTime() > Date.now()).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
  }
  async settleApproval(id, patch) { await this.rest.update('grant_approvals', { id }, { ...patch }); }

  // ── connected programs (what a person has granted) and developer apps (what a developer registered) ──
  async grants(accountId) {
    const rows = (await this.rest.select('access_tokens', { user_id: accountId, source: 'oauth' }, 'id, name, scopes, is_active, revoked_at, expires_at, last_used_at, created_at, metadata'))
      .filter((r) => r.is_active !== false && !r.revoked_at);
    const by = new Map();
    for (const r of rows) { const cid = r.metadata?.client_id || r.name; const g = by.get(cid) || { clientId: cid, name: r.metadata?.client_name || r.name, scopes: new Set(), lastUsed: null, since: r.created_at }; for (const sc of r.scopes || []) g.scopes.add(sc); if (r.last_used_at && (!g.lastUsed || r.last_used_at > g.lastUsed)) g.lastUsed = r.last_used_at; if (r.created_at < g.since) g.since = r.created_at; by.set(cid, g); }
    return [...by.values()].map((g) => ({ ...g, scopes: [...g.scopes] })).sort((a, b) => String(b.lastUsed || b.since).localeCompare(String(a.lastUsed || a.since)));
  }
  async revokeGrant(accountId, clientId) {
    const now = new Date().toISOString();
    const rows = (await this.rest.select('access_tokens', { user_id: accountId, source: 'oauth' }, 'id, metadata')).filter((r) => r.metadata?.client_id === clientId);
    for (const r of rows) await this.rest.update('access_tokens', { id: r.id }, { is_active: false, revoked_at: now, revoked_reason: 'removed under Connected programs' });
    await this.rest.update('oauth_refresh_tokens', { client_id: clientId, user_id: accountId }, { revoked_at: now });
    return rows.length;
  }
  async devClients(accountId) {
    return (await this.rest.select('oauth_clients', { owner_account: accountId }, 'client_id, name, redirect_uris, allowed_scopes, logo_url, homepage, reviewed, created_at, client_secret'))
      .map((c) => ({ clientId: c.client_id, name: c.name, redirectUris: c.redirect_uris || [], scopes: c.allowed_scopes || [], logo: c.logo_url || null, homepage: c.homepage || null, confidential: !!c.client_secret, reviewed: !!c.reviewed, createdAt: c.created_at }));
  }
  /**
   * APP REVIEW + DAILY CAPS (2026-10-29). A developer's app is READ-ONLY for everyone but its own developer until it is
   * reviewed; every app call counts against a per-person daily cap, writes against a smaller one. Caps come from env
   * (ON3_APP_DAILY_CALLS / ON3_APP_DAILY_WRITES) so they can be raised without a deploy of code.
   */
  /** Per-account settings 0n3 owns (account_settings). Missing row = the defaults. */
  async settings(accountId) {
    const r = (await this.rest.select('account_settings', { account_id: accountId }, 'ask_ai_writes, bot, updated_at'))[0];
    return { ask_ai_writes: !!r?.ask_ai_writes, bot: cleanBot(r?.bot), updated_at: r?.updated_at || null };
  }
  async setSettings(accountId, patch = {}) {
    const row = { account_id: accountId, updated_at: new Date().toISOString() };
    if (typeof patch.ask_ai_writes === 'boolean') row.ask_ai_writes = patch.ask_ai_writes;
    if (patch.bot && typeof patch.bot === 'object') row.bot = cleanBot({ ...(await this.settings(accountId)).bot, ...patch.bot });
    await this.rest.upsert('account_settings', row, 'account_id');
    return this.settings(accountId);
  }

  async clientPolicy(clientId) {
    this._pol = this._pol || new Map(); const hit = this._pol.get(clientId);
    if (hit && hit.at > Date.now() - 60_000) return hit.v;
    const c = (await this.rest.select('oauth_clients', { client_id: clientId }, 'client_id, owner_account, reviewed'))[0] || null;
    const v = c ? { owner: c.owner_account || null, reviewed: !!c.reviewed } : null;
    this._pol.set(clientId, { at: Date.now(), v }); return v;
  }
  caps() {
    const n = (k, d) => { const x = Number(this.env?.[k]); return Number.isFinite(x) && x > 0 ? x : d; };
    return { calls: n('ON3_APP_DAILY_CALLS', 2000), writes: n('ON3_APP_DAILY_WRITES', 100) };
  }
  async bumpUsage(accountId, clientId, write) {
    if (!this.rest.rpc) return null;
    const r = await this.rest.rpc('grant_usage_bump', { p_account: accountId, p_client: clientId, p_write: !!write });
    return Array.isArray(r) ? r[0] : r;
  }
  isAdmin(account) {
    const list = String(this.env?.ON3_ADMIN_EMAILS || 'mike@rocketopp.com').split(',').map((e) => e.trim().toLowerCase()).filter(Boolean);
    return !!account?.email && list.includes(String(account.email).trim().toLowerCase());
  }
  async reviewQueue() {
    const rows = await this.rest.select('oauth_clients', { reviewed: false }, 'client_id, name, owner_account, redirect_uris, allowed_scopes, homepage, created_at');
    return rows.filter((r) => r.owner_account);
  }
  async reviewClient(clientId, { reviewed = true, by = null } = {}) {
    const c = (await this.rest.select('oauth_clients', { client_id: clientId }, 'client_id'))[0];
    if (!c) return false;
    await this.rest.update('oauth_clients', { client_id: clientId }, { reviewed: !!reviewed, reviewed_at: reviewed ? new Date().toISOString() : null, reviewed_by: reviewed ? by : null });
    this._pol?.delete(clientId); return true;
  }

  async createDevClient(accountId, b = {}) {
    const r = await this.registerClient({ client_name: b.name, redirect_uris: b.redirectUris, scope: (b.scopes || []).join(' ') || 'openid profile email offline_access', token_endpoint_auth_method: b.confidential === false ? 'none' : 'client_secret_post', logo_uri: b.logo, client_uri: b.homepage }, { owner: accountId });
    return r;
  }
  async deleteDevClient(accountId, clientId) {
    const c = (await this.rest.select('oauth_clients', { client_id: clientId }, 'client_id, owner_account'))[0];
    if (!c || c.owner_account !== accountId) return false;
    await this.rest.delete('oauth_clients', { client_id: clientId });
    return true;
  }
  async exchange(body) {
    const fail = (error, error_description, status = 400) => ({ status, body: { error, error_description } });
    if (body?.authorization && /^Basic /i.test(body.authorization)) { try { const [id, sec] = Buffer.from(body.authorization.slice(6), 'base64').toString('utf8').split(':'); body = { ...body, client_id: body.client_id || decodeURIComponent(id || ''), client_secret: body.client_secret || decodeURIComponent(sec || '') }; } catch { /* malformed header → the checks below fail it */ } }
    const client = await this.oauthClient(body?.client_id);
    if (!client) return fail('invalid_client', 'Unknown client_id.', 401);
    if (client.client_secret) {
      const given = String(body?.client_secret || '');
      if (!given || sha256(given) !== client.client_secret) return fail('invalid_client', 'Bad client_secret.', 401);
    }
    const now = new Date().toISOString();
    if (body?.grant_type === 'authorization_code') {
      const row = (await this.rest.select('oauth_codes', { code: String(body.code || '') }, '*'))[0];
      if (!row || row.client_id !== client.client_id) return fail('invalid_grant', 'Unknown authorization code.');
      if (row.used) return fail('invalid_grant', 'That code was already used.');
      if (new Date(row.expires_at).getTime() < Date.now()) return fail('invalid_grant', 'That code expired (10 minutes).');
      if (body.redirect_uri && body.redirect_uri !== row.redirect_uri) return fail('invalid_grant', 'redirect_uri does not match the authorization request.');
      const verifier = String(body.code_verifier || '');
      if (!row.code_challenge || !verifier || createHash('sha256').update(verifier).digest('base64url') !== row.code_challenge) return fail('invalid_grant', 'PKCE verification failed.');
      await this.rest.update('oauth_codes', { code: row.code }, { used: true });
      return { status: 200, body: await this.mintAccess(row.user_id, client, row.scopes && row.scopes.length ? row.scopes : ['mcp'], { nonce: row.nonce || null }) };
    }
    if (body?.grant_type === 'refresh_token') {
      const row = (await this.rest.select('oauth_refresh_tokens', { token_hash: sha256(String(body.refresh_token || '')) }, '*'))[0];
      if (!row || row.client_id !== client.client_id) return fail('invalid_grant', 'Unknown refresh token.');
      if (row.revoked_at) return fail('invalid_grant', 'That refresh token was revoked.');
      if (new Date(row.expires_at).getTime() < Date.now()) return fail('invalid_grant', 'That refresh token expired.');
      const prior = row.access_token_id ? (await this.rest.select('access_tokens', { id: row.access_token_id }, 'scopes'))[0] : null;
      await this.rest.update('oauth_refresh_tokens', { token_hash: row.token_hash }, { revoked_at: now });
      if (row.access_token_id) await this.rest.update('access_tokens', { id: row.access_token_id }, { is_active: false, revoked_at: now, revoked_reason: 'rotated by refresh_token' });
      return { status: 200, body: await this.mintAccess(row.user_id, client, prior?.scopes?.length ? prior.scopes : ['mcp']) };
    }
    return fail('unsupported_grant_type', 'Use authorization_code or refresh_token.');
  }
  /** Email + password → Supabase password grant → the same session() every other door uses. */
  async loginPassword(email, password) {
    const r = await this.fetch(`${this.sb.url}/auth/v1/token?grant_type=password`, { method: 'POST', headers: { apikey: this.sb.serviceKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ email: String(email || '').trim().toLowerCase(), password: String(password || '') }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) return { error: j.error_description || j.msg || j.error || 'Sign-in failed.' };
    const s = await this.session(j.access_token);
    if (s.status !== 200) return { error: s.body.error };
    return { userId: s.body.account.id, email: s.body.account.email };
  }

  // ── connect (OAuth doors) ───────────────────────────────────────────────
  providers() {
    const e = this.env;
    const has = (...k) => k.every((x) => !!e[x]);
    return [
      { key: 'stripe', name: 'Stripe', method: 'oauth', grant: 'Connect · read_write', configured: has('STRIPE_CONNECT_CLIENT_ID', 'STRIPE_SECRET_KEY'), why: 'Needs STRIPE_CONNECT_CLIENT_ID (the platform ca_ id) and a standard STRIPE_SECRET_KEY.' },
      { key: 'google', name: 'Google', method: 'oauth', grant: 'Calendar · Drive · Tasks · Sheets · Analytics · Search Console', configured: has('GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'), why: 'Needs GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET with https://0n3.app/connect/google/callback registered.' },
      { key: 'slack', name: 'Slack', method: 'oauth', grant: 'Bot in your workspace', configured: has('SLACK_CLIENT_ID', 'SLACK_CLIENT_SECRET'), why: 'Needs SLACK_CLIENT_ID / SLACK_CLIENT_SECRET with https://0n3.app/connect/slack/callback registered.' },
      { key: 'github', name: 'GitHub', method: 'oauth', grant: 'Repos · issues · pull requests', configured: has('GITHUB_CLIENT_ID', 'GITHUB_CLIENT_SECRET'), why: 'Needs a GitHub OAuth app: GITHUB_CLIENT_ID / GITHUB_CLIENT_SECRET.' },
      { key: 'microsoft', name: 'Microsoft 365', method: 'oauth', grant: 'Outlook mail · calendar · OneDrive · Teams', configured: has('MICROSOFT_CLIENT_ID', 'MICROSOFT_CLIENT_SECRET'), why: 'Needs an Entra ID app registration: MICROSOFT_CLIENT_ID / MICROSOFT_CLIENT_SECRET with https://0n3.app/connect/microsoft/callback registered.' },
      { key: 'azure', name: 'Microsoft Azure', method: 'oauth', grant: 'Subscriptions · resource groups · storage · VMs', configured: has('MICROSOFT_CLIENT_ID', 'MICROSOFT_CLIENT_SECRET'), why: 'Needs the same Entra ID app registration as Microsoft 365 (MICROSOFT_CLIENT_ID / MICROSOFT_CLIENT_SECRET) with https://0n3.app/connect/azure/callback registered and the Azure Service Management permission.' },
      { key: 'ebay', name: 'eBay', method: 'oauth', grant: 'Sell: inventory · offers · orders · marketing · finances', configured: has('EBAY_CLIENT_ID', 'EBAY_CLIENT_SECRET', 'EBAY_RUNAME'), why: 'Needs an eBay developer keyset: EBAY_CLIENT_ID (App ID) / EBAY_CLIENT_SECRET (Cert ID) and EBAY_RUNAME, the redirect name whose Auth accepted URL is https://0n3.app/connect/ebay/callback. EBAY_ENV=SANDBOX for the sandbox keyset.' },
      ...Object.entries(MORE_DOORS).map(([key, d]) => ({ key, name: d.name, method: 'oauth', grant: d.grant, configured: has(...d.needs), why: `Needs ${d.needs.join(' / ')} with ${this.base}/connect/${key}/callback registered.` })),
      { key: 'crm', name: 'Your CRM', method: 'app', grant: 'Marketplace app install', configured: false, why: 'Installs from the CRM marketplace through 0nCore; the location token lands here as a record.' },
      { key: 'apikey', name: 'Any service by key', method: 'key', grant: 'Paste a key', configured: true, why: '' },
    ];
  }
  sign(accountId, provider) { const ts = Date.now().toString(36); const mac = createHmac('sha256', this.secret).update(`${accountId}.${provider}.${ts}`).digest('hex').slice(0, 24); return Buffer.from(`${accountId}.${provider}.${ts}.${mac}`).toString('base64url'); }
  verifyState(state, provider) {
    try {
      const [accountId, prov, ts, mac] = Buffer.from(String(state), 'base64url').toString('utf8').split('.');
      if (prov !== provider) return null;
      if (Date.now() - parseInt(ts, 36) > 15 * 60 * 1000) return null;
      const want = createHmac('sha256', this.secret).update(`${accountId}.${provider}.${ts}`).digest('hex').slice(0, 24);
      if (want.length !== String(mac).length || !timingSafeEqual(Buffer.from(want), Buffer.from(String(mac)))) return null;
      return accountId;
    } catch { return null; }
  }
  /** PKCE without storage: the verifier is an HMAC of the signed state, so the callback can rebuild it. */
  pkceVerifier(state) { return createHmac('sha256', this.secret).update(`pkce.${state}`).digest('base64url'); }
  startUrl(provider, accountId, { service = '' } = {}) {
    const p = this.providers().find((x) => x.key === provider);
    if (!p || p.method !== 'oauth') return { error: `${provider} does not connect by OAuth here.` };
    if (!p.configured) return { error: p.why };
    const e = this.env, state = this.sign(accountId, provider), cb = `${this.base}/connect/${provider}/callback`;
    const door = OAUTH_DOORS[provider];
    if (door) {
      const redirect = door.redirectValue ? (door.redirectValue(e) || '') : cb;
      if (door.redirectValue && !redirect) return { error: `${provider} needs its registered redirect name (RuName) in the environment.` };
      if (door.authorize) return { url: door.authorize(e, { state, redirect }) };
      const authorizeUrl = typeof door.authorizeUrl === 'function' ? door.authorizeUrl(e) : door.authorizeUrl;
      const scope = this.doorScope(provider, door);
      const q = new URLSearchParams({ client_id: door.clientId(e) || '', redirect_uri: redirect, response_type: 'code', ...(scope ? { scope } : {}), state, ...(door.extra || {}) });
      if (door.pkce) { q.set('code_challenge', createHash('sha256').update(this.pkceVerifier(state)).digest('base64url')); q.set('code_challenge_method', 'S256'); }
      return { url: `${authorizeUrl}?${q.toString()}` };
    }
    switch (provider) {
      case 'stripe': return { url: `https://connect.stripe.com/oauth/authorize?response_type=code&client_id=${encodeURIComponent(e.STRIPE_CONNECT_CLIENT_ID)}&scope=read_write&redirect_uri=${encodeURIComponent(cb)}&state=${state}` };
      case 'google': return { url: `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(e.GOOGLE_CLIENT_ID)}&redirect_uri=${encodeURIComponent(cb)}&response_type=code&access_type=offline&prompt=consent&scope=${encodeURIComponent([
        'openid', 'email', 'profile',
        'https://www.googleapis.com/auth/calendar',
        'https://www.googleapis.com/auth/drive.file',
        'https://www.googleapis.com/auth/tasks',
        'https://www.googleapis.com/auth/spreadsheets',
        // WRITE where a mini-app has to create something. The door asked for
        // analytics.readonly + webmasters.readonly, which can list and nothing
        // else — so "set GA4 and Search Console up for this domain" was refused
        // by Google before any of our code ran.
        'https://www.googleapis.com/auth/analytics.edit',
        // analytics.edit does not cover the GA4 Data API (reports answer 403 without this one) — see tokens.js SA_SCOPES.
        'https://www.googleapis.com/auth/analytics.readonly',
        'https://www.googleapis.com/auth/webmasters',
        'https://www.googleapis.com/auth/siteverification',
        // Gmail / Ads / Apps Script / YouTube ask for theirs only when that app is the one being connected.
        ...(GOOGLE_EXTRA[service] || []),
      ].join(' '))}${GOOGLE_EXTRA[service] ? '&include_granted_scopes=true' : ''}&state=${state}` };
      case 'slack': return { url: `https://slack.com/oauth/v2/authorize?client_id=${encodeURIComponent(e.SLACK_CLIENT_ID)}&scope=${encodeURIComponent('chat:write,chat:write.public,channels:read,users:read,users:read.email')}&redirect_uri=${encodeURIComponent(cb)}&state=${state}` };
      case 'github': return { url: `https://github.com/login/oauth/authorize?client_id=${encodeURIComponent(e.GITHUB_CLIENT_ID)}&redirect_uri=${encodeURIComponent(cb)}&scope=${encodeURIComponent('repo read:user user:email')}&state=${state}` };
      default: return { error: 'unknown provider' };
    }
  }
  doorScope(provider, door) { const o = this.env[`${provider.toUpperCase()}_SCOPES`]; return o ? o.split(/[\s,]+/).filter(Boolean).join(door.scopeSep || ' ') : door.scope; }
  async callback(provider, query = {}) {
    const door0 = OAUTH_DOORS[provider];
    const code = (door0?.codeParam && query[door0.codeParam]) || query.code || '';
    const state = query.state || '';
    const accountId = this.verifyState(state, provider);
    if (!accountId) return { ok: false, error: 'This connect link expired or was not issued here. Start again from 0n3.app/connect.' };
    const e = this.env, cb = `${this.base}/connect/${provider}/callback`;
    const form = (o) => new URLSearchParams(o).toString();
    let env;
    try {
      const door = door0;
      if (door?.exchange) {
        const who = await door.exchange(this.fetch, { code, e, redirect: cb, query });
        env = makeConnection({ service: door.service, name: who.name, credentials: who.credentials, meta: { ...(who.meta || {}), via: 'oauth' }, authType: door.authType });
      } else if (door) {
        const redirect = door.redirectValue ? (door.redirectValue(e) || '') : cb;
        const tokenUrl = typeof door.tokenUrl === 'function' ? door.tokenUrl(e) : door.tokenUrl;
        const headers = { 'Content-Type': 'application/x-www-form-urlencoded', ...(door.tokenHeaders || {}) };
        const body = { grant_type: 'authorization_code', code, redirect_uri: redirect };
        if (door.pkce) body.code_verifier = this.pkceVerifier(state);
        const scope = this.doorScope(provider, door);
        if (door.tokenAuth === 'basic') headers.Authorization = `Basic ${Buffer.from(`${door.clientId(e) || ''}:${door.clientSecret(e) || ''}`).toString('base64')}`;
        else Object.assign(body, { client_id: door.clientId(e) || '', client_secret: door.clientSecret(e) || '', ...(scope ? { scope } : {}) });
        const r = await this.fetch(tokenUrl, { method: 'POST', headers, body: form(body) });
        const d = await r.json().catch(() => ({}));
        if (!r.ok || !d.access_token) throw new Error(d.error_description || d.error || `${provider} answered ${r.status}`);
        if (!d.refresh_token && door.noRefresh !== 'keep-access') throw new Error(`${provider} returned no refresh token — the app must request offline_access. Remove the app from your account and connect again.`);
        const who = await door.identity(this.fetch, d.access_token, e, query).catch(() => ({ name: provider, meta: {} }));
        // The durable secret is the refresh token + the app's own id/secret; the access token is minted per call (tokens.js).
        // A provider with no refresh token (TickTick) issues a long-lived access token instead, and that is what is kept.
        const durable = d.refresh_token ? { refresh_token: d.refresh_token } : { access_token: d.access_token, expires_at: d.expires_in ? new Date(Date.now() + Number(d.expires_in) * 1000).toISOString() : null };
        env = makeConnection({ service: door.service, name: who.name, credentials: { client_id: door.clientId(e), client_secret: door.clientSecret(e), ...durable, ...(MORE_DOORS[provider] ? {} : { tenant_id: 'common' }), ...(who.credentials || {}) }, meta: { ...(who.meta || {}), scopes: d.scope || scope, via: 'oauth' }, authType: door.authType });
      } else if (provider === 'stripe') {
        const r = await this.fetch('https://connect.stripe.com/oauth/token', { method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`${e.STRIPE_SECRET_KEY}:`).toString('base64')}`, 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ grant_type: 'authorization_code', code }) });
        const d = await r.json(); if (!r.ok || !d.access_token) throw new Error(d.error_description || d.error || `Stripe answered ${r.status}`);
        env = makeConnection({ service: 'stripe', name: `Stripe ${d.stripe_user_id}`, credentials: { apiKey: d.access_token, refresh_token: d.refresh_token, stripe_user_id: d.stripe_user_id, publishable_key: d.stripe_publishable_key }, meta: { account: d.stripe_user_id, scope: d.scope, livemode: d.livemode, via: 'connect_oauth' }, authType: 'oauth' });
      } else if (provider === 'google') {
        const r = await this.fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ code, client_id: e.GOOGLE_CLIENT_ID, client_secret: e.GOOGLE_CLIENT_SECRET, redirect_uri: cb, grant_type: 'authorization_code' }) });
        const d = await r.json(); if (!r.ok || !d.refresh_token) throw new Error(d.error_description || d.error || 'Google returned no refresh token — remove the app at myaccount.google.com/permissions and connect again.');
        const who = await (await this.fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: `Bearer ${d.access_token}` } })).json().catch(() => ({}));
        env = makeConnection({ service: 'google', name: who.email ? `Google · ${who.email}` : 'Google', credentials: { client_id: e.GOOGLE_CLIENT_ID, client_secret: e.GOOGLE_CLIENT_SECRET, refresh_token: d.refresh_token }, meta: { email: who.email || null, scopes: d.scope || '', via: 'oauth' }, authType: 'oauth' });
      } else if (provider === 'slack') {
        const r = await this.fetch('https://slack.com/api/oauth.v2.access', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ code, client_id: e.SLACK_CLIENT_ID, client_secret: e.SLACK_CLIENT_SECRET, redirect_uri: cb }) });
        const d = await r.json(); if (!d.ok) throw new Error(d.error || 'Slack refused the code');
        env = makeConnection({ service: 'slack', name: `Slack · ${d.team?.name || d.team?.id}`, credentials: { botToken: d.access_token }, meta: { team_id: d.team?.id, team: d.team?.name, bot_user_id: d.bot_user_id, scopes: d.scope, via: 'oauth' }, authType: 'bot_token' });
      } else if (provider === 'github') {
        const r = await this.fetch('https://github.com/login/oauth/access_token', { method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' }, body: form({ code, client_id: e.GITHUB_CLIENT_ID, client_secret: e.GITHUB_CLIENT_SECRET, redirect_uri: cb }) });
        const d = await r.json(); if (!d.access_token) throw new Error(d.error_description || d.error || 'GitHub refused the code');
        const who = await (await this.fetch('https://api.github.com/user', { headers: { Authorization: `Bearer ${d.access_token}`, Accept: 'application/vnd.github+json' } })).json().catch(() => ({}));
        env = makeConnection({ service: 'github', name: who.login ? `GitHub · ${who.login}` : 'GitHub', credentials: { token: d.access_token }, meta: { login: who.login || null, scopes: d.scope || '', via: 'oauth' }, authType: 'token' });
      } else return { ok: false, error: 'unknown provider' };
    } catch (err) { return { ok: false, error: err.message }; }
    const record = await this.store.put(accountId, env, { actor: `connect:${provider}` });
    // One sign-in, every catalog service that reads the same account (TikTok's tiktok + tiktok_ads).
    for (const also of door0?.alsoAs || []) await this.store.put(accountId, { ...env, service: also }, { actor: `connect:${provider}` });
    return { ok: true, record };
  }

  // ── support ─────────────────────────────────────────────────────────────
  async support(accountId, email, { subject, message }) {
    const s = String(subject || '').trim().slice(0, 160), m = String(message || '').trim().slice(0, 5000);
    if (!s || !m) return { status: 400, body: { error: 'Subject and message are both needed.' } };
    await this.rest.insert('hq_support_requests', { account_id: accountId, email: email || null, subject: s, message: m });
    return { status: 200, body: { ok: true } };
  }
  async supportList(accountId) {
    const rows = await this.rest.select('hq_support_requests', { account_id: accountId }, 'id, subject, message, status, reply, created_at, updated_at');
    return rows.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
  }

  // ── MCP server probe — look BEFORE you save ────────────────────────────
  //
  // The connect form calls this with a URL the user typed, and shows what came
  // back before anything is written to the vault. Saving an unverified URL and
  // finding out at call time that it was wrong is how a connection UI turns
  // into a support queue: the failure lands hours later, somewhere else, with
  // none of the context that would explain it.
  //
  // The probe is also the honest place to discover auth. We try anonymously
  // first; a remote that needs a token says so, and only then does the form ask
  // for one. Nobody should have to guess whether their server wants a bearer.
  async mcpProbe(accountId, { url, auth = 'none', token = '', headerName = '', headers = {} } = {}) {
    if (!url) return { status: 400, body: { error: 'A URL is required.' } };
    try {
      await assertSafeUrl(url);
    } catch (e) {
      // The SSRF guard's own words. A user who pasted a private address should
      // be told exactly that, not handed a generic failure.
      return { status: 400, body: { ok: false, error: e.message, url } };
    }
    const credentials = auth === 'bearer' && token ? { token }
      : auth === 'headers' ? Object.fromEntries(Object.entries(headers || {}).filter(([k, v]) => k && v))
      : {};
    const probe = {
      $0n: { type: 'connection', version: '2.1.1', kind: 'mcp', name: 'probe' },
      service: 'probe', environment: 'production',
      auth: { type: auth === 'none' ? 'none' : auth, credentials },
      options: { mcp: { url, transport: 'streamable-http', headerName: headerName || null, timeoutMs: 15000 } },
      meta: {},
    };
    try {
      const r = await listRemoteTools(probe, { fetchImpl: this.fetch });
      return {
        status: 200,
        body: {
          ok: true, url, authUsed: auth,
          tools: r.tools.map((t) => ({ name: t.name, description: (t.description || '').slice(0, 160) })),
          count: r.tools.length,
        },
      };
    } catch (e) {
      const detail = redact(e.message, credentials);
      // 401/403 from the remote is not a failure of the form — it is the answer
      // to "does this server need credentials?". Say so, and say which kinds
      // we can offer, rather than making the user infer it from a stack trace.
      const needsAuth = /401|403|unauthor|forbidden/i.test(detail);
      return { status: 200, body: { ok: false, url, error: detail, needsAuth, authUsed: auth, hint: needsAuth ? 'This server wants credentials. Choose Bearer token or custom headers and probe again.' : null } };
    }
  }

  // ── catalog for the add-connection form ────────────────────────────────
  catalog() {
    // `domain` is for the company logo on the Connect tiles: the registrable
    // part of the service's API host. The CRM deliberately gets none — its
    // platform is never named or pictured in our product.
    // Brand domains where the API host is not the brand (hubapi.com is HubSpot,
    // googleapis.com is Google, …) and our own products, which carry our mark.
    const BRAND = { hubspot: 'hubspot.com', gmail: 'gmail.com', jira: 'atlassian.com', quickbooks: 'quickbooks.intuit.com', whatsapp: 'whatsapp.com', instagram: 'instagram.com', instagram_ads: 'instagram.com', twitter: 'x.com', woocommerce: 'woocommerce.com', wordpress: 'wordpress.org', activecampaign: 'activecampaign.com', youtube: 'youtube.com', gcloud: 'cloud.google.com', cockroachdb: 'cockroachlabs.com', ollama: 'ollama.com', google_calendar: 'calendar.google.com', google_sheets: 'sheets.google.com', google_drive: 'drive.google.com', google_ads: 'ads.google.com', aws: 'aws.amazon.com', microsoft: 'microsoft.com', facebook_ads: 'facebook.com', linkedin_ads: 'linkedin.com', tiktok_ads: 'tiktok.com', x_ads: 'x.com' };
    const OURS = /(^|\.)(0ncore\.com|0ntask\.com|0nmcp\.com|vercel\.app|localhost)$/;
    const domainOf = (u) => { try { const h = new URL(u).hostname; if (!h || h.includes('{')) return null; if (OURS.test(h)) return '0n'; return h.split('.').slice(-2).join('.'); } catch { return null; } };
    // `hidden`: a tile the Connect page leaves out unless it is already connected — owner-only engines that take a master
    // database key, and services the provider turned off (connect-guides.js `hide` / `retired`).
    return listServices().map((s) => { const svc = getService(s.key); const g = guideFor(s.key); return { key: s.key, name: s.name, type: s.type, description: s.description || svc?.description || '', authType: svc?.authType || 'custom', credentialKeys: svc?.credentialKeys || [], endpoints: Object.keys(svc?.endpoints || {}).length, domain: s.key === 'crm' ? null : (BRAND[s.key] || domainOf(svc?.baseUrl || '')), ...(g?.hide || (g?.retired && !/MCP/.test(g.retired)) ? { hidden: g.hide || 'retired' } : {}) }; });
  }
}
