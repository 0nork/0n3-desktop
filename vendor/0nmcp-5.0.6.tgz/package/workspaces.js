/**
 * WORKSPACES — the dashboard layer on 0n3.
 *
 * A workspace is a named bundle of connections + apps + a white-labeled front
 * end, owned by an account (email is the join key, as everywhere). The `0n_`
 * token already scopes per account; a workspace is a scope beneath it.
 *
 *   workspaces         name, slug, brand, layout, status
 *   workspace_apps     ordered tiles: mini-app | integrated app | catalog service | link
 *   workspace_domains  custom hosts, attached to the host platform and verified by DNS
 *   workspace_runs     receipts of every mini-app run from a workspace
 *
 * The store speaks through the same `rest` seam as the vault, so tests run on
 * memoryRest and production on supabase-js with the service role.
 *
 * The public view (`publicView`) is what a visitor sees on 0n3.app/w/<slug> or
 * on a custom domain: brand, tiles, nothing that identifies the owner beyond
 * what they chose to show, never a credential, never an account id.
 */
import { randomBytes } from 'node:crypto';
import { listApps, loadApps } from './apps/registry.js';
import { INTEGRATED_APPS, integratedApp } from './apps/integrated.js';
import { getService, listServices } from './catalog.js';
import { PROVIDERS } from './chat.js';
import { cleanDesign } from './outreach.js';

export const TABLES = { ws: 'workspaces', apps: 'workspace_apps', domains: 'workspace_domains', runs: 'workspace_runs', chats: 'workspace_chats' };
export const KINDS = ['ai', 'mini', 'integrated', 'service', 'link'];
export const STATUSES = ['draft', 'live', 'off'];
/** The order auto-arrange uses: the AI first, then jobs, then the 0n apps, then services, then links. */
export const ARRANGE = { ai: 0, mini: 1, integrated: 2, service: 3, link: 4 };
export const autoArrange = (tiles) => [...tiles].map((t, i) => ({ t, i })).sort((a, b) => ((ARRANGE[a.t.kind] ?? 9) - (ARRANGE[b.t.kind] ?? 9)) || (a.i - b.i)).map((x) => x.t);
const RESERVED = new Set(['api', 'mcp', 'vault', 'oauth', 'connect', 'start', 'tokens', 'support', 'account', 'downloads', 'login', 'register', 'w', 'workspaces', 'admin', 'www', 'assets']);

export const slugify = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
export const normHost = (h) => String(h || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/\.$/, '');
const HOST_RE = /^(?=.{4,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;
/** Hosts 0n3 itself answers on; a custom domain can never be one of these. */
export const OWN_HOSTS = /(^|\.)(0n3\.app|0n2\.vercel\.app|vercel\.app|0ntask\.com|0ncore\.com|0nmcp\.com|localhost)$/;

const now = () => new Date().toISOString();
const sortPos = (a, b) => (a.position - b.position) || String(a.app_key).localeCompare(String(b.app_key));

export class WorkspaceStore {
  /**
   * @param {{ rest: any, platform?: { token?: string, projectId?: string, teamId?: string }, fetchImpl?: typeof fetch, base?: string }} o
   */
  constructor({ rest, platform = {}, fetchImpl = fetch, base = 'https://0n3.app' }) {
    if (!rest) throw new Error('WorkspaceStore needs a rest seam');
    this.rest = rest; this.platform = platform; this.fetch = fetchImpl; this.base = base.replace(/\/$/, '');
  }

  // ── workspaces ───────────────────────────────────────────────────────────
  async list(accountId) {
    const rows = await this.rest.select(TABLES.ws, { account_id: accountId });
    const out = [];
    for (const w of rows.sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)))) {
      const apps = await this.rest.select(TABLES.apps, { workspace_id: w.id });
      const domains = await this.rest.select(TABLES.domains, { workspace_id: w.id });
      out.push({ ...shapeWs(w), apps: apps.length, domains: domains.map((d) => ({ host: d.host, verified: !!d.verified_at })), ...summarize(w.canvas, apps) });
    }
    return out;
  }

  /**
   * A copy: same brand, layout, tiles and canvas, a new address, always a draft. Domains are not copied (a host
   * belongs to one workspace) and runs are not copied (they happened to the original).
   */
  async duplicate(accountId, id, { name } = {}) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    const n = String(name || `${w.name} copy`).trim().slice(0, 80);
    const made = await this.create(accountId, { name: n, tagline: w.tagline, brand: w.brand, layout: w.layout });
    if (w.canvas) await this.rest.update(TABLES.ws, { id: made.id }, { canvas: cleanCanvas(w.canvas), updated_at: now() });
    const tiles = (await this.rest.select(TABLES.apps, { workspace_id: id })).sort(sortPos);
    for (const t of tiles) await this.rest.insert(TABLES.apps, { workspace_id: made.id, app_key: t.app_key, kind: t.kind, title: t.title || null, config: t.config || {}, position: t.position, created_at: now() });
    return this.get(accountId, made.id);
  }

  async get(accountId, id) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    const apps = (await this.rest.select(TABLES.apps, { workspace_id: id })).sort(sortPos).map(shapeApp);
    const domains = (await this.rest.select(TABLES.domains, { workspace_id: id })).map(shapeDomain);
    const runs = (await this.rest.select(TABLES.runs, { workspace_id: id })).sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, 25).map(shapeRun);
    return { ...shapeWs(w), apps, domains, runs, url: `${this.base}/w/${w.slug}` };
  }

  async create(accountId, { name, slug, tagline, brand, layout } = {}) {
    const n = String(name || '').trim().slice(0, 80);
    if (!n) throw new Error('A workspace needs a name.');
    let s = slugify(slug || n);
    if (!s) throw new Error('That name makes no usable address. Add a letter or a number.');
    if (RESERVED.has(s)) s = `${s}-ws`;
    // Unique slug: append a short suffix only when taken, never silently rename a free one.
    for (let i = 0; (await this.rest.select(TABLES.ws, { slug: s })).length; i++) { s = `${slugify(slug || n)}-${randomBytes(2).toString('hex')}`; if (i > 5) throw new Error('Could not find a free address.'); }
    const row = { account_id: accountId, slug: s, name: n, tagline: strOrNull(tagline, 160), brand: cleanBrand(brand), layout: cleanLayout(layout), status: 'draft', created_at: now(), updated_at: now() };
    const saved = await this.rest.upsert(TABLES.ws, row, 'slug');
    return shapeWs(saved);
  }

  async update(accountId, id, patch = {}) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    const p = { updated_at: now() };
    if (patch.name !== undefined) { const n = String(patch.name).trim().slice(0, 80); if (!n) throw new Error('A workspace needs a name.'); p.name = n; }
    if (patch.tagline !== undefined) p.tagline = strOrNull(patch.tagline, 160);
    if (patch.brand !== undefined) p.brand = cleanBrand({ ...(w.brand || {}), ...(patch.brand || {}) });
    if (patch.layout !== undefined) p.layout = cleanLayout({ ...(w.layout || {}), ...(patch.layout || {}) });
    // draft = only the owner, while building · live = anyone with the address · off = inactive, kept but not served.
    if (patch.status !== undefined) { if (!STATUSES.includes(patch.status)) throw new Error('status is draft, live or off'); p.status = patch.status; }
    if (patch.slug !== undefined) {
      const s = slugify(patch.slug);
      if (!s || RESERVED.has(s)) throw new Error('That address is not available.');
      if (s !== w.slug && (await this.rest.select(TABLES.ws, { slug: s })).length) throw new Error('That address is taken.');
      p.slug = s;
    }
    await this.rest.update(TABLES.ws, { id }, p);
    return shapeWs({ ...w, ...p });
  }

  async remove(accountId, id) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return false;
    // Child rows cascade in Postgres; the memory seam has no cascade, so do it by hand (harmless twice).
    for (const t of [TABLES.apps, TABLES.domains, TABLES.runs, TABLES.chats]) await this.rest.delete(t, { workspace_id: id });
    await this.rest.delete(TABLES.ws, { id });
    return true;
  }

  // ── tiles ────────────────────────────────────────────────────────────────
  /** Replace the whole tile list in the order given. Unknown keys are refused by name. */
  async setApps(accountId, id, tiles, { arrange = false } = {}) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    if (!Array.isArray(tiles)) throw new Error('apps must be a list');
    await loadApps();
    const pal = await this.palette();
    const seen = new Set(); const rows = [];
    tiles.forEach((t, i) => {
      const kind = KINDS.includes(t.kind) ? t.kind : 'mini';
      const key = String(t.app_key || t.key || '').trim();
      if (!key || seen.has(key)) return;
      if (kind !== 'link' && !pal.find((p) => p.kind === kind && p.key === key)) throw new Error(`No ${kind} app called "${key}".`);
      if (kind === 'link' && !/^https?:\/\//.test(String(t.config?.url || ''))) throw new Error(`Link "${key}" needs a config.url starting with http.`);
      seen.add(key);
      rows.push({ workspace_id: id, app_key: key, kind, title: strOrNull(t.title, 80), config: t.config && typeof t.config === 'object' ? t.config : {}, position: i, created_at: now() });
    });
    const ordered = arrange ? autoArrange(rows).map((r, i) => ({ ...r, position: i })) : rows;
    await this.rest.delete(TABLES.apps, { workspace_id: id });
    for (const r of ordered) await this.rest.insert(TABLES.apps, r);
    await this.rest.update(TABLES.ws, { id }, { updated_at: now() });
    return ordered.sort(sortPos).map(shapeApp);
  }

  /** Everything that can be placed on a workspace. One list, three sources, no fourth registry. */
  async palette() {
    await loadApps();
    const mini = listApps().map((a) => ({ kind: 'mini', key: a.key, name: a.name, what: a.what, needs: a.needs.map((n) => n.service), inputs: a.inputs }));
    const integrated = INTEGRATED_APPS.map((a) => ({ kind: 'integrated', key: a.key, name: a.name, what: a.what, url: a.url, for: a.for, needs: a.needs.map((n) => n.service), product: !!a.product }));
    const service = listServices().map((s) => { const svc = getService(s.key); return { kind: 'service', key: s.key, name: s.name, what: s.description || svc?.description || '', needs: [s.key], endpoints: Object.keys(svc?.endpoints || {}).length }; });
    const ai = Object.entries(PROVIDERS).map(([key, p]) => ({ kind: 'ai', key, name: p.name, what: `A chat box run by ${p.name} with the board as its hands. ${p.keyless ? 'No key needed.' : `Uses your own ${p.service} key.`}`, needs: p.keyless ? [] : [p.service], model: p.model }));
    return [...ai, ...mini, ...integrated, ...service];
  }

  // ── runs ─────────────────────────────────────────────────────────────────
  async recordRun(accountId, id, { app_key, inputs, receipt, ok, actor, run_key = null, job_id = null, state = 'done', output }) {
    const row = { workspace_id: id, account_id: accountId, app_key, inputs: inputs || {}, receipt: receipt || {}, ok: !!ok, actor: actor || null, at: now() };
    if (run_key) Object.assign(row, { run_key, job_id, state, output: output === undefined ? (receipt?.output ?? null) : output });
    await this.rest.insert(TABLES.runs, row);
  }
  /** A Job run that is still going: written as `running` so a poll can see it, then finished in place. */
  async finishRun(accountId, run_key, { receipt, ok }) {
    await this.rest.update(TABLES.runs, { run_key, account_id: accountId }, { receipt: receipt || {}, ok: !!ok, state: receipt?.waiting?.length ? 'waiting' : 'done', output: receipt?.output ?? null });
  }
  async getRun(accountId, run_key) {
    const r = (await this.rest.select(TABLES.runs, { run_key }))[0];
    return r && r.account_id === accountId ? r : null;
  }
  async jobRuns(accountId, job_id, limit = 10) {
    const rows = await this.rest.select(TABLES.runs, { account_id: accountId, job_id });
    return rows.sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, limit);
  }

  // ── domains ──────────────────────────────────────────────────────────────
  async addDomain(accountId, id, hostIn) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    const host = normHost(hostIn);
    if (!HOST_RE.test(host)) throw new Error('That is not a domain name. Use something like app.yourbrand.com.');
    if (OWN_HOSTS.test(host)) throw new Error('That host belongs to 0n. Use a domain you own.');
    const taken = (await this.rest.select(TABLES.domains, { host }))[0];
    if (taken && taken.workspace_id !== id) throw new Error('That domain is attached to another workspace.');
    const token = taken?.token || randomBytes(12).toString('hex');
    const platform = await this.platformAttach(host);
    const row = { host, workspace_id: id, account_id: accountId, token, platform, verified_at: taken?.verified_at || null, created_at: taken?.created_at || now() };
    await this.rest.upsert(TABLES.domains, row, 'host');
    return shapeDomain(row);
  }

  async removeDomain(accountId, id, hostIn) {
    const host = normHost(hostIn);
    const d = (await this.rest.select(TABLES.domains, { host }))[0];
    if (!d || d.workspace_id !== id || d.account_id !== accountId) return false;
    await this.platformDetach(host);
    await this.rest.delete(TABLES.domains, { host });
    return true;
  }

  /**
   * Verify = DNS proves the customer controls the host AND the platform will
   * serve it. Two independent checks, both reported, never one standing in
   * for the other: a TXT record alone routes no traffic, and a platform
   * "verified" alone does not prove the customer meant this workspace.
   */
  async verifyDomain(accountId, id, hostIn) {
    const host = normHost(hostIn);
    const d = (await this.rest.select(TABLES.domains, { host }))[0];
    if (!d || d.workspace_id !== id || d.account_id !== accountId) return null;
    const txt = await this.txtOf(`_0n3.${host}`);
    const owned = txt.some((v) => v === `0n3-verify=${d.token}`);
    const platform = await this.platformStatus(host, d.platform);
    const verified = owned && platform.serving;
    const patch = { platform, verified_at: verified ? (d.verified_at || now()) : null };
    await this.rest.update(TABLES.domains, { host }, patch);
    return { ...shapeDomain({ ...d, ...patch }), checks: { txt: { ok: owned, saw: txt }, platform } };
  }

  async txtOf(name) {
    try {
      const r = await this.fetch(`https://dns.google/resolve?name=${encodeURIComponent(name)}&type=TXT`, { headers: { Accept: 'application/dns-json' } });
      const d = await r.json();
      return (d.Answer || []).filter((a) => a.type === 16).map((a) => String(a.data || '').replace(/^"|"$/g, '').replace(/"\s*"/g, ''));
    } catch { return []; }
  }

  // The host platform (Vercel) — attach / detach / status. Without the three
  // env values the workspace still records the domain and says plainly that
  // traffic will not route yet; nothing pretends.
  get platformReady() { return !!(this.platform.token && this.platform.projectId); }
  platformUrl(p) { const q = this.platform.teamId ? `?teamId=${encodeURIComponent(this.platform.teamId)}` : ''; return `https://api.vercel.com${p}${q}`; }
  async platformCall(method, p, body) {
    const r = await this.fetch(this.platformUrl(p), { method, headers: { Authorization: `Bearer ${this.platform.token}`, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({}));
    return { ok: r.ok, status: r.status, data: d };
  }
  async platformAttach(host) {
    if (!this.platformReady) return { attached: false, reason: 'The host platform is not linked on this deployment (VERCEL_TOKEN / VERCEL_PROJECT_ID). The domain is recorded; traffic will not route until it is.' };
    const r = await this.platformCall('POST', `/v10/projects/${this.platform.projectId}/domains`, { name: host });
    if (!r.ok && r.data?.error?.code !== 'domain_already_in_use_by_project' && r.status !== 409) return { attached: false, reason: r.data?.error?.message || `platform answered ${r.status}` };
    const d = r.ok ? r.data : (await this.platformCall('GET', `/v9/projects/${this.platform.projectId}/domains/${host}`)).data;
    return { attached: true, verified: !!d.verified, verification: d.verification || [], apexName: d.apexName || null, redirect: d.redirect || null };
  }
  async platformDetach(host) {
    if (!this.platformReady) return;
    await this.platformCall('DELETE', `/v9/projects/${this.platform.projectId}/domains/${host}`).catch(() => {});
  }
  async platformStatus(host, prev = {}) {
    if (!this.platformReady) return { ...prev, serving: false, reason: prev.reason || 'host platform not linked' };
    const v = await this.platformCall('POST', `/v9/projects/${this.platform.projectId}/domains/${host}/verify`);
    const c = await this.platformCall('GET', `/v9/projects/${this.platform.projectId}/domains/${host}/config`);
    const verified = !!(v.data?.verified ?? prev.verified);
    const misconfigured = c.data?.misconfigured !== false;
    return { attached: true, verified, verification: v.data?.verification || prev.verification || [], misconfigured, serving: verified && !misconfigured, reason: !verified ? 'platform has not verified ownership' : misconfigured ? 'DNS does not point here yet' : null };
  }

  /** What the customer must publish, said once, in one place. */
  dnsInstructions(d) {
    const apex = d.host.split('.').length === 2;
    return [
      { type: 'TXT', name: `_0n3.${d.host}`, value: `0n3-verify=${d.token}`, why: 'proves you control the domain' },
      apex ? { type: 'A', name: d.host, value: '76.76.21.21', why: 'sends visitors here' } : { type: 'CNAME', name: d.host, value: 'cname.vercel-dns.com', why: 'sends visitors here' },
      ...((d.platform?.verification || []).map((v) => ({ type: v.type, name: v.domain, value: v.value, why: 'the host platform asked for this one too' }))),
    ];
  }

  // ── the public face ──────────────────────────────────────────────────────
  /** By slug (0n3.app/w/<slug>) or by host (a custom domain). Drafts answer only to their owner. */
  async publicView({ slug, host, accountId = null, pageId = null }) {
    let w = null;
    if (host) {
      const d = (await this.rest.select(TABLES.domains, { host: normHost(host) }))[0];
      if (!d) return null;
      w = (await this.rest.select(TABLES.ws, { id: d.workspace_id }))[0];
      // An unverified host still renders for its owner, so they can see what visitors will.
      if (w && !d.verified_at && w.account_id !== accountId) return null;
    } else if (slug) {
      w = (await this.rest.select(TABLES.ws, { slug: slugify(slug) }))[0];
    }
    if (!w) return null;
    if (w.status !== 'live' && w.account_id !== accountId) return null;
    await loadApps();
    const tiles = (await this.rest.select(TABLES.apps, { workspace_id: w.id })).sort(sortPos).map((t) => {
      const base = { key: t.app_key, kind: t.kind, title: t.title || null, config: publicConfig(t) };
      if (t.kind === 'mini') { const a = listApps().find((x) => x.key === t.app_key); return a ? { ...base, title: base.title || a.name, what: a.what, needs: a.needs.map((n) => n.service), inputs: a.inputs } : null; }
      if (t.kind === 'integrated') { const a = integratedApp(t.app_key); return a ? { ...base, title: base.title || a.name, what: a.what, url: a.url, needs: a.needs.map((n) => n.service) } : null; }
      if (t.kind === 'ai') { const p = PROVIDERS[t.app_key]; return p ? { ...base, title: base.title || `Ask ${p.name.split(' (')[0]}`, what: t.config?.note || 'Tell it what you want done across the apps on this board.', provider: t.app_key, model: t.config?.model || p.model, needs: p.keyless ? [] : [p.service] } : null; }
      if (t.kind === 'service') { const s = getService(t.app_key); return s ? { ...base, title: base.title || s.name, what: s.description || '', endpoints: Object.keys(s.endpoints || {}).length, needs: [t.app_key] } : null; }
      return { ...base, title: base.title || t.app_key, what: t.config?.note || '', url: t.config?.url };
    }).filter(Boolean);
    const pages = w.canvas ? this.pagesOf(w.canvas) : [];
    const page = pages.length ? this.pageOf(w.canvas, pageId || pages[0].id) : null;
    return { slug: w.slug, name: w.name, tagline: w.tagline || null, brand: w.brand || {}, layout: w.layout || {}, status: w.status, owner: w.account_id === accountId, tiles, page, pages };
  }

  /** What the chat may touch on this board: the services (directly or through a tile's needs) and the mini-apps. */
  fenceOf(tiles) {
    const services = new Set(); const apps = [];
    for (const t of tiles) {
      const key = t.app_key || t.key;
      if (t.kind === 'service') services.add(key);
      if (t.kind === 'mini') { apps.push(key); for (const n of (t.needs || [])) services.add(n); }
      if (t.kind === 'integrated') for (const n of (t.needs || [])) services.add(n);
    }
    return { services: [...services], apps };
  }

  /** The AI tile on a board, if any: provider + model. */
  aiOf(tiles) { const t = tiles.find((x) => x.kind === 'ai'); return t ? { provider: t.app_key || t.key || t.provider, model: t.config?.model || t.model || null } : null; }

  // ── chat threads ─────────────────────────────────────────────────────────
  async thread(id, accountId) { return (await this.rest.select(TABLES.chats, { workspace_id: id, account_id: accountId }))[0] || null; }
  async saveThread(id, accountId, { actor, provider, model, messages, trace }) {
    const prev = await this.thread(id, accountId);
    const row = { workspace_id: id, account_id: accountId, actor: actor || null, provider: provider || null, model: model || null, messages: (messages || []).slice(-40), trace: trace || [], turns: (prev?.turns || 0) + 1, updated_at: now() };
    await this.rest.upsert(TABLES.chats, row, 'workspace_id,account_id');
    return row;
  }
  async clearThread(id, accountId) { await this.rest.delete(TABLES.chats, { workspace_id: id, account_id: accountId }); }

  // ── the builder canvas ───────────────────────────────────────────────────
  async getCanvas(accountId, id) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    return cleanCanvas(w.canvas || {});
  }
  async setCanvas(accountId, id, canvas) {
    const w = (await this.rest.select(TABLES.ws, { id }))[0];
    if (!w || w.account_id !== accountId) return null;
    const c = cleanCanvas(canvas);
    // A 0n3 Pages page saved back by an editor that does not know about it (the canvas UI) keeps its site, screenshot and
    // format: a save that omits `site` for a page id that had one never wipes the design.
    const prevPages = new Map((cleanCanvas(w.canvas || {}).pages || []).filter((p) => p.format === 'struktur').map((p) => [p.id, p]));
    if (prevPages.size && c.pages) c.pages = c.pages.map((p) => (p.format === 'struktur' || !prevPages.has(p.id) ? p : { ...p, format: 'struktur', site: prevPages.get(p.id).site, ...(prevPages.get(p.id).thumb ? { thumb: prevPages.get(p.id).thumb } : {}), updatedAt: prevPages.get(p.id).updatedAt }));
    // A Job's number ("run Job #12") belongs to the Job, not to whoever saved the canvas last: a save that does not carry it keeps it.
    const had = new Map((cleanCanvas(w.canvas || {}).sequences || []).filter((q) => q.no).map((q) => [q.id, q.no]));
    if (had.size && c.sequences) c.sequences = c.sequences.map((q) => (q.no || !had.has(q.id) ? q : { ...q, no: had.get(q.id) }));
    await this.rest.update(TABLES.ws, { id }, { canvas: c, updated_at: now() });
    return c;
  }
  /** The page a visitor sees: the shape nodes of one page (notes and boxes' labels kept out), plus whether a button can start anything. */
  pageOf(canvas, pageId = null) {
    const c = cleanCanvas(canvas || {});
    const p = primaryPage(c, pageId); if (!p) return null;
    const shapes = (p.nodes || []).filter((n) => n.type === 'shape' && n.key !== 'sticky');
    const bounds = shapes.reduce((b, n) => ({ w: Math.max(b.w, (n.x || 0) + (n.w || 0)), h: Math.max(b.h, (n.y || 0) + (n.h || 0)) }), { w: 0, h: 0 });
    const hasFlows = c.v === 2 ? (c.sequences || []).some((q) => q.nodes.some((n) => n.type !== 'shape')) : c.nodes.some((n) => n.type !== 'shape');
    return { id: p.id || null, name: p.name || c.name || '', nodes: shapes.map((n) => ({ id: n.id, key: n.key, x: n.x, y: n.y, w: n.w, h: n.h, values: n.values || {}, style: n.style || {}, app: n.app || null, access: n.key === 'chat' || n.key === 'button' ? (n.access || {}) : undefined })), bounds, hasFlows };
  }
  /** Every page a visitor may open, in board order: id + name, nothing else. */
  pagesOf(canvas) {
    const c = cleanCanvas(canvas || {});
    if (c.v !== 2) return c.nodes.some((n) => n.type === 'shape' && n.key !== 'sticky') ? [{ id: null, name: c.name || 'Page' }] : [];
    const order = (c.board?.items || []).filter((i) => i.kind === 'page').sort((a, b) => (a.y - b.y) || (a.x - b.x)).map((i) => i.ref);
    const seen = new Set();
    return [...order, ...c.pages.map((p) => p.id)].filter((id) => { if (seen.has(id)) return false; seen.add(id); return true; }).map((id) => c.pages.find((p) => p.id === id)).filter((p) => p && p.nodes.some((n) => n.type === 'shape' && n.key !== 'sticky')).map((p) => ({ id: p.id, name: p.name }));
  }

  /**
   * The desks this account drew: every canvas with a "Desk agent" step. The poller on the owner's machine reads this to know
   * which mailbox feeds which project folder, who may write, and which agent runs it. One row per workspace.
   */
  async deskConfigs(accountId) {
    const rows = await this.rest.select(TABLES.ws, { account_id: accountId });
    const out = [];
    for (const w of rows) {
      const c = cleanCanvas(w.canvas || {});
      const agent = c.nodes.find((n) => n.type === 'terminal' && n.key === 'desk_agent'); if (!agent) continue;
      const inbox = c.nodes.find((n) => n.type === 'trigger' && n.key === 'inbox');
      const ask = c.nodes.find((n) => n.type === 'logic' && n.key === 'ask');
      const v = agent.values || {}; const iv = inbox?.values || {};
      out.push({ workspace: w.id, slug: w.slug, name: w.name, project: v.project || w.name, folder: v.folder || '', agent: agent.app || 'claude_code', machine: v.machine || '', rules: v.rules || '', mailbox: iv.mailbox || '', senders: String(iv.senders || '').split(/[,\s]+/).filter(Boolean), subjectFilter: iv.subject || '', askPolicy: ask?.values?.policy || 'outward', reply: !!c.nodes.find((n) => n.type === 'task' && n.key === 'send_email') || true });
    }
    return out;
  }

  /** The raw row by slug — for recording a visitor's run under the right owner. */
  async bySlug(slug) { return (await this.rest.select(TABLES.ws, { slug: slugify(slug) }))[0] || null; }

  /** For a sibling product: every live workspace of one account, by account id. */
  async forAccount(accountId) {
    return (await this.list(accountId)).map((w) => ({ id: w.id, slug: w.slug, name: w.name, status: w.status, url: `${this.base}/w/${w.slug}`, apps: w.apps, domains: w.domains }));
  }
}

// ── shapes ──────────────────────────────────────────────────────────────────
const MAX_NODES = 400;
/** Keep only what the builder writes, bounded. A node is plain data; functions and unknown keys are dropped. */
/** One document's nodes + edges, bounded and typed. Used for the legacy canvas and for every page / sequence of a v2 canvas. */
export function cleanDoc(c = {}) {
  const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
  const nodes = (Array.isArray(c.nodes) ? c.nodes : []).slice(0, MAX_NODES).map((n) => {
    const o = { id: String(n.id || '').slice(0, 24), type: String(n.type || '').slice(0, 16), key: String(n.key || '').slice(0, 40), x: num(n.x), y: num(n.y), title: n.title === undefined ? undefined : String(n.title).slice(0, 120), app: n.app ? String(n.app).slice(0, 40) : undefined, label: n.label ? String(n.label).slice(0, 120) : undefined, values: n.values && typeof n.values === 'object' ? Object.fromEntries(Object.entries(n.values).slice(0, 24).map(([k, v]) => [String(k).slice(0, 40), typeof v === 'string' ? v.slice(0, 4000) : v])) : {} };
    if (n.type === 'shape') { o.w = Math.max(16, num(n.w, 100)); o.h = Math.max(16, num(n.h, 40)); o.style = n.style && typeof n.style === 'object' ? Object.fromEntries(Object.entries(n.style).slice(0, 16).map(([k, v]) => [String(k).slice(0, 24), String(v).slice(0, 600)])) : {}; o.access = n.access && typeof n.access === 'object' ? Object.fromEntries(Object.entries(n.access).slice(0, 40).map(([k, v]) => [String(k).slice(0, 40), Array.isArray(v) ? v.map(String).slice(0, 6) : []])) : {}; if (Array.isArray(n.for)) o.for = n.for.map(String).slice(0, 40); }
    else { o.outs = Array.isArray(n.outs) ? n.outs.map(String).slice(0, 4) : ['']; o.retries = String(n.retries || '2').slice(0, 3); o.timeout = String(n.timeout || '30').slice(0, 4); o.hasApp = !!n.hasApp; o.icon = n.icon ? String(n.icon).slice(0, 40) : undefined; o.isStart = !!n.isStart; if (n.summary) o.summary = String(n.summary).slice(0, 200); }
    return o;
  }).filter((n) => n.id && n.type && n.key);
  const ids = new Set(nodes.map((n) => n.id));
  const edges = (Array.isArray(c.edges) ? c.edges : []).filter((e) => ids.has(e.from) && ids.has(e.to)).slice(0, MAX_NODES * 2).map((e) => ({ from: String(e.from), to: String(e.to), port: num(e.port), ...(e.wait && String(e.wait).trim() ? { wait: String(e.wait).trim().slice(0, 40) } : {}) }));
  return { nodes, edges };
}
const BOARD_KINDS = new Set(['page', 'seq', 'note', 'heading', 'box', 'outreach']);
/**
 * The canvas, cleaned. v1 = one document (nodes + edges, the 2026-10-22 builder). v2 = the 2026-10-23 design: PAGES and
 * SEQUENCES are documents of their own, and the BOARD lays them out with links (page element → sequence). v1 fields are
 * kept on a v2 canvas as a flattened view so every older reader keeps working.
 */
export function cleanCanvas(c = {}) {
  const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
  const settings = c.settings && typeof c.settings === 'object' ? { suggestions: c.settings.suggestions !== false, snap: c.settings.snap !== false } : { suggestions: true, snap: true };
  const name = c.name ? String(c.name).slice(0, 120) : undefined;
  const v2 = Array.isArray(c.pages) || Array.isArray(c.sequences) || (c.board && typeof c.board === 'object');
  if (!v2) return { v: 1, ...cleanDoc(c), name, settings, updatedAt: now() };
  // A 0n3 Pages document (format "struktur", pages.js) carries the builder's own JSON in `site` and its screenshot path in `thumb`.
  const doc = (d) => ({ id: String(d.id || '').slice(0, 24), name: String(d.name || 'Untitled').slice(0, 120), ...(Number(d.no) > 0 ? { no: Math.floor(Number(d.no)) } : {}), ...(d.format === 'struktur' && d.site && typeof d.site === 'object' ? { format: 'struktur', site: d.site, ...(d.thumb ? { thumb: String(d.thumb).slice(0, 300) } : {}), ...(d.updatedAt ? { updatedAt: Number(d.updatedAt) || undefined } : {}) } : {}), ...cleanDoc(d) });
  const pages = (Array.isArray(c.pages) ? c.pages : []).slice(0, 40).map(doc).filter((d) => d.id);
  const sequences = (Array.isArray(c.sequences) ? c.sequences : []).slice(0, 80).map(doc).filter((d) => d.id);
  // OUTREACH designs (outreach.js) live in their project beside its pages and jobs.
  const outreach = (Array.isArray(c.outreach) ? c.outreach : []).slice(0, 120).map(cleanDesign).filter(Boolean);
  const docIds = new Set([...pages, ...sequences, ...outreach].map((d) => d.id));
  const items = (Array.isArray(c.board?.items) ? c.board.items : []).slice(0, 200).map((i) => ({ id: String(i.id || '').slice(0, 24), kind: String(i.kind || '').slice(0, 12), ref: i.ref ? String(i.ref).slice(0, 24) : undefined, x: num(i.x), y: num(i.y), w: Math.max(16, num(i.w, 200)), h: Math.max(16, num(i.h, 100)), text: i.text ? String(i.text).slice(0, 2000) : '' })).filter((i) => i.id && BOARD_KINDS.has(i.kind) && (!['page', 'seq', 'outreach'].includes(i.kind) || docIds.has(i.ref)));
  const itemIds = new Set(items.map((i) => i.id));
  // A link's `el` is its CONDITION: the page element (a button, a form, a Job block) whose action starts the job. Empty = the
  // line is drawn but incomplete — the board says so and opens the page to pick the form (Mike 2026-11-14).
  const links = (Array.isArray(c.board?.links) ? c.board.links : []).slice(0, 400).map((l) => ({ id: String(l.id || '').slice(0, 24), from: String(l.from || ''), el: String(l.el || ''), to: String(l.to || ''), ...(l.auto ? { auto: true } : {}) })).filter((l) => l.id && itemIds.has(l.from) && itemIds.has(l.to));
  // The flattened view: every page's elements and every sequence's blocks, so v1 readers (desk config, chat fence) still see them.
  const nodes = [...pages.flatMap((p) => p.nodes), ...sequences.flatMap((q) => q.nodes)].slice(0, MAX_NODES * 4);
  const edges = sequences.flatMap((q) => q.edges);
  return { v: 2, pages, sequences, outreach, board: { items, links }, nodes, edges, name, settings, updatedAt: now() };
}
/** The page a visitor lands on: the one asked for, else the top-left page on the board, else the first page. v1 = the canvas itself. */
export function primaryPage(canvas, pageId = null) {
  const c = canvas || {};
  if (c.v !== 2 || !Array.isArray(c.pages) || !c.pages.length) return c.nodes ? { id: null, name: c.name || '', nodes: c.nodes, edges: c.edges || [] } : null;
  if (pageId) { const p = c.pages.find((x) => x.id === pageId); if (p) return p; }
  const onBoard = (c.board?.items || []).filter((i) => i.kind === 'page').sort((a, b) => (a.y - b.y) || (a.x - b.x));
  for (const it of onBoard) { const p = c.pages.find((x) => x.id === it.ref); if (p) return p; }
  return c.pages[0];
}
/**
 * The sequence a page button starts, and where to start it. v2: the board link from that page item + element to a sequence item;
 * else any sequence with a "Page button" trigger named like the button's `runs`. v1: the canvas's own trigger of that name.
 */
export function flowForButton(canvas, pageId, button) {
  const c = canvas || {};
  const want = String(button?.values?.runs || '').trim().toLowerCase();
  const startIn = (nodes) => nodes.find((n) => n.type === 'trigger' && n.key === 'page_button' && String(n.values?.name || n.title || '').trim().toLowerCase() === want) || nodes.find((n) => n.type === 'trigger' && String(n.title || '').trim().toLowerCase() === want) || nodes.find((n) => n.type === 'trigger' || n.key === 'terminal_cmd') || nodes.find((n) => n.type !== 'shape') || null;
  if (c.v === 2) {
    const items = c.board?.items || []; const links = c.board?.links || [];
    const pageItems = items.filter((i) => i.kind === 'page' && i.ref === pageId).map((i) => i.id);
    const link = links.find((l) => pageItems.includes(l.from) && l.el === button.id);
    if (link) { const si = items.find((i) => i.id === link.to); const q = si && (c.sequences || []).find((x) => x.id === si.ref); if (q) { const st = startIn(q.nodes); if (st) return { sequence: q, nodes: q.nodes, edges: q.edges, start: st }; } }
    for (const q of c.sequences || []) { const st = want && q.nodes.find((n) => n.type === 'trigger' && n.key === 'page_button' && String(n.values?.name || n.title || '').trim().toLowerCase() === want); if (st) return { sequence: q, nodes: q.nodes, edges: q.edges, start: st }; }
    return null;
  }
  const nodes = c.nodes || []; const st = want ? (nodes.find((n) => n.type === 'trigger' && n.key === 'page_button' && String(n.values?.name || n.title || '').trim().toLowerCase() === want) || nodes.find((n) => n.type === 'trigger' && String(n.title || '').trim().toLowerCase() === want)) : null;
  return st ? { sequence: null, nodes, edges: c.edges || [], start: st } : null;
}
const strOrNull = (v, max) => { const s = v === undefined || v === null ? '' : String(v).trim(); return s ? s.slice(0, max) : null; };
function cleanBrand(b = {}) {
  const out = {};
  if (b.color && /^#[0-9a-f]{6}$/i.test(String(b.color))) out.color = String(b.color).toLowerCase();
  if (b.logo_url && /^https:\/\//.test(String(b.logo_url))) out.logo_url = String(b.logo_url).slice(0, 500);
  if (b.dark !== undefined) out.dark = !!b.dark;
  if (b.font && ['sans', 'serif', 'mono'].includes(b.font)) out.font = b.font;
  return out;
}
function cleanLayout(l = {}) {
  const out = {};
  if (l.hero && ['tiles', 'list'].includes(l.hero)) out.hero = l.hero;
  if (l.intro !== undefined) out.intro = strOrNull(l.intro, 600);
  if (l.footer !== undefined) out.footer = strOrNull(l.footer, 200);
  if (l.show_powered_by !== undefined) out.show_powered_by = !!l.show_powered_by;
  return out;
}
const shapeWs = (w) => ({ id: w.id, slug: w.slug, name: w.name, tagline: w.tagline || null, brand: w.brand || {}, layout: w.layout || {}, status: STATUSES.includes(w.status) ? w.status : 'draft', createdAt: w.created_at, updatedAt: w.updated_at });
/**
 * What a card on the workspaces page says without opening the builder: how many pages and sequences the canvas holds, which
 * apps the sequences, chat boxes and tiles use (service keys, in first-use order), and a one-line description when the owner
 * wrote none. Derived from the canvas every time, never stored twice.
 */
export function summarize(canvas, tiles = []) {
  const c = cleanCanvas(canvas || {});
  const pages = c.v === 2 ? c.pages.length : (c.nodes.some((n) => n.type === 'shape' && n.key !== 'sticky') ? 1 : 0);
  const sequences = c.v === 2 ? c.sequences.length : (c.nodes.some((n) => n.type !== 'shape') ? 1 : 0);
  const used = [];
  const add = (k) => { if (k && !used.includes(k)) used.push(k); };
  for (const n of c.nodes) { if (n.type === 'action') add(n.key); else if (n.app && (n.hasApp || n.key === 'chat' || n.type === 'ai' || n.type === 'terminal')) add(n.app); }
  for (const t of tiles) { if (t.kind === 'service' || t.kind === 'ai') add(t.app_key); }
  const steps = c.v === 2 ? c.sequences.reduce((s, q) => s + q.nodes.length, 0) : c.nodes.filter((n) => n.type !== 'shape').length;
  const parts = [];
  if (pages) parts.push(`${pages} page${pages === 1 ? '' : 's'}`);
  if (sequences) parts.push(`${sequences} sequence${sequences === 1 ? '' : 's'}${steps ? ` (${steps} steps)` : ''}`);
  if (used.length) parts.push(`uses ${used.slice(0, 4).join(', ')}${used.length > 4 ? ` +${used.length - 4}` : ''}`);
  return { pages, sequences, seqNames: c.v === 2 ? c.sequences.map((q) => q.name) : [], appsUsed: used, summary: parts.join(' · ') || 'Nothing on the board yet' };
}
const shapeApp = (t) => ({ app_key: t.app_key, kind: t.kind, title: t.title || null, config: t.config || {}, position: t.position });
const shapeDomain = (d) => ({ host: d.host, token: d.token, verified: !!d.verified_at, verifiedAt: d.verified_at || null, platform: d.platform || {}, createdAt: d.created_at });
const shapeRun = (r) => ({ id: r.id, app_key: r.app_key, ok: !!r.ok, at: r.at, actor: r.actor || null, inputs: r.inputs || {}, receipt: r.receipt || {} });
/** Config a visitor may see: link targets and notes, never input defaults that could carry a value the owner typed. */
const publicConfig = (t) => { const c = t.config || {}; const out = {}; if (c.url) out.url = c.url; if (c.note) out.note = c.note; if (c.cta) out.cta = String(c.cta).slice(0, 40); return out; };

/**
 * THE CANVAS DRAWS ITSELF FROM THE PAGE (2026-11-14). A Job block dropped on a page IS a connection: page → job, and the
 * condition is that block (its button or its form). So when a page is saved, every Job block whose Job lives in the same
 * project gets its board line — the job's card is placed beside the page if it is not on the board yet — and a line this
 * function drew earlier for a block that is gone is removed. Lines a person drew by hand are never touched.
 */
export function wireJobBlocks(canvas, pageId, site) {
  const c = canvas || {};
  if (c.v !== 2 && !Array.isArray(c.pages)) return c;
  const rid = () => randomBytes(4).toString('hex');
  const items = [...((c.board && c.board.items) || [])]; let links = [...((c.board && c.board.links) || [])];
  const blocks = (site?.pages || []).flatMap((p) => p.blocks || []).filter((b) => b.type === 'job' && b.content?.jobId);
  const seqIds = new Set((c.sequences || []).map((q) => q.id));
  let pageItem = items.find((i) => i.kind === 'page' && i.ref === pageId);
  const mine = blocks.filter((b) => seqIds.has(b.content.jobId));
  if (!pageItem && mine.length) { pageItem = { id: 'bi' + rid(), kind: 'page', ref: pageId, x: 60, y: 60 + items.length * 30, w: 280, h: 200, text: '' }; items.push(pageItem); }
  if (pageItem) {
    const live = new Set(blocks.map((b) => b.id));
    links = links.filter((l) => !(l.auto && l.from === pageItem.id && !live.has(l.el)));
    mine.forEach((b, i) => {
      let si = items.find((x) => x.kind === 'seq' && x.ref === b.content.jobId);
      if (!si) { si = { id: 'bi' + rid(), kind: 'seq', ref: b.content.jobId, x: pageItem.x + pageItem.w + 140, y: pageItem.y + i * 230, w: 336, h: 200, text: b.content.jobName || '' }; items.push(si); }
      if (!links.some((l) => l.from === pageItem.id && l.to === si.id && l.el === b.id)) links.push({ id: 'ln' + rid(), from: pageItem.id, el: b.id, to: si.id, auto: true });
    });
  }
  return { ...c, board: { ...(c.board || {}), items, links } };
}

/**
 * The board's lines, read for people: each page → job line with its CONDITION in words, and `complete: false` when the line
 * has no condition yet (Mike: "it will show a simple incomplete and allow them to click into that page and specify the form").
 * `choices` are what that page offers to pick from: its Job blocks, forms and buttons.
 */
export function wiring(canvas) {
  const c = canvas || {};
  if (c.v !== 2) return { lines: [], choices: {} };
  const items = c.board?.items || [];
  const pageOf = (id) => { const it = items.find((i) => i.id === id && i.kind === 'page'); return it && (c.pages || []).find((p) => p.id === it.ref); };
  const seqOf = (id) => { const it = items.find((i) => i.id === id && i.kind === 'seq'); return it && (c.sequences || []).find((q) => q.id === it.ref); };
  const choicesFor = (p) => {
    if (!p) return [];
    if (p.format === 'struktur') return (p.site?.pages || []).flatMap((pp) => (pp.blocks || []).flatMap((b) => {
      if (b.type === 'job') return [{ el: b.id, kind: b.content?.showsAs === 'form' ? 'form' : b.content?.showsAs === 'button' ? 'button' : 'job', label: `${b.content?.showsAs === 'form' ? 'Form' : b.content?.showsAs === 'button' ? 'Button' : 'Job'}: ${b.content?.title || b.content?.jobName || 'Job'}${pp.slug && pp.slug !== '/' ? ` (${pp.slug})` : ''}` }];
      if (b.type === 'contact') return [{ el: b.id, kind: 'form', label: `Form: ${b.content?.title || 'Contact form'}` }];
      if (b.type === 'hero' && b.content?.buttonText) return [{ el: b.id, kind: 'button', label: `Button: ${b.content.buttonText}` }];
      if (b.type === 'cta' && b.content?.buttonText) return [{ el: b.id, kind: 'button', label: `Button: ${b.content.buttonText}` }];
      return [];
    }));
    return (p.nodes || []).filter((n) => ['button', 'form', 'input'].includes(n.key)).map((n) => ({ el: n.id, kind: n.key === 'button' ? 'button' : 'form', label: `${n.key === 'button' ? 'Button' : 'Form'}: ${n.values?.label || n.title || n.key}` }));
  };
  const choices = {}; for (const it of items.filter((i) => i.kind === 'page')) choices[it.id] = choicesFor(pageOf(it.id));
  const lines = (c.board?.links || []).map((l) => {
    const p = pageOf(l.from); const q = seqOf(l.to); const pick = (choices[l.from] || []).find((x) => x.el === l.el);
    return { id: l.id, from: l.from, to: l.to, page: p ? { id: p.id, name: p.name } : null, job: q ? { id: q.id, name: q.name, no: q.no || null } : null, condition: pick ? pick.label : null, el: l.el || null, complete: !!pick, auto: !!l.auto };
  });
  return { lines, choices };
}
