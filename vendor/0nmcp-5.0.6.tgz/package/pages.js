/**
 * 0n3 PAGES (2026-11-14) — web0n's drag-and-drop builder (Struktur) hosted by 0n3.
 *
 * A Struktur page is a page of a 0n3 PROJECT: canvas.pages[] entry with format "struktur", `site` (the builder's own JSON:
 * { title, description, theme, pages: [{ id, title, slug, parentId, updatedAt, blocks }], currentPageId }) and `thumb`
 * (a storage path once the editor has captured one). Projects own pages, so domains, jobs and the board come with them.
 *
 * LINKS ARE SIGNED, NOT LOGGED IN. The CRM app (or anyone the owner hands a link to) opens the editor or the preview
 * without holding the account's master key: a link carries { account, project, page, scope, expiry } signed with a key
 * derived from ON3_VAULT_KEY. view links do not expire (they are the page's preview address); edit links last 12 hours.
 * Rotating ON3_VAULT_KEY would void every link — use PAGES_LINK_SECRET to rotate links alone.
 */
import crypto from 'node:crypto';

export const EDIT_TTL_MS = 12 * 3600 * 1000;
export const MAX_SITE_BYTES = 900 * 1024;
export const MAX_THUMB_BYTES = 600 * 1024;

const secret = (env = process.env) => {
  const k = env.PAGES_LINK_SECRET || env.ON3_VAULT_KEY || '';
  if (!k) throw new Error('PAGES_LINK_SECRET (or ON3_VAULT_KEY) is not set');
  return crypto.createHash('sha256').update('0n3-pages|' + k).digest();
};
const b64u = (b) => Buffer.from(b).toString('base64url');

export function signLink({ account, project, page, scope = 'view', ttlMs = null }, env) {
  const body = b64u(JSON.stringify({ a: account, w: project, p: page, s: scope, e: ttlMs ? Date.now() + ttlMs : 0 }));
  const mac = crypto.createHmac('sha256', secret(env)).update(body).digest('base64url').slice(0, 32);
  return `${body}.${mac}`;
}

export function verifyLink(token, env) {
  const [body, mac] = String(token || '').split('.');
  if (!body || !mac) return null;
  const want = crypto.createHmac('sha256', secret(env)).update(body).digest('base64url').slice(0, 32);
  if (mac.length !== want.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(want))) return null;
  let p; try { p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); } catch { return null; }
  if (!p || !p.a || !p.w || !p.p || !['view', 'edit'].includes(p.s)) return null;
  if (p.e && Date.now() > p.e) return null;
  return { account: p.a, project: p.w, page: p.p, scope: p.s, expires: p.e || null };
}

export function linksFor({ base, account, project, page }, env) {
  const view = signLink({ account, project, page, scope: 'view' }, env);
  const edit = signLink({ account, project, page, scope: 'edit', ttlMs: EDIT_TTL_MS }, env);
  return { previewUrl: `${base}/p/${view}`, editUrl: `${base}/pages/${edit}`, thumbUrl: `${base}/api/pages/thumb/${view}`, editExpires: new Date(Date.now() + EDIT_TTL_MS).toISOString() };
}

/** The builder's JSON, checked enough that a bad AI draft is refused with a reason instead of saved broken. */
export function cleanSite(site) {
  if (!site || typeof site !== 'object') throw new Error('site must be an object: { title, description, theme, pages: [...] }');
  let s = site;
  // A single page ({ title, theme, blocks }) is accepted and wrapped, because that is what most drafts produce.
  if (!Array.isArray(s.pages) && Array.isArray(s.blocks)) s = { title: s.title || 'Untitled', description: s.description || '', theme: s.theme || {}, pages: [{ id: 'page-home', title: 'Home', slug: '/', parentId: null, updatedAt: Date.now(), blocks: s.blocks }], currentPageId: 'page-home' };
  if (!Array.isArray(s.pages) || !s.pages.length) throw new Error('site.pages must hold at least one page');
  for (const p of s.pages) {
    if (!p || typeof p !== 'object' || !Array.isArray(p.blocks)) throw new Error(`page ${p && p.title ? `"${p.title}"` : ''} needs a blocks array`);
    if (!p.id) p.id = 'page-' + crypto.randomBytes(4).toString('hex');
    if (!p.slug) p.slug = p.id === s.pages[0].id ? '/' : '/' + String(p.title || p.id).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    if (p.parentId === undefined) p.parentId = null;
    if (!p.updatedAt) p.updatedAt = Date.now();
    for (const b of p.blocks) {
      if (!b || typeof b !== 'object' || !b.type) throw new Error('every block needs a type (hero, features, testimonials, pricing, cta, footer, media, contact, custom, app, elements, canvas, job)');
      if (!b.id) b.id = `${b.type}-${crypto.randomBytes(3).toString('hex')}`;
      if (!b.content || typeof b.content !== 'object') b.content = {};
      if (!b.styles || typeof b.styles !== 'object') b.styles = {};
      // A Job block (0n3 Jobs on pages) always carries a full style set, so a hand-written or AI-written one still renders well.
      if (b.type === 'job') b.styles = { backgroundColor: '#ffffff', textColor: '#18181b', accentColor: s.theme?.brandPrimary || '#171717', buttonTextColor: '#ffffff', paddingTop: 'py-16', paddingBottom: 'py-16', borderRadius: 'rounded-full', align: 'center', shadow: 'shadow-md', layoutStyle: 'centered', ...b.styles };
    }
  }
  if (!s.currentPageId || !s.pages.some((p) => p.id === s.currentPageId)) s.currentPageId = s.pages[0].id;
  s.theme = { primaryFont: 'font-sans', secondaryFont: 'font-sans', brandPrimary: '#4F46E5', brandSecondary: '#10B981', globalBorderRadius: 'rounded-xl', containerWidth: 'max-w-6xl', ...(s.theme || {}) };
  const bytes = Buffer.byteLength(JSON.stringify(s));
  if (bytes > MAX_SITE_BYTES) throw new Error(`the site is ${Math.round(bytes / 1024)} KB; the limit is ${MAX_SITE_BYTES / 1024} KB — use image URLs, not embedded images`);
  return s;
}

const esc = (v) => String(v ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hex = (v, d) => (/^#[0-9a-f]{3,8}$/i.test(String(v || '').trim()) ? String(v).trim() : d);

/**
 * A thumbnail for a page nobody has opened in the editor yet: the page's own sections as bands, in their own colours,
 * with their headlines. Drawn from the JSON, so it exists the moment the AI writes the page; the editor replaces it with a
 * real screenshot on the first save.
 */
export function schematicThumb(site, pageId = null) {
  const page = (site?.pages || []).find((p) => p.id === pageId) || (site?.pages || [])[0] || { blocks: [] };
  const H = { hero: 150, features: 90, testimonials: 70, pricing: 90, cta: 60, footer: 40, media: 90, contact: 70, custom: 60, app: 70, elements: 80, canvas: 90, job: 70 };
  let y = 0; const W = 640; const out = [];
  for (const b of (page.blocks || []).slice(0, 7)) {
    const h = H[b.type] || 70; if (y >= 400) break;
    const bg = hex(b.styles?.backgroundColor, '#f4f4f5'); const fg = hex(b.styles?.textColor, '#18181b'); const ac = hex(b.styles?.accentColor, '#4f46e5');
    const title = esc(String(b.content?.title || b.content?.logoText || b.type).slice(0, 48));
    out.push(`<rect x="0" y="${y}" width="${W}" height="${h}" fill="${bg}"/>`);
    out.push(`<text x="${b.type === 'hero' ? W / 2 : 28}" y="${y + Math.min(48, h / 2 + 6)}" text-anchor="${b.type === 'hero' ? 'middle' : 'start'}" font-family="Helvetica,Arial,sans-serif" font-size="${b.type === 'hero' ? 26 : 16}" font-weight="700" fill="${fg}">${title}</text>`);
    if (b.type === 'hero' && b.content?.buttonText) out.push(`<rect x="${W / 2 - 70}" y="${y + 80}" width="140" height="30" rx="15" fill="${ac}"/><text x="${W / 2}" y="${y + 100}" text-anchor="middle" font-family="Helvetica,Arial,sans-serif" font-size="12" font-weight="700" fill="${hex(b.styles?.buttonTextColor, '#ffffff')}">${esc(String(b.content.buttonText).slice(0, 20))}</text>`);
    if (['features', 'pricing', 'testimonials'].includes(b.type)) for (let i = 0; i < 3; i++) out.push(`<rect x="${28 + i * 200}" y="${y + h - 38}" width="180" height="26" rx="6" fill="${fg}" opacity="0.08"/>`);
    y += h;
  }
  if (!out.length) out.push(`<rect width="${W}" height="400" fill="#f4f4f5"/><text x="${W / 2}" y="205" text-anchor="middle" font-family="Helvetica,Arial,sans-serif" font-size="18" fill="#71717a">Empty page</text>`);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="400" viewBox="0 0 ${W} 400">${out.join('')}</svg>`;
}

/** The project page that holds a Struktur site, as the API hands it out (never the full site in a list). */
export function summary(p, links) {
  return { id: p.id, name: p.name, format: 'struktur', title: p.site?.title || p.name, pages: (p.site?.pages || []).map((x) => ({ id: x.id, title: x.title, slug: x.slug })), updatedAt: p.updatedAt || null, hasScreenshot: !!p.thumb, ...links };
}

/** "data:image/jpeg;base64,…" → { buffer, type }, refusing anything that is not a small png/jpeg/webp. */
export function decodeThumb(dataUrl) {
  const m = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
  if (!m) return null;
  const buffer = Buffer.from(m[2], 'base64');
  if (buffer.length > MAX_THUMB_BYTES) throw new Error(`thumbnail is ${Math.round(buffer.length / 1024)} KB; the limit is ${MAX_THUMB_BYTES / 1024} KB`);
  return { buffer, type: m[1] };
}

/**
 * What an AI is told to write a 0n3 Pages site (the same format and honesty rules as 0nCore's page_builder brief).
 * Used by POST /api/build. Answer = the site JSON itself.
 */
export const SITE_SYSTEM = `You design ONE web page for 0n3 Pages, a drag-and-drop builder. Answer with ONE JSON object and nothing else:
{ "title", "description" (one sentence for search), "theme": { "primaryFont": "font-sans"|"font-serif", "brandPrimary": "#hex", "brandSecondary": "#hex", "globalBorderRadius": "rounded-xl", "containerWidth": "max-w-6xl" }, "pages": [ { "title": "Home", "slug": "/", "blocks": [ ...sections top to bottom ] } ] }
EVERY block: { "type", "content", "styles" }; styles is ALWAYS complete: { "backgroundColor": "#hex", "textColor": "#hex", "accentColor": "#hex", "buttonTextColor": "#hex", "paddingTop": "py-16"|"py-20"|"py-24", "paddingBottom": same, "borderRadius": "rounded-xl", "align": "left"|"center"|"right", "shadow": "shadow-md"|"shadow-xl", "layoutStyle": "centered"|"split"|"grid" }
SECTION types and content:
- hero: title, subtitle (short label above), description, buttonText, buttonLink, secondaryButtonText, secondaryButtonLink, imageUrl, imageAlt (layoutStyle split = image beside text)
- features: title, description, features: [ { id, title, description, icon } ] (icon = Lucide name: Sparkles, Heart, Star, Shield, Zap, Clock, Calendar, Phone, MapPin, Gift, Award, Smile, TrendingUp, DollarSign, Users, CheckCircle)
- testimonials: title, testimonials: [ { id, name, role, quote, avatar } ]
- pricing: title, description, pricing: [ { id, planName, price, period, description, features: [..], isPopular, buttonText } ]
- cta: title, description, buttonText, buttonLink
- contact: title, description, contactEmail, contactPhone, address
- media: title, description, imageUrl, imageAlt
- footer: logoText, description, links: [ { label, url } ]
RULES: real, specific copy for this business in short plain sentences; never lorem ipsum. NEVER invent prices, reviews, testimonials, phone numbers, emails or addresses the person did not give: leave that section or field out. One brand palette; alternate section backgrounds (dark hero, light features, accent call to action); the hero says what it is and who it is for; end with a call to action. Images: https://images.unsplash.com/photo-... URLs that fit the business, with ?auto=format&fit=crop&w=1200&q=80. 3 to 6 sections. Short lowercase ids.`;
