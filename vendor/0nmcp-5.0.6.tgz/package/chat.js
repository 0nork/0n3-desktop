/**
 * THE WORKSPACE CHAT — an AI of the person's choice, with the board as its hands.
 *
 * Mike, 2026-10-22: "Most workspaces will start with an AI selection … they drag
 * in stripe, wordpress and mailchimp … their workspace will have a chatbox
 * connected to [that AI] that can create products in their WP store, attach
 * all prices and collect payment as well as create all email campaigns."
 *
 * So: the model is the person's own (their key, in their vault, under the
 * provider's service key); the tools are 0n3's generic runtime tools, FENCED to
 * what is on the board (only those services, only those mini-apps); the calls
 * run through the same engine every MCP client uses, with the connections of
 * whoever is chatting. The provider adapters below speak four dialects of the
 * same conversation: OpenAI-compatible (OpenAI, Groq, Cerebras, Mistral, OpenRouter, NVIDIA,
 * Ollama), Anthropic, Gemini. Which one answers is ai-router.js's job: the person's own order, with fallback.
 *
 * No Anthropic API is paid for by 0n: Anthropic is available only as the
 * customer's OWN key, like every other provider here.
 */
import { callTool } from './runtime.js';
import { getService } from './catalog.js';
import { SCOPE_METHODS } from './flow-defs.js';

export const PROVIDERS = {
  // strengths: 0..1 starting guesses per task, replaced over time by what this account's own feedback and tests measure
  // (ai-router.js). free: the provider gives a free tier on an email sign-up. get: where the person makes their OWN key.
  anthropic:  { name: 'Anthropic Claude (your key)', short: 'Cl', domain: 'anthropic.com', service: 'anthropic', model: 'claude-sonnet-5-5', base: 'https://api.anthropic.com/v1', dialect: 'anthropic', free: false, get: 'https://console.anthropic.com/settings/keys', strengths: { logic: 0.95, json: 0.9, tools: 0.95, speed: 0.6 } },
  openai:     { name: 'OpenAI (GPT)', short: 'AI', domain: 'openai.com', service: 'openai', model: 'gpt-4.1', base: 'https://api.openai.com/v1', dialect: 'openai', free: false, get: 'https://platform.openai.com/api-keys', strengths: { logic: 0.85, json: 0.9, tools: 0.9, speed: 0.6 } },
  gemini:     { name: 'Google Gemini', short: 'Ge', domain: 'gemini.google.com', service: 'gemini', aliases: ['google_ai'], model: 'gemini-2.5-flash', base: 'https://generativelanguage.googleapis.com/v1beta', dialect: 'gemini', free: true, get: 'https://aistudio.google.com/apikey', strengths: { logic: 0.8, json: 0.85, tools: 0.8, speed: 0.8 } },
  cerebras:   { name: 'Cerebras (very fast)', short: 'Ce', domain: 'cerebras.ai', service: 'cerebras', model: 'gpt-oss-120b', base: 'https://api.cerebras.ai/v1', dialect: 'openai', free: true, get: 'https://cloud.cerebras.ai', strengths: { logic: 0.75, json: 0.7, tools: 0.7, speed: 0.98 } },
  groq:       { name: 'Groq (fast)', short: 'Gq', domain: 'groq.com', service: 'groq', model: 'openai/gpt-oss-20b'  /* llama-3.3-70b-versatile retired by Groq (404). 2026-11-04: 120b drafted an empty board 3 of 6 tries (reasoning eats the JSON turn); 20b 3/3 with sequences */, base: 'https://api.groq.com/openai/v1', dialect: 'openai', free: true, get: 'https://console.groq.com/keys', strengths: { logic: 0.65, json: 0.7, tools: 0.7, speed: 0.95 } },
  mistral:    { name: 'Mistral', short: 'Mi', domain: 'mistral.ai', service: 'mistral', model: 'mistral-small-latest', base: 'https://api.mistral.ai/v1', dialect: 'openai', free: true, get: 'https://console.mistral.ai/api-keys', strengths: { logic: 0.65, json: 0.75, tools: 0.7, speed: 0.75 } },
  openrouter: { name: 'OpenRouter (free models)', short: 'OR', domain: 'openrouter.ai', service: 'openrouter', model: 'meta-llama/llama-3.3-70b-instruct:free', base: 'https://openrouter.ai/api/v1', dialect: 'openai', free: true, get: 'https://openrouter.ai/settings/keys', strengths: { logic: 0.6, json: 0.55, tools: 0.5, speed: 0.5 } },
  nvidia:     { name: 'NVIDIA NIM', short: 'Nv', domain: 'nvidia.com', service: 'nvidia', model: 'meta/llama-3.3-70b-instruct', base: 'https://integrate.api.nvidia.com/v1', dialect: 'openai', free: true, get: 'https://build.nvidia.com', strengths: { logic: 0.6, json: 0.6, tools: 0.55, speed: 0.6 } },
  ollama:     { name: 'Ollama (local)', short: 'Ol', domain: 'ollama.com', service: 'ollama', model: 'llama3.1', base: 'http://localhost:11434/v1', dialect: 'openai', keyless: true, local: true, free: true, get: 'https://ollama.com/download', strengths: { logic: 0.5, json: 0.5, tools: 0.4, speed: 0.5 } },
};
export const providerOf = (k) => PROVIDERS[k] || null;
const keyOf = (env) => { const c = env?.auth?.credentials || {}; return c.apiKey || c.api_key || c.key || c.token || c.access_token || null; };

const MAX_ROUNDS = 12;
const MAX_TOOL_CHARS = 24_000;

/** The generic tool surface the model sees. Same names as the MCP tools, so a skill written for one works for the other. */
export const TOOL_DEFS = [
  { name: 'whoami', description: 'Which account this is and which services it has connected.', parameters: { type: 'object', properties: {} } },
  { name: 'services', description: 'The services on this workspace, with whether they are connected for the person chatting.', parameters: { type: 'object', properties: {} } },
  { name: 'service_info', description: 'A service\'s endpoints and their params. Read this before api_call.', parameters: { type: 'object', properties: { service: { type: 'string' } }, required: ['service'] } },
  { name: 'api_call', description: 'Call one endpoint of one service with the person\'s own connection. Params = path, query or body fields from service_info.', parameters: { type: 'object', properties: { service: { type: 'string' }, endpoint: { type: 'string' }, params: { type: 'object', additionalProperties: true }, label: { type: 'string', description: 'Which record when several are held' } }, required: ['service', 'endpoint'] } },
  { name: 'app_info', description: 'What a mini-app on this workspace does, needs and takes.', parameters: { type: 'object', properties: { app: { type: 'string' } }, required: ['app'] } },
  { name: 'app_run', description: 'Run a mini-app on this workspace. Returns a receipt of every step.', parameters: { type: 'object', properties: { app: { type: 'string' }, input: { type: 'object', additionalProperties: true }, label: { type: 'string' } }, required: ['app'] } },
];

/**
 * @param {{ server: any, fence: { services: string[], apps: string[] }, workspace: { name: string, tagline?: string, intro?: string } }} o
 */
export function systemPrompt({ fence, workspace, account }) {
  return [
    `You are the assistant inside "${workspace.name}", a workspace built on 0n3.${workspace.tagline ? ` ${workspace.tagline}` : ''}`,
    workspace.intro ? workspace.intro : '',
    `The person chatting is ${account?.email || 'signed in to 0n'}. Every call you make runs with THEIR OWN connections; you never see or handle a secret.`,
    `Services on this board: ${fence.services.length ? fence.services.join(', ') : 'none'}. Mini-apps on this board: ${fence.apps.length ? fence.apps.join(', ') : 'none'}. You can only call those; anything else, say it is not on this board and what they could add.`,
    'Work the way a careful operator does: read service_info before api_call; name the exact thing you are about to create, charge, send or publish and ask once before anything irreversible unless the person already spelled it out; after a call, report what the provider actually said — a refusal names the fix, never say done for a step that did not run.',
    'If a service is not connected for this person, say so and point them to the Connect page on 0n3 (or the key box on this board). Keep answers short and concrete.',
  ].filter(Boolean).join('\n');
}

/** Run one guarded tool call against the runtime. Refuses anything outside the fence before touching the engine. */
export async function runFencedTool({ server, fence }, name, args = {}) {
  const def = TOOL_DEFS.find((t) => t.name === name);
  if (!def) return { error: `No tool called ${name}.` };
  const a = args && typeof args === 'object' ? args : {};
  if (name === 'services') {
    const all = await callTool(server, 'services', {});
    const rows = Array.isArray(all) ? all : (all?.services || []);
    return rows.filter((s) => fence.services.includes(s.key));
  }
  if (name === 'service_info' || name === 'api_call') {
    if (!fence.services.includes(String(a.service || ''))) return { error: `${a.service || '(no service)'} is not on this workspace. On the board: ${fence.services.join(', ') || 'nothing yet'}.` };
    // Scopes on a page element: Read = GET, Create = POST, Update = PUT/PATCH, Delete = DELETE.
    if (name === 'api_call' && fence.access) {
      const scopes = fence.access[a.service] || []; const allowed = scopes.flatMap((s) => SCOPE_METHODS[s] || []);
      const ep = getService(a.service)?.endpoints?.[a.endpoint]; const method = String(ep?.method || 'GET').toUpperCase();
      if (allowed.length && !allowed.includes(method)) return { error: `${a.service}.${a.endpoint} is ${method}; this element may only ${scopes.join(', ')} on ${a.service}.` };
    }
  }
  if (name === 'app_info' || name === 'app_run') {
    if (!fence.apps.includes(String(a.app || ''))) return { error: `${a.app || '(no app)'} is not on this workspace. Mini-apps here: ${fence.apps.join(', ') || 'none'}.` };
  }
  try { return await callTool(server, name, a); } catch (e) { return { error: e.message }; }
}

const clip = (v) => { const s = typeof v === 'string' ? v : JSON.stringify(v); return s.length > MAX_TOOL_CHARS ? s.slice(0, MAX_TOOL_CHARS) + ` …[${s.length - MAX_TOOL_CHARS} more chars]` : s; };

/**
 * One turn of the conversation. `history` is the stored thread in a neutral
 * shape: [{ role: 'user'|'assistant', content }]. Returns the assistant's
 * answer, the trace of tool calls it made, and the updated history.
 *
 * @param {{ provider: string, model?: string, apiKey: string|null, fetchImpl?: typeof fetch }} ai
 * @param {{ server: any, fence: any, workspace: any, account: any }} ctx
 * @param {{ history: any[], message: string }} turn
 */
export async function chatTurn(ai, ctx, { history = [], message }) {
  const p = providerOf(ai.provider);
  if (!p) return { error: `Unknown AI provider "${ai.provider}".` };
  if (!p.keyless && !ai.apiKey) return { error: `No ${p.name} key is connected for you. Add one under "${p.service}" and try again.`, missing: p.service };
  const model = ai.model || p.model;
  const fetchImpl = ai.fetchImpl || fetch;
  const sys = systemPrompt(ctx);
  const msgs = [...history, { role: 'user', content: String(message || '').slice(0, 8000) }];
  const trace = [];
  const tools = { call: async (name, args) => { const started = Date.now(); const result = await runFencedTool(ctx, name, args); trace.push({ tool: name, args, ok: !(result && result.error), ms: Date.now() - started, result: clip(result).slice(0, 2000) }); return clip(result); } };
  let out;
  try {
    out = p.dialect === 'anthropic' ? await anthropicLoop({ p, model, key: ai.apiKey, fetchImpl, sys, msgs, tools })
      : p.dialect === 'gemini' ? await geminiLoop({ p, model, key: ai.apiKey, fetchImpl, sys, msgs, tools })
      : await openaiLoop({ p, model, key: ai.apiKey, fetchImpl, sys, msgs, tools });
  } catch (e) { return { error: e.message, trace }; }
  if (out.error) return { error: out.error, trace };
  const answer = String(out.text || '').trim() || '(no answer)';
  return { answer, trace, model, history: [...msgs, { role: 'assistant', content: answer }] };
}

const providerError = async (r, p) => { const d = await r.json().catch(() => ({})); return `${p.name} answered ${r.status}: ${d?.error?.message || d?.error || d?.message || JSON.stringify(d).slice(0, 300)}`; };

// ── OpenAI-compatible (OpenAI, Groq, Ollama) ─────────────────────────────────
async function openaiLoop({ p, model, key, fetchImpl, sys, msgs, tools }) {
  const conv = [{ role: 'system', content: sys }, ...msgs.map((m) => ({ role: m.role, content: m.content }))];
  const defs = TOOL_DEFS.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters } }));
  for (let round = 0; round < MAX_ROUNDS; round++) {
    const r = await fetchImpl(`${p.base}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: `Bearer ${key}` } : {}) }, body: JSON.stringify({ model, messages: conv, tools: defs, tool_choice: 'auto', temperature: 0.2 }) });
    if (!r.ok) return { error: await providerError(r, p) };
    const d = await r.json();
    const m = d.choices?.[0]?.message;
    if (!m) return { error: `${p.name} returned no message.` };
    conv.push(m);
    const calls = m.tool_calls || [];
    if (!calls.length) return { text: m.content };
    for (const c of calls) {
      let args = {}; try { args = JSON.parse(c.function?.arguments || '{}'); } catch { args = {}; }
      const result = await tools.call(c.function?.name, args);
      conv.push({ role: 'tool', tool_call_id: c.id, content: result });
    }
  }
  return { error: 'Stopped after too many tool rounds without an answer.' };
}

// ── Anthropic Messages ───────────────────────────────────────────────────────
async function anthropicLoop({ p, model, key, fetchImpl, sys, msgs, tools }) {
  const conv = msgs.map((m) => ({ role: m.role, content: m.content }));
  const defs = TOOL_DEFS.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
  for (let round = 0; round < MAX_ROUNDS; round++) {
    const r = await fetchImpl(`${p.base}/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model, max_tokens: 2048, system: sys, messages: conv, tools: defs }) });
    if (!r.ok) return { error: await providerError(r, p) };
    const d = await r.json();
    const blocks = d.content || [];
    conv.push({ role: 'assistant', content: blocks });
    const uses = blocks.filter((b) => b.type === 'tool_use');
    if (!uses.length || d.stop_reason !== 'tool_use') return { text: blocks.filter((b) => b.type === 'text').map((b) => b.text).join('\n') };
    const results = [];
    for (const u of uses) results.push({ type: 'tool_result', tool_use_id: u.id, content: await tools.call(u.name, u.input || {}) });
    conv.push({ role: 'user', content: results });
  }
  return { error: 'Stopped after too many tool rounds without an answer.' };
}

// ── Gemini generateContent ───────────────────────────────────────────────────
async function geminiLoop({ p, model, key, fetchImpl, sys, msgs, tools }) {
  const contents = msgs.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
  const decls = TOOL_DEFS.map((t) => ({ name: t.name, description: t.description, parameters: t.parameters }));
  for (let round = 0; round < MAX_ROUNDS; round++) {
    const r = await fetchImpl(`${p.base}/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ systemInstruction: { parts: [{ text: sys }] }, contents, tools: [{ functionDeclarations: decls }] }) });
    if (!r.ok) return { error: await providerError(r, p) };
    const d = await r.json();
    const parts = d.candidates?.[0]?.content?.parts || [];
    contents.push({ role: 'model', parts });
    const calls = parts.filter((x) => x.functionCall);
    if (!calls.length) return { text: parts.filter((x) => x.text).map((x) => x.text).join('\n') };
    const responses = [];
    for (const c of calls) { const raw = await tools.call(c.functionCall.name, c.functionCall.args || {}); let parsed; try { parsed = JSON.parse(raw); } catch { parsed = { text: raw }; } responses.push({ functionResponse: { name: c.functionCall.name, response: typeof parsed === 'object' && parsed && !Array.isArray(parsed) ? parsed : { result: parsed } } }); }
    contents.push({ role: 'user', parts: responses });
  }
  return { error: 'Stopped after too many tool rounds without an answer.' };
}

/**
 * One plain completion — no tools, JSON wanted — on the person's own provider. Used by the builder's "Describe it".
 * Returns { text } or { error }. The caller parses the JSON; a provider that wraps it in prose still works (we strip).
 */
export async function complete({ provider, apiKey, model, system, user, fetchImpl = fetch, maxTokens = 4000 }) {
  const p = providerOf(provider);
  if (!p) return { error: `Unknown AI provider "${provider}".` };
  if (!p.keyless && !apiKey) return { error: `No ${p.name} key is connected for you. Add one under "${p.service}" and try again.`, missing: p.service };
  const m = model || p.model;
  try {
    if (p.dialect === 'anthropic') {
      const r = await fetchImpl(`${p.base}/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: m, max_tokens: maxTokens, system, messages: [{ role: 'user', content: user }] }) });
      if (!r.ok) return { error: await providerError(r, p) };
      const d = await r.json(); return { text: (d.content || []).filter((x) => x.type === 'text').map((x) => x.text).join('\n'), model: m };
    }
    if (p.dialect === 'gemini') {
      const r = await fetchImpl(`${p.base}/models/${encodeURIComponent(m)}:generateContent?key=${encodeURIComponent(apiKey)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts: [{ text: user }] }], generationConfig: { responseMimeType: 'application/json', maxOutputTokens: maxTokens } }) });
      if (!r.ok) return { error: await providerError(r, p) };
      const d = await r.json(); return { text: (d.candidates?.[0]?.content?.parts || []).filter((x) => x.text).map((x) => x.text).join('\n'), model: m };
    }
    const r = await fetchImpl(`${p.base}/chat/completions`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}) }, body: JSON.stringify({ model: m, messages: [{ role: 'system', content: system }, { role: 'user', content: user }], temperature: 0.4, max_tokens: maxTokens, response_format: { type: 'json_object' } }) });
    if (!r.ok) return { error: await providerError(r, p) };
    const d = await r.json(); return { text: d.choices?.[0]?.message?.content || '', model: m };
  } catch (e) { return { error: e.message }; }
}

export { keyOf };
