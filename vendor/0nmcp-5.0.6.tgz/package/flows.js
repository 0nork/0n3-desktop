/**
 * THE FLOW ENGINE — walks the flow blocks on a canvas and runs each one for
 * real through the same runtime tools an MCP client gets. Every step lands in
 * a receipt: ok / skipped-with-why / failed-with-the-provider's-own-words.
 * Nothing is simulated; a "Test run" is a run with a test payload.
 *
 *   trigger   → the payload (a test event, a webhook body, a page form)
 *   task      → api_call(app, TASKS[key].ep[app], params) or app_run for mini-app tasks
 *   action    → api_call(service, values.endpoint, values.params)
 *   logic     → if/else picks a port · filter stops · loop walks its children per item (≤ 25)
 *   waits     → a line's `wait` ('2 days') or a Wait block's `for`: a real run PARKS the rest of that branch (park() stores
 *               where it was and what it knew; the 5-minute clock resumes it with runFlow({ resume })). A test run does not
 *               wait: it says what it would have waited and goes straight on.
 *   data      → map / format into the context
 *   ai        → one provider call through chat.js (the person's own key), result saved under values.out
 *   tables    → the table blocks (blocks.js): pictures out of an email, a picture read several separate times on the person's own
 *               computer, only the rows every reading agrees on, rules per row, and a table updated without touching what a
 *               person typed. A reading that is not back in time PARKS the step itself and the clock picks it up again.
 *   terminal  → a desk run on the person's own machine (desk_agent / terminal_agent); skipped with the install line when no desk is wired
 *
 * DRY RUN (2026-11-10, Mike: "getting this UI WORKING and actually firing"): `dry: true` walks the same blocks with the same
 * data, and every READ (a GET endpoint), AI step, condition and mapping runs for real — but nothing that CHANGES an account
 * is sent. Each such step says what it would have done, in which connected account, with which values. A test must never
 * put "Test Customer" into a client's CRM to prove a drawing is wired.
 */
import { callTool } from './runtime.js';
import { chatTurn, providerOf, keyOf } from './chat.js';
import { getService } from './catalog.js';
import { agreeRows, keepRows, parseShare, rowsFromReading } from './blocks.js';
import { updateTable } from './table-io.js';
import { runMapBlock, drawMap } from './maps.js';
import { KINDS, promptFor, shapeDesign } from './outreach.js';
import { TASKS, TRIGGERS, defOf, ctxKey, isStart, resolveAll, resolveTemplate, evalCondition, evalFormat, parseJson, pathGet, nameOf, SCOPE_METHODS, parseWait, waitLabel } from './flow-defs.js';

const MAX_STEPS = 60;
const MAX_LOOP = 25;

/**
 * @param {{ server: any, store?: any, accountId?: string, nodes: any[], edges: any[], startId?: string, payload?: any,
 *           ai?: (provider: string) => Promise<{ apiKey: string|null }>, fetchImpl?: typeof fetch, access?: Record<string, string[]> | null,
 *           park?: (w: { node: string, from: string, ctx: any, dueAt: string, wait: string }) => Promise<string>,
 *           resume?: { node: string, ctx: any } }} o
 */
export async function runFlow({ server, nodes, edges, startId, payload = {}, ai = async () => ({ apiKey: null }), fetchImpl = fetch, access = null, desk = null, park = null, resume = null, dry = false, files = null, reader = null, memory = null, readWaitMs = 40000, sleep = (ms) => new Promise((r) => setTimeout(r, ms)) }) {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const flow = nodes.filter((n) => n.type !== 'shape');
  const start = resume ? byId[resume.node] : ((startId && byId[startId]) || flow.find(isStart) || flow[0]);
  const startedAt = new Date().toISOString();
  const steps = []; const waiting = [];
  if (!start) return { complete: false, outcome: resume ? 'The step this run was waiting to reach is no longer in the job, so it stopped here.' : 'Nothing to run: the canvas has no flow blocks.', steps, waiting, startedAt, finishedAt: startedAt };
  const ctx = resume ? { ...(resume.ctx || {}), now: new Date().toISOString() } : { trigger: payload || {}, now: new Date().toISOString() };
  const log = (n, state, detail, extra = {}) => { steps.push({ step: n.title || n.key, node: n.id, state, detail: String(detail || '').slice(0, 500), ...extra }); };
  const fenced = (service, method) => {
    if (!access) return null;
    const scopes = access[service];
    if (!scopes || !scopes.length) return `${nameOf(service)} is not on this element's allowed apps.`;
    const allowed = scopes.flatMap((s) => SCOPE_METHODS[s] || []);
    if (method && allowed.length && !allowed.includes(method)) return `${nameOf(service)} is allowed for ${scopes.join(', ')} only.`;
    return null;
  };

  const call = async (n, service, endpoint, params) => {
    const t0 = Date.now();
    const why = fenced(service, null);
    if (why) { log(n, 'skipped', why, { ms: 0 }); return null; }
    // The CRM scopes every write to a location; the connection record knows which one. Fill it in rather than let the CRM answer 403 for a missing field.
    if (service === 'crm' && params && typeof params === 'object' && !params.locationId) {
      try { const rec = await callTool(server, 'vault_record', { service: 'crm', label: n.label || undefined }); const loc = rec?.meta?.location_id || rec?.meta?.locationId; if (loc) params = { ...params, locationId: loc }; } catch { /* the CRM will say */ }
    }
    // DRY RUN: a call that changes something is described, not sent. The receipt names the account it would have used.
    const method = String(getService(service)?.endpoints?.[endpoint]?.method || 'POST').toUpperCase();
    if (dry && method !== 'GET') {
      let rec = null; try { rec = await callTool(server, 'vault_record', { service, label: n.label || undefined }); } catch { rec = null; }
      if (!rec || rec.error) { log(n, 'skipped', `${nameOf(service)} is not in your vault — connect it first`, { ms: 0, service, endpoint, dry: true }); return { ok: false, error: 'not connected' }; }
      const acct = rec.label || rec.$0n?.name || n.label || '';
      const would = Object.fromEntries(Object.entries(params && typeof params === 'object' ? params : {}).slice(0, 12).map(([k, val]) => [k, typeof val === 'string' ? val.slice(0, 160) : val]));
      log(n, 'ok', `Dry run — would ${method} ${nameOf(service)} · ${endpoint}${acct ? ` in “${acct}”` : ''}. Nothing was sent.`, { ms: Date.now() - t0, service, endpoint, dry: true, account: acct || undefined, would });
      return { ok: true, status: 0, data: { ...would, id: 'dry-run', dry: true } }; // the next steps see the values this one would have saved
    }
    let r;
    // `label` = which record when the account holds several for one service (12 CRM locations on Mike's account): the block chooses.
    try { r = await callTool(server, 'api_call', { service, endpoint, params, label: n.label || undefined }); } catch (e) { r = { error: e.message }; }
    const ms = Date.now() - t0;
    // Not connected is a SKIP with the fix named, like the handoff shows; a provider refusal is a FAIL with its own words.
    if (r && r.error && !r.data) { const notConn = /not connected/i.test(r.error); log(n, notConn ? 'skipped' : 'failed', notConn ? `${nameOf(service)} is not in your vault — connect it first` : r.error, { ms, service, endpoint }); return { ok: false, error: r.error }; }
    const ok = r && (r.ok !== false) && !(r.status >= 400);
    log(n, ok ? 'ok' : 'failed', ok ? `${nameOf(service)} · ${r.status || 200}` : (r.error || `${nameOf(service)} answered ${r.status}`), { ms, service, endpoint });
    return { ok, status: r.status, data: r.data, error: ok ? null : r.error };
  };

  // One api_call for the table blocks: no receipt line of its own (the block writes ONE line for the whole job).
  const api = async (n, service, endpoint, params) => {
    const why = fenced(service, String(getService(service)?.endpoints?.[endpoint]?.method || 'POST').toUpperCase());
    if (why) return { ok: false, error: why };
    let r; try { r = await callTool(server, 'api_call', { service, endpoint, params, label: n.label || undefined }); } catch (e) { r = { error: e.message }; }
    if (r && r.error && r.data === undefined) return { ok: false, error: r.error, notConnected: /not connected/i.test(r.error) };
    const ok = r && r.success !== false && r.ok !== false && !(Number(r.status) >= 400);
    return { ok, status: r?.status, data: r?.data, usage: r?.usage || null, error: ok ? null : (r?.data?.error?.message || r?.data?.message || r?.error || `answered ${r?.status}`) };
  };
  const asList = (x) => (Array.isArray(x) ? x : (typeof x === 'string' && x.trim().startsWith('[') ? parseJsonArray(x) : []));

  const walk = async (n, depth = 0) => {
    if (steps.length >= MAX_STEPS) { log(n, 'skipped', `Stopped at ${MAX_STEPS} steps.`); return; }
    const d = defOf(n);
    // A field left blank uses the placeholder the builder showed for it ('{{trigger.email}}' and friends): what you see is what runs.
    const defaults = Object.fromEntries((d.fields || []).filter(([, , ph]) => ph).map(([k, , ph]) => [k, ph]));
    const filled = { ...defaults, ...Object.fromEntries(Object.entries(n.values || {}).filter(([, val]) => val !== '' && val !== undefined && val !== null)) };
    const v = resolveAll(filled, ctx);
    const key = ctxKey(n);
    let port = 0; let out = null; let continueFlow = true; let waitFor = '';
    switch (n.type) {
      case 'trigger': {
        out = ctx.trigger;
        log(n, 'ok', n.key === 'page_button' ? `Button "${v.name || n.title}" pressed` : n.key === 'schedule' ? `Schedule fired (${v.cron || 'now'})` : n.key === 'email' && ctx.trigger?.subject ? `Email “${String(ctx.trigger.subject).slice(0, 80)}” in ${ctx.trigger.mailbox || v.mailbox || 'the mailbox'}` : 'Test event received', { ms: 0 });
        break;
      }
      case 'task': {
        const def = TASKS[n.key]; const app = n.app;
        if (!def) { log(n, 'failed', `Unknown task ${n.key}`); break; }
        if (def.big === 'email_pictures') {
          const t0 = Date.now();
          if (!v.mailbox || !v.message) { log(n, 'failed', 'This step needs the mailbox and the email. Start the job with “Email arrives”, or fill both in.', { ms: 0 }); continueFlow = false; break; }
          if (!files) { log(n, 'failed', 'File storage is not available here, so the pictures cannot be kept for the next step.', { ms: 0 }); continueFlow = false; break; }
          const r = await api(n, app, 'list_message_attachments', { mailbox: v.mailbox, messageId: v.message });
          if (!r.ok) { log(n, r.notConnected ? 'skipped' : 'failed', r.notConnected ? `${nameOf(app)} is not in your vault — connect it first` : `${nameOf(app)}: ${r.error}`, { ms: Date.now() - t0 }); continueFlow = false; break; }
          const pics = (r.data?.value || []).filter((a) => /^image\//i.test(a.contentType || '') && a.contentBytes).sort((a, b) => (b.size || 0) - (a.size || 0)).slice(0, Math.min(6, Math.max(1, Number(v.max) || 1)));
          if (!pics.length) { log(n, 'failed', `That email has no picture in it (${(r.data?.value || []).length} attachment${(r.data?.value || []).length === 1 ? '' : 's'}).`, { ms: Date.now() - t0 }); continueFlow = false; break; }
          const kept = [];
          try { for (const [i, a] of pics.entries()) { const type = String(a.contentType).toLowerCase().split(';')[0]; const ext = /png/.test(type) ? 'png' : /jpe?g/.test(type) ? 'jpg' : /webp/.test(type) ? 'webp' : 'img'; kept.push(await files.put(`picture-${i + 1}.${ext}`, Buffer.from(a.contentBytes, 'base64'), type)); } }
          catch (e) { log(n, 'failed', `The picture could not be kept: ${e.message}`, { ms: Date.now() - t0 }); continueFlow = false; break; }
          out = { pictures: kept, count: kept.length, message: v.message, mailbox: v.mailbox };
          log(n, 'ok', `${kept.length} picture${kept.length === 1 ? '' : 's'} taken from the email (${kept.map((k) => `${Math.round((k.size || 0) / 1024)} KB`).join(', ')})`, { ms: Date.now() - t0 });
          break;
        }
        if (def.big === 'map') {
          // THE MAP BLOCKS (maps.js): one receipt line for the whole block; a refusal carries the provider's own words.
          const t0 = Date.now();
          const r = await runMapBlock({ op: n.key, app, v, ctx, dry, wait: sleep, api: (svc, e, p) => api(n, svc, e, p) });
          log(n, r.state, r.detail, { ms: Date.now() - t0, ...(r.extra || {}) });
          if (r.out) out = r.out; if (r.state !== 'ok') continueFlow = false;
          break;
        }
        if (def.big === 'update_table') {
          const t0 = Date.now();
          const r = await updateTable({ api: (s, e, p) => api(n, s, e, p), app, values: { ...v, rows: asList(v.rows) }, dry, memory });
          log(n, r.state, r.detail, { ms: Date.now() - t0, ...(r.extra || {}), ...(r.out?.kept?.length ? { list: r.out.kept.slice(0, 20).map((k) => `${k.key} · ${k.column}: the tab has “${k.has}”, the new value was “${k.would}”`) } : {}) });
          if (r.out) out = r.out; if (r.state !== 'ok') continueFlow = false;
          break;
        }
        if (def.app_run && def.app_run[app]) {
          const t0 = Date.now(); const why = fenced(app, 'POST'); if (why) { log(n, 'skipped', why, { ms: 0 }); break; }
          if (dry) { log(n, 'ok', `Dry run — would run “${def.label}” in ${nameOf(app)}. Nothing was sent.`, { ms: 0, dry: true, would: v }); out = { dry: true }; break; }
          let r; try { r = await callTool(server, 'app_run', { app: def.app_run[app], input: v }); } catch (e) { r = { error: e.message }; }
          const ok = !r.error && r.complete !== false; out = r; log(n, ok ? 'ok' : (r.error ? 'failed' : 'failed'), ok ? (r.outcome || 'Done') : (r.error || r.outcome || 'Did not finish'), { ms: Date.now() - t0, receipt: r.steps ? r.steps.slice(0, 12) : undefined });
          break;
        }
        const ep = def.ep && def.ep[app];
        if (!ep) { log(n, 'skipped', `${nameOf(app)} cannot do "${def.label}" here — pick another app.`); break; }
        const params = def.params && def.params[app] ? def.params[app](v, ctx) : v;
        const r = await call(n, app, ep, params); const data = r && def.out && def.out[app] && r.data && typeof r.data === 'object' ? def.out[app](r.data) : r?.data; out = r ? { ...(data && typeof data === 'object' ? data : { data }), ok: r.ok } : null;
        break;
      }
      case 'action': {
        if (!v.endpoint) { log(n, 'skipped', `No endpoint chosen for ${nameOf(n.app)}.`); break; }
        const r = await call(n, n.app, v.endpoint, parseJson(typeof v.params === 'string' ? v.params : JSON.stringify(v.params || {})));
        out = r ? { ...(r.data && typeof r.data === 'object' ? r.data : { data: r.data }), ok: r.ok } : null;
        break;
      }
      case 'logic': {
        if (n.key === 'ifelse') { const yes = evalCondition(n.values?.cond, ctx); port = yes ? 0 : 1; log(n, 'ok', `${yes ? 'Yes' : 'No'}: ${resolveTemplate(String(n.values?.cond || ''), ctx)}`, { ms: 0 }); }
        else if (n.key === 'filter') { const pass = evalCondition(n.values?.cond, ctx); log(n, pass ? 'ok' : 'skipped', pass ? 'Passed' : `Stopped: ${resolveTemplate(String(n.values?.cond || ''), ctx)} is not true`, { ms: 0 }); continueFlow = pass; }
        else if (n.key === 'delay') { const ms = parseWait(v.for); if (!ms) { log(n, 'failed', `"${v.for}" is not a length of time. Write it like 2 days, 3 hours or 1 week.`, { ms: 0 }); continueFlow = false; } else { log(n, 'ok', `Wait ${waitLabel(ms)}`, { ms: 0 }); waitFor = v.for; } }
        else if (n.key === 'loop') {
          const list = resolveTemplate(String(n.values?.over || ''), ctx); const items = Array.isArray(list) ? list : (typeof list === 'string' && list.trim().startsWith('[') ? parseJsonArray(list) : []);
          log(n, 'ok', `${Math.min(items.length, MAX_LOOP)} item${items.length === 1 ? '' : 's'}${items.length > MAX_LOOP ? ` (capped at ${MAX_LOOP})` : ''}`, { ms: 0 });
          for (const item of items.slice(0, MAX_LOOP)) { ctx.item = item; await follow(n, 0, '', depth); }
          delete ctx.item; continueFlow = false;
        }
        break;
      }
      case 'data': {
        if (n.key === 'map') { const o = {}; for (const line of String(n.values?.map || '').split('\n')) { const m = /^(.*?)\s*(?:→|->|=>)\s*(.*)$/.exec(line.trim()); if (m) o[m[2].trim()] = pathGet(ctx, m[1].trim()) ?? resolveTemplate(m[1].trim(), ctx); } out = o; for (const [k, val] of Object.entries(o)) setPath(ctx, k, val); log(n, 'ok', `${Object.keys(o).length} field${Object.keys(o).length === 1 ? '' : 's'} mapped`, { ms: 0 }); }
        else if (n.key === 'format') { const val = evalFormat(n.values?.expr, ctx); const name = (n.values?.out || key).trim(); ctx[name] = val; out = val; log(n, 'ok', `${name} = ${String(val).slice(0, 80)}`, { ms: 0 }); }
        else if (n.key === 'agree') {
          const res = agreeRows(asList(v.readings), { key: v.key, min: parseShare(v.min) });
          const held = res.held.slice(0, 30).map((h) => (h.key ? `${h.key}: ${h.why}` : h.why));
          if (!res.ok) { log(n, 'failed', res.why, { ms: 0, list: held }); continueFlow = false; out = res; }
          else { out = res; log(n, 'ok', `${res.rows.length} of ${res.total} rows were read the same way ${res.readings.length} times${res.held.length ? ` · ${res.held.length} held back` : ''}`, { ms: 0, ...(held.length ? { list: held } : {}) }); }
        }
        else if (n.key === 'keep_rows') {
          const res = keepRows(asList(v.rows), n.values?.rules || '', { key: v.key || ctx.agreed?.key || '' });
          out = res;
          if (!res.ok) { log(n, 'failed', res.problems[0], { ms: 0, list: res.problems.slice(0, 10) }); continueFlow = false; }
          else log(n, 'ok', `${res.rows.length} of ${res.rows.length + res.dropped.length} rows pass ${res.rules} rule${res.rules === 1 ? '' : 's'}${res.dropped.length ? ` · ${res.dropped.length} left out` : ''}`, { ms: 0, ...(res.dropped.length ? { list: res.dropped.slice(0, 30).map((d) => `${d.key}: ${d.why}`) } : {}) });
        }
        else if (n.key === 'draw_map') {
          const res = drawMap(ctx, { title: v.title, extra: v.extra });
          if (!res.ok) { log(n, 'failed', res.why, { ms: 0 }); continueFlow = false; }
          else { out = res.map; log(n, 'ok', `Map drawn: ${res.map.points.length} place${res.map.points.length === 1 ? '' : 's'}, ${res.map.lines.length} route${res.map.lines.length === 1 ? '' : 's'}${res.map.areas.length ? `, ${res.map.areas.length} area${res.map.areas.length === 1 ? '' : 's'}` : ''}`, { ms: 0, map: res.map }); }
        }
        else if (n.key === 'return') {
          // THE JOB'S ANSWER (2026-11-12, Mike: "being able to grab the output of the sequences is most important"). What this
          // block resolves to is what POST /api/jobs/:job/run hands back as `output`. JSON written with {{…}} inside is resolved
          // first and then parsed, so a Job can return a real object. It ends its path: nothing after a Return runs.
          out = returnValue(n.values?.value ?? '{{last}}', ctx); ctx.__output = out; continueFlow = false;
          log(n, 'ok', `Returned ${describeOutput(out)}`, { ms: 0 });
        }
        else { log(n, 'ok', 'Paths joined', { ms: 0 }); }
        break;
      }
      case 'ai': {
        if (n.key === 'read_picture') {
          const t0 = Date.now();
          if (!reader) { log(n, 'skipped', 'Reading a picture happens on your own computer, and none is linked yet — set it up once from the Install page.', { ms: 0 }); continueFlow = false; break; }
          const pictures = asList(v.pictures).filter((p) => p && p.path);
          const times = Math.min(4, Math.max(1, Number(v.times) || 2));
          ctx.__reading = ctx.__reading || {};
          let job = ctx.__reading[n.id];
          if (!job) {
            if (!pictures.length) { log(n, 'failed', 'There is no picture to read. Put “Get the pictures from an email” before this step.', { ms: 0 }); continueFlow = false; break; }
            try { const ids = []; for (let i = 0; i < times; i++) ids.push(await reader.start({ pictures, prompt: String(v.prompt || ''), label: `${n.title || 'Read a picture'} · reading ${i + 1} of ${times}` })); job = ctx.__reading[n.id] = { ids, since: Date.now(), parks: 0 }; }
            catch (e) { log(n, 'failed', `The reading could not be started: ${e.message}`, { ms: Date.now() - t0 }); continueFlow = false; break; }
          }
          let got = null; let bad = null;
          for (;;) {
            const st = await Promise.all(job.ids.map((id) => reader.check(id).catch((e) => ({ state: 'unknown', reply: e.message }))));
            bad = st.find((x) => x.state === 'failed') || null; if (bad) break;
            if (st.every((x) => x.state === 'done')) { got = st; break; }
            if (Date.now() - t0 >= readWaitMs) break;
            await sleep(3000);
          }
          if (bad) { delete ctx.__reading[n.id]; log(n, 'failed', `A reading did not finish: ${String(bad.reply || '').slice(0, 200)}`, { ms: Date.now() - t0 }); continueFlow = false; break; }
          if (!got) {
            continueFlow = false;
            const waited = Math.round((Date.now() - job.since) / 1000);
            if (park && job.parks < 6) {
              job.parks++;
              try { const dueAt = new Date(Date.now() + 60000).toISOString(); const id = await park({ node: n.id, from: n.id, ctx: JSON.parse(JSON.stringify(ctx)), dueAt, wait: 'the reading' }); waiting.push({ id, node: n.id, step: n.title || n.key, dueAt, wait: 'the reading' }); log(n, 'waiting', `Your computer is still reading (${waited} s so far). The job picks up here by itself when it is done.`, { ms: Date.now() - t0, wait: 'the reading', waitId: id }); }
              catch (e) { log(n, 'failed', `Your computer is still reading and the job could not wait for it: ${e.message}`, { ms: Date.now() - t0 }); }
            } else { delete ctx.__reading[n.id]; log(n, 'failed', `Your computer did not finish reading within ${waited} s. Is it on and awake? Nothing after this step ran.`, { ms: Date.now() - t0 }); }
            break;
          }
          delete ctx.__reading[n.id];
          const readings = got.map((x) => rowsFromReading(x.reply));
          out = { readings, first: readings[0] || [], second: readings[1] || [], rows: readings.map((r) => r.length), runs: job.ids };
          const empty = readings.findIndex((r) => !r.length);
          if (empty >= 0) { log(n, 'failed', `Reading ${empty + 1} came back without a table: “${String(got[empty].reply || '').slice(0, 140)}”`, { ms: Date.now() - t0 }); continueFlow = false; break; }
          log(n, 'ok', `Read ${times} separate time${times === 1 ? '' : 's'} on your computer: ${readings.map((r) => `${r.length} rows`).join(', ')}`, { ms: Date.now() - t0 });
          break;
        }
        const t0 = Date.now(); const p = providerOf(n.app);
        if (!p) { log(n, 'failed', `Unknown AI ${n.app}`); break; }
        // ai(n.app) may hand back `chat` — the AI router: the step's AI first, then the owner's other AIs on a limit or error.
        const got = await ai(n.app);
        const ctxChat = { server, fence: { services: [], apps: [] }, workspace: { name: 'flow', intro: 'Answer plainly, no tool calls.' }, account: null };
        // OUTREACH: the designer's own instructions for that kind (outreach.js), the answer shaped into a design. Later steps read
        // it as {{design.html}}, {{design.subject}}, {{design.svg}}, {{design.posts}} (or under the "Save result as" name).
        let od = null;
        if (n.key === 'outreach') { try { od = promptFor(String(v.kind || 'email').trim().toLowerCase(), v, {}); } catch (e) { log(n, 'failed', e.message, { ms: 0 }); continueFlow = false; break; } }
        const msg = { history: [], message: od ? `${od.system}\n\n${od.user}` : String(v.prompt || '') };
        const turn = got.chat ? await got.chat(ctxChat, msg) : await chatTurn({ provider: n.app, apiKey: got.apiKey, fetchImpl }, ctxChat, msg);
        if (turn.error) { log(n, 'failed', turn.error, { ms: Date.now() - t0 }); break; }
        if (od) {
          let d; try { d = shapeDesign(String(v.kind || 'email').trim().toLowerCase(), turn.answer, v); } catch (e) { log(n, 'failed', e.message, { ms: Date.now() - t0 }); continueFlow = false; break; }
          const nm = (n.values?.out || 'design').trim(); ctx[nm] = d; out = d;
          log(n, 'ok', `Designed ${KINDS[d.kind].label.toLowerCase()}: ${d.name}${d.subject ? ` — "${d.subject}"` : ''}${d.kind === 'social' ? ' (picture described, not drawn yet)' : ''}`, { ms: Date.now() - t0 });
          break;
        }
        const name = (n.values?.out || key).trim(); ctx[name] = turn.answer; out = turn.answer;
        const who = providerOf(turn.provider)?.name || p.name;
        log(n, 'ok', `${who}${turn.tried?.length ? ` (after ${turn.tried.map((x) => providerOf(x.provider)?.name || x.provider).join(', ')} failed)` : ''}: ${turn.answer.slice(0, 120)}`, { ms: Date.now() - t0 });
        break;
      }
      case 'terminal': {
        const t0 = Date.now();
        // The desk is how a flow reaches the person's own machine: the step becomes a desk run (queued for their
        // machine, or any of theirs), the agent they installed claims it, and the receipt names the run. The flow does
        // not wait — a machine may be asleep — so what follows this step sees `{{agent.run}}` and `{{agent.state}}`.
        if (n.key === 'terminal_cmd') { log(n, 'ok', 'This flow is exposed to your coding agent as a tool; it started from there.', { ms: 0 }); out = { summary: 'tool start' }; break; }
        if (!desk) { log(n, 'skipped', `${nameOf(n.app)} on your machine is not linked yet — set it up once from the Install page (the one-line desk installer), then this step hands the job over.`, { ms: 0 }); out = { summary: '' }; break; }
        const v = n.values || {};
        const request = n.key === 'desk_agent'
          ? resolveTemplate(String(v.prompt || v.request || payload.message || payload.request || `Request from the "${n.title || 'desk'}" step`), ctx)
          : resolveTemplate(String(v.prompt || ''), ctx);
        if (!String(request || '').trim()) { log(n, 'failed', 'The step has no instructions for the agent.', { ms: 0 }); break; }
        if (dry) { out = { run: 'dry-run', state: 'dry', summary: 'dry run' }; ctx.agent = out; log(n, 'ok', `Dry run — would hand this to ${nameOf(n.app)} on your computer: “${String(request).slice(0, 160)}”. Nothing was queued.`, { ms: 0, dry: true }); break; }
        try {
          const run = await desk.create({ project: v.project || null, folder: v.folder || v.cwd || null, machine: v.machine || null, agent: n.app || 'claude_code', rules: v.rules || '', request: String(request), source: { kind: 'flow', subject: n.title || n.key } });
          out = { run: run.id, state: run.state, machine: run.machine || 'any of your machines', summary: `handed to your desk (run ${run.id})` };
          ctx.agent = out;
          log(n, 'ok', `Handed to your desk: run ${run.id}, queued for ${run.machine || 'any of your machines'} · ${nameOf(n.app)} in ${v.folder || v.cwd || 'the project folder'}. It asks on your phone if unsure; the receipt lands in Alerts.`, { ms: Date.now() - t0 });
        } catch (e) { log(n, 'failed', e.message, { ms: Date.now() - t0 }); }
        break;
      }
      default: log(n, 'skipped', `Unknown block type ${n.type}`);
    }
    if (out !== null && out !== undefined) { ctx[key] = out; ctx.last = out; if (d.alias) ctx[d.alias] = out; }
    if (!continueFlow) return;
    await follow(n, port, waitFor, depth);
  };

  // Down every line out of n on that port. A line with a wait (or every line out of a Wait block) parks what follows on a
  // real run; a test run says what it would have waited and carries on, so a test never takes two days.
  const follow = async (n, port, blockWait, depth) => {
    for (const e of edges.filter((x) => x.from === n.id && (x.port || 0) === port)) {
      const c = byId[e.to]; if (!c) continue;
      const words = e.wait || blockWait; const ms = parseWait(words);
      if (!ms) { await walk(c, depth + 1); continue; }
      const label = waitLabel(ms); const dueAt = new Date(Date.now() + ms).toISOString();
      if (!park) { log(c, 'ok', `Would wait ${label} before this step. A test run does not wait.`, { ms: 0, wait: label }); await walk(c, depth + 1); continue; }
      const snap = JSON.stringify(ctx);
      if (snap.length > 200000) { log(c, 'failed', `Could not wait ${label}: what the run knows by now is too large to keep (${Math.round(snap.length / 1000)} KB, the limit is 200 KB).`, { ms: 0 }); continue; }
      try {
        const id = await park({ node: c.id, from: n.id, ctx: JSON.parse(snap), dueAt, wait: label });
        waiting.push({ id, node: c.id, step: c.title || c.key, dueAt, wait: label });
        log(c, 'waiting', `Waits ${label}, then continues here (due ${dueAt.slice(0, 16).replace('T', ' ')} UTC).`, { ms: 0, wait: label, dueAt, waitId: id });
      } catch (err) { log(c, 'failed', `Could not start the ${label} wait: ${err.message}`, { ms: 0 }); }
    }
  };

  await walk(start);
  const failed = steps.filter((s) => s.state === 'failed').length; const skipped = steps.filter((s) => s.state === 'skipped').length; const ok = steps.filter((s) => s.state === 'ok').length;
  const later = waiting.length ? ` ${waiting.length === 1 ? `Continues in ${waiting[0].wait} at "${waiting[0].step}".` : `${waiting.length} paths continue later (first in ${waiting.map((w) => w.wait)[0]}).`}` : '';
  const outcome = (!failed && !skipped ? (waiting.length ? 'Everything up to the wait was done.' : 'Everything requested was done.') : `${ok} of ${steps.length - waiting.length} steps done — ${[failed && `${failed} failed`, skipped && `${skipped} skipped`].filter(Boolean).join(', ')}. See steps.`) + later;
  const output = Object.prototype.hasOwnProperty.call(ctx, '__output') ? ctx.__output : (ctx.last ?? null);
  const outputFrom = Object.prototype.hasOwnProperty.call(ctx, '__output') ? 'return' : (ctx.last !== undefined ? 'last step' : 'none');
  if (dry) { const held = steps.filter((x) => x.dry && x.state === 'ok').length; return { output, outputFrom, complete: failed === 0 && skipped === 0, partial: failed === 0 && skipped > 0, dry: true, outcome: `Dry run: ${ok} of ${steps.length} steps passed${held ? `, ${held} would change an account and ${held === 1 ? 'was' : 'were'} held back` : ''}${failed || skipped ? ` — ${[failed && `${failed} failed`, skipped && `${skipped} skipped`].filter(Boolean).join(', ')}` : ''}. Nothing was sent.`, steps, waiting, startedAt, finishedAt: new Date().toISOString(), start: start.id }; }
  return { complete: failed === 0 && skipped === 0, partial: failed === 0 && skipped > 0, outcome, output, outputFrom, steps, waiting, startedAt, finishedAt: new Date().toISOString(), start: start.id };
}

/** A Return block's value: a {{path}} keeps its type; JSON with {{…}} inside is resolved (values JSON-quoted) and parsed. */
export function returnValue(raw, ctx) {
  if (typeof raw !== 'string') return raw;
  const t = raw.trim();
  if (/^[\[{]/.test(t)) {
    // 1) Valid JSON as written ({"name": "{{contact.name}}"}): parse, then fill every string (a lone {{path}} keeps its type).
    const deep = (v) => (typeof v === 'string' ? resolveTemplate(v, ctx) : Array.isArray(v) ? v.map(deep) : v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, deep(x)])) : v);
    try { return deep(JSON.parse(t)); } catch { /* 2) bare {{path}} values: drop each in as JSON */ }
    try { return JSON.parse(t.replace(/\{\{\s*([\w.$-]+)\s*\}\}/g, (_, p) => { const v = pathGet(ctx, p); return JSON.stringify(v === undefined ? null : v); })); } catch { /* not JSON after all */ }
  }
  return resolveTemplate(raw, ctx);
}
const describeOutput = (o) => (o === null || o === undefined || o === '' ? 'nothing' : Array.isArray(o) ? `a list of ${o.length}` : typeof o === 'object' ? `an object (${Object.keys(o).slice(0, 6).join(', ')}${Object.keys(o).length > 6 ? ', …' : ''})` : `“${String(o).slice(0, 120)}”`);

function parseJsonArray(s) { try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return []; } }
function setPath(obj, path, val) { const ks = String(path).split('.'); let o = obj; for (let i = 0; i < ks.length - 1; i++) { if (!o[ks[i]] || typeof o[ks[i]] !== 'object') o[ks[i]] = {}; o = o[ks[i]]; } o[ks[ks.length - 1]] = val; }

/** The flow a page button starts: the trigger named like the button's `runs`, else the first start. */
export function startForButton(nodes, runs) {
  const want = String(runs || '').trim().toLowerCase();
  const t = nodes.find((n) => n.type === 'trigger' && n.key === 'page_button' && String(n.values?.name || n.title || '').trim().toLowerCase() === want) || nodes.find((n) => n.type === 'trigger' && String(n.title || '').trim().toLowerCase() === want);
  return t || null;
}

/** Which services + mini-apps a chat element may touch, from its access map. Empty access = nothing. */
export function fenceFromAccess(access) {
  const services = Object.entries(access || {}).filter(([, s]) => Array.isArray(s) && s.length).map(([k]) => k);
  return { services, apps: [], access: access || {} };
}

export { TRIGGERS };
