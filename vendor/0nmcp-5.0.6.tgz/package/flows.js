/**
 * THE FLOW ENGINE — walks the flow blocks on a canvas and runs each one for
 * real through the same runtime tools an MCP client gets. Every step lands in
 * a receipt: ok / skipped-with-why / failed-with-the-provider's-own-words.
 * Nothing is simulated; a "Test run" is a run with a test payload.
 *
 *   trigger   → the payload (a test event, a webhook body, a page form)
 *   task      → api_call(app, TASKS[key].ep[app], params) or app_run for mini-app tasks
 *   action    → api_call(service, values.endpoint, values.params)
 *   logic     → if/else picks a port · filter stops · loop walks its children per item (≤ 25)
 *   waits     → a line's `wait` ('2 days') or a Wait block's `for`: a real run PARKS the rest of that branch (park() stores
 *               where it was and what it knew; the 5-minute clock resumes it with runFlow({ resume })). A test run does not
 *               wait: it says what it would have waited and goes straight on.
 *   data      → map / format into the context
 *   ai        → one provider call through chat.js (the person's own key), result saved under values.out
 *   terminal  → a desk run on the person's own machine (desk_agent / terminal_agent); skipped with the install line when no desk is wired
 */
import { callTool } from './runtime.js';
import { chatTurn, providerOf, keyOf } from './chat.js';
import { TASKS, TRIGGERS, defOf, ctxKey, isStart, resolveAll, resolveTemplate, evalCondition, evalFormat, parseJson, pathGet, nameOf, SCOPE_METHODS, parseWait, waitLabel } from './flow-defs.js';

const MAX_STEPS = 60;
const MAX_LOOP = 25;

/**
 * @param {{ server: any, store?: any, accountId?: string, nodes: any[], edges: any[], startId?: string, payload?: any,
 *           ai?: (provider: string) => Promise<{ apiKey: string|null }>, fetchImpl?: typeof fetch, access?: Record<string, string[]> | null,
 *           park?: (w: { node: string, from: string, ctx: any, dueAt: string, wait: string }) => Promise<string>,
 *           resume?: { node: string, ctx: any } }} o
 */
export async function runFlow({ server, nodes, edges, startId, payload = {}, ai = async () => ({ apiKey: null }), fetchImpl = fetch, access = null, desk = null, park = null, resume = null }) {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const flow = nodes.filter((n) => n.type !== 'shape');
  const start = resume ? byId[resume.node] : ((startId && byId[startId]) || flow.find(isStart) || flow[0]);
  const startedAt = new Date().toISOString();
  const steps = []; const waiting = [];
  if (!start) return { complete: false, outcome: resume ? 'The step this run was waiting to reach is no longer in the sequence, so it stopped here.' : 'Nothing to run: the canvas has no flow blocks.', steps, waiting, startedAt, finishedAt: startedAt };
  const ctx = resume ? { ...(resume.ctx || {}), now: new Date().toISOString() } : { trigger: payload || {}, now: new Date().toISOString() };
  const log = (n, state, detail, extra = {}) => { steps.push({ step: n.title || n.key, node: n.id, state, detail: String(detail || '').slice(0, 500), ...extra }); };
  const fenced = (service, method) => {
    if (!access) return null;
    const scopes = access[service];
    if (!scopes || !scopes.length) return `${nameOf(service)} is not on this element's allowed apps.`;
    const allowed = scopes.flatMap((s) => SCOPE_METHODS[s] || []);
    if (method && allowed.length && !allowed.includes(method)) return `${nameOf(service)} is allowed for ${scopes.join(', ')} only.`;
    return null;
  };

  const call = async (n, service, endpoint, params) => {
    const t0 = Date.now();
    const why = fenced(service, null);
    if (why) { log(n, 'skipped', why, { ms: 0 }); return null; }
    // The CRM scopes every write to a location; the connection record knows which one. Fill it in rather than let the CRM answer 403 for a missing field.
    if (service === 'crm' && params && typeof params === 'object' && !params.locationId) {
      try { const rec = await callTool(server, 'vault_record', { service: 'crm', label: n.label || undefined }); const loc = rec?.meta?.location_id || rec?.meta?.locationId; if (loc) params = { ...params, locationId: loc }; } catch { /* the CRM will say */ }
    }
    let r;
    // `label` = which record when the account holds several for one service (12 CRM locations on Mike's account): the block chooses.
    try { r = await callTool(server, 'api_call', { service, endpoint, params, label: n.label || undefined }); } catch (e) { r = { error: e.message }; }
    const ms = Date.now() - t0;
    // Not connected is a SKIP with the fix named, like the handoff shows; a provider refusal is a FAIL with its own words.
    if (r && r.error && !r.data) { const notConn = /not connected/i.test(r.error); log(n, notConn ? 'skipped' : 'failed', notConn ? `${nameOf(service)} is not in your vault — connect it first` : r.error, { ms, service, endpoint }); return { ok: false, error: r.error }; }
    const ok = r && (r.ok !== false) && !(r.status >= 400);
    log(n, ok ? 'ok' : 'failed', ok ? `${nameOf(service)} · ${r.status || 200}` : (r.error || `${nameOf(service)} answered ${r.status}`), { ms, service, endpoint });
    return { ok, status: r.status, data: r.data, error: ok ? null : r.error };
  };

  const walk = async (n, depth = 0) => {
    if (steps.length >= MAX_STEPS) { log(n, 'skipped', `Stopped at ${MAX_STEPS} steps.`); return; }
    const d = defOf(n);
    // A field left blank uses the placeholder the builder showed for it ('{{trigger.email}}' and friends): what you see is what runs.
    const defaults = Object.fromEntries((d.fields || []).filter(([, , ph]) => ph).map(([k, , ph]) => [k, ph]));
    const filled = { ...defaults, ...Object.fromEntries(Object.entries(n.values || {}).filter(([, val]) => val !== '' && val !== undefined && val !== null)) };
    const v = resolveAll(filled, ctx);
    const key = ctxKey(n);
    let port = 0; let out = null; let continueFlow = true; let waitFor = '';
    switch (n.type) {
      case 'trigger': {
        out = ctx.trigger;
        log(n, 'ok', n.key === 'page_button' ? `Button "${v.name || n.title}" pressed` : n.key === 'schedule' ? `Schedule fired (${v.cron || 'now'})` : 'Test event received', { ms: 0 });
        break;
      }
      case 'task': {
        const def = TASKS[n.key]; const app = n.app;
        if (!def) { log(n, 'failed', `Unknown task ${n.key}`); break; }
        if (def.app_run && def.app_run[app]) {
          const t0 = Date.now(); const why = fenced(app, 'POST'); if (why) { log(n, 'skipped', why, { ms: 0 }); break; }
          let r; try { r = await callTool(server, 'app_run', { app: def.app_run[app], input: v }); } catch (e) { r = { error: e.message }; }
          const ok = !r.error && r.complete !== false; out = r; log(n, ok ? 'ok' : (r.error ? 'failed' : 'failed'), ok ? (r.outcome || 'Done') : (r.error || r.outcome || 'Did not finish'), { ms: Date.now() - t0, receipt: r.steps ? r.steps.slice(0, 12) : undefined });
          break;
        }
        const ep = def.ep && def.ep[app];
        if (!ep) { log(n, 'skipped', `${nameOf(app)} cannot do "${def.label}" here — pick another app.`); break; }
        const params = def.params && def.params[app] ? def.params[app](v, ctx) : v;
        const r = await call(n, app, ep, params); const data = r && def.out && def.out[app] && r.data && typeof r.data === 'object' ? def.out[app](r.data) : r?.data; out = r ? { ...(data && typeof data === 'object' ? data : { data }), ok: r.ok } : null;
        break;
      }
      case 'action': {
        if (!v.endpoint) { log(n, 'skipped', `No endpoint chosen for ${nameOf(n.app)}.`); break; }
        const r = await call(n, n.app, v.endpoint, parseJson(typeof v.params === 'string' ? v.params : JSON.stringify(v.params || {})));
        out = r ? { ...(r.data && typeof r.data === 'object' ? r.data : { data: r.data }), ok: r.ok } : null;
        break;
      }
      case 'logic': {
        if (n.key === 'ifelse') { const yes = evalCondition(n.values?.cond, ctx); port = yes ? 0 : 1; log(n, 'ok', `${yes ? 'Yes' : 'No'}: ${resolveTemplate(String(n.values?.cond || ''), ctx)}`, { ms: 0 }); }
        else if (n.key === 'filter') { const pass = evalCondition(n.values?.cond, ctx); log(n, pass ? 'ok' : 'skipped', pass ? 'Passed' : `Stopped: ${resolveTemplate(String(n.values?.cond || ''), ctx)} is not true`, { ms: 0 }); continueFlow = pass; }
        else if (n.key === 'delay') { const ms = parseWait(v.for); if (!ms) { log(n, 'failed', `"${v.for}" is not a length of time. Write it like 2 days, 3 hours or 1 week.`, { ms: 0 }); continueFlow = false; } else { log(n, 'ok', `Wait ${waitLabel(ms)}`, { ms: 0 }); waitFor = v.for; } }
        else if (n.key === 'loop') {
          const list = resolveTemplate(String(n.values?.over || ''), ctx); const items = Array.isArray(list) ? list : (typeof list === 'string' && list.trim().startsWith('[') ? parseJsonArray(list) : []);
          log(n, 'ok', `${Math.min(items.length, MAX_LOOP)} item${items.length === 1 ? '' : 's'}${items.length > MAX_LOOP ? ` (capped at ${MAX_LOOP})` : ''}`, { ms: 0 });
          for (const item of items.slice(0, MAX_LOOP)) { ctx.item = item; await follow(n, 0, '', depth); }
          delete ctx.item; continueFlow = false;
        }
        break;
      }
      case 'data': {
        if (n.key === 'map') { const o = {}; for (const line of String(n.values?.map || '').split('\n')) { const m = /^(.*?)\s*(?:→|->|=>)\s*(.*)$/.exec(line.trim()); if (m) o[m[2].trim()] = pathGet(ctx, m[1].trim()) ?? resolveTemplate(m[1].trim(), ctx); } out = o; for (const [k, val] of Object.entries(o)) setPath(ctx, k, val); log(n, 'ok', `${Object.keys(o).length} field${Object.keys(o).length === 1 ? '' : 's'} mapped`, { ms: 0 }); }
        else if (n.key === 'format') { const val = evalFormat(n.values?.expr, ctx); const name = (n.values?.out || key).trim(); ctx[name] = val; out = val; log(n, 'ok', `${name} = ${String(val).slice(0, 80)}`, { ms: 0 }); }
        else { log(n, 'ok', 'Paths joined', { ms: 0 }); }
        break;
      }
      case 'ai': {
        const t0 = Date.now(); const p = providerOf(n.app);
        if (!p) { log(n, 'failed', `Unknown AI ${n.app}`); break; }
        // ai(n.app) may hand back `chat` — the AI router: the step's AI first, then the owner's other AIs on a limit or error.
        const got = await ai(n.app);
        const ctxChat = { server, fence: { services: [], apps: [] }, workspace: { name: 'flow', intro: 'Answer plainly, no tool calls.' }, account: null };
        const msg = { history: [], message: String(v.prompt || '') };
        const turn = got.chat ? await got.chat(ctxChat, msg) : await chatTurn({ provider: n.app, apiKey: got.apiKey, fetchImpl }, ctxChat, msg);
        if (turn.error) { log(n, 'failed', turn.error, { ms: Date.now() - t0 }); break; }
        const name = (n.values?.out || key).trim(); ctx[name] = turn.answer; out = turn.answer;
        const who = providerOf(turn.provider)?.name || p.name;
        log(n, 'ok', `${who}${turn.tried?.length ? ` (after ${turn.tried.map((x) => providerOf(x.provider)?.name || x.provider).join(', ')} failed)` : ''}: ${turn.answer.slice(0, 120)}`, { ms: Date.now() - t0 });
        break;
      }
      case 'terminal': {
        const t0 = Date.now();
        // The desk is how a flow reaches the person's own machine: the step becomes a desk run (queued for their
        // machine, or any of theirs), the agent they installed claims it, and the receipt names the run. The flow does
        // not wait — a machine may be asleep — so what follows this step sees `{{agent.run}}` and `{{agent.state}}`.
        if (n.key === 'terminal_cmd') { log(n, 'ok', 'This flow is exposed to your coding agent as a tool; it started from there.', { ms: 0 }); out = { summary: 'tool start' }; break; }
        if (!desk) { log(n, 'skipped', `${nameOf(n.app)} on your machine is not linked yet — set it up once from the Install page (the one-line desk installer), then this step hands the job over.`, { ms: 0 }); out = { summary: '' }; break; }
        const v = n.values || {};
        const request = n.key === 'desk_agent'
          ? resolveTemplate(String(v.prompt || v.request || payload.message || payload.request || `Request from the "${n.title || 'desk'}" step`), ctx)
          : resolveTemplate(String(v.prompt || ''), ctx);
        if (!String(request || '').trim()) { log(n, 'failed', 'The step has no instructions for the agent.', { ms: 0 }); break; }
        try {
          const run = await desk.create({ project: v.project || null, folder: v.folder || v.cwd || null, machine: v.machine || null, agent: n.app || 'claude_code', rules: v.rules || '', request: String(request), source: { kind: 'flow', subject: n.title || n.key } });
          out = { run: run.id, state: run.state, machine: run.machine || 'any of your machines', summary: `handed to your desk (run ${run.id})` };
          ctx.agent = out;
          log(n, 'ok', `Handed to your desk: run ${run.id}, queued for ${run.machine || 'any of your machines'} · ${nameOf(n.app)} in ${v.folder || v.cwd || 'the project folder'}. It asks on your phone if unsure; the receipt lands in Alerts.`, { ms: Date.now() - t0 });
        } catch (e) { log(n, 'failed', e.message, { ms: Date.now() - t0 }); }
        break;
      }
      default: log(n, 'skipped', `Unknown block type ${n.type}`);
    }
    if (out !== null && out !== undefined) { ctx[key] = out; ctx.last = out; if (d.alias) ctx[d.alias] = out; }
    if (!continueFlow) return;
    await follow(n, port, waitFor, depth);
  };

  // Down every line out of n on that port. A line with a wait (or every line out of a Wait block) parks what follows on a
  // real run; a test run says what it would have waited and carries on, so a test never takes two days.
  const follow = async (n, port, blockWait, depth) => {
    for (const e of edges.filter((x) => x.from === n.id && (x.port || 0) === port)) {
      const c = byId[e.to]; if (!c) continue;
      const words = e.wait || blockWait; const ms = parseWait(words);
      if (!ms) { await walk(c, depth + 1); continue; }
      const label = waitLabel(ms); const dueAt = new Date(Date.now() + ms).toISOString();
      if (!park) { log(c, 'ok', `Would wait ${label} before this step. A test run does not wait.`, { ms: 0, wait: label }); await walk(c, depth + 1); continue; }
      const snap = JSON.stringify(ctx);
      if (snap.length > 200000) { log(c, 'failed', `Could not wait ${label}: what the run knows by now is too large to keep (${Math.round(snap.length / 1000)} KB, the limit is 200 KB).`, { ms: 0 }); continue; }
      try {
        const id = await park({ node: c.id, from: n.id, ctx: JSON.parse(snap), dueAt, wait: label });
        waiting.push({ id, node: c.id, step: c.title || c.key, dueAt, wait: label });
        log(c, 'waiting', `Waits ${label}, then continues here (due ${dueAt.slice(0, 16).replace('T', ' ')} UTC).`, { ms: 0, wait: label, dueAt, waitId: id });
      } catch (err) { log(c, 'failed', `Could not start the ${label} wait: ${err.message}`, { ms: 0 }); }
    }
  };

  await walk(start);
  const failed = steps.filter((s) => s.state === 'failed').length; const skipped = steps.filter((s) => s.state === 'skipped').length; const ok = steps.filter((s) => s.state === 'ok').length;
  const later = waiting.length ? ` ${waiting.length === 1 ? `Continues in ${waiting[0].wait} at "${waiting[0].step}".` : `${waiting.length} paths continue later (first in ${waiting.map((w) => w.wait)[0]}).`}` : '';
  const outcome = (!failed && !skipped ? (waiting.length ? 'Everything up to the wait was done.' : 'Everything requested was done.') : `${ok} of ${steps.length - waiting.length} steps done — ${[failed && `${failed} failed`, skipped && `${skipped} skipped`].filter(Boolean).join(', ')}. See steps.`) + later;
  return { complete: failed === 0 && skipped === 0, partial: failed === 0 && skipped > 0, outcome, steps, waiting, startedAt, finishedAt: new Date().toISOString(), start: start.id };
}

function parseJsonArray(s) { try { const v = JSON.parse(s); return Array.isArray(v) ? v : []; } catch { return []; } }
function setPath(obj, path, val) { const ks = String(path).split('.'); let o = obj; for (let i = 0; i < ks.length - 1; i++) { if (!o[ks[i]] || typeof o[ks[i]] !== 'object') o[ks[i]] = {}; o = o[ks[i]]; } o[ks[ks.length - 1]] = val; }

/** The flow a page button starts: the trigger named like the button's `runs`, else the first start. */
export function startForButton(nodes, runs) {
  const want = String(runs || '').trim().toLowerCase();
  const t = nodes.find((n) => n.type === 'trigger' && n.key === 'page_button' && String(n.values?.name || n.title || '').trim().toLowerCase() === want) || nodes.find((n) => n.type === 'trigger' && String(n.title || '').trim().toLowerCase() === want);
  return t || null;
}

/** Which services + mini-apps a chat element may touch, from its access map. Empty access = nothing. */
export function fenceFromAccess(access) {
  const services = Object.entries(access || {}).filter(([, s]) => Array.isArray(s) && s.length).map(([k]) => k);
  return { services, apps: [], access: access || {} };
}

export { TRIGGERS };
