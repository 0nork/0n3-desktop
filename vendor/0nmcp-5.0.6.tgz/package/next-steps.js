/**
 * NEXT STEPS (2026-10-29) — Mike: the builders "need to recommend the next steps." Pure: the account's real state in,
 * up to four suggestions out, most useful first. Each says why in one line and carries the one action that does it
 * (a page to open, or a template to start). Never suggests what the plan cannot do without saying so.
 */
import { SEQ_TEMPLATES } from './flow-defs.js';
import { limitsFor, PLANS } from './billing.js';

const T = (key) => SEQ_TEMPLATES.find((t) => t.key === key);
/** What usually comes after a template a business already has. */
const AFTER = { speed_to_lead: ['no_show', 'review_request'], quote_request: ['speed_to_lead', 'win_back'], newsletter: ['event_signup', 'referral'], appointment_confirm: ['no_show', 'review_request'],
  no_show: ['win_back'], review_request: ['referral'], new_client: ['payment_thanks', 'review_request'], payment_thanks: ['review_request'], event_signup: ['newsletter'], support_ticket: ['review_request'], referral: ['speed_to_lead'], win_back: ['review_request'] };

/**
 * @param {{ plan?: string, services?: string[], workspaces?: Array<{ id: string, name?: string, status?: string, sequences?: number, pages?: number, domains?: any[], templates?: string[] }>,
 *           runsThisMonth?: number, deskMachines?: number }} s
 */
export function nextSteps(s = {}) {
  const L = limitsFor(s.plan); const services = new Set(s.services || []); const ws = s.workspaces || [];
  const seqs = ws.reduce((n, w) => n + (w.sequences || 0), 0); const pages = ws.reduce((n, w) => n + (w.pages || 0), 0);
  const published = ws.some((w) => w.status === 'published'); const domains = ws.reduce((n, w) => n + (w.domains || []).length, 0);
  const byName = new Map(SEQ_TEMPLATES.map((t) => [t.name.toLowerCase(), t.key]));
  const used = new Set(ws.flatMap((w) => [...(w.templates || []), ...(w.seqNames || []).map((n) => byName.get(String(n).toLowerCase())).filter(Boolean)]));
  const out = [];
  const add = (id, title, why, action) => { if (!out.some((o) => o.id === id)) out.push({ id, title, why, action }); };
  const tpl = (key, why) => { const t = T(key); if (t) add(`tpl:${key}`, `Add “${t.name}”`, why || t.what, { kind: 'template', template: key, label: 'Use this template' }); };

  if (!ws.length) add('workspace', 'Create your workspace', 'Everything you build — sequences, pages, your own domain — lives in one workspace.', { kind: 'open', href: '/workspaces', label: 'Create it' });
  if (!services.has('crm')) add('crm', 'Connect your CRM', 'Email, texting, voicemail drops, tags and bookings all run through it. New accounts get one automatically; connect your own if you already have one.', { kind: 'open', href: '/connect', label: 'Connect' });
  const messaging = ['resend', 'sendgrid', 'postmark', 'gmail', 'slack', 'telegram', 'twilio'].some((k) => services.has(k));
  if (services.size <= 1 && !messaging) add('connect', 'Connect the apps you already use', 'Stripe, Google, Slack, your email — 0n3 can only act with the apps you connect.', { kind: 'open', href: '/connect', label: 'Connect apps' });
  if (ws.length && !seqs) tpl(services.has('stripe') ? 'new_client' : 'speed_to_lead', services.has('stripe') ? 'You take payments: welcome every new client automatically.' : 'Answer every lead in under a minute — the single biggest win for most businesses.');
  if (seqs && !(s.runsThisMonth > 0)) add('test', 'Run your sequence once', 'A test run shows every step’s result, so you know it works before a customer presses the button.', { kind: 'open', href: '/m', label: 'Open and run' });
  if (seqs && !pages) add('page', 'Give it a page', 'A page with a button is how a customer starts your sequence — a form, a booking, a “get help”.', { kind: 'open', href: '/workspaces', label: 'Add a page' });
  if (pages && !published) add('publish', 'Publish your page', 'It is only visible to you until you publish it.', { kind: 'open', href: '/workspaces', label: 'Publish' });
  if (published && !domains) add('domain', L.domains ? 'Put it on your own domain' : 'Use your own domain (Starter)', L.domains ? 'Customers trust yourname.com more than a shared link.' : `Your own domain comes with ${PLANS.starter.name} ($${PLANS.starter.price}/month).`, { kind: 'open', href: L.domains ? '/workspaces' : '/billing', label: L.domains ? 'Add domain' : 'See plans' });
  if (PLANS[L.plan].crm === 'base' && seqs) add('crm-messaging', 'Send email and texts from your CRM', `Your free CRM covers contacts, forms and surveys. ${PLANS.starter.name} ($${PLANS.starter.price}/month) turns on email and texting; ${PLANS.pro.name} adds voicemail drops and everything else.`, { kind: 'open', href: '/billing', label: 'See plans' });
  for (const k of used) for (const nxt of AFTER[k] || []) if (!used.has(nxt)) tpl(nxt);
  if (seqs >= 1 && !used.size) tpl('review_request', 'Happy customers bring the next ones: ask every one for a review.');
  if (L.desk && !(s.deskMachines > 0) && seqs >= 2) add('desk', 'Let your computer do the work', 'The desk agent runs your AI on your own machine and asks on your phone when unsure.', { kind: 'open', href: '/install', label: 'Install' });
  const near = (used2, lim) => lim !== Infinity && used2 >= lim * 0.8;
  if (near(s.runsThisMonth || 0, L.runsPerMonth) || near(seqs, L.sequences) || near(ws.length, L.workspaces)) {
    const up = ['starter', 'pro', 'business'].find((p) => PLANS[p].price > PLANS[L.plan].price);
    if (up) add('upgrade', `Room to grow: ${PLANS[up].name}`, `You are close to your ${PLANS[L.plan].name} limits. ${PLANS[up].name} is $${PLANS[up].price}/month.`, { kind: 'open', href: '/billing', label: 'See plans' });
  }
  return out.slice(0, 4);
}
