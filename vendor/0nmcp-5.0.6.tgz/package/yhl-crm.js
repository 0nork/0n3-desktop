/**
 * YOUTH HOCKEY LEAGUES → KID-CARDS CRM (Mike, 2026-11-22/23).
 *
 * Every YHL account event becomes a TAG on the person's contact in the Kid-Cards CRM location, and the CRM's own
 * workflows ("YHL · …") act on the tag: welcome, thank-you, payment trouble, cancellation, beta-ending upgrade, team
 * app requests. This file only says WHAT happened; it never sends an email itself.
 *
 *   signup            yhl:signup (+ yhl:beta while the free beta runs)        ← send-email hook (signup email)
 *   confirmed         yhl:confirmed                                             ← YHL /auth/callback, user's own token
 *   password-reset    yhl:password-reset (re-fires)                            ← send-email hook (recovery email)
 *   season            yhl:customer, yhl:season-pass (re-fires)                  ← Stripe webhook, metadata.app=yhl-positioning
 *   monthly           yhl:customer, yhl:monthly (re-fires)                      ← Stripe webhook
 *   payment-failed    yhl:payment-failed (re-fires)                            ← Stripe subscription past_due/unpaid
 *   cancelled         yhl:monthly-cancelled (re-fires)                          ← Stripe subscription deleted
 *   team-request      yhl:team-app-request (re-fires)                           ← YHL account page, user's own token
 *   contact           yhl:contact (re-fires)                                    ← YHL /contact form, hCaptcha-checked
 *
 * "Re-fires": the tag is removed then added, so a CRM "tag added" trigger runs again for a second player or a second
 * reset. Tags are ADDED, never replaced: the contact may already hold Kid-Cards tags from mykidcard.com.
 * Email is the identity (Rule 0-SSO): trimmed + lowercased at every boundary.
 *
 * Env: CRM_KIDCARD_PIT (location PIT), CRM_KIDCARD_LOCATION (default ZgtjOKKk4IeXI8E1g9Jv).
 */

const CRM = 'https://services.leadconnectorhq.com';

/** End of the free beta: midnight Eastern at the end of Dec 15, 2026. */
export const YHL_BETA_ENDS = Date.parse('2026-12-16T05:00:00Z');

const EVENTS = {
  signup:           { add: ['yhl:signup'], refire: false },
  confirmed:        { add: ['yhl:confirmed'], refire: false },
  'password-reset': { add: ['yhl:password-reset'], refire: true },
  season:           { add: ['yhl:customer', 'yhl:season-pass'], refire: true },
  monthly:          { add: ['yhl:customer', 'yhl:monthly'], refire: true },
  'payment-failed': { add: ['yhl:payment-failed'], refire: true },
  cancelled:        { add: ['yhl:monthly-cancelled'], refire: true },
  'team-request':   { add: ['yhl:team-app-request'], refire: true },
  contact:          { add: ['yhl:contact'], refire: true },
};
export const YHL_EVENTS = Object.keys(EVENTS);

/** Pure: the CRM changes for one event. Returns null for an unknown event or a missing email. */
export function yhlPlan(kind, { email, name, note } = {}, now = Date.now()) {
  const ev = EVENTS[kind]; const addr = String(email || '').trim().toLowerCase();
  if (!ev || !addr.includes('@')) return null;
  const full = String(name || '').trim();
  const [firstName, ...rest] = full ? full.split(/\s+/) : [];
  const add = [...ev.add, ...(kind === 'signup' && now < YHL_BETA_ENDS ? ['yhl:beta'] : [])];
  return {
    contact: { email: addr, ...(firstName ? { firstName } : {}), ...(rest.length ? { lastName: rest.join(' ') } : {}), source: 'youthhockeyleagues.com' },
    add,
    remove: ev.refire ? ev.add.filter((t) => t !== 'yhl:customer') : [],
    note: note ? `YHL · ${note}` : null,
  };
}

async function call(method, path, body, pit) {
  const r = await fetch(`${CRM}${path}`, {
    method, headers: { authorization: `Bearer ${pit}`, version: '2021-07-28', 'content-type': 'application/json', accept: 'application/json' },
    body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(8000),
  });
  const text = await r.text();
  if (!r.ok) throw new Error(`CRM ${method} ${path} ${r.status}: ${text.slice(0, 200)}`);
  return text ? JSON.parse(text) : {};
}

/** Apply one event to the Kid-Cards CRM. Never throws: an event that cannot be recorded is logged, never blocks the caller. */
export async function yhlEvent(kind, data, env = process.env) {
  const p = yhlPlan(kind, data);
  if (!p) return { ok: false, error: 'unknown event or no email' };
  const pit = env.CRM_KIDCARD_PIT, loc = env.CRM_KIDCARD_LOCATION || 'ZgtjOKKk4IeXI8E1g9Jv';
  if (!pit) { console.error(`[yhl-crm] ${kind} skipped: CRM_KIDCARD_PIT is not set`); return { ok: false, error: 'not configured' }; }
  try {
    const up = await call('POST', '/contacts/upsert', { locationId: loc, ...p.contact }, pit);
    const id = up.contact?.id; if (!id) throw new Error('upsert returned no contact id');
    if (p.remove.length) await call('DELETE', `/contacts/${id}/tags`, { tags: p.remove }, pit).catch(() => {});
    await call('POST', `/contacts/${id}/tags`, { tags: p.add }, pit);
    if (p.note) await call('POST', `/contacts/${id}/notes`, { body: p.note }, pit).catch((e) => console.error('[yhl-crm] note:', e.message));
    console.log(`[yhl-crm] ${kind} → ${id} +${p.add.join(',')}`);
    return { ok: true, contactId: id, tags: p.add };
  } catch (e) {
    console.error(`[yhl-crm] ${kind} failed:`, e.message);
    return { ok: false, error: e.message };
  }
}

/** Is this Stripe object a YHL Positioning Trainer purchase? (Checkout + subscription both carry the metadata.) */
export const isYhl = (o) => o?.metadata?.app === 'yhl-positioning';

/**
 * Pure: the YHL event for one Stripe webhook event, or null. `email` is filled in by the caller when Stripe does not
 * carry it on the object (subscription events only name the customer).
 */
export function yhlStripeEvent(ev) {
  const o = ev?.data?.object || {}; if (!isYhl(o)) return null;
  const player = o.metadata?.player ? `player ${o.metadata.player}` : 'one player';
  const email = (o.customer_details?.email || o.customer_email || '').trim().toLowerCase() || null;
  const name = o.customer_details?.name || '';
  if (ev.type === 'checkout.session.completed') {
    if (o.payment_status && o.payment_status !== 'paid' && o.mode !== 'subscription') return null;
    return o.mode === 'subscription'
      ? { kind: 'monthly', email, name, customer: o.customer, note: `Monthly pass bought for ${player}.` }
      : { kind: 'season', email, name, customer: o.customer, note: `Season pass ${o.metadata?.season || ''} bought for ${player}.`.replace('  ', ' ') };
  }
  if (ev.type === 'customer.subscription.updated') {
    const prev = ev.data?.previous_attributes?.status;
    if (['past_due', 'unpaid'].includes(o.status) && prev && prev !== o.status) return { kind: 'payment-failed', email, customer: o.customer, note: `Monthly payment failed for ${player} (status ${o.status}).` };
    return null;
  }
  if (ev.type === 'customer.subscription.deleted') return { kind: 'cancelled', email, customer: o.customer, note: `Monthly pass for ${player} ended.` };
  return null;
}

/** Pure: a cleaned contact-form message, or an error string. */
export function cleanContact(b = {}) {
  const email = String(b.email || '').trim().toLowerCase(); const name = String(b.name || '').trim().slice(0, 80);
  const topic = String(b.topic || 'General').trim().slice(0, 40); const message = String(b.message || '').trim().slice(0, 2000);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: 'Enter a valid email.' };
  if (name.length < 2) return { error: 'Enter your name.' };
  if (message.length < 5) return { error: 'Write a short message.' };
  if (b.website) return { error: 'spam' }; // honeypot
  return { email, name, note: `Contact form (${topic}): ${message}` };
}
