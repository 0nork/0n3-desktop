/**
 * CRM AUTO-PROVISION — every 0n account gets a white-labeled 0ncore CRM
 * sub-account the moment it is created.
 *
 * Mike, 2026-10-23: "Every account that's built will come with the basic
 * functionality of the CRM … simple contact management, forms and surveys.
 * Everything else needs to be unlocked with a plan." 0ncore.com is the CRM brand.
 *
 * ONE OWNER OF THE AGENCY CREDENTIAL, ONE DOOR. Creating a sub-account and
 * minting a token for it needs the agency marketplace OAuth that only 0nCore
 * holds, so 0n3 does not copy it: it calls 0nCore's bridge first-party
 * (`POST /api/bridge/crm-location`, shared secret), which finds-or-creates the
 * sub-account by email, never guesses between several, and mints the token.
 * 0n3 then records the location in the vault as a MANAGED record: no token is
 * stored here; `tokens.js` asks the bridge for a fresh one whenever a call
 * needs it. The tier lives on the record and on the profile; the CRM tool
 * factory fences the base tier to contacts, forms and surveys.
 */
import { makeConnection } from './envelope.js';

export const BASE_TIER = 'base';
export const BRAND = '0ncore';

/**
 * @param {{ profile: { id: string, email: string|null, full_name?: string|null, business_name?: string|null, crm_location_id?: string|null },
 *           store: any, rest: any, env?: any, fetchImpl?: typeof fetch, timeoutMs?: number }} o
 * @returns {Promise<{ ok: boolean, locationId?: string, created?: boolean, tier?: string, ambiguous?: boolean, candidates?: any[], reason?: string, skipped?: boolean }>}
 */
export async function provisionCrm({ profile, store, rest, env = process.env, fetchImpl = fetch, timeoutMs = 25_000 }) {
  const email = String(profile?.email || '').trim().toLowerCase();
  if (!email) return { ok: false, skipped: true, reason: 'no email on the profile' };
  // RFC 2606 reserved addresses (our test suites use @…invalid) never get a real CRM sub-account in the agency.
  if (/\.(invalid|test|example|localhost)$/.test(email.split('@')[1] || '')) return { ok: false, skipped: true, reason: 'test address; no CRM provisioned' };
  const base = (env.ONCORE_URL || 'https://www.0ncore.com').replace(/\/$/, '');
  const secret = env.ONCORE_INTERNAL_SECRET || '';
  if (!secret) return { ok: false, skipped: true, reason: 'ONCORE_INTERNAL_SECRET is not set; the CRM was not provisioned' };
  // An account that already holds ANY CRM connection is left alone: a managed base record beside a real one would let the
  // resolver pick the fenced record for the same location. Idempotent on every sign-in.
  const crm = (await store.list(profile.id)).filter((r) => r.service === 'crm');
  const have = crm.find((r) => r.meta?.via === '0ncore-bridge');
  if (have && have.meta?.location_id) return { ok: true, locationId: have.meta.location_id, tier: have.meta.tier || BASE_TIER, created: false, reason: 'already provisioned' };
  if (crm.length) return { ok: true, skipped: true, locationId: crm[0].meta?.location_id || null, reason: 'the account already has its own CRM connection; nothing provisioned' };

  const businessName = String(profile.business_name || profile.full_name || email.split('@')[0]).trim();
  let r, d;
  try {
    r = await fetchImpl(`${base}/api/bridge/crm-location`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-bridge-secret': secret }, body: JSON.stringify({ email, businessName, source: '0n3', brand: BRAND, tier: BASE_TIER, locationId: profile.crm_location_id || undefined }), signal: AbortSignal.timeout(timeoutMs) });
    d = await r.json().catch(() => ({}));
  } catch (e) { return await fail(rest, profile.id, `0ncore did not answer: ${e.message}`); }
  if (d && d.ambiguous) { await note(rest, profile.id, `ambiguous: this email is on ${d.candidates?.length || 'several'} CRM sub-accounts — a person must pick`); return { ok: false, ambiguous: true, candidates: d.candidates || [], reason: d.error }; }
  if (!r.ok || !d || !d.ok || !d.locationId) return await fail(rest, profile.id, d?.error || `0ncore answered ${r.status}`);

  // The managed record: the location, the tier, and NO token — the bridge mints one per call.
  await store.put(profile.id, makeConnection({ service: 'crm', name: `CRM · ${BRAND}`, authType: 'oauth', credentials: { managed_by: BRAND, location_id: d.locationId }, meta: { location_id: d.locationId, tier: BASE_TIER, via: '0ncore-bridge', brand: BRAND, name: d.locationName || null, companyId: d.companyId || null } }), { actor: '0n3 provision' });
  try { await rest.update('profiles', { id: profile.id }, { crm_location_id: profile.crm_location_id || d.locationId, crm_tier: BASE_TIER, provisioned_at: new Date().toISOString(), provisioning_error: null }); } catch (e) { console.error('[provision] profile update:', e.message); }
  return { ok: true, locationId: d.locationId, created: !!d.created, tier: BASE_TIER };
}

async function fail(rest, id, reason) { await note(rest, id, reason); return { ok: false, reason }; }
async function note(rest, id, reason) { try { await rest.update('profiles', { id }, { provisioning_error: String(reason).slice(0, 500) }); } catch { /* the return value carries it */ } }

/** Which CRM tools the base tier may call: contacts, forms, surveys. Built from the factory's own module map. */
export function baseTierTools({ V3_MODULES, legacyContacts = [] }) {
  const names = new Set(legacyContacts.map((d) => d.name));
  for (const k of ['contacts', 'forms', 'surveys']) for (const d of V3_MODULES[k] || []) names.add(d.name);
  return names;
}
/** Starter's CRM: the base tier + conversations (email, SMS, chat), emails and campaigns. Pro and Business are unfenced. */
export function messagingTierTools({ V3_MODULES, legacyContacts = [] }) {
  const names = baseTierTools({ V3_MODULES, legacyContacts });
  for (const k of ['conversations', 'emails', 'email-isv', 'campaigns']) for (const d of V3_MODULES[k] || []) names.add(d.name);
  return names;
}
export const TIER_REFUSAL = (tool, tier = 'base') => tier === 'messaging'
  ? `${tool} is not in the Starter CRM (contacts, forms, surveys, email and texting). Pro ($29/month) unlocks the whole CRM — voicemail drops, calendars, pipelines, invoices: https://0n3.app/billing`
  : `${tool} is not in the free CRM (contacts, forms and surveys). Starter ($9/month) adds email and texting; Pro ($29/month) unlocks everything: https://0n3.app/billing`;
