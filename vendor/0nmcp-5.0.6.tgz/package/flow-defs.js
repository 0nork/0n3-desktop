/**
 * FLOW + PAGE DEFINITIONS — shared by the engine (flows.js, node) and the
 * builder (web/src/Builder.jsx, browser). Pure data and pure functions only:
 * no node imports, no DOM.
 *
 * From Mike's Claude Design handoff "0n3 Builder" (2026-10-22): a canvas holds
 * two kinds of node. FLOW BLOCKS (trigger · task · action · logic · data · ai ·
 * terminal) run in order along wires. PAGE ELEMENTS (section · row · column ·
 * divider · heading · text · picture · tooltip · text field · text area ·
 * button · chat box · box · design note) render on the mini page a customer
 * signs in to; they never run, but a button starts a flow and a chat box is
 * agentic within the apps and scopes set on it.
 *
 * Endpoint names below are the REAL catalog names (measured 2026-10-22 against
 * catalog.js); a wrong one shows up as the catalog's own refusal in a receipt,
 * never as a silent "ok".
 */

export const W = 248;      // flow block width on the canvas
export const GRID = 16;    // the invisible snap grid

export const SCOPES = [['read', 'Read'], ['create', 'Create'], ['update', 'Update'], ['delete', 'Delete'], ['run', 'Run flows']];

/** Catalog keys the builder lists under Apps; the vault decides which are connected. */
export const SERVICES = ['crm', 'stripe', 'resend', 'sendgrid', 'postmark', 'mailgun', 'brevo', 'gmail', 'slack', 'discord', 'telegram', 'twilio', 'whatsapp', 'hubspot', 'pipedrive', 'grok_bot', 'intercom', 'activecampaign', 'mailchimp', 'airtable', 'notion', 'supabase', 'google_sheets', 'google_drive', 'google_calendar', 'calendly', 'github', 'linear', 'jira', 'asana', 'trello', 'monday', 'ontask', 'shopify', 'woocommerce', 'square', 'quickbooks', 'xero', 'cloudflare', 'godaddy', 'hostinger', 'netlify', 'webflow', 'wordpress', 'twitter', 'linkedin', 'instagram', 'reddit', 'youtube', 'openai', 'groq', 'mistral', 'cohere', 'ollama', 'elevenlabs', 'deepgram', 'ebay', 'zendesk', 'freshdesk', 'typeform', 'docusign', 'zoom', 'figma', 'n8n', 'make', 'zapier'];
export const NAMES = { desk: 'Your computer', microsoft: 'Microsoft 365', crm: 'CRM', google_sheets: 'Google Sheets', google_drive: 'Google Drive', google_calendar: 'Google Calendar', ontask: '0nTask', github: 'GitHub', hubspot: 'HubSpot', activecampaign: 'ActiveCampaign', woocommerce: 'WooCommerce', quickbooks: 'QuickBooks', godaddy: 'GoDaddy', wordpress: 'WordPress', twitter: 'X', linkedin: 'LinkedIn', youtube: 'YouTube', openai: 'OpenAI', elevenlabs: 'ElevenLabs', ebay: 'eBay', docusign: 'DocuSign', sendgrid: 'SendGrid', mailchimp: 'Mailchimp', whatsapp: 'WhatsApp', tiktok: 'TikTok', claude_code: 'Claude Code', gemini_cli: 'Gemini CLI', codex: 'Codex', cursor: 'Cursor' };
/** Where each app's favicon comes from (the same Google favicon source the Connect page uses). Unknown keys fall back to <key>.com. */
export const DOMAINS = { crm: 'gohighlevel.com', stripe: 'stripe.com', resend: 'resend.com', sendgrid: 'sendgrid.com', postmark: 'postmarkapp.com', mailgun: 'mailgun.com', brevo: 'brevo.com', gmail: 'mail.google.com', google: 'google.com', google_sheets: 'docs.google.com', google_drive: 'drive.google.com', google_calendar: 'calendar.google.com', slack: 'slack.com', discord: 'discord.com', telegram: 'telegram.org', twilio: 'twilio.com', whatsapp: 'whatsapp.com', hubspot: 'hubspot.com', pipedrive: 'pipedrive.com', grok_bot: 'x.ai', intercom: 'intercom.com', activecampaign: 'activecampaign.com', mailchimp: 'mailchimp.com', airtable: 'airtable.com', notion: 'notion.so', supabase: 'supabase.com', asana: 'asana.com', linear: 'linear.app', jira: 'atlassian.com', trello: 'trello.com', monday: 'monday.com', square: 'squareup.com', quickbooks: 'quickbooks.intuit.com', twitter: 'x.com', linkedin: 'linkedin.com', instagram: 'instagram.com', reddit: 'reddit.com', youtube: 'youtube.com', hostinger: 'hostinger.com', netlify: 'netlify.com', webflow: 'webflow.com', wordpress: 'wordpress.com', github: 'github.com', ebay: 'ebay.com', cloudflare: 'cloudflare.com', godaddy: 'godaddy.com', groq: 'groq.com', ollama: 'ollama.com', mistral: 'mistral.ai', cohere: 'cohere.com', openai: 'openai.com', gemini: 'gemini.google.com', anthropic: 'claude.ai', claude_code: 'claude.ai', claude: 'claude.ai', chatgpt: 'openai.com', gemini_cli: 'gemini.google.com', cursor: 'cursor.com', codex: 'openai.com', windsurf: 'windsurf.com', vscode: 'code.visualstudio.com', shopify: 'shopify.com', zapier: 'zapier.com', calendly: 'calendly.com', zoom: 'zoom.us', dropbox: 'dropbox.com', figma: 'figma.com', vercel: 'vercel.com', paypal: 'paypal.com', ontask: '0ntask.com', oncore: '0ncore.com', typeform: 'typeform.com', xero: 'xero.com', elevenlabs: 'elevenlabs.io', deepgram: 'deepgram.com', zendesk: 'zendesk.com', freshdesk: 'freshdesk.com', docusign: 'docusign.com', n8n: 'n8n.io', make: 'make.com', woocommerce: 'woocommerce.com' };
export const domainOf = (k) => DOMAINS[k] || (k ? String(k).replace(/_/g, '') + '.com' : '');
export const nameOf = (k) => NAMES[k] || (k ? k.charAt(0).toUpperCase() + k.slice(1).replace(/_/g, ' ') : '');

/**
 * TASKS — a plain action, done by whichever app the person picks. `ep[app]` is
 * the real catalog endpoint; `params[app](values, ctx)` shapes the call. An
 * app with no entry passes the field values straight through, and the receipt
 * carries whatever the provider said about them.
 */
export const TASKS = {
  send_email: { label: 'Send email', icon: 'Mail', apps: ['resend', 'crm', 'sendgrid', 'postmark', 'mailgun', 'gmail', 'brevo'], rec: 'resend',
    fields: [['to', 'To', '{{trigger.email}}'], ['subject', 'Subject', 'Welcome aboard'], ['html', 'Message', 'Hi {{contact.firstName}}, …', 1], ['from', 'From (optional)', ''], ['contactId', 'CRM contact (CRM only)', '{{contact.id}}']],
    ep: { crm: 'send_message', resend: 'send_email', sendgrid: 'send_email', postmark: 'send_email', mailgun: 'send_message', gmail: 'send_message', brevo: 'send_email' },
    params: { crm: (v) => ({ type: 'Email', contactId: v.contactId || '{{contact.id}}', subject: v.subject, html: v.html, ...(v.from ? { emailFrom: v.from } : {}) }), resend: (v) => ({ from: v.from || 'hello@0n3.app', to: [v.to], subject: v.subject, html: v.html }), postmark: (v) => ({ From: v.from, To: v.to, Subject: v.subject, HtmlBody: v.html }), mailgun: (v) => ({ from: v.from, to: v.to, subject: v.subject, html: v.html }), sendgrid: (v) => ({ personalizations: [{ to: [{ email: v.to }] }], from: { email: v.from }, subject: v.subject, content: [{ type: 'text/html', value: v.html }] }) } },
  send_message: { label: 'Send text / message', icon: 'MessageSquare', apps: ['slack', 'crm', 'discord', 'telegram', 'twilio'], rec: 'slack',
    fields: [['channel', 'Channel or number (not for CRM)', '#sales'], ['text', 'Message', 'Hi {{contact.firstName}}, thanks for reaching out!', 1], ['contactId', 'CRM contact (CRM only)', '{{contact.id}}']],
    ep: { crm: 'send_message', slack: 'send_message', discord: 'send_message', telegram: 'send_message', twilio: 'send_sms' },
    params: { crm: (v) => ({ type: 'SMS', contactId: v.contactId || '{{contact.id}}', message: v.text }), slack: (v) => ({ channel: v.channel, text: v.text }), telegram: (v) => ({ chat_id: v.channel, text: v.text }), discord: (v) => ({ channelId: v.channel, content: v.text }), twilio: (v) => ({ to: v.channel, body: v.text }) } },
  create_contact: { label: 'Create contact', icon: 'UserPlus', apps: ['crm', 'hubspot', 'pipedrive', 'brevo', 'activecampaign', 'intercom', 'mailchimp'], rec: 'crm', alias: 'contact',
    fields: [['email', 'Email', '{{trigger.email}}'], ['firstName', 'First name', '{{trigger.name}}'], ['phone', 'Phone', '{{trigger.phone}}'], ['tags', 'Tags (comma separated)', '']],
    out: { crm: (d) => d.contact || d, pipedrive: (d) => d.data || d },
    ep: { crm: 'upsert_contact', hubspot: 'create_contact', pipedrive: 'add_person', brevo: 'create_contact', activecampaign: 'create_contact', intercom: 'create_contact', mailchimp: 'add_member' },
    params: { crm: (v) => ({ email: v.email || undefined, firstName: v.firstName || undefined, phone: v.phone || undefined, ...(v.tags ? { tags: String(v.tags).split(',').map((t) => t.trim()).filter(Boolean) } : {}) }), hubspot: (v) => ({ properties: { email: v.email, firstname: v.firstName, phone: v.phone } }), pipedrive: (v) => ({ name: v.firstName || v.email || 'New contact', ...(v.email ? { emails: [{ value: v.email, primary: true, label: 'work' }] } : {}), ...(v.phone ? { phones: [{ value: v.phone, primary: true, label: 'work' }] } : {}) }), brevo: (v) => ({ email: v.email, attributes: { FIRSTNAME: v.firstName } }), activecampaign: (v) => ({ contact: { email: v.email, firstName: v.firstName, phone: v.phone } }), intercom: (v) => ({ role: 'user', email: v.email, name: v.firstName }), mailchimp: (v) => ({ email_address: v.email, status: 'subscribed', merge_fields: { FNAME: v.firstName } }) } },
  create_record: { label: 'Create record', icon: 'Database', apps: ['airtable', 'notion', 'supabase', 'google_sheets'], rec: 'google_sheets', alias: 'record',
    fields: [['spreadsheet', 'Google Sheet link (Google Sheets only)', ''], ['table', 'Table or tab name', 'Sheet1'], ['values', 'Values (JSON)', '{ "email": "{{trigger.email}}" }', 1]],
    ep: { airtable: 'create_record', notion: 'create_page', supabase: 'insert_row', google_sheets: 'append_values' },
    // Sheets appends to a TAB of ONE spreadsheet: the id comes from the pasted link (…/spreadsheets/d/<id>/edit), and
    // USER_ENTERED lets "49.00" land as a number. Without the id Google has nothing to write to (measured 2026-11-06:
    // the step sent only a range, so every Sheets step that ever ran failed).
    params: { google_sheets: (v) => ({ spreadsheetId: sheetIdOf(v.spreadsheet), range: v.table || 'Sheet1', valueInputOption: 'USER_ENTERED', values: [Object.values(parseJson(v.values))] }), airtable: (v) => ({ table: v.table, fields: parseJson(v.values) }), supabase: (v) => ({ table: v.table, row: parseJson(v.values) }), notion: (v) => ({ parent: v.table, properties: parseJson(v.values) }) } },
  // THE TABLE BLOCKS (blocks.js): an emailed picture of a spreadsheet → rows in a shared table, safely.
  email_pictures: { label: 'Get the pictures from an email', icon: 'Image', apps: ['microsoft'], rec: 'microsoft', alias: 'email', big: 'email_pictures',
    hint: 'Takes the pictures out of one email (a screenshot pasted into the message counts) and keeps them for the next step.',
    fields: [['mailbox', 'Mailbox', '{{trigger.mailbox}}'], ['message', 'Which email', '{{trigger.id}}'], ['max', 'How many pictures (largest first)', '1']] },
  update_table: { label: 'Update a table', icon: 'Database', apps: ['microsoft', 'google_sheets'], rec: 'microsoft', alias: 'table', big: 'update_table',
    hint: 'Updates rows in place and adds new ones under the last row. Columns are found by name. A cell a person changed is kept and named, never overwritten.',
    fields: [['workbook', 'Link to the Excel workbook or Google Sheet', ''], ['tab', 'Tab name', 'Sheet1'], ['rows', 'Rows', '{{kept.rows}}'], ['key', 'Column that names a row', ''], ['map', 'Different column names? one per line: theirs → yours (optional)', '', 1]] },
  // THE MAP BLOCKS (maps.js): GraphHopper and OpenStreetMap as blocks. Each one adds what it learned to the job's map, so
  // "Draw a map" (Data) needs no wiring. A place is a name ("Atlanta, GA") or coordinates ("33.75, -84.39"), one per line.
  find_places: { label: 'Find places', icon: 'MapPin', apps: ['nominatim', 'graphhopper'], rec: 'nominatim', alias: 'places', big: 'map', ep: { nominatim: 'search', graphhopper: 'geocode' },
    hint: 'Turns place names into positions on the map. OpenStreetMap search needs no key: one name a second, 12 names a step.',
    fields: [['places', 'Places, one per line', '{{trigger.places}}', 1], ['country', 'Only in these countries (two-letter codes)', 'us']] },
  name_points: { label: 'Name a point', icon: 'LocateFixed', apps: ['nominatim', 'graphhopper'], rec: 'nominatim', alias: 'named', big: 'map', ep: { nominatim: 'reverse', graphhopper: 'reverse_geocode' },
    hint: 'Says what is at a position: the address, city and state.',
    fields: [['points', 'Coordinates, one per line', '{{trigger.point}}', 1]] },
  road_route: { label: 'Road route', icon: 'Route', apps: ['graphhopper'], rec: 'graphhopper', alias: 'route', big: 'map', ep: { graphhopper: 'route' },
    hint: 'The road between stops, in order: miles, drive time and the line for the map. If your plan has no truck routing the receipt says the line is a car route.',
    fields: [['stops', 'Stops in order, one per line', '{{places.places}}', 1], ['vehicle', 'Vehicle: car, truck, small truck, bike, foot', 'car'], ['directions', 'Turn-by-turn directions? yes or no', 'no'], ['country', 'Only in these countries', 'us']] },
  distance_table: { label: 'Distance table', icon: 'Table', apps: ['graphhopper'], rec: 'graphhopper', alias: 'distances', big: 'map', ep: { graphhopper: 'matrix' },
    hint: 'Road miles and drive time from every starting place to every destination, in one call. Leave “To” empty to compare the list with itself.',
    fields: [['from', 'From, one per line', '{{places.places}}', 1], ['to', 'To, one per line (empty = the same list)', '', 1], ['vehicle', 'Vehicle', 'car'], ['country', 'Only in these countries', 'us']] },
  reach_area: { label: 'How far can I get', icon: 'Radar', apps: ['graphhopper'], rec: 'graphhopper', alias: 'reach', big: 'map', ep: { graphhopper: 'isochrone' },
    hint: 'The area you can reach from a place within a drive time or a distance, drawn on the map.',
    fields: [['from', 'From', '{{places.first}}'], ['minutes', 'Within this many minutes', '30'], ['miles', 'Or within this many miles (instead of minutes)', ''], ['vehicle', 'Vehicle', 'car'], ['toward', 'Measure driving TOWARD the place? yes or no', 'no'], ['country', 'Only in these countries', 'us']] },
  best_order: { label: 'Best order for stops', icon: 'ListOrdered', apps: ['graphhopper'], rec: 'graphhopper', alias: 'order', big: 'map', ep: { graphhopper: 'optimize' },
    hint: 'Puts stops in the order that takes the least driving, starting from one place.',
    fields: [['start', 'Start from', '{{places.first}}'], ['stops', 'Stops to visit, one per line', '{{places.places}}', 1], ['back', 'Come back to the start? yes or no', 'no'], ['vehicle', 'Vehicle', 'car'], ['country', 'Only in these countries', 'us']] },
  group_places: { label: 'Group places into areas', icon: 'Group', apps: ['graphhopper'], rec: 'graphhopper', alias: 'groups', big: 'map', ep: { graphhopper: 'cluster' },
    hint: 'Splits a list of places into territories by road distance.',
    fields: [['places', 'Places, one per line', '{{places.places}}', 1], ['groups', 'How many groups', '2'], ['vehicle', 'Vehicle', 'car'], ['country', 'Only in these countries', 'us']] },
  find_nearby: { label: 'Find things on the map', icon: 'Search', apps: ['overpass'], rec: 'overpass', alias: 'found', big: 'map', ep: { overpass: 'query' },
    hint: 'Looks OpenStreetMap up near a place or along a route. Knows: truck stops, rest areas, weigh stations, low bridges, weight limits, no-truck roads, fuel, food, hotels, parking, hospitals, charging stations, warehouses.',
    fields: [['what', 'What to look for (comma separated)', 'truck stops, rest areas'], ['near', 'Near a place, or along a route', '{{route.line}}'], ['miles', 'Within this many miles (blank = 2 along a route, 10 near a place)', ''], ['max', 'At most this many', '60'], ['country', 'Only in these countries', 'us']] },
  truck_check: { label: 'Truck route check', icon: 'Truck', apps: ['overpass'], rec: 'overpass', alias: 'check', app_run: { overpass: 'truck_route_check' },
    hint: 'One route checked for a truck: posted heights under 13 ft 6 in, weight limits, no-truck roads, and where to stop.',
    fields: [['origin', 'From', '{{trigger.origin}}'], ['destination', 'To', '{{trigger.destination}}']] },
  map_note: { label: 'Report a map problem', icon: 'StickyNote', apps: ['openstreetmap'], rec: 'openstreetmap', alias: 'note', big: 'map', ep: { openstreetmap: 'create_note' },
    hint: 'Leaves a public note on OpenStreetMap where the map is wrong (a bridge height, a closed road), signed with your OpenStreetMap name.',
    fields: [['where', 'Where', '{{places.first}}'], ['text', 'What is wrong', '', 1]] },
  create_task: { label: 'Create task', icon: 'CheckSquare', apps: ['ontask', 'crm', 'pipedrive', 'asana', 'jira', 'trello'], rec: 'ontask', alias: 'task',
    fields: [['title', 'Title', 'Follow up with {{contact.firstName}}'], ['due', 'Due', 'in 2 days']],
    ep: { ontask: 'create_task', crm: 'create_contact_task', pipedrive: 'add_activity', asana: 'create_task', jira: 'create_issue', trello: 'create_card' },
    params: { crm: (v) => ({ contactId: '{{contact.id}}', title: v.title, dueDate: new Date(Date.now() + (parseInt(String(v.due).replace(/\D/g, ''), 10) || 1) * 864e5).toISOString(), completed: false }), ontask: (v) => ({ title: v.title, due: v.due }), pipedrive: (v) => ({ subject: v.title, type: 'task', due_date: new Date(Date.now() + (parseInt(String(v.due).replace(/\D/g, ''), 10) || 1) * 864e5).toISOString().slice(0, 10) }), asana: (v) => ({ name: v.title, due_on: v.due }), jira: (v) => ({ summary: v.title }), trello: (v) => ({ name: v.title, due: v.due }) } },
  charge: { label: 'Charge a card', icon: 'CreditCard', apps: ['stripe', 'square'], rec: 'stripe', alias: 'charge',
    fields: [['amount', 'Amount', '49.00'], ['customer', 'Customer', '{{contact.id}}'], ['currency', 'Currency', 'usd']],
    ep: { stripe: 'create_charge', square: 'create_payment' },
    params: { stripe: (v) => ({ amount: Math.round(parseFloat(v.amount || '0') * 100), currency: v.currency || 'usd', customer: v.customer }), square: (v) => ({ amount_money: { amount: Math.round(parseFloat(v.amount || '0') * 100), currency: (v.currency || 'usd').toUpperCase() }, customer_id: v.customer }) } },
  post_social: { label: 'Post to social', icon: 'Share2', apps: ['twitter', 'linkedin', 'wordpress'], rec: 'linkedin', alias: 'post',
    fields: [['text', 'Post', '', 1]],
    ep: { twitter: 'create_tweet', linkedin: 'create_post', wordpress: 'create_post' },
    params: { twitter: (v) => ({ text: v.text }), linkedin: (v) => ({ text: v.text }), wordpress: (v) => ({ title: v.text.slice(0, 60), content: v.text, status: 'publish' }) } },
  launch_site: { label: 'Launch a site', icon: 'Globe', apps: ['hostinger'], rec: 'hostinger', alias: 'site', app_run: { hostinger: 'hostinger_site_launch' },
    fields: [['domain', 'Domain', 'client.com'], ['title', 'Site title', 'Client site']] },
  book_event: { label: 'Book on the calendar', icon: 'CalendarPlus', apps: ['google_calendar', 'crm'], rec: 'google_calendar', alias: 'event',
    fields: [['summary', 'Title', 'Session with {{trigger.name}}'], ['start', 'Start (ISO)', '{{trigger.start}}'], ['end', 'End (ISO)', '{{trigger.end}}'], ['attendee', 'Attendee email', '{{trigger.email}}'], ['calendarId', 'CRM calendar id (CRM only)', '']],
    ep: { crm: 'create_appointment', google_calendar: 'create_event' },
    params: { crm: (v) => ({ calendarId: v.calendarId, contactId: '{{contact.id}}', startTime: v.start, endTime: v.end, title: v.summary }), google_calendar: (v) => ({ summary: v.summary, start: { dateTime: v.start }, end: { dateTime: v.end }, attendees: v.attendee ? [{ email: v.attendee }] : [] }) } },
  voicemail_drop: { label: 'Voicemail drop', icon: 'Voicemail', apps: ['crm'], rec: 'crm', alias: 'voicemail',
    hint: 'Leaves a ringless voicemail by starting your CRM workflow that has the Voicemail Drop step (pick it by id; record the message in the CRM once).',
    fields: [['workflowId', 'CRM workflow with the voicemail drop', ''], ['contactId', 'Contact', '{{contact.id}}']],
    ep: { crm: 'add_contact_to_workflow' }, params: { crm: (v) => ({ contactId: v.contactId, workflowId: v.workflowId }) } },
  add_tag: { label: 'Tag the contact', icon: 'Tag', apps: ['crm'], rec: 'crm', alias: 'tagged',
    fields: [['tags', 'Tags (comma separated)', 'lead, website'], ['contactId', 'Contact', '{{contact.id}}']],
    ep: { crm: 'add_contact_tags' }, params: { crm: (v) => ({ contactId: v.contactId, tags: String(v.tags || '').split(',').map((t) => t.trim()).filter(Boolean) }) } },
  start_workflow: { label: 'Start a CRM workflow', icon: 'Workflow', apps: ['crm'], rec: 'crm', alias: 'workflow',
    hint: 'Anything your CRM workflows do — drips, reminders, review requests, missed-call text back — one step.',
    fields: [['workflowId', 'Workflow id', ''], ['contactId', 'Contact', '{{contact.id}}']],
    ep: { crm: 'add_contact_to_workflow' }, params: { crm: (v) => ({ contactId: v.contactId, workflowId: v.workflowId }) } },
  add_note: { label: 'Add a note', icon: 'StickyNote', apps: ['crm', 'pipedrive'], rec: 'crm', alias: 'note',
    fields: [['body', 'Note', 'Came in from {{trigger.source}}: {{trigger.message}}', 1], ['contactId', 'Contact', '{{contact.id}}']],
    ep: { crm: 'create_contact_note', pipedrive: 'add_note' }, params: { crm: (v) => ({ contactId: v.contactId, body: v.body }), pipedrive: (v) => { const n = (x) => (/^\d+$/.test(String(x || '').trim()) ? Number(x) : undefined); return { content: v.body, person_id: n(v.contactId) }; } } },
  create_deal: { label: 'Create opportunity', icon: 'Handshake', apps: ['crm', 'pipedrive'], rec: 'crm', alias: 'deal',
    fields: [['name', 'Name', '{{contact.firstName}} — new lead'], ['pipelineId', 'Pipeline id', ''], ['stageId', 'Stage id', ''], ['value', 'Value', '0'], ['contactId', 'Contact', '{{contact.id}}']],
    ep: { crm: 'create_opportunity', pipedrive: 'add_deal' }, out: { pipedrive: (d) => d.data || d }, params: { crm: (v) => ({ name: v.name, pipelineId: v.pipelineId, pipelineStageId: v.stageId, monetaryValue: Number(v.value) || 0, contactId: v.contactId, status: 'open' }), pipedrive: (v) => { const n = (x) => (/^\d+$/.test(String(x || '').trim()) ? Number(x) : undefined); return { title: v.name, value: Number(v.value) || 0, pipeline_id: n(v.pipelineId), stage_id: n(v.stageId), person_id: n(v.contactId), status: 'open' }; } } },
};

export const TRIGGERS = {
  webhook: { label: 'Webhook', icon: 'Webhook', sub: 'POST to a URL 0n3 gives you', fields: [['path', 'Path', '/hooks/new-payment']] },
  schedule: { label: 'Schedule', icon: 'Clock', sub: 'Every hour, day, or cron', fields: [['cron', 'When', 'Every day at 9:00']] },
  app_event: { label: 'App event', icon: 'Zap', sub: 'Payment, form, new row…', hasApp: true, apps: ['stripe', 'crm', 'typeform', 'shopify', 'github', 'calendly', 'ebay'], rec: 'stripe', fields: [['event', 'Event', 'payment_intent.succeeded']] },
  inbox: { label: 'Inbox', icon: 'Inbox', sub: 'An email to your desk', fields: [['mailbox', 'Mailbox the desk reads', 'desk@yourcompany.com'], ['senders', 'Who may write (emails, comma-separated)', 'you@yourcompany.com'], ['subject', 'Only subjects containing (optional)', '']] },
  email: { label: 'Email arrives', icon: 'Mail', sub: 'A new email in a mailbox you connected', hasApp: true, apps: ['microsoft'], rec: 'microsoft', fields: [['mailbox', 'Mailbox', 'you@yourcompany.com'], ['subject', 'Only subjects containing (optional)', '']] },
  page_button: { label: 'Page button', icon: 'MousePointerClick', sub: 'A button on the mini page', fields: [['name', 'Flow name (the button names it)', 'New request']] },
};
export const LOGIC = {
  ifelse: { label: 'If / else', icon: 'GitBranch', sub: 'Two paths', outs: ['Yes', 'No'], fields: [['cond', 'Condition', '{{trigger.amount}} > 100']] },
  loop: { label: 'Loop', icon: 'Repeat', sub: 'Once per item', fields: [['over', 'For each', '{{sheet.rows}}']] },
  delay: { label: 'Wait', icon: 'Hourglass', sub: 'Pause, then continue', fields: [['for', 'For', '2 days']] },
  ask: { label: 'Ask before acting', icon: 'MessageCircleQuestion', sub: 'Pause and ask you when unsure', outs: ['Answered'], fields: [['policy', 'Ask when', 'outward'], ['note', 'What always needs a yes', 'Anything that deploys, sends, charges or publishes']] },
  filter: { label: 'Filter', icon: 'Filter', sub: 'Stop unless true', fields: [['cond', 'Only continue if', '{{contact.email}} exists']] },
};
export const READ_PICTURE_PROMPT = 'This image is a table. Return ONLY a JSON array with one object per data row, top to bottom. Use the column headers EXACTLY as printed in the header row as the keys, include EVERY column in EVERY object, and use "" for a cell that is empty in the image. Copy every value exactly as shown: never correct, guess, reformat, or fill a blank cell from the row above. The print is small: read every digit one character at a time, and count the rows before you answer so none is skipped or repeated.';
export const DATA = {
  map: { label: 'Map fields', icon: 'Shuffle', sub: 'Rename and reshape', alias: 'mapped', fields: [['map', 'Mapping', 'email → contact.email\nname → contact.firstName', 1]] },
  format: { label: 'Format', icon: 'Type', sub: 'Dates, money, text', alias: 'formatted', fields: [['expr', 'Expression', 'money({{trigger.amount}}, "USD")'], ['out', 'Save as', 'text']] },
  merge: { label: 'Merge', icon: 'Merge', sub: 'Join two paths', fields: [] },
  agree: { label: 'Keep what agrees', icon: 'CheckSquare', sub: 'Only rows every reading gives identically', alias: 'agreed', fields: [['readings', 'The separate readings', '{{reading.readings}}'], ['key', 'Column that names a row (blank = the first)', ''], ['min', 'Stop unless at least this share agrees', '50%']] },
  return: { label: 'Return', icon: 'Flag', sub: 'What this Job hands back when it runs', alias: 'output', end: true, fields: [['value', 'What to return (text, {{a.value}}, or JSON with {{…}} inside)', '{{last}}', 1]] },
  draw_map: { label: 'Draw a map', icon: 'Map', sub: 'Everything this job found, on one OpenStreetMap', alias: 'map', fields: [['title', 'Title', ''], ['extra', 'Also draw (places or a line, optional)', '', 1]] },
  keep_rows: { label: 'Keep rows that pass', icon: 'Filter', sub: 'Every rule must be true for a row to stay', alias: 'kept', fields: [['rows', 'Rows', '{{agreed.rows}}'], ['rules', 'Rules, one per line, each starting with a column name — like: State is not CA, WA', '', 1]] },
};
export const AI = {
  read_picture: { label: 'Read a picture', icon: 'Image', sub: 'Your own computer reads it, as many separate times as you ask', hasApp: true, apps: ['desk'], rec: 'desk', alias: 'reading', fields: [['pictures', 'Pictures', '{{email.pictures}}'], ['times', 'How many separate readings', '2'], ['prompt', 'What to read', READ_PICTURE_PROMPT, 1]] },
  // OUTREACH (outreach.js): the AI designer as a job step — a logo, an HTML email or a social post, saved to the job's project.
  outreach: { label: 'Design it (Outreach)', icon: 'Palette', sub: 'Logo, HTML email or social post', hasApp: true, apps: ['groq', 'openai', 'gemini', 'anthropic'], rec: 'groq', alias: 'design', fields: [['kind', 'Design (logo, email or social)', 'email'], ['brief', 'What it is for', 'Welcome {{trigger.firstName}} to {{brand}}', 1], ['brand', 'Business name', '{{brand}}'], ['networks', 'Networks (social only)', 'facebook, instagram']] },
  ai: { label: 'AI step', icon: 'Sparkles', sub: 'Summarise, draft, decide', hasApp: true, apps: ['groq', 'openai', 'gemini', 'anthropic', 'ollama'], rec: 'groq', fields: [['prompt', 'Instructions', 'Write a two-line welcome note for {{contact.firstName}}.', 1], ['out', 'Save result as', 'note']] },
};
export const AGENTS = {
  claude_code: { name: 'Claude Code', how: 'Run once in any terminal', client: 'claude_code' },
  gemini_cli: { name: 'Gemini CLI', how: 'Run once in any terminal', client: 'gemini_cli' },
  codex: { name: 'Codex', how: 'Run once in any terminal', client: 'codex' },
  cursor: { name: 'Cursor', how: 'One click, or .cursor/mcp.json', client: 'cursor' },
};
export const TERMINAL = {
  terminal_cmd: { label: 'From your terminal', icon: 'Terminal', sub: 'A coding agent calls this flow as a tool', hasApp: true, apps: Object.keys(AGENTS), rec: 'claude_code', terminal: true, fields: [['tool', 'Tool name the agent sees', 'deploy_client_site'], ['describe', 'What it does (the agent reads this)', 'Launch the client site and tell the team', 1]] },
  desk_agent: { label: 'Desk agent', icon: 'MonitorSmartphone', sub: 'Your desktop agent does the work in a project', hasApp: true, apps: Object.keys(AGENTS), rec: 'claude_code', terminal: true, fields: [['project', 'Project name (what the mail calls it)', 'Acme Fitness'], ['folder', 'Folder on your machine', '~/Projects/acme-fitness'], ['machine', 'Machine name (blank = any of yours)', ''], ['rules', 'Rules the agent reads first', 'Read CLAUDE.md. No online sign-ups, no pricing anywhere.', 1]] },
  terminal_agent: { label: 'Ask your coding agent', icon: 'SquareTerminal', sub: 'Hand a job to Claude Code, Gemini, Codex…', hasApp: true, apps: Object.keys(AGENTS), rec: 'claude_code', terminal: true, fields: [['prompt', 'Instructions', 'Fix the failing test in {{trigger.repo}} and open a PR.', 1], ['cwd', 'Folder', '~/Github/0n3']] },
};
/** Website elements — the pieces of the mini page. They render; they never run. */
export const SHAPES = {
  section: { label: 'Section', icon: 'LayoutPanelTop', sub: 'A band of the page', group: 'Layout', w: 640, h: 300, defaults: { title: 'Welcome' }, fields: [['title', 'Title', 'Welcome']] },
  row: { label: 'Row', icon: 'Columns3', sub: 'Side-by-side columns', group: 'Layout', w: 600, h: 180, defaults: { cols: '3' }, fields: [['cols', 'Columns (2–4)', '3']] },
  column: { label: 'Column', icon: 'RectangleVertical', sub: 'A single stack', group: 'Layout', w: 220, h: 240, defaults: { title: 'Column' }, fields: [['title', 'Label', 'Column']] },
  divider: { label: 'Divider', icon: 'Minus', sub: 'A thin rule', group: 'Layout', w: 400, h: 24, defaults: {}, fields: [] },
  heading: { label: 'Heading', icon: 'Heading', sub: 'Large title text', group: 'Content', w: 420, h: 44, defaults: { text: 'Your projects' }, fields: [['text', 'Text', 'Your projects']] },
  paragraph: { label: 'Text', icon: 'Text', sub: 'A paragraph', group: 'Content', w: 380, h: 84, defaults: { text: 'Everything you asked us to set up, in one place. Ask a question below or start a request.' }, fields: [['text', 'Text', '', 1]] },
  image: { label: 'Picture', icon: 'Image', sub: 'Photo or logo', group: 'Content', w: 320, h: 200, defaults: { caption: 'Hero image', url: '' }, fields: [['url', 'Image URL (https://…)', ''], ['caption', 'Caption', 'Hero image']] },
  file: { label: 'File', icon: 'Paperclip', sub: 'A PDF or document to download', group: 'Content', w: 320, h: 72, defaults: { name: 'Document', url: '', size: '' }, fields: [['name', 'Shown as', 'Brochure.pdf'], ['url', 'File URL (https://…)', '']] },
  tooltip: { label: 'Tooltip', icon: 'MessageCircle', sub: 'Hint on hover', group: 'Content', w: 220, h: 56, defaults: { text: 'Click to start a new request' }, fields: [['text', 'Text', 'Click to start a new request']] },
  input: { label: 'Text field', icon: 'TextCursorInput', sub: 'One-line answer', group: 'Inputs', w: 320, h: 76, defaults: { label: 'Your email', placeholder: 'you@company.com', name: 'email' }, fields: [['label', 'Label', 'Your email'], ['placeholder', 'Placeholder', 'you@company.com'], ['name', 'Field name (used in flows as {{trigger.name}})', 'email']] },
  datetime: { label: 'Date & time', icon: 'CalendarClock', sub: 'Pick a day and hour', group: 'Inputs', w: 320, h: 76, defaults: { label: 'When should this happen?', placeholder: 'Oct 23, 2026 · 2:30 PM', name: 'when' }, fields: [['label', 'Label', 'When should this happen?'], ['placeholder', 'Shown value', 'Oct 23, 2026 · 2:30 PM'], ['name', 'Field name (the flow reads {{trigger.<name>}})', 'when']] },
  textarea: { label: 'Text area', icon: 'AlignLeft', sub: 'Multi-line answer', group: 'Inputs', w: 360, h: 150, defaults: { label: 'Tell us what you need', placeholder: 'Describe the change…', name: 'message' }, fields: [['label', 'Label', 'Tell us what you need'], ['placeholder', 'Placeholder', 'Describe the change…'], ['name', 'Field name', 'message']] },
  button: { label: 'Button', icon: 'MousePointerClick', sub: 'Starts a flow', group: 'Inputs', w: 180, h: 52, defaults: { label: 'Send request', runs: 'New request' }, fields: [['label', 'Label', 'Send request'], ['runs', 'Runs the flow', 'New request']] },
  chat: { label: 'Chat box', icon: 'MessagesSquare', sub: 'Talk to the project', group: 'Inputs', w: 340, h: 360, hasApp: true, apps: ['groq', 'openai', 'gemini', 'anthropic', 'ollama'], rec: 'groq', defaults: { title: 'Ask us', placeholder: 'Ask anything about your account…' }, fields: [['title', 'Title', 'Ask us'], ['placeholder', 'Placeholder', 'Ask anything about your account…']] },
  box: { label: 'Box', icon: 'Square', sub: 'Outlined shape', group: 'Decor', w: 280, h: 180, defaults: { text: '' }, fields: [['text', 'Label', '']] },
  sticky: { label: 'Note for the AI', icon: 'Bot', sub: 'Read at Build plan · never shown to customers', group: 'Decor', w: 200, h: 160, defaults: { text: 'Keep this page to one screen on mobile. Requests must reach Slack within a minute.' }, fields: [['text', 'Note', '', 1]] },
};
export const CATS = [['shapes', 'Page', 'Website elements. Together they make the mini page your customer signs in to. Drag a corner to resize.'], ['tasks', 'Tasks', 'Plain actions. Pick which app does each one; the recommended app is already chosen.'], ['triggers', 'Triggers', 'What starts a flow: a webhook, a schedule, an app event, or a button on the page.'], ['terminal', 'Terminal', 'Link the coding agent in your own terminal. It can start a flow, or do a step inside one.'], ['apps', 'Apps', 'Your connected services, every endpoint callable. A green dot means it is in your vault.'], ['logic', 'Logic', 'Branch, repeat, wait.'], ['data', 'Data', 'Reshape values between blocks.'], ['ai', 'AI', 'Bring your own model; nothing is sent anywhere you did not connect.']];
export const TYPE_OF = { task: TASKS, trigger: TRIGGERS, logic: LOGIC, data: DATA, ai: AI, terminal: TERMINAL, shape: SHAPES };
export const defOf = (n) => (n.type === 'action' ? { label: `${nameOf(n.key)} call`, icon: 'Plug', fields: [['endpoint', 'Endpoint', 'list_contacts'], ['params', 'Params (JSON)', '{ }', 1]] } : (TYPE_OF[n.type] || {})[n.key] || {});
export const kindLabel = (n) => ({ task: 'Task', trigger: 'Trigger', action: 'App action', logic: 'Logic', data: 'Data', ai: 'AI', terminal: 'Terminal', shape: 'Page element' })[n.type] || n.type;
export const isStart = (n) => n.type === 'trigger' || n.key === 'terminal_cmd';

export const uid = () => Math.random().toString(36).slice(2, 8);
export const snap = (v) => Math.round(v / GRID) * GRID;
/** A Google Sheet id from its link, or the id itself. */
export const sheetIdOf = (v) => { const m = /\/spreadsheets\/d\/([A-Za-z0-9_-]{20,})/.exec(String(v || '')); return m ? m[1] : String(v || '').trim(); };
export function parseJson(s) { try { const v = JSON.parse(s || '{}'); return v && typeof v === 'object' ? v : {}; } catch { return {}; } }

/** Make a node. Shapes carry w/h/values/style/access; flow blocks carry app/fields/outs. */
export function mkNode(type, key, x, y, extra = {}) {
  const d = type === 'action' ? null : (TYPE_OF[type] || {})[key];
  if (type !== 'action' && !d) throw new Error(`No ${type} called ${key}`);
  const n = { id: uid(), type, key, x, y, values: {}, ...extra };
  if (type === 'action') { n.title = extra.title || `${nameOf(key)} call`; n.app = key; n.hasApp = false; n.icon = 'Plug'; n.outs = ['']; n.values = { endpoint: '', params: '{ }', ...(extra.values || {}) }; }
  else if (type === 'shape') { n.w = extra.w || d.w; n.h = extra.h || d.h; n.title = extra.title || d.label; n.icon = d.icon; n.values = { ...d.defaults, ...(extra.values || {}) }; n.hasApp = !!d.hasApp; n.app = extra.app || d.rec; n.style = extra.style || {}; n.access = extra.access || {}; }
  else { n.title = extra.title || d.label; n.icon = d.icon; n.hasApp = !!(type === 'task' || d.hasApp); n.app = n.app || d.rec; n.outs = d.outs || ['']; n.values = { ...(extra.values || {}) }; n.retries = extra.retries || '2'; n.timeout = extra.timeout || '30'; }
  return n;
}

/** Flow order from the starts, following wires by port. Shapes are not part of it. */
export function flowOrder(nodes, edges) {
  const flow = nodes.filter((n) => n.type !== 'shape'); const out = []; const seen = new Set();
  const visit = (id) => { if (seen.has(id)) return; seen.add(id); const n = flow.find((x) => x.id === id); if (!n) return; out.push(n); edges.filter((e) => e.from === id).sort((a, b) => a.port - b.port).forEach((e) => visit(e.to)); };
  flow.filter(isStart).forEach((n) => visit(n.id)); flow.forEach((n) => visit(n.id));
  return out;
}

/** Column layout for flow blocks by wire depth (Auto-tidy). Shapes keep their place. */
export function tidy(nodes, edges) {
  const flow = nodes.filter((n) => n.type !== 'shape');
  const layer = {}; const indeg = {}; flow.forEach((n) => { indeg[n.id] = 0; }); edges.forEach((e) => { indeg[e.to] = (indeg[e.to] || 0) + 1; });
  const q = flow.filter((n) => !indeg[n.id]).map((n) => n.id); q.forEach((id) => { layer[id] = 0; });
  const seen = new Set(q);
  while (q.length) { const id = q.shift(); edges.filter((e) => e.from === id).forEach((e) => { layer[e.to] = Math.max(layer[e.to] || 0, layer[id] + 1); if (!seen.has(e.to)) { seen.add(e.to); q.push(e.to); } }); }
  const cols = {}; flow.forEach((n) => { const l = layer[n.id] || 0; (cols[l] = cols[l] || []).push(n); });
  // Flow blocks go BELOW the page elements, never over them: the page is what the customer sees, the flow is its wiring.
  const shapes = nodes.filter((n) => n.type === 'shape' && n.key !== 'sticky');
  const top = shapes.length ? Math.max(...shapes.map((n) => (n.y || 0) + (n.h || 0))) + 80 : 80;
  const pos = {}; Object.keys(cols).forEach((l) => { cols[l].sort((a, b) => a.y - b.y).forEach((n, i) => { pos[n.id] = { x: 40 + l * (W + 92), y: top + i * 170 }; }); });
  return nodes.map((n) => (pos[n.id] ? { ...n, ...pos[n.id] } : n));
}

/** `{{a.b.c}}` against a context. Unknown paths resolve to ''. Whole-value substitution keeps the type (an object stays an object). */
export function resolveTemplate(str, ctx) {
  if (typeof str !== 'string') return str;
  const whole = /^\s*\{\{\s*([\w.$-]+)\s*\}\}\s*$/.exec(str);
  if (whole) { const v = pathGet(ctx, whole[1]); return v === undefined ? '' : v; }
  return str.replace(/\{\{\s*([\w.$-]+)\s*\}\}/g, (_, p) => { const v = pathGet(ctx, p); return v === undefined || v === null ? '' : (typeof v === 'object' ? JSON.stringify(v) : String(v)); });
}
export function pathGet(obj, path) { return String(path).split('.').reduce((o, k) => (o && typeof o === 'object' && k in o ? o[k] : undefined), obj); }
export const resolveAll = (values, ctx) => Object.fromEntries(Object.entries(values || {}).map(([k, v]) => [k, resolveTemplate(v, ctx)]));

/** A condition without eval: `{{a}} > 100`, `{{x}} == y`, `{{s}} contains z`, `{{v}} exists`, `{{v}} is empty`. */
export function evalCondition(cond, ctx) {
  const s = resolveTemplate(String(cond || ''), ctx);
  const text = typeof s === 'string' ? s.trim() : String(s);
  let m;
  if ((m = /^(.*?)\s*\b(exists|is set)$/i.exec(text))) return m[1].trim() !== '' && m[1].trim() !== 'undefined';
  if ((m = /^(.*?)\s*\bis empty$/i.exec(text))) return m[1].trim() === '';
  if ((m = /^(.*?)\s+(contains|includes)\s+(.*)$/i.exec(text))) return m[1].toLowerCase().includes(unq(m[3]).toLowerCase());
  if ((m = /^(.*?)\s*(>=|<=|==|!=|=|>|<)\s*(.*)$/.exec(text))) {
    const a = unq(m[1]), b = unq(m[3]); const na = Number(a), nb = Number(b); const num = a !== '' && b !== '' && !Number.isNaN(na) && !Number.isNaN(nb);
    switch (m[2]) { case '>': return num ? na > nb : a > b; case '<': return num ? na < nb : a < b; case '>=': return num ? na >= nb : a >= b; case '<=': return num ? na <= nb : a <= b; case '!=': return num ? na !== nb : a !== b; default: return num ? na === nb : a === b; }
  }
  return text !== '' && text !== 'false' && text !== '0';
}
const unq = (v) => String(v).trim().replace(/^["']|["']$/g, '');

/** The small format language: money(x, "USD"), upper(x), lower(x), date(x), trim(x); anything else resolves as a template. */
export function evalFormat(expr, ctx) {
  const s = resolveTemplate(String(expr || ''), ctx); const text = typeof s === 'string' ? s.trim() : String(s);
  const m = /^(money|upper|lower|date|trim|length)\((.*)\)$/i.exec(text);
  if (!m) return text;
  const args = m[2].split(',').map(unq);
  switch (m[1].toLowerCase()) {
    case 'money': { const n = Number(args[0]); const cur = (args[1] || 'USD').toUpperCase(); return Number.isNaN(n) ? args[0] : new Intl.NumberFormat('en-US', { style: 'currency', currency: cur }).format(n); }
    case 'upper': return args[0].toUpperCase(); case 'lower': return args[0].toLowerCase(); case 'trim': return args[0].trim(); case 'length': return String(args[0].length);
    case 'date': { const d = new Date(args[0] || Date.now()); return Number.isNaN(d.getTime()) ? args[0] : d.toISOString().slice(0, 10); }
    default: return text;
  }
}

/** Scopes → which HTTP methods a fenced call may use. "run" is app_run / flows. */
export const SCOPE_METHODS = { read: ['GET'], create: ['POST'], update: ['PUT', 'PATCH'], delete: ['DELETE'] };

/** The prebuilt designs and flows from the handoff. Each returns { name, nodes, edges }. */
export const TEMPLATES = [
  { key: 'desk', name: 'Request desk', kind: 'Desk', what: 'Email your desk. Your desktop agent opens the project and does the work. If it is unsure it asks on your phone and waits; your answer sends it on. The reply carries the receipt.', chips: ['claude_code', 'gmail', 'resend'], count: 5 },
  { key: 'request', name: 'New request', kind: 'Job', what: 'Fired by a page button: opens a task in 0nTask, tells the team in Slack, confirms to the client by email.', chips: ['ontask', 'slack', 'resend'], count: 4 },
  { key: 'portal', name: 'Client portal page', kind: 'Mini-app design', what: 'A mini page your customer signs in to: a welcome, a picture, a request button, and a chat box that answers from this project.', chips: ['groq', 'crm', 'ontask'], count: 8 },
  { key: 'support', name: 'Support desk', kind: 'Mini-app design', what: 'A heading, a request form, and an agentic chat that can open tickets and look up orders for the customer.', chips: ['groq', 'crm', 'shopify'], count: 7 },
  { key: 'booking', name: 'Booking page', kind: 'Mini-app design', what: 'Three columns of services, a name and email field, and a button that books through your calendar.', chips: ['google_calendar', 'crm', 'resend'], count: 9 },
  { key: 'terminal', name: 'Connect your terminal', what: 'Your coding agent (Claude Code, Gemini CLI, Codex…) calls this flow as a tool. It makes the change, opens the pull request, deploys, and tells the team.', chips: ['claude_code', 'github', 'hostinger', 'slack'], count: 6 },
  { key: 'payment', name: 'New payment → welcome', what: 'A payment lands, the buyer becomes a CRM contact, gets a welcome email, and the team hears about it.', chips: ['stripe', 'crm', 'resend', 'slack'], count: 5 },
  { key: 'lead', name: 'Lead form → first task', what: 'A form submission is enriched by an AI step, saved to the CRM, and a follow-up task opens in 0nTask.', chips: ['typeform', 'groq', 'crm', 'ontask'], count: 4 },
  { key: 'picture_table', name: 'Emailed picture into a table', kind: 'Job', what: 'Someone emails a screenshot of a spreadsheet. Your computer reads it twice, only the rows both readings agree on go forward, your rules pick the rows you want, and they land in your Excel or Google Sheet without touching anything a person typed there.', chips: ['microsoft', 'google_sheets'], count: 6 },
  { key: 'report', name: 'Daily report', what: 'Every morning, read a sheet, summarise it, and post the summary to a channel.', chips: ['google_sheets', 'groq', 'slack'], count: 4 },
  { key: 'launch', name: 'Site launch', what: 'Launch a site on Hostinger, point DNS at it through GoDaddy, then email the client the link.', chips: ['hostinger', 'godaddy', 'resend'], count: 4 },
];

/**
 * EVERYDAY SEQUENCES (2026-10-29) — Mike: "the builders need to be even simpler — smarter — enough templates that make
 * sense." Data, not code: a trigger and a straight line of steps. Built around the CRM because it already does email,
 * texting, voicemail drops, tags, workflows, notes, deals and bookings. `group` sorts them by the job a business has.
 * Fields left blank fall back to each step's own placeholder (e.g. {{contact.id}} from the first CRM step).
 */
const C = (title, values = {}) => ({ task: 'create_contact', app: 'crm', title, values });
export const SEQ_TEMPLATES = [
  { key: 'speed_to_lead', group: 'Get leads', name: 'Speed to lead', what: 'A lead fills your form: saved to the CRM, texted within a minute, emailed, and a deal opens so nobody forgets them.', chips: ['crm'],
    trigger: ['page_button', 'New lead', { name: 'New lead' }],
    steps: [C('Save the lead', { tags: 'new-lead' }), { task: 'send_message', app: 'crm', title: 'Text them now', values: { text: 'Hi {{contact.firstName}}, thanks for reaching out to {{brand}}! When is a good time for a quick call?' } },
      { task: 'send_email', app: 'crm', title: 'Email the details', values: { subject: 'Thanks for reaching out', html: 'Hi {{contact.firstName}},<br>Here is what happens next…' } }, { task: 'create_deal', app: 'crm', title: 'Open a deal', values: { name: '{{contact.firstName}} — new lead' } }] },
  { key: 'quote_request', group: 'Get leads', name: 'Quote request', what: 'Someone asks for a quote: contact saved, the request noted on their record, a deal opened, and a task for you to send the price.', chips: ['crm', 'ontask'],
    trigger: ['page_button', 'Quote request', { name: 'Quote request' }],
    steps: [C('Save the contact', { tags: 'quote' }), { task: 'add_note', app: 'crm', title: 'Note what they asked', values: { body: 'Quote request: {{trigger.message}}' } }, { task: 'create_deal', app: 'crm', title: 'Open a deal' }, { task: 'create_task', app: 'ontask', title: 'Send the quote', values: { title: 'Send a quote to {{contact.firstName}}', due: 'in 1 day' } }] },
  { key: 'newsletter', group: 'Get leads', name: 'Newsletter sign-up', what: 'A visitor joins your list: tagged in the CRM and started on your welcome drip.', chips: ['crm'],
    trigger: ['page_button', 'Join the list', { name: 'Join the list' }],
    steps: [C('Save the subscriber', { tags: 'newsletter' }), { task: 'start_workflow', app: 'crm', title: 'Start the welcome drip' }] },
  { key: 'referral', group: 'Get leads', name: 'Referral', what: 'A customer refers a friend: the friend is saved and tagged, gets a warm text, and you get a task to thank the referrer.', chips: ['crm', 'ontask'],
    trigger: ['page_button', 'Refer a friend', { name: 'Refer a friend' }],
    steps: [C('Save the friend', { tags: 'referral' }), { task: 'send_message', app: 'crm', title: 'Warm intro text', values: { text: 'Hi {{contact.firstName}}, a friend of yours thought {{brand}} could help. Want a quick call?' } }, { task: 'create_task', app: 'ontask', title: 'Thank the referrer', values: { title: 'Thank whoever referred {{contact.firstName}}', due: 'in 1 day' } }] },
  { key: 'appointment_confirm', group: 'Book & confirm', name: 'Booking confirmation', what: 'Someone books: it goes on your CRM calendar, they get a text and an email confirming it.', chips: ['crm'],
    trigger: ['page_button', 'Book a time', { name: 'Book a time' }],
    steps: [C('Save the contact', { tags: 'booked' }), { task: 'book_event', app: 'crm', title: 'Put it on the calendar' }, { task: 'send_message', app: 'crm', title: 'Text the confirmation', values: { text: 'You are booked, {{contact.firstName}}! See you {{trigger.start}}.' } }, { task: 'send_email', app: 'crm', title: 'Email the confirmation', values: { subject: 'Your booking is confirmed', html: 'See you {{trigger.start}}.' } }] },
  { key: 'no_show', group: 'Follow up', name: 'No-show follow-up', what: 'Mark someone as a no-show: they get a friendly text and a voicemail drop asking to rebook.', chips: ['crm'],
    trigger: ['page_button', 'Missed appointment', { name: 'Missed appointment' }],
    steps: [C('Find the contact', { tags: 'no-show' }), { task: 'send_message', app: 'crm', title: 'Rebook text', values: { text: 'Hi {{contact.firstName}}, we missed you today. Want to pick a new time?' } }, { task: 'voicemail_drop', app: 'crm', title: 'Voicemail drop' }] },
  { key: 'win_back', group: 'Follow up', name: 'Win back a past customer', what: 'Reach a customer you have not heard from: a voicemail drop, a text and an email, then a task to call.', chips: ['crm', 'ontask'],
    trigger: ['page_button', 'Win back', { name: 'Win back' }],
    steps: [C('Find the contact', { tags: 'win-back' }), { task: 'voicemail_drop', app: 'crm', title: 'Voicemail drop' }, { task: 'send_message', app: 'crm', title: 'Text', values: { text: 'Hi {{contact.firstName}}, it has been a while! We have something new you will like.' } }, { task: 'send_email', app: 'crm', title: 'Email the offer', values: { subject: 'We miss you', html: 'Here is something just for you…' } }, { task: 'create_task', app: 'ontask', title: 'Call them', values: { title: 'Call {{contact.firstName}}', due: 'in 3 days' } }] },
  { key: 'review_request', group: 'Keep customers', name: 'Review request', what: 'Job done: the customer gets a thank-you text with your review link, and your review workflow follows up.', chips: ['crm'],
    trigger: ['page_button', 'Job done', { name: 'Job done' }],
    steps: [C('Find the customer', { tags: 'review-requested' }), { task: 'send_message', app: 'crm', title: 'Thank-you + review link', values: { text: 'Thanks for choosing {{brand}}, {{contact.firstName}}! Would you leave us a quick review? {{trigger.link}}' } }, { task: 'start_workflow', app: 'crm', title: 'Review reminders' }] },
  { key: 'new_client', group: 'Get paid', name: 'New client onboarding', what: 'A payment lands: the buyer becomes a tagged client in the CRM, gets a welcome email and text, and your team gets the kickoff task.', chips: ['stripe', 'crm', 'ontask', 'slack'],
    trigger: ['app_event', 'Payment received', { event: 'payment' }, 'stripe'],
    steps: [C('Save the client', { tags: 'client' }), { task: 'send_email', app: 'crm', title: 'Welcome email', values: { subject: 'Welcome to {{brand}}', html: 'Here is how we get started…' } }, { task: 'send_message', app: 'crm', title: 'Welcome text', values: { text: 'Welcome aboard, {{contact.firstName}}! Check your email for next steps.' } }, { task: 'create_task', app: 'ontask', title: 'Kickoff', values: { title: 'Kickoff with {{contact.firstName}}', due: 'in 1 day' } }, { task: 'send_message', app: 'slack', title: 'Tell the team', values: { channel: '#sales', text: 'New client: {{contact.firstName}} ({{trigger.email}})' } }] },
  { key: 'payment_thanks', group: 'Get paid', name: 'Payment thank-you', what: 'Every payment: a thank-you text and the customer tagged, so repeat buyers stand out.', chips: ['stripe', 'crm'],
    trigger: ['app_event', 'Payment received', { event: 'payment' }, 'stripe'],
    steps: [C('Find the customer', { tags: 'customer' }), { task: 'send_message', app: 'crm', title: 'Thank-you text', values: { text: 'Thank you, {{contact.firstName}}! Your payment came through.' } }] },
  { key: 'event_signup', group: 'Book & confirm', name: 'Event sign-up', what: 'Someone registers: tagged for the event, emailed their spot, and texted a reminder workflow.', chips: ['crm'],
    trigger: ['page_button', 'Register', { name: 'Register' }],
    steps: [C('Save the attendee', { tags: 'event' }), { task: 'send_email', app: 'crm', title: 'Your spot is saved', values: { subject: 'You are registered', html: 'See you there!' } }, { task: 'start_workflow', app: 'crm', title: 'Reminder texts' }] },
  { key: 'support_ticket', group: 'Keep customers', name: 'Support ticket', what: 'A customer reports a problem: the problem is noted on their CRM record, a task opens for your team, and they get a "we are on it" text.', chips: ['crm', 'ontask'],
    trigger: ['page_button', 'Get help', { name: 'Get help' }],
    steps: [C('Find the customer'), { task: 'add_note', app: 'crm', title: 'Note the problem', values: { body: 'Support: {{trigger.message}}' } }, { task: 'create_task', app: 'ontask', title: 'Fix it', values: { title: 'Help {{contact.firstName}}: {{trigger.message}}', due: 'in 1 day' } }, { task: 'send_message', app: 'crm', title: 'We are on it', values: { text: 'Got it, {{contact.firstName}} — we are on it and will update you shortly.' } }] },
];
TEMPLATES.push({ key: 'route_map', group: 'Maps', name: 'A route on a map', kind: 'Job', what: 'Give it the stops: it finds them, measures the road, lists the truck stops on the way and draws the map.', chips: ['nominatim', 'graphhopper', 'overpass'], count: 6 });
TEMPLATES.push(...SEQ_TEMPLATES.map(({ key, group, name, what, chips, steps }) => ({ key, group, name, kind: 'Job', what, chips, count: steps.length + 1 })));
const fillBrand = (v, brand) => Object.fromEntries(Object.entries(v || {}).map(([k, x]) => [k, typeof x === 'string' ? x.replace(/\{\{brand\}\}/g, brand) : x]));

export function buildTemplate(k, brand = 'Acme') {
  const mk = mkNode; const link = (a, b, p = 0) => ({ from: a.id, to: b.id, port: p });
  if (k === 'picture_table') {
    const t = mk('trigger', 'email', 40, 160, { title: 'The list arrives by email', app: 'microsoft', values: { mailbox: '', subject: '' } });
    const p = mk('task', 'email_pictures', 380, 160, { title: 'Take the picture out', app: 'microsoft', values: {} });
    const r = mk('ai', 'read_picture', 720, 160, { title: 'Read it twice', values: { times: '2' } });
    const a = mk('data', 'agree', 1060, 160, { title: 'Keep what both readings agree on', values: { min: '50%' } });
    const f = mk('data', 'keep_rows', 1400, 160, { title: 'Keep the rows I want', values: { rules: '' } });
    const u = mk('task', 'update_table', 1740, 160, { title: 'Put them in my table', app: 'microsoft', values: { tab: 'Sheet1' } });
    const nodes = [t, p, r, a, f, u]; return { name: 'Emailed picture into a table', nodes, edges: nodes.slice(1).map((n, i) => link(nodes[i], n)) };
  }
  if (k === 'route_map') {
    const t = mk('trigger', 'webhook', 40, 160, { title: 'Start with the stops', values: { path: '/hooks/route' } });
    const f = mk('task', 'find_places', 380, 160, { title: 'Find the stops', app: 'nominatim', values: {} });
    const r = mk('task', 'road_route', 720, 160, { title: 'The road between them', app: 'graphhopper', values: { vehicle: 'truck' } });
    const n = mk('task', 'find_nearby', 1060, 160, { title: 'Truck stops on the way', app: 'overpass', values: { what: 'truck stops, rest areas' } });
    const d = mk('data', 'draw_map', 1400, 160, { title: 'Draw it', values: { title: 'Route' } });
    const o = mk('data', 'return', 1740, 160, { title: 'Hand back the miles', values: { value: '{ "miles": {{route.miles}}, "hours": {{route.hours}}, "stops_found": {{found.count}} }' } });
    const nodes = [t, f, r, n, d, o]; return { name: 'A route on a map', nodes, edges: nodes.slice(1).map((x, i) => link(nodes[i], x)) };
  }
  const seq = SEQ_TEMPLATES.find((x) => x.key === k);
  if (seq) {
    const [tk, title, tv, tapp] = seq.trigger;
    const t = mk('trigger', tk, 40, 160, { title, values: tv, ...(tapp ? { app: tapp } : {}) });
    const steps = seq.steps.map((st, i) => mk('task', st.task, 380 + i * 340, 160, { title: st.title, app: st.app, values: fillBrand(st.values, brand) }));
    const nodes = [t, ...steps]; return { name: seq.name, nodes, edges: nodes.slice(1).map((n, i) => link(nodes[i], n)) };
  }
  if (k === 'desk') {
    const t = mk('trigger', 'inbox', 40, 160, { title: 'Email to the desk', values: { mailbox: '', senders: '' } });
    const a = mk('terminal', 'desk_agent', 380, 160, { title: `${brand} updater`, values: { project: brand, folder: `~/Github/${brand.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`, rules: 'Read CLAUDE.md first. Keep every client rule in it.' } });
    const g = mk('logic', 'ask', 720, 160, { title: 'Ask before acting', values: { policy: 'outward', note: 'Anything that deploys, sends, charges or publishes' } });
    const r = mk('task', 'send_email', 1060, 160, { title: 'Reply with the receipt', values: { to: '{{trigger.from}}', subject: 'Re: {{trigger.subject}}', html: '{{agent.reply}}' } });
    const note = mk('shape', 'sticky', 380, 330, { values: { text: 'The agent runs on YOUR machine with YOUR keys. A question pauses the run and rings your phone; your answer resumes it.' } });
    return { name: `${brand} updater`, nodes: [t, a, g, r, note], edges: [link(t, a), link(a, g), link(g, r)] };
  }
  if (k === 'request') {
    const t = mk('trigger', 'page_button', 40, 160, { title: 'Request submitted', values: { name: 'New request' } });
    const tk = mk('task', 'create_task', 380, 160, { title: 'Open a task', app: 'ontask', values: { title: 'Request from {{trigger.email}}: {{trigger.message}}', due: 'in 1 day' } });
    const m = mk('task', 'send_message', 720, 60, { title: 'Tell the team', app: 'slack', values: { channel: '#clients', text: '{{trigger.message}} — from {{trigger.email}}' } });
    const e = mk('task', 'send_email', 720, 260, { title: 'Confirm to client', app: 'resend', values: { to: '{{trigger.email}}', subject: 'Got it — we are on it', html: 'Thanks, we have your request and will be in touch shortly.' } });
    return { name: 'New request', nodes: [t, tk, m, e], edges: [link(t, tk), link(tk, m), link(tk, e)] };
  }
  if (k === 'portal') {
    const sec = mk('shape', 'section', 32, 32, { w: 768, h: 560, values: { title: `${brand} client hub` } });
    const h = mk('shape', 'heading', 64, 96, { w: 400, values: { text: 'Welcome back' } });
    const p = mk('shape', 'paragraph', 64, 160, { w: 400, h: 80, values: { text: 'Everything we set up for you lives here. Ask a question or send a request; the team sees it in minutes.' } });
    const img = mk('shape', 'image', 64, 272, { w: 400, h: 192, values: { caption: 'Latest site preview' } });
    const b = mk('shape', 'button', 64, 496, { w: 176, values: { label: 'Send a request', runs: 'New request' }, access: { crm: ['create'], slack: ['create'] } });
    const tip = mk('shape', 'tooltip', 256, 496, { w: 208, values: { text: 'Opens a short form' } });
    const chat = mk('shape', 'chat', 496, 96, { w: 272, h: 448, values: { title: `Ask ${brand}`, placeholder: 'Ask anything about your account…' }, access: { crm: ['read'], ontask: ['read', 'create'], google_calendar: ['read'] } });
    const note = mk('shape', 'sticky', 840, 40, { values: { text: 'Chat answers come from the connected model, with only this project’s data.' } });
    const t = mk('trigger', 'page_button', 32, 640, { title: 'New request', values: { name: 'New request' } });
    const c = mk('task', 'create_contact', 380, 640, { title: 'Save the request', values: { email: '{{trigger.email}}', firstName: '{{trigger.name}}' } });
    const m = mk('task', 'send_message', 720, 640, { title: 'Tell the team', app: 'slack', values: { channel: '#clients', text: 'New request from {{trigger.email}}: {{trigger.message}}' } });
    return { name: 'Client portal page', nodes: [sec, h, p, img, b, tip, chat, note, t, c, m], edges: [link(t, c), link(c, m)] };
  }
  if (k === 'support') {
    const sec = mk('shape', 'section', 32, 32, { w: 768, h: 544, values: { title: 'Support' } });
    const h = mk('shape', 'heading', 64, 96, { w: 352, values: { text: 'How can we help?' } });
    const ta = mk('shape', 'textarea', 64, 160, { w: 352, h: 160, values: { label: 'Describe the problem', placeholder: 'What happened, and where?', name: 'message' } });
    const b = mk('shape', 'button', 64, 352, { w: 192, values: { label: 'Open a ticket', runs: 'New ticket' }, access: { crm: ['create'], resend: ['create'] } });
    const chat = mk('shape', 'chat', 448, 96, { w: 320, h: 448, values: { title: 'Support agent', placeholder: 'Ask about an order or ticket…' }, access: { crm: ['read', 'create', 'update'], shopify: ['read'], slack: ['create'] } });
    const note = mk('shape', 'sticky', 832, 32, { values: { text: 'The chat can open tickets itself. Scopes are set on the element.' } });
    const t = mk('trigger', 'page_button', 32, 620, { title: 'New ticket', values: { name: 'New ticket' } });
    const tk = mk('task', 'create_task', 380, 620, { title: 'Open the ticket', values: { title: 'Ticket: {{trigger.message}}', due: 'in 1 day' } });
    return { name: 'Support desk', nodes: [sec, h, ta, b, chat, note, t, tk], edges: [link(t, tk)] };
  }
  if (k === 'booking') {
    const sec = mk('shape', 'section', 32, 32, { w: 768, h: 688, values: { title: 'Book a session' } });
    const h = mk('shape', 'heading', 64, 96, { w: 480, values: { text: 'Pick a service' } });
    const row = mk('shape', 'row', 64, 160, { w: 704, h: 160, values: { cols: '3' } });
    const n1 = mk('shape', 'input', 64, 352, { w: 336, values: { label: 'Your name', placeholder: 'Dana Reyes', name: 'name' } });
    const n2 = mk('shape', 'input', 432, 352, { w: 336, values: { label: 'Email', placeholder: 'dana@acme.com', name: 'email' } });
    const n3 = mk('shape', 'datetime', 64, 448, { w: 336, values: { label: 'When', placeholder: 'Oct 23, 2026 · 2:30 PM', name: 'start' } });
    const b = mk('shape', 'button', 64, 560, { w: 208, values: { label: 'Book it', runs: 'New booking' }, access: { google_calendar: ['read', 'create'], crm: ['create'], resend: ['create'] } });
    const tip = mk('shape', 'tooltip', 288, 556, { w: 240, values: { text: 'Checks the calendar first' } });
    const t = mk('trigger', 'page_button', 32, 760, { title: 'New booking', values: { name: 'New booking' } });
    const ev = mk('task', 'book_event', 380, 760, { title: 'Put it on the calendar' });
    const c = mk('task', 'create_contact', 720, 760, { title: 'Save the contact' });
    return { name: 'Booking page', nodes: [sec, h, row, n1, n2, n3, b, tip, t, ev, c], edges: [link(t, ev), link(ev, c)] };
  }
  if (k === 'terminal') {
    const t = mk('terminal', 'terminal_cmd', 40, 160, { title: 'From your terminal', values: { tool: 'ship_client_fix', describe: 'Fix the reported bug, open a PR, deploy the client site, tell the team' } });
    const a = mk('terminal', 'terminal_agent', 380, 160, { title: 'Make the change', values: { prompt: 'Fix the bug described in {{trigger.input}} and commit on a new branch.', cwd: '~/Github/client-site' } });
    const pr = mk('action', 'github', 720, 160, { title: 'Open a pull request', values: { endpoint: 'create_issue', params: '{ "title": "{{agent.summary}}" }' } });
    const dep = mk('task', 'launch_site', 1060, 60, { title: 'Deploy the site', app: 'hostinger' });
    const m = mk('task', 'send_message', 1060, 260, { title: 'Tell the team', app: 'slack', values: { channel: '#clients', text: '{{agent.summary}} · {{pr.url}}' } });
    const note = mk('shape', 'sticky', 380, 330, { values: { text: 'The agent never gets a key. Every call goes through the vault with your 0n_ token.' } });
    return { name: 'Connect your terminal', nodes: [t, a, pr, dep, m, note], edges: [link(t, a), link(a, pr), link(pr, dep), link(pr, m)] };
  }
  if (k === 'payment') {
    const t = mk('trigger', 'app_event', 40, 160, { title: 'New payment', app: 'stripe', values: { event: 'payment_intent.succeeded' } });
    const c = mk('task', 'create_contact', 380, 160, { title: 'Save the buyer' });
    const i = mk('logic', 'ifelse', 720, 160, { title: 'Over $100?', values: { cond: '{{trigger.amount}} > 100' } });
    const e = mk('task', 'send_email', 1060, 60, { title: 'Welcome email', values: { to: '{{contact.email}}', subject: 'Welcome aboard', html: 'Hi {{contact.firstName}}, thank you.' } });
    const s = mk('task', 'send_message', 1060, 260, { title: 'Tell the team', app: 'slack', values: { channel: '#sales', text: 'New payment from {{trigger.email}}' } });
    return { name: 'New payment → welcome', nodes: [t, c, i, e, s], edges: [link(t, c), link(c, i), link(i, e, 0), link(i, s, 1)] };
  }
  if (k === 'lead') {
    const t = mk('trigger', 'app_event', 40, 160, { title: 'Form submitted', app: 'typeform', values: { event: 'form_response' } });
    const a = mk('ai', 'ai', 380, 160, { title: 'Qualify the lead', values: { prompt: 'In one line, is this lead worth a call? {{trigger.message}}', out: 'note' } });
    const c = mk('task', 'create_contact', 720, 160); const tk = mk('task', 'create_task', 1060, 160, { title: 'Follow-up task', values: { title: 'Call {{contact.firstName}} — {{note}}', due: 'in 2 days' } });
    return { name: 'Lead form → first task', nodes: [t, a, c, tk], edges: [link(t, a), link(a, c), link(c, tk)] };
  }
  if (k === 'report') {
    const t = mk('trigger', 'schedule', 40, 160, { title: 'Every morning', values: { cron: 'Daily at 9:00' } });
    const r = mk('action', 'google_sheets', 380, 160, { title: 'Read the sheet', values: { endpoint: 'get_values', params: '{ "range": "Sheet1!A1:D50" }' } });
    const a = mk('ai', 'ai', 720, 160, { title: 'Summarise', values: { prompt: 'Summarise these rows in three lines: {{read_the_sheet.data}}', out: 'summary' } });
    const m = mk('task', 'send_message', 1060, 160, { title: 'Post the summary', app: 'slack', values: { channel: '#daily', text: '{{summary}}' } });
    return { name: 'Daily report', nodes: [t, r, a, m], edges: [link(t, r), link(r, a), link(a, m)] };
  }
  const t = mk('trigger', 'webhook', 40, 160, { title: 'Client approved', values: { path: '/hooks/client-approved' } });
  const l = mk('task', 'launch_site', 380, 160, { app: 'hostinger', values: { domain: '{{trigger.domain}}', title: '{{trigger.title}}' } });
  const d = mk('action', 'godaddy', 720, 160, { title: 'Point DNS', values: { endpoint: 'add_dns_records', params: '{ "domain": "{{trigger.domain}}", "records": [] }' } });
  const e = mk('task', 'send_email', 1060, 160, { title: 'Send the link', values: { to: '{{trigger.email}}', subject: 'Your site is live', html: 'https://{{trigger.domain}}' } });
  return { name: 'Site launch', nodes: [t, l, d, e], edges: [link(t, l), link(l, d), link(d, e)] };
}

/** A key for a node's output in the flow context: its alias, else its title as a slug. */
export const ctxKey = (n) => (defOf(n).alias) || String(n.title || n.key).toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');

/**
 * A template as the v2 builder stores it: page elements become a PAGE document, flow blocks a SEQUENCE document, and a button
 * whose `runs` names a "Page button" trigger links the two on the board. Either half may be empty.
 */
export function splitTemplate(k, brand = 'Acme') {
  const t = buildTemplate(k, brand);
  let shapes = t.nodes.filter((n) => n.type === 'shape'); let flow = t.nodes.filter((n) => n.type !== 'shape');
  // A flow template's notes for the AI stay with the sequence; a note alone never makes a page.
  if (flow.length && shapes.every((n) => n.key === 'sticky')) { flow = [...flow, ...shapes]; shapes = []; }
  const page = shapes.length ? { id: uid(), name: t.name, nodes: shapes, edges: [] } : null;
  const seqName = page && flow.length ? (flow.find(isStart)?.title || `${t.name} flow`) : t.name;
  const seqEdges = t.edges.filter((e) => flow.some((n) => n.id === e.from) && flow.some((n) => n.id === e.to));
  // Laid out from the top: in a template the blocks sat under the page elements; as a sequence of their own they start at the top.
  const sequence = flow.length ? { id: uid(), name: seqName, nodes: tidy(flow, seqEdges), edges: seqEdges } : null;
  const links = [];
  if (page && sequence) for (const b of shapes.filter((n) => n.key === 'button')) { const want = String(b.values?.runs || '').trim().toLowerCase(); if (want && flow.some((n) => n.type === 'trigger' && n.key === 'page_button' && String(n.values?.name || n.title || '').trim().toLowerCase() === want)) links.push({ el: b.id }); }
  return { name: t.name, page, sequence, links };
}

/**
 * WAITS ON THE LINES (Mike, 2026-11-08: "the line connecting to capabilities will show the delay or timeframe so that the
 * sequence can be run over a longer period of time"). A line carries `wait: '2 days'`; so does a Wait block's `for`.
 * parseWait turns the words into milliseconds, or null when they say nothing measurable. The clock that resumes a waiting
 * run ticks every 5 minutes, so anything shorter waits about that long. Capped at a year.
 */
export const WAIT_PRESETS = ['15 minutes', '1 hour', '1 day', '2 days', '3 days', '1 week', '2 weeks', '30 days'];
export const MAX_WAIT_MS = 365 * 86400000;
const UNIT_MS = { s: 1000, sec: 1000, second: 1000, m: 60000, min: 60000, minute: 60000, h: 3600000, hr: 3600000, hour: 3600000, d: 86400000, day: 86400000, w: 604800000, wk: 604800000, week: 604800000, mo: 2592000000, month: 2592000000 };
export function parseWait(text) {
  const s = String(text || '').toLowerCase().replace(/,|\band\b/g, ' ').trim();
  if (!s) return null;
  let ms = 0; let hit = false;
  const re = /(\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|ten)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|wks?|w|months?|mo)\b/g;
  const WORD = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, ten: 10 };
  for (let m; (m = re.exec(s));) {
    const n = WORD[m[1]] ?? Number(m[1]); const u = m[2];
    const per = UNIT_MS[u] ?? UNIT_MS[u.replace(/s$/, '')]; if (!per || !Number.isFinite(n)) continue;
    ms += n * per; hit = true;
  }
  if (!hit || ms <= 0) return null;
  return Math.min(Math.round(ms), MAX_WAIT_MS);
}
/** The short words a line shows: 90 min → "1 h 30 min", 172800000 → "2 days". */
export function waitLabel(ms) {
  if (!ms) return '';
  const d = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000), m = Math.round((ms % 3600000) / 60000);
  if (d >= 7 && d % 7 === 0 && !h && !m) return `${d / 7} week${d === 7 ? '' : 's'}`;
  return [d && `${d} day${d === 1 ? '' : 's'}`, h && `${h} h`, m && `${m} min`].filter(Boolean).join(' ') || '1 min';
}
