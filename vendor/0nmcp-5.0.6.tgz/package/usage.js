/**
 * METERED USAGE (2026-11-07). Mike: "we need metered billing to work regardless within 0n3."
 *
 * ONE unit = one ACTION: an app call (api_call), a connected-MCP call (mcp_call), a CRM call (crm_*), or one step of a
 * mini-app. It is counted at the one place every action already passes — the audit line (vault/store.js audit, `tool`
 * set) — so a new caller cannot forget to meter. Vault writes (put/remove) carry no tool and are never counted.
 *
 * Two halves, so billing can never slow or break the work:
 *   count()  — one atomic increment of usage_counts (account, month). Fire-and-forget; a failed count is logged.
 *   report() — the cron (every 10 min) sends each paid account's NEW units to the Stripe meter `0n3_action`, with an
 *              identifier per (account, month, total) so a retry can never bill twice. Stripe's graduated price does the
 *              arithmetic: the plan's allowance at $0, then $0.01 each (billing.js USAGE).
 *
 * Never billed: free accounts (no card — their allowance is a cap, enforced where runs are gated), VIP / admin /
 * hand-granted plans (penthouse, enterprise, founder…), and anyone without a Stripe customer. Their units are still
 * counted, so the Billing page shows real usage for everybody.
 */
export const METER_EVENT = '0n3_action';
export const monthOf = (at = new Date()) => new Date(at).toISOString().slice(0, 7);
export const COUNTED_TOOL = (tool) => !!tool; // every audit line that names a tool is an action

export function createUsage({ rest, stripe = null, now = () => new Date() }) {
  async function count(accountId, n = 1) {
    if (!accountId || !(n > 0)) return null;
    try {
      const r = await rest.rpc('usage_bump', { p_account: accountId, p_month: monthOf(now()), p_n: n });
      return Array.isArray(r) ? r[0]?.units ?? null : r?.units ?? null;
    } catch (e) { console.error('[0n3 usage] count:', e.message); return null; }
  }
  async function month(accountId, m = monthOf(now())) {
    try { return (await rest.select('usage_counts', { account_id: accountId, month: m }, 'units, reported'))[0] || { units: 0, reported: 0 }; }
    catch { return { units: 0, reported: 0 }; }
  }
  /** A plan 0n3 billing sold (starter/pro/command/business) on a live subscription, not a hand grant or a VIP. */
  const billable = (p, paid) => !!p && !p.is_vip && !p.is_admin && !!p.stripe_customer_id && paid.includes(String(p.plan || '').toLowerCase())
    && ['active', 'trialing', 'past_due', null, undefined].includes(p.plan_status);

  async function report({ paid, months = [monthOf(now())], limit = 500 } = {}) {
    if (!stripe) throw new Error('Usage reporting needs Stripe.');
    const out = { checked: 0, sent: 0, units: 0, skipped: 0, failed: [] };
    for (const m of months) {
      let rows = [];
      try { rows = await rest.rpc('usage_unreported', { p_month: m, p_limit: limit }); } catch (e) { out.failed.push({ month: m, error: e.message }); continue; }
      for (const row of rows || []) {
        out.checked++;
        const delta = Number(row.units) - Number(row.reported || 0); if (!(delta > 0)) continue;
        const p = (await rest.select('profiles', { id: row.account_id }, 'id, plan, plan_status, stripe_customer_id, is_vip, is_admin').catch(() => []))[0];
        if (!billable(p, paid)) {
          // Not billed now. A free account stays unreported, so an upgrade later this month bills the month honestly
          // (the allowance tier absorbs it); a VIP / hand grant is marked reported so it is never billed at all.
          if (p && (p.is_vip || p.is_admin || (p.plan && !paid.includes(String(p.plan).toLowerCase()) && p.plan !== 'free'))) await rest.update('usage_counts', { account_id: row.account_id, month: m }, { reported: row.units }).catch(() => {});
          out.skipped++; continue;
        }
        try {
          await stripe('/billing/meter_events', { event_name: METER_EVENT, identifier: `0n3-${row.account_id}-${m}-${row.units}`, 'payload[value]': String(delta), 'payload[stripe_customer_id]': p.stripe_customer_id });
          await rest.update('usage_counts', { account_id: row.account_id, month: m }, { reported: row.units, reported_at: now().toISOString() });
          out.sent++; out.units += delta;
        } catch (e) {
          // Stripe refuses a repeated identifier: it already has these units, so record them as reported.
          if (/identifier/i.test(e.message) && /already|exists|duplicate/i.test(e.message)) { await rest.update('usage_counts', { account_id: row.account_id, month: m }, { reported: row.units }).catch(() => {}); continue; }
          out.failed.push({ account: String(row.account_id).slice(0, 8), error: e.message });
        }
      }
    }
    return out;
  }
  return { count, month, report };
}
