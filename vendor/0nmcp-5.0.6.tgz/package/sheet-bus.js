/**
 * THE SHEET BUS — the canvas chat's record + history, in the person's OWN cloud spreadsheet.
 *
 *   createSheetBus({ provider: 'google' | 'microsoft', token, fetchImpl })
 *     .create(title, { shareWith })   → { provider, id, url, ... }   a new spreadsheet with tabs Requests | Replies | History
 *     .append(sheet, tab, rows)       → appends rows to one tab
 *
 * Google: Sheets API v4 (spreadsheets.create + values.append, valueInputOption RAW).
 * Microsoft: a workbook uploaded to the person's OneDrive at /0n3/<title>.xlsx (the bytes are built here, below), one
 * Excel table per tab, rows appended with tables/{id}/rows/add on Microsoft Graph.
 *
 * Credentials come from the person's vault through the same seam api_call uses: the resolver hands the record,
 * tokens.js freshCredentials mints the live access token. Nothing here stores a token.
 *
 * SheetMirror sits on top: it turns desk events (request, note, question, reply) into rows, coalesces bursts of notes
 * (at most one write per run every ~3 s; a request, a question and the final reply flush at once), and NEVER throws —
 * a mirror failure is logged loudly as [SHEET MIRROR FAILED] with the provider's own words and kept on the board.
 */
import { freshCredentials } from './tokens.js';

export const TABS = {
  Requests: ['Time', 'Run', 'Board', 'From', 'Message', 'Status'],
  Replies: ['Time', 'Run', 'Kind', 'Text'],
  History: ['Time', 'Run', 'Role', 'Text'],
};
export const PROVIDERS = ['google', 'microsoft'];
/** The vault records each provider may authenticate through, most specific first (google_sheets → google; onedrive → microsoft). */
export const CANDIDATES = { google: ['google_sheets', 'google_drive', 'google'], microsoft: ['onedrive', 'microsoft'] };
const CELL_MAX = { google: 45000, microsoft: 30000 };
const sheetTitle = (t) => `0n3 · ${String(t || 'Untitled board').slice(0, 90)}`;

async function speak(r, what) {
  const t = await r.text(); let j = null; try { j = JSON.parse(t); } catch { /* not json */ }
  if (!r.ok) {
    const words = j?.error?.message || j?.error_description || (typeof j?.error === 'string' ? j.error : '') || t.slice(0, 300) || `HTTP ${r.status}`;
    throw Object.assign(new Error(`${what} → ${r.status}: ${words}`), { status: r.status });
  }
  return j || {};
}

/**
 * A live token for the provider from the person's vault: tries every candidate record (an account can hold several
 * google records, some of them config-only) and returns the first that mints. Throws with the last provider's words.
 */
export async function vaultToken(resolver, provider, { fetchImpl = fetch } = {}) {
  const cands = CANDIDATES[provider]; if (!cands) throw new Error(`Unknown sheet provider ${provider}. Use google or microsoft.`);
  const list = await resolver.list();
  // Best record first: one whose granted scopes cover spreadsheets, then one that can mint (refresh token / service account),
  // a pasted short-lived access token last. Measured on Mike's vault 2026-10-31: four google records, one of them
  // Apps-Script-only and one search-console-only, so "the first google record" would have been the wrong one.
  const recs = cands.flatMap((svc) => list.filter((r) => r.service === svc).map((r) => ({ svc, label: r.$0n?.name, rank: rankRecord(provider, r) }))).sort((a, b) => a.rank - b.rank);
  if (!recs.length) throw new Error(provider === 'google' ? 'Google is not connected for this account. Connect Google (Sheets) at 0n3.app/connect.' : 'Microsoft is not connected for this account. Connect Microsoft (OneDrive) at 0n3.app/connect.');
  let last = null;
  for (const { svc, label } of recs) {
    try {
      const env = await resolver.get(svc, label); const c = env?.auth?.credentials; if (!c) continue;
      const creds = await freshCredentials(svc, c, { fetchImpl });
      if (creds.access_token) return { access_token: creds.access_token, creds, service: svc, label: label || null, meta: env.meta || {} };
    } catch (e) { last = e; }
  }
  throw new Error(last ? last.message : `None of this account's ${provider} records can mint a token (they hold no refresh token or service-account key).`);
}

const SHEET_SCOPES = { google: [/\/auth\/spreadsheets$/, /\/auth\/drive$/], microsoft: [/Files\.ReadWrite/i] };
export function rankRecord(provider, r) {
  const keys = r.auth?.credentialKeys || []; const scopes = [].concat(r.meta?.scopes || r.meta?.scope || []).join(' ').split(/\s+/).filter(Boolean);
  const mint = keys.includes('refresh_token') || keys.includes('private_key') || keys.includes('client_secret');
  const scoped = scopes.length ? (scopes.some((x) => SHEET_SCOPES[provider].some((re) => re.test(x))) ? 0 : 20) : 10;
  return scoped + (mint ? 0 : 5);
}

// ── google ──────────────────────────────────────────────────────────────────
const SHEETS = 'https://sheets.googleapis.com/v4/spreadsheets';
const googleAdapter = ({ fetchImpl, token }) => ({
  async create(title, { shareWith } = {}) {
    const t = await token(); const H = { Authorization: `Bearer ${t.access_token}`, 'Content-Type': 'application/json' };
    const body = {
      properties: { title: sheetTitle(title) },
      sheets: Object.entries(TABS).map(([name, header], i) => ({ properties: { title: name, index: i, gridProperties: { frozenRowCount: 1 } }, data: [{ startRow: 0, startColumn: 0, rowData: [{ values: header.map((h) => ({ userEnteredValue: { stringValue: h } })) }] }] })),
    };
    const d = await speak(await fetchImpl(SHEETS, { method: 'POST', headers: H, body: JSON.stringify(body) }), 'Google Sheets create');
    const out = { provider: 'google', id: d.spreadsheetId, url: d.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${d.spreadsheetId}/edit` };
    // A service account owns what it creates; share it with the person so the record is in THEIR Drive view.
    if (t.creds?.type === 'service_account' && shareWith) {
      try { await speak(await fetchImpl(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(out.id)}/permissions?sendNotificationEmail=false`, { method: 'POST', headers: H, body: JSON.stringify({ role: 'writer', type: 'user', emailAddress: shareWith }) }), 'Google Drive share'); out.sharedWith = shareWith; }
      catch (e) { out.shareError = e.message; console.error('[SHEET MIRROR FAILED]', e.message); }
    }
    return out;
  },
  async append(sheet, tab, rows) {
    const t = await token();
    const range = encodeURIComponent(`${tab}!A1`);
    return speak(await fetchImpl(`${SHEETS}/${encodeURIComponent(sheet.id)}/values/${range}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`, { method: 'POST', headers: { Authorization: `Bearer ${t.access_token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ values: rows }) }), `Google Sheets append ${tab}`);
  },
});

// ── microsoft ───────────────────────────────────────────────────────────────
const GRAPH = 'https://graph.microsoft.com/v1.0';
/** /me/drive for a delegated (refresh-token) record; /users/{u}/drive for an app registration that names a user. */
export function driveBase(creds = {}, meta = {}) {
  if (creds.refresh_token || (!creds.client_secret && creds.access_token)) return `${GRAPH}/me/drive`;
  const user = creds.user_id || creds.user_principal_name || creds.upn || creds.user || meta.user_id || meta.user_principal_name || meta.email;
  if (user) return `${GRAPH}/users/${encodeURIComponent(user)}/drive`;
  throw new Error('This Microsoft connection is an app registration with no user, so it has no OneDrive of its own. Connect Microsoft with your own sign-in (delegated), or add user_principal_name to the record.');
}
const XLSX_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const colLetter = (n) => String.fromCharCode(64 + n);
const microsoftAdapter = ({ fetchImpl, token }) => ({
  async create(title) {
    const t = await token(); const drive = driveBase(t.creds, t.meta); const auth = { Authorization: `Bearer ${t.access_token}` };
    const name = `${String(title || 'Untitled board').replace(/[\\/:*?"<>|#%]/g, '-').slice(0, 100)}.xlsx`;
    const up = await speak(await fetchImpl(`${drive}/root:/0n3/${encodeURIComponent(name)}:/content?@microsoft.graph.conflictBehavior=rename`, { method: 'PUT', headers: { ...auth, 'Content-Type': XLSX_TYPE }, body: buildXlsx(Object.entries(TABS).map(([n, header]) => ({ name: n, header }))) }), 'OneDrive upload');
    const tables = {};
    for (const [tab, header] of Object.entries(TABS)) {
      const tb = await speak(await fetchImpl(`${drive}/items/${encodeURIComponent(up.id)}/workbook/tables/add`, { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json' }, body: JSON.stringify({ address: `${tab}!A1:${colLetter(header.length)}1`, hasHeaders: true }) }), `Excel table ${tab}`);
      tables[tab] = tb.id || tb.name;
    }
    return { provider: 'microsoft', id: up.id, url: up.webUrl, drive, tables, path: `/0n3/${up.name || name}` };
  },
  async append(sheet, tab, rows) {
    const t = await token(); const drive = sheet.drive || driveBase(t.creds, t.meta);
    const table = sheet.tables?.[tab]; if (!table) throw new Error(`The workbook has no table for ${tab}. Re-link the sheet.`);
    return speak(await fetchImpl(`${drive}/items/${encodeURIComponent(sheet.id)}/workbook/tables/${encodeURIComponent(table)}/rows/add`, { method: 'POST', headers: { Authorization: `Bearer ${t.access_token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ values: rows }) }), `Excel rows ${tab}`);
  },
});

/** One interface, two adapters. `token` is an async () → { access_token, creds, meta } (vaultToken bound to a resolver). */
export function createSheetBus({ provider, token, fetchImpl = fetch }) {
  const make = { google: googleAdapter, microsoft: microsoftAdapter }[provider];
  if (!make) throw new Error(`Unknown sheet provider ${provider}. Use google or microsoft.`);
  if (typeof token !== 'function') throw new Error('createSheetBus needs a token function');
  let cached = null; const once = async () => (cached ||= await token());
  const a = make({ fetchImpl, token: once });
  const max = CELL_MAX[provider];
  const fit = (rows) => rows.map((r) => r.map((v) => (v === null || v === undefined ? '' : String(v).slice(0, max))));
  return { provider, create: (title, o) => a.create(title, o), append: (sheet, tab, rows) => a.append(sheet, tab, fit(rows)) };
}

// ── the mirror ──────────────────────────────────────────────────────────────
export const FLUSH_MS = 3000;
const PENDING_MAX = 300;
const ROLE = { request: 'request', note: 'agent', question: 'question', answer: 'answer', reply: 'reply' };
/** Desk events → rows, grouped by tab. */
export function rowsFor(events, boardId) {
  const out = { Requests: [], Replies: [], History: [] };
  for (const e of events) {
    if (e.kind === 'request') out.Requests.push([e.at, e.runId, boardId, e.from || '', e.text, e.status || 'queued']);
    else if (e.kind === 'note' || e.kind === 'question' || e.kind === 'reply') out.Replies.push([e.at, e.runId, e.kind, e.text]);
    out.History.push([e.at, e.runId, ROLE[e.kind] || e.kind, e.text]);
  }
  return out;
}

export class SheetMirror {
  /** @param {{ canvas: import('./canvas.js').CanvasStore, busFor: (accountId: string, provider: string) => any, now?: () => number, flushMs?: number }} o */
  constructor({ canvas, busFor, now = Date.now, flushMs = FLUSH_MS }) { this.canvas = canvas; this.busFor = busFor; this.now = now; this.flushMs = flushMs; }

  /** Record one event on the run's board. `final` flushes now; a note waits until the run's last write is flushMs old. Never throws. */
  async event(accountId, run, { kind, text, from, status }, { final = false } = {}) {
    try {
      const boardId = run?.source?.boardId; if (run?.source?.kind !== 'canvas' || !boardId) return { skipped: 'not a canvas run' };
      const row = await this.canvas.row(accountId, boardId); const sheet = row?.sheet;
      if (!sheet?.id) return { skipped: 'no sheet linked' };
      const ev = { at: new Date(this.now()).toISOString(), runId: run.id, kind, text: String(text ?? ''), ...(from ? { from } : {}), ...(status ? { status } : {}) };
      const pending = [...(sheet.pending || []), ev].slice(-PENDING_MAX);
      const last = Number(sheet.flushed?.[run.id] || 0);
      if (!final && this.now() - last < this.flushMs) { await this.canvas.setSheet(accountId, boardId, { ...sheet, pending }); return { buffered: pending.length }; }
      return await this.flush(accountId, boardId, { ...sheet, pending }, run.id);
    } catch (e) { console.error('[SHEET MIRROR FAILED]', e.message); return { ok: false, error: e.message }; }
  }

  async flush(accountId, boardId, sheet, runId) {
    const events = sheet.pending || [];
    const flushed = Object.fromEntries(Object.entries({ ...(sheet.flushed || {}), [runId]: this.now() }).slice(-50));
    try {
      const bus = await this.busFor(accountId, sheet.provider);
      const byTab = rowsFor(events, boardId);
      for (const tab of ['Requests', 'Replies', 'History']) if (byTab[tab].length) await bus.append(sheet, tab, byTab[tab]);
      await this.canvas.setSheet(accountId, boardId, { ...sheet, pending: [], flushed, last_ok_at: new Date(this.now()).toISOString() });
      return { ok: true, wrote: events.length };
    } catch (e) {
      console.error(`[SHEET MIRROR FAILED] ${sheet.provider} board ${boardId}: ${e.message}`);
      // Keep the rows: the next event retries them. The error is on the board for the UI to show.
      await this.canvas.setSheet(accountId, boardId, { ...sheet, flushed, last_error: e.message, last_error_at: new Date(this.now()).toISOString() }).catch(() => {});
      return { ok: false, error: e.message };
    }
  }
}

/** Await a mirror promise, but never longer than `ms` — the response must not wait on a slow spreadsheet. */
export const within = (p, ms = 4000) => Promise.race([Promise.resolve(p).catch((e) => ({ ok: false, error: e.message })), new Promise((r) => setTimeout(() => r({ ok: false, error: `still writing after ${ms} ms` }), ms).unref?.())]);

// ── a minimal valid .xlsx, built in code ────────────────────────────────────
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
export function crc32(buf) { let c = 0xffffffff; for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
/** A STORE-method zip: no compression, so nothing beyond CRC-32 is needed. */
export function zip(files) {
  const locals = []; const centrals = []; let offset = 0;
  for (const { name, data } of files) {
    const n = Buffer.from(name, 'utf8'); const d = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8'); const crc = crc32(d);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0, 6); lh.writeUInt16LE(0, 8); lh.writeUInt16LE(0, 10); lh.writeUInt16LE(0x21, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(d.length, 18); lh.writeUInt32LE(d.length, 22); lh.writeUInt16LE(n.length, 26); lh.writeUInt16LE(0, 28);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0, 8); ch.writeUInt16LE(0, 10); ch.writeUInt16LE(0, 12); ch.writeUInt16LE(0x21, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(d.length, 20); ch.writeUInt32LE(d.length, 24); ch.writeUInt16LE(n.length, 28); ch.writeUInt16LE(0, 30); ch.writeUInt16LE(0, 32); ch.writeUInt16LE(0, 34); ch.writeUInt16LE(0, 36); ch.writeUInt32LE(0, 38); ch.writeUInt32LE(offset, 42);
    locals.push(lh, n, d); centrals.push(ch, n); offset += 30 + n.length + d.length;
  }
  const cd = Buffer.concat(centrals);
  const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(0, 4); end.writeUInt16LE(0, 6); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16); end.writeUInt16LE(0, 20);
  return Buffer.concat([...locals, cd, end]);
}
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const X = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
const NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
/** The smallest workbook Excel opens cleanly: one worksheet per tab, a header row of inline strings, a default style. */
export function buildXlsx(sheets) {
  const ct = `${X}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`;
  const rels = `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="${REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
  const wb = `${X}<workbook xmlns="${NS}" xmlns:r="${REL}"><sheets>${sheets.map((s, i) => `<sheet name="${esc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`;
  const wbRels = `${X}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="${REL}/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="${REL}/styles" Target="styles.xml"/></Relationships>`;
  const styles = `${X}<styleSheet xmlns="${NS}"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const ws = (header = []) => `${X}<worksheet xmlns="${NS}"><sheetData>${header.length ? `<row r="1">${header.map((h, i) => `<c r="${colLetter(i + 1)}1" t="inlineStr"><is><t>${esc(h)}</t></is></c>`).join('')}</row>` : ''}</sheetData></worksheet>`;
  return zip([
    { name: '[Content_Types].xml', data: ct }, { name: '_rels/.rels', data: rels }, { name: 'xl/workbook.xml', data: wb },
    { name: 'xl/_rels/workbook.xml.rels', data: wbRels }, { name: 'xl/styles.xml', data: styles },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: ws(s.header) })),
  ]);
}
