/**
 * WHERE THE KEY LIVES — the AI providers in catalog-ai.js (2026-11-23). Same shape as GUIDES in connect-guides.js, which
 * merges these in, and written the plain way (4th–5th grade, one action per step, the last step is pasting).
 *
 * `unverified: true` = the provider's docs name the place but we could not confirm the exact page or button labels.
 * `pattern` only where the provider documents its key prefix; nothing is guessed.
 */

// Shared with the My AI page: these providers can also be one of the person's AIs there.
export const MY_AI = 'Once added, it joins your list on My AI. 0n3 uses it to think through your jobs, and if it runs out of turns, the next AI on your list takes over.';
const CHAT = (who) => `Once ${who} is connected, your AI can chat with ${who}'s models and list them.`;
const MASTER = (who) => `${who} is a "master" AI: one key reaches many AI models from many companies. Once it is connected, your AI can chat with any of them and list them.`;
const FULL = ['The key works for the whole account. There is nothing to tick.'];
const PASTE = 'Come back here and paste it in the box below.';
const ONCE = 'Copy it now, because you only see it once.';
const KEY = { apiKey: { label: 'API key' } };

export const AI_PROVIDER_GUIDES = {
  // ── frontier labs ──────────────────────────────────────────────────────────
  anthropic: {
    url: 'https://platform.claude.com/settings/keys', where: 'Claude Console → Settings → API Keys', looks: 'sk-ant-…',
    what: 'Once Claude is connected, your AI can talk to Claude, count words (tokens) and list Claude models. ' + MY_AI,
    steps: ['Go to platform.claude.com and sign in.', 'Click Settings. Then click API Keys.', 'Click Create Key. Name it 0n3.', `A long code that starts with sk-ant shows up. That is your key. ${ONCE}`, PASTE],
    note: 'Claude keys cost a little money each time they are used. Add some credit under Billing first, or the key will not work.',
    scopes: FULL, fields: { apiKey: { label: 'Claude key' } }, pattern: 'sk-ant-[A-Za-z0-9_-]{20,}',
  },
  gemini: {
    url: 'https://aistudio.google.com/apikey', where: 'Google AI Studio → Get API key', looks: 'AIza + 35 characters',
    what: 'Once Gemini is connected, your AI can ask Gemini, make embeddings (number codes for text) and list Gemini models. ' + MY_AI,
    steps: ['Go to aistudio.google.com/apikey.', 'Sign in with your Google account.', 'Click Create API key. If it asks for a project, pick any one.', 'A code that starts with AIza shows up. That is your key. Copy it.', PASTE],
    note: 'Gemini is free to start. The free plan has a limit each day. When you hit it, 0n3 moves on to your next AI.',
    scopes: FULL, fields: { apiKey: { label: 'Gemini key' } }, pattern: 'AIza[0-9A-Za-z_-]{35}',
  },
  xai: {
    url: 'https://console.x.ai/team/default/api-keys', where: 'xAI Console → API Keys', looks: 'a long code',
    what: "Once xAI is connected, your AI can chat with Grok, make pictures with Grok Imagine, and list xAI's models.",
    steps: ['Go to console.x.ai and sign in.', 'Click API Keys.', 'Click Create API Key. Name it 0n3 and click Save.', `A key shows up. ${ONCE}`, PASTE],
    note: 'This is the Grok API. Grok Bot routines are a different app on 0n3.',
    scopes: ['Leave every endpoint and model allowed (the default).'], fields: KEY,
  },
  deepseek: {
    url: 'https://platform.deepseek.com/api_keys', where: 'DeepSeek Platform → API keys', looks: 'sk-…',
    what: CHAT('DeepSeek'),
    steps: ['Go to platform.deepseek.com/api_keys and sign in.', 'Click Create new API key. Name it 0n3.', `A key that starts with sk- shows up. ${ONCE}`, PASTE],
    note: 'DeepSeek needs a little credit on the account (Top up) before the key works.',
    scopes: FULL, fields: KEY,
  },
  ai21: {
    url: 'https://studio.ai21.com/', where: 'AI21 Studio → Settings (bottom left) → API Keys', looks: 'a long code', unverified: true,
    what: CHAT('AI21 (Jamba)'),
    steps: ['Go to studio.ai21.com and sign in.', 'Click Settings at the bottom left. Then click API Keys.', 'Click Create new key. Copy it.', PASTE],
    scopes: FULL, fields: KEY,
  },
  reka: {
    url: 'https://developer.reka.ai/keys', where: 'Reka Platform → API Keys', looks: 'a long code', unverified: true,
    what: CHAT('Reka'),
    steps: ['Go to developer.reka.ai/keys and sign in.', 'Click the button to make a new key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  moonshot: {
    url: 'https://platform.kimi.ai/console/api-keys', where: 'Kimi Platform → Console → API Keys', looks: 'a long code', unverified: true,
    what: CHAT('Kimi (Moonshot AI)'),
    steps: ['Go to platform.kimi.ai/console/api-keys and sign in.', 'Click Create API Key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    note: 'This is the international Kimi platform (api.moonshot.ai). A key from the China site will not work here.',
    scopes: FULL, fields: KEY,
  },
  zai: {
    url: 'https://z.ai/manage-apikey/apikey-list', where: 'Z.ai → API Keys', looks: 'a long code', unverified: true,
    what: "Once Z.ai is connected, your AI can chat with GLM models, make pictures and list Z.ai's models.",
    steps: ['Go to z.ai/manage-apikey/apikey-list and sign in.', 'Click Create a new API key. Name it 0n3.', 'Copy the key.', PASTE],
    note: 'This is the international Z.ai platform. A key from the China site (bigmodel.cn) will not work here.',
    scopes: FULL, fields: KEY,
  },
  qwen: {
    url: 'https://modelstudio.console.alibabacloud.com/model/settings/api-key', where: 'Alibaba Cloud Model Studio → API Key (Singapore region)', looks: 'sk-…',
    what: 'Once Qwen is connected, your AI can chat with Qwen models, make embeddings (number codes for text) and list the models.',
    steps: ['Go to the Model Studio API Key page and sign in to Alibaba Cloud.', 'Make sure the region at the top says Singapore.', 'Click Create API Key. Copy it.', 'Optional: copy your Workspace ID from the same page. It moves you to Alibaba\'s newer address.', 'Come back here. Paste the key (and the Workspace ID if you have it) below.'],
    note: 'Keys only work in the region they were made in. 0n3 talks to the international (Singapore) region.',
    scopes: FULL, fields: { apiKey: { label: 'API key' }, workspaceId: { label: 'Workspace ID (optional)', where: 'Model Studio → the workspace you use' } },
  },
  minimax: {
    url: 'https://platform.minimax.io/user-center/basic-information/interface-key', where: 'MiniMax Platform → Account → API Keys', looks: 'a long code',
    what: CHAT('MiniMax'),
    steps: ['Go to platform.minimax.io and sign in.', 'Open Account, then API Keys.', `Click Create new secret key. Name it 0n3. ${ONCE}`, PASTE],
    note: 'This is the international platform (api.minimax.io). An M Plan subscription key lives under Billing → M Plan instead.',
    scopes: FULL, fields: KEY,
  },
  perplexity: {
    url: 'https://console.perplexity.ai/project/keys', where: 'Perplexity API console → API Keys', looks: 'pplx-…', unverified: true,
    what: 'Once Perplexity is connected, your AI can ask questions that Perplexity answers by searching the web, with links to where it found each fact.',
    steps: ['Go to console.perplexity.ai and sign in.', 'Open API Keys.', `Click Create Key. ${ONCE}`, PASTE],
    note: 'Perplexity needs credit on the account before the key works.',
    scopes: FULL, fields: KEY,
  },

  // ── master APIs (aggregators) ──────────────────────────────────────────────
  openrouter: {
    url: 'https://openrouter.ai/settings/keys', where: 'OpenRouter → Settings → Keys', looks: 'sk-or-v1- + 64 hex',
    what: MASTER('OpenRouter') + ' ' + MY_AI,
    steps: ['Go to openrouter.ai and sign in. It is free to start.', 'Go to openrouter.ai/settings/keys.', 'Click the button to create a key. Name it 0n3.', `A code that starts with sk-or shows up. That is your key. ${ONCE}`, PASTE],
    note: 'OpenRouter has many free models. 0n3 uses a free one, so you do not need to add money. Free models have a limit each day.',
    scopes: ['Leave the credit limit empty, or set one to cap spending.'], fields: { apiKey: { label: 'OpenRouter key' } }, pattern: 'sk-or-v1-[a-f0-9]{64}',
  },
  requesty: {
    url: 'https://app.requesty.ai/api-keys', where: 'Requesty → API Keys', looks: 'sk-…',
    what: MASTER('Requesty'),
    steps: ['Go to app.requesty.ai/api-keys and sign in.', 'Click Create API Key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  eden_ai: {
    url: 'https://app.edenai.run/', where: 'Eden AI app → API Keys', looks: 'a long code', unverified: true,
    what: MASTER('Eden AI'),
    steps: ['Go to app.edenai.run and sign in.', 'Open API Keys.', 'Copy your key, or make a new one.', PASTE],
    scopes: FULL, fields: KEY,
  },
  aimlapi: {
    url: 'https://aimlapi.com/app/keys', where: 'AI/ML API → Key Management', looks: 'a long code',
    what: MASTER('AI/ML API'),
    steps: ['Go to aimlapi.com/app/keys and sign in.', 'Click Create API Key.', 'Copy the key.', PASTE],
    scopes: FULL, fields: KEY,
  },
  vercel_ai_gateway: {
    url: 'https://vercel.com/d?to=/[team]/~/ai-gateway/api-keys', where: 'Vercel dashboard → AI Gateway → API Keys', looks: 'a long code',
    what: MASTER('Vercel AI Gateway'),
    steps: ['Sign in to vercel.com and open your team.', 'Click AI Gateway. Then click API Keys.', `Click Create API Key. Name it 0n3. ${ONCE}`, PASTE],
    note: 'This is not your Vercel account token. The Vercel app on 0n3 uses that one; the AI Gateway has its own key.',
    scopes: ['An AI Gateway key covers every model on the gateway; there is nothing to tick.'], fields: KEY,
  },
  cloudflare_ai_gateway: {
    url: 'https://dash.cloudflare.com/?to=/:account/ai/ai-gateway', where: 'Cloudflare dashboard → AI → AI Gateway → your gateway → Settings', looks: 'a token + a 32-letter account ID + a gateway name', unverified: true,
    what: MASTER('Cloudflare AI Gateway') + ' The provider keys are kept inside your gateway.',
    steps: ['Sign in to dash.cloudflare.com. Open AI, then AI Gateway.', 'Make a gateway (or use "default"). Turn on Authenticated Gateway and create a token.', 'Under Provider Keys, add the AI companies you want to use.', 'Copy the token, your Account ID and the gateway name.', 'Come back here and paste all three in the boxes below.'],
    note: 'Just want Cloudflare\'s own models? Use the Cloudflare app on 0n3 — it runs Workers AI with your normal Cloudflare token.',
    scopes: ['Authenticated Gateway on, with keys stored for each provider you call.'],
    fields: { apiToken: { label: 'Gateway token' }, accountId: { label: 'Account ID', where: 'any domain → Overview → API section, or the 32-hex id in the dashboard URL' }, gatewayId: { label: 'Gateway name', where: 'AI Gateway list (default is "default")' } },
  },
  portkey: {
    url: 'https://app.portkey.ai/api-keys', where: 'Portkey → API Keys', looks: 'a long code',
    what: MASTER('Portkey') + ' Pick the model as @your-provider/model from your Portkey Model Catalog.',
    steps: ['Go to app.portkey.ai and sign in.', 'In Model Catalog, add the AI companies you want (each gets a name like @openai).', `Open API Keys. Click Create. ${ONCE}`, PASTE],
    scopes: ['Give the key access to the providers in your Model Catalog.'], fields: KEY,
  },
  litellm: {
    url: 'https://docs.litellm.ai/docs/proxy/virtual_keys', where: 'Your own LiteLLM proxy → admin UI → Virtual Keys', looks: 'sk-… plus your proxy address',
    what: MASTER('Your LiteLLM proxy'),
    steps: ['Open the admin page of your own LiteLLM proxy.', 'Click Virtual Keys. Then click Create New Key. Name it 0n3.', 'Copy the key.', 'Copy your proxy\'s web address. It must start with https://.', 'Come back here. Paste the key and the address below.'],
    note: 'The proxy must be reachable on the internet over https. One on your own computer (localhost) cannot be reached by 0n3.',
    scopes: ['Allow the key to use the models you want 0n3 to call.'],
    fields: { apiKey: { label: 'Virtual or master key' }, baseUrl: { label: 'Proxy address', where: 'like https://litellm.example.com' } },
  },
  huggingface: {
    url: 'https://huggingface.co/settings/tokens/new?ownUserPermissions=inference.serverless.write&tokenType=fineGrained', where: 'Hugging Face → Settings → Access Tokens → Create new token (Fine-grained)', looks: 'hf_…',
    what: MASTER('Hugging Face'),
    steps: ['Open the link. Sign in to Hugging Face.', 'Name the token 0n3.', 'Make sure "Make calls to Inference Providers" is ticked.', `Click Create token. ${ONCE}`, PASTE],
    scopes: ['Inference → Make calls to Inference Providers'], fields: { apiKey: { label: 'Access token' } },
  },

  // ── fast inference hosts ───────────────────────────────────────────────────
  together_ai: {
    url: 'https://api.together.ai/settings/projects/~current/api-keys', where: 'Together → Settings → Projects → API keys', looks: 'a long code',
    what: "Once Together AI is connected, your AI can chat with hundreds of open models, make pictures and list Together's models.",
    steps: ['Go to the Together API keys page and sign in.', 'Click Create API key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  fireworks_ai: {
    url: 'https://app.fireworks.ai/settings/users/api-keys', where: 'Fireworks → Settings → API Keys', looks: 'fw_…',
    what: 'Once Fireworks is connected, your AI can chat with fast open models, make embeddings (number codes for text) and list models.',
    steps: ['Go to app.fireworks.ai/settings/users/api-keys and sign in.', 'Click Create API key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  deepinfra: {
    url: 'https://deepinfra.com/dash/keys', where: 'DeepInfra dashboard → API Keys', looks: 'a long code',
    what: 'Once DeepInfra is connected, your AI can chat with low-cost open models, make embeddings (number codes for text) and list models.',
    steps: ['Go to deepinfra.com/dash/keys and sign in.', 'Click New API Key. Name it 0n3.', 'Copy the key.', PASTE],
    scopes: ['A scoped key needs models:read for the model list.'], fields: KEY,
  },
  sambanova: {
    url: 'https://cloud.sambanova.ai/apis', where: 'SambaNova Cloud → APIs', looks: 'a long code',
    what: 'Once SambaNova is connected, your AI can chat with very fast models, make embeddings (number codes for text) and list models.',
    steps: ['Go to cloud.sambanova.ai/apis and sign in.', 'Click Create API Key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  hyperbolic: {
    url: 'https://app.hyperbolic.ai/settings/api-keys', where: 'Hyperbolic → Settings → API Keys', looks: 'sk_live_…',
    what: CHAT('Hyperbolic').replace(' and list them', ''),
    steps: ['Go to app.hyperbolic.ai/settings/api-keys and sign in.', 'Click Create API Key. Name it 0n3.', `A key that starts with sk_live_ shows up. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY, pattern: 'sk_live_[A-Za-z0-9_-]{16,}',
  },
  novita: {
    url: 'https://novita.ai/settings/key-management', where: 'Novita → Settings → Key Management', looks: 'sk_…',
    what: CHAT('Novita').replace(' and list them', ''),
    steps: ['Go to novita.ai/settings/key-management and sign in.', 'Click Create API Key. Name it 0n3.', `A key that starts with sk_ shows up. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  nebius: {
    url: 'https://tokenfactory.nebius.com/project/api-keys', where: 'Nebius Token Factory → API keys', looks: 'a long code',
    what: CHAT('Nebius').replace(' and list them', ''),
    steps: ['Go to tokenfactory.nebius.com/project/api-keys and sign in.', 'Click Create API key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  baseten: {
    url: 'https://app.baseten.co/settings/api_keys', where: 'Baseten → Settings → API keys', looks: 'b10_… (older keys have no prefix)',
    what: CHAT('Baseten'),
    steps: ['Go to app.baseten.co/settings/api_keys and sign in.', 'Click Create API key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  cerebras: {
    url: 'https://cloud.cerebras.ai', where: 'Cerebras Cloud → API Keys', looks: 'csk-…',
    what: 'Once Cerebras is connected, your AI can chat with very fast models and list them. ' + MY_AI,
    steps: ['Go to cloud.cerebras.ai and sign up with your email. It is free.', 'In the menu on the left, click API Keys.', 'Click the button to make a new key. Name it 0n3.', 'A code that starts with csk- shows up. That is your key. Copy it.', PASTE],
    note: 'Cerebras is very fast and free to start, with a limit each day.',
    scopes: FULL, fields: { apiKey: { label: 'Cerebras key' } }, pattern: 'csk-[A-Za-z0-9]{20,}',
  },
  nvidia: {
    url: 'https://build.nvidia.com/settings', where: 'build.nvidia.com → Settings → API Keys', looks: 'nvapi-…',
    what: 'Once NVIDIA is connected, your AI can chat with the models NVIDIA hosts and list them. ' + MY_AI,
    steps: ['Go to build.nvidia.com and sign in. It is free to start.', 'Click Settings, then API Keys.', 'Click the button to make a new key.', 'A code that starts with nvapi- shows up. That is your key. Copy it.', PASTE],
    note: 'NVIDIA gives free credits to start. When they run out, 0n3 moves on to your next AI.',
    scopes: FULL, fields: { apiKey: { label: 'NVIDIA key' } }, pattern: 'nvapi-[A-Za-z0-9_-]{20,}',
  },
  azure_openai: {
    url: 'https://portal.azure.com/#browse/Microsoft.CognitiveServices%2Faccounts', where: 'Azure portal → your Azure OpenAI resource → Keys and Endpoint', looks: 'a long code + your resource name', unverified: true,
    what: 'Once Azure OpenAI is connected, your AI can chat, make embeddings (number codes for text) and use the Responses API with the models you deployed in your own Azure resource.',
    steps: ['Sign in to portal.azure.com and open your Azure OpenAI resource.', 'Click Keys and Endpoint.', 'Copy KEY 1.', 'Look at the Endpoint, like https://NAME.openai.azure.com. The NAME part is your resource name.', 'Come back here. Paste the key and the resource name below.'],
    note: 'For the model, type your DEPLOYMENT name (the name you gave the model when you deployed it).',
    scopes: ['Any of the two resource keys works; they carry the resource\'s full access.'],
    fields: { apiKey: { label: 'Key 1' }, resource: { label: 'Resource name', where: 'the NAME in https://NAME.openai.azure.com' } },
  },

  // ── media, voice, embeddings ───────────────────────────────────────────────
  fal_ai: {
    url: 'https://fal.ai/dashboard/keys', where: 'fal dashboard → Keys', looks: 'a long code',
    what: 'fal is a "master" app for pictures, video and sound: one key runs hundreds of media AI models. Once it is connected, your AI can start a run, check on it and get the result.',
    steps: ['Go to fal.ai/dashboard/keys and sign in.', 'Click Add key. Name it 0n3. Pick the API scope.', `Copy the key. ${ONCE}`, PASTE],
    scopes: ['Key scope: API'], fields: KEY,
  },
  runway: {
    url: 'https://dev.runway.com/', where: 'Runway developer portal → your project → API Keys', looks: 'key_…',
    what: 'Once Runway is connected, your AI can turn a picture into a video, make pictures from words, and check on each job.',
    steps: ['Go to dev.runway.com and sign in.', 'Make a project, or open yours.', 'Click the API Keys tab. Click Create new key.', `A key that starts with key_ shows up. ${ONCE}`, PASTE],
    note: 'You need the Admin or Developer role in the Runway organization, and credits on it.',
    scopes: FULL, fields: KEY, pattern: 'key_[A-Za-z0-9]{20,}',
  },
  luma: {
    url: 'https://platform.lumalabs.ai/', where: 'Luma API platform → API Keys', looks: 'a long code', unverified: true,
    what: 'Once Luma is connected, your AI can make videos from words or pictures and check on each one.',
    steps: ['Go to platform.lumalabs.ai and sign in.', 'Open API Keys. Click Create.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  ideogram: {
    url: 'https://ideogram.ai/platform', where: 'Ideogram → your avatar → API → Settings → API keys', looks: 'a long code',
    what: 'Once Ideogram is connected, your AI can make pictures from words, and it is good at getting words inside pictures right (logos, posters).',
    steps: ['Go to ideogram.ai/platform and sign in.', 'Click your picture (avatar), then API. Add a payment method if it asks.', `Click Create API key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  leonardo: {
    url: 'https://app.leonardo.ai/api-access', where: 'Leonardo → API Access', looks: 'a long code (a UUID)',
    what: 'Once Leonardo is connected, your AI can make pictures from words, check on each one and list the models.',
    steps: ['Go to app.leonardo.ai/api-access and sign in.', 'Buy some API credits if you have none. The key does not work without them.', `Click Create New Key. Name it 0n3. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  bfl: {
    url: 'https://dashboard.bfl.ai', where: 'BFL dashboard → your project → API → Keys', looks: 'a long code', unverified: true,
    what: 'Once Black Forest Labs is connected, your AI can make pictures with FLUX, from the people who made FLUX.',
    steps: ['Go to dashboard.bfl.ai and sign in.', 'Open your project. Click API, then Keys.', `Click Add key. ${ONCE}`, PASTE],
    note: 'A new picture is ready a few seconds later at the polling_url the first answer gives you.',
    scopes: FULL, fields: KEY,
  },
  assemblyai: {
    url: 'https://www.assemblyai.com/dashboard', where: 'AssemblyAI dashboard → API Keys', looks: 'a long code', unverified: true,
    what: 'Once AssemblyAI is connected, your AI can turn a recording at a web address into text, check on it, list and delete transcripts.',
    steps: ['Go to assemblyai.com/dashboard and sign in.', 'Open API Keys.', 'Copy your key.', PASTE],
    scopes: FULL, fields: KEY,
  },
  cartesia: {
    url: 'https://play.cartesia.ai/keys', where: 'Cartesia → API Keys', looks: 'sk_car_…',
    what: 'Once Cartesia is connected, your AI can turn text into spoken voice and list the voices.',
    steps: ['Go to play.cartesia.ai/keys and sign in.', 'Click New. Name the key 0n3.', `A key that starts with sk_car_ shows up. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY, pattern: 'sk_car_[A-Za-z0-9_-]{16,}',
  },
  voyage: {
    url: 'https://dashboard.voyageai.com/organization/api-keys', where: 'Voyage dashboard → Organization → API keys', looks: 'a long code', unverified: true,
    what: 'Once Voyage is connected, your AI can make embeddings (number codes for text, used for search) and sort documents by best match.',
    steps: ['Go to dashboard.voyageai.com/organization/api-keys and sign in.', 'Click Create new secret key. Name it 0n3.', `Copy the key. ${ONCE}`, PASTE],
    scopes: FULL, fields: KEY,
  },
  jina: {
    url: 'https://jina.ai/', where: 'jina.ai → API Key & Billing', looks: 'a long code', unverified: true,
    what: 'Once Jina is connected, your AI can make embeddings (number codes for text), sort documents by best match, and read any web page as clean text.',
    steps: ['Go to jina.ai and open any API page (Embeddings, Reader…).', 'Click the API Key & Billing tab. A free key is made for you.', 'Copy the key.', PASTE],
    scopes: ['One key works for every Jina API; there is nothing to tick.'], fields: KEY,
  },
};
