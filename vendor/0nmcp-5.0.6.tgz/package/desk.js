/**
 * THE DESK — runs that can wait for a person.
 *
 * Mike's loop, as a product (docs/AGENT-DESK.md): a request arrives (an email
 * to the desk's mailbox, a page form, a button) → the OWNER's desktop agent
 * picks it up → if it has a question it does NOT act, it asks → the question is
 * pushed to the owner's phone → the answer re-queues the run with the whole
 * thread → the agent resumes, finishes, and the receipt comes back.
 *
 *   desk_runs          one request; state queued → running → waiting → running → done | failed
 *   desk_questions     a question the agent asked; answered by a person on the phone
 *   push_subscriptions the phones (web push, VAPID) that get told
 *
 * The desktop agent is whatever the person installed (today: the mail poller on
 * Mike's Mac running Claude Code). It CLAIMS queued runs for its machine name,
 * posts notes, asks, and finishes. The server never pushes work to a machine;
 * the machine asks. Nothing here runs a model.
 */
import { randomBytes } from 'node:crypto';

export const TABLES = { runs: 'desk_runs', questions: 'desk_questions', push: 'push_subscriptions', machines: 'desk_machines' };
/** A machine counts as online when it polled inside this window (the agent polls every 30 s by default). */
export const ONLINE_MS = 90 * 1000;
export const STATES = ['queued', 'running', 'waiting', 'done', 'failed'];
const now = () => new Date().toISOString();
const clip = (s, n) => String(s ?? '').slice(0, n);

export class DeskStore {
  /** @param {{ rest: any, push?: { send: (sub: any, payload: any) => Promise<void> } | null }} o */
  constructor({ rest, push = null }) { if (!rest) throw new Error('DeskStore needs a rest seam'); this.rest = rest; this.push = push; }

  // ── machines (the heartbeat is the poll) ───────────────────────────────
  /** A desk agent checked in: on login (hello) and on every poll for work. */
  async seen(accountId, machine, { agent = null, version = null } = {}) {
    const m = clip(machine, 80).trim(); if (!m) return null;
    const prev = (await this.rest.select(TABLES.machines, { account_id: accountId, machine: m }))[0];
    const row = { account_id: accountId, machine: m, agent: agent ? clip(agent, 40) : (prev?.agent || null), version: version ? clip(version, 20) : (prev?.version || null), first_seen_at: prev?.first_seen_at || now(), last_seen_at: now() };
    await this.rest.upsert(TABLES.machines, row, 'account_id,machine');
    return shapeM(row);
  }
  async machines(accountId) {
    return (await this.rest.select(TABLES.machines, { account_id: accountId })).map(shapeM).sort((a, b) => String(b.lastSeenAt).localeCompare(String(a.lastSeenAt)));
  }

  // ── runs ───────────────────────────────────────────────────────────────
  async create(accountId, { workspaceId = null, project = null, machine = null, source = {}, request }) {
    const text = clip(request, 20000);
    if (!text.trim()) throw new Error('A run needs a request.');
    const row = { account_id: accountId, workspace_id: workspaceId || null, project: project ? clip(project, 120) : null, machine: machine ? clip(machine, 80) : null, source: cleanSource(source), state: 'queued', thread: [{ at: now(), role: 'request', by: clip(source?.from || 'owner', 160), text }], created_at: now(), updated_at: now() };
    const saved = await this.rest.upsert(TABLES.runs, row, 'id');
    return shape(saved);
  }
  async get(accountId, id) { const r = (await this.rest.select(TABLES.runs, { id }))[0]; return r && r.account_id === accountId ? shape(r) : null; }
  async list(accountId, { state = null, limit = 50 } = {}) {
    const rows = await this.rest.select(TABLES.runs, state ? { account_id: accountId, state } : { account_id: accountId });
    return rows.sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at))).slice(0, limit).map(shape);
  }
  /** One canvas board's runs, oldest first, full threads (the canvas chat polls this). */
  async forBoard(accountId, boardId) {
    const rows = await this.rest.select(TABLES.runs, { account_id: accountId });
    return rows.filter((r) => r.source?.kind === 'canvas' && r.source?.boardId === boardId).sort((a, b) => String(a.created_at).localeCompare(String(b.created_at))).map(shape);
  }
  /** Queued runs a machine may claim: its own, or any with no machine named. */
  async next(accountId, machine) {
    const rows = await this.rest.select(TABLES.runs, { account_id: accountId, state: 'queued' });
    return rows.filter((r) => !r.machine || r.machine === machine).sort((a, b) => String(a.updated_at).localeCompare(String(b.updated_at))).map(shape);
  }
  async claim(accountId, id, machine) {
    const r = (await this.rest.select(TABLES.runs, { id }))[0];
    if (!r || r.account_id !== accountId) return null;
    if (r.state !== 'queued') return { ...shape(r), claimed: false };
    const patch = { state: 'running', machine: machine ? clip(machine, 80) : r.machine, claimed_at: now(), updated_at: now() };
    await this.rest.update(TABLES.runs, { id }, patch);
    return { ...shape({ ...r, ...patch }), claimed: true };
  }
  /** Record stored files on a run (metadata only; the bytes live in the files seam). */
  async attach(accountId, id, files) {
    const r = (await this.rest.select(TABLES.runs, { id }))[0];
    if (!r || r.account_id !== accountId) return null;
    const source = cleanSource({ ...(r.source || {}), files: [...((r.source || {}).files || []), ...files] });
    await this.rest.update(TABLES.runs, { id }, { source, updated_at: now() });
    return shape({ ...r, source });
  }
  async note(accountId, id, text, by = 'agent') {
    const r = (await this.rest.select(TABLES.runs, { id }))[0];
    if (!r || r.account_id !== accountId) return null;
    const thread = [...(r.thread || []), { at: now(), role: 'agent', by, text: clip(text, 8000) }];
    await this.rest.update(TABLES.runs, { id }, { thread, updated_at: now() });
    return shape({ ...r, thread });
  }
  /** The agent asks and stops. The run waits; every phone the owner has is told. */
  async ask(accountId, id, { text, options = [] }, by = 'agent') {
    const r = (await this.rest.select(TABLES.runs, { id }))[0];
    if (!r || r.account_id !== accountId) return null;
    const q = clip(text, 4000).trim(); if (!q) throw new Error('A question needs text.');
    const opts = (Array.isArray(options) ? options : []).map((o) => clip(o, 200)).filter(Boolean).slice(0, 6);
    const question = { run_id: id, account_id: accountId, text: q, options: opts, created_at: now() };
    const saved = await this.rest.upsert(TABLES.questions, question, 'id');
    const thread = [...(r.thread || []), { at: now(), role: 'question', by, text: q, options: opts, question_id: saved.id }];
    await this.rest.update(TABLES.runs, { id }, { state: 'waiting', thread, updated_at: now() });
    const pushed = await this.notify(accountId, { title: r.project ? `${r.project}: a question` : 'Your desk has a question', body: q.slice(0, 140), url: `/desk/${id}`, tag: `desk-${id}` });
    return { run: shape({ ...r, state: 'waiting', thread }), question: shapeQ(saved), pushed };
  }
  /** A person answers. The run goes back to the queue with the whole thread; the machine picks it up. */
  async answer(accountId, questionId, { answer }, by) {
    const q = (await this.rest.select(TABLES.questions, { id: questionId }))[0];
    if (!q || q.account_id !== accountId) return null;
    if (q.answered_at) return { already: true, question: shapeQ(q) };
    const a = clip(answer, 8000).trim(); if (!a) throw new Error('An answer needs text.');
    await this.rest.update(TABLES.questions, { id: questionId }, { answer: a, answered_by: by || null, answered_at: now() });
    const r = (await this.rest.select(TABLES.runs, { id: q.run_id }))[0];
    const thread = [...(r.thread || []), { at: now(), role: 'answer', by: by || 'owner', text: a, question_id: questionId }];
    await this.rest.update(TABLES.runs, { id: q.run_id }, { state: 'queued', thread, updated_at: now() });
    return { question: shapeQ({ ...q, answer: a, answered_by: by, answered_at: now() }), run: shape({ ...r, state: 'queued', thread }) };
  }
  async finish(accountId, id, { receipt = null, reply = '', ok = true } = {}, by = 'agent') {
    const r = (await this.rest.select(TABLES.runs, { id }))[0];
    if (!r || r.account_id !== accountId) return null;
    const thread = [...(r.thread || []), { at: now(), role: 'receipt', by, text: clip(reply, 20000), ok: !!ok }];
    const patch = { state: ok ? 'done' : 'failed', receipt: receipt && typeof receipt === 'object' ? receipt : null, thread, updated_at: now() };
    await this.rest.update(TABLES.runs, { id }, patch);
    // an app's ASK is machine-to-machine (a batch of card reads): its answer goes back to the app, not to the phone
    if ((r.source || {}).kind !== 'ask') await this.notify(accountId, { title: r.project ? `${r.project}: ${ok ? 'done' : 'did not finish'}` : (ok ? 'Done' : 'Did not finish'), body: clip(reply, 140) || (ok ? 'Everything requested was done.' : 'See the receipt.'), url: `/desk/${id}`, tag: `desk-${id}` });
    return shape({ ...r, ...patch });
  }
  /** Open questions first, then recent runs: what the phone shows. */
  async alerts(accountId) {
    const qs = (await this.rest.select(TABLES.questions, { account_id: accountId })).filter((q) => !q.answered_at).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    const runs = await this.list(accountId, { limit: 30 });
    const byRun = Object.fromEntries(runs.map((r) => [r.id, r]));
    return { questions: qs.map((q) => ({ ...shapeQ(q), run: byRun[q.run_id] ? { id: byRun[q.run_id].id, project: byRun[q.run_id].project, request: byRun[q.run_id].request } : null })), runs };
  }

  // ── phones ─────────────────────────────────────────────────────────────
  async subscribe(accountId, sub, ua = '') {
    if (!sub || typeof sub.endpoint !== 'string' || !/^https:\/\//.test(sub.endpoint) || !sub.keys?.p256dh || !sub.keys?.auth) throw new Error('Not a push subscription.');
    await this.rest.upsert(TABLES.push, { endpoint: clip(sub.endpoint, 1000), account_id: accountId, keys: { p256dh: clip(sub.keys.p256dh, 200), auth: clip(sub.keys.auth, 100) }, ua: clip(ua, 200), created_at: now(), fails: 0 }, 'endpoint');
    return { ok: true };
  }
  async unsubscribe(accountId, endpoint) { const rows = await this.rest.select(TABLES.push, { endpoint }); if (rows[0] && rows[0].account_id === accountId) await this.rest.delete(TABLES.push, { endpoint }); return { ok: true }; }
  async phones(accountId) { return (await this.rest.select(TABLES.push, { account_id: accountId })).map((p) => ({ endpoint: p.endpoint.slice(0, 60) + '…', ua: p.ua, since: p.created_at, lastOk: p.last_ok_at, fails: p.fails })); }
  /** Push to every phone the account has. Dead endpoints are dropped after three failures. Never throws. */
  async notify(accountId, payload) {
    if (!this.push) return { sent: 0, reason: 'push not configured' };
    const subs = await this.rest.select(TABLES.push, { account_id: accountId });
    let sent = 0; const errors = [];
    for (const s of subs) {
      try { await this.push.send({ endpoint: s.endpoint, keys: s.keys }, payload); sent++; await this.rest.update(TABLES.push, { endpoint: s.endpoint }, { last_ok_at: now(), fails: 0 }); }
      catch (e) {
        const gone = e.statusCode === 404 || e.statusCode === 410; const fails = (s.fails || 0) + 1;
        errors.push(`${e.statusCode || ''} ${e.message || e}`.trim());
        if (gone || fails >= 3) await this.rest.delete(TABLES.push, { endpoint: s.endpoint }); else await this.rest.update(TABLES.push, { endpoint: s.endpoint }, { fails });
      }
    }
    return { sent, of: subs.length, errors: errors.slice(0, 3) };
  }
}

/** web-push behind one function, so tests pass a fake and production passes the real one. */
export function webPushSender({ publicKey, privateKey, subject }) {
  if (!publicKey || !privateKey) return null;
  let wp = null;
  return {
    publicKey,
    async send(sub, payload) {
      if (!wp) { wp = (await import('web-push')).default; wp.setVapidDetails(subject || 'mailto:hello@0n3.app', publicKey, privateKey); }
      await wp.sendNotification(sub, JSON.stringify(payload), { TTL: 60 * 60 * 24, urgency: 'high' });
    },
  };
}

const cleanFile = (f = {}) => ({ name: clip(f.name, 120), type: clip(f.type || 'application/octet-stream', 80), size: Number(f.size) || 0, path: clip(f.path, 300) });
const cleanSource = (s = {}) => ({ kind: clip(s.kind || 'manual', 20), from: s.from ? clip(s.from, 160) : undefined, subject: s.subject ? clip(s.subject, 300) : undefined, message_id: s.message_id ? clip(s.message_id, 200) : undefined, thread_id: s.thread_id ? clip(s.thread_id, 200) : undefined, mailbox: s.mailbox ? clip(s.mailbox, 160) : undefined, files: Array.isArray(s.files) && s.files.length ? s.files.slice(0, s.kind === 'ask' ? ASK_MAX_FILES : 12).map(cleanFile) : undefined, ...(s.kind === 'canvas' ? cleanCanvasSource(s) : {}), ...(s.kind === 'ask' ? cleanAskSource(s) : {}) });
/**
 * An ASK (2026-11-08): an app hands the person's own desktop AI a question + photos and wants the answer back as data — the
 * first user is CardFlow reading Pokémon cards. No project folder, read-only on the desk (see desk-agent.js askTurn).
 * `app` names the caller on the thread, `model` is a hint the agent may honour (fast | smart), `want` json | text.
 */
export const ASK_MAX_FILES = 25;
const cleanAskSource = (s) => ({ app: s.app ? clip(s.app, 40) : undefined, model: ['fast', 'smart'].includes(s.model) ? s.model : undefined, want: s.want === 'json' ? 'json' : 'text' });
/** A canvas run carries its board, what was selected and a text picture of the whole board (canvas.js builds them). */
const cleanCanvasSource = (s) => ({ boardId: s.boardId ? clip(s.boardId, 60) : undefined, selection: Array.isArray(s.selection) ? s.selection.slice(0, 100) : undefined, sceneText: s.sceneText ? clip(s.sceneText, 8000) : undefined, brain: s.brain ? clip(s.brain, 20) : undefined, site: s.site ? clip(s.site, 80) : undefined, url: s.url ? clip(s.url, 300) : undefined, repo: s.repo ? clip(s.repo, 140) : undefined, folder: s.folder ? clip(s.folder, 300) : undefined });
const shapeM = (m) => ({ machine: m.machine, agent: m.agent || null, version: m.version || null, firstSeenAt: m.first_seen_at, lastSeenAt: m.last_seen_at, online: Date.now() - new Date(m.last_seen_at).getTime() < ONLINE_MS });
const shape = (r) => ({ id: r.id, workspaceId: r.workspace_id || null, project: r.project || null, machine: r.machine || null, source: r.source || {}, state: r.state, thread: r.thread || [], receipt: r.receipt || null, request: (r.thread || []).find((t) => t.role === 'request')?.text || '', createdAt: r.created_at, updatedAt: r.updated_at, claimedAt: r.claimed_at || null });
const shapeQ = (q) => ({ id: q.id, runId: q.run_id, text: q.text, options: q.options || [], answer: q.answer || null, answeredBy: q.answered_by || null, answeredAt: q.answered_at || null, createdAt: q.created_at });
export const newId = () => randomBytes(8).toString('hex');
