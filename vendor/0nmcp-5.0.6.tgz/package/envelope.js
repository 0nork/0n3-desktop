/**
 * THE .0n CONNECTION ENVELOPE — the wire format for a connection record.
 *
 * This is the shape 0nMCP 4.x wrote to ~/.0n/connections/<service>.0n and the
 * shape 0n-spec 2.1.1 calls a "connection". 0n3 keeps it verbatim so every
 * existing file is a valid vault record and every vault record can be written
 * back as a file:
 *
 *   {
 *     "$0n": { "type": "connection", "version": "2.1.1", "name", "created", "updated" },
 *     "service": "stripe",
 *     "environment": "production",
 *     "auth": { "type": "api_key", "credentials": { "apiKey": "…" } },
 *     "options": {},          // non-secret request options (base_url, …)
 *     "meta": {}              // non-secret facts (account id, location_id, …)
 *   }
 *
 * Only `auth.credentials` is secret. Everything else is safe to list, log and
 * show in a UI, and `stripSecrets()` is the one function that produces that view.
 */
export const SPEC_VERSION = '2.1.1';

const AUTH_TYPE_BY_KEY = [
  ['access_token', 'oauth'],
  ['apiKey', 'api_key'],
  ['api_key', 'api_key'],
  ['botToken', 'bot_token'],
  ['token', 'token'],
  ['username', 'basic'],
];

export function authTypeFor(credentials = {}) {
  for (const [k, t] of AUTH_TYPE_BY_KEY) if (credentials[k] !== undefined) return t;
  return 'custom';
}

export function makeConnection({ service, name, credentials, environment = 'production', options = {}, meta = {}, created, authType }) {
  if (!service || typeof service !== 'string') throw new Error('service is required');
  if (!credentials || typeof credentials !== 'object' || Array.isArray(credentials)) throw new Error('credentials must be an object');
  const now = new Date().toISOString();
  return {
    $0n: { type: 'connection', version: SPEC_VERSION, name: name || service, created: created || now, updated: now },
    service,
    environment,
    auth: { type: authType || authTypeFor(credentials), credentials },
    options: options || {},
    meta: meta || {},
  };
}

/** @returns {{ ok: boolean, errors: string[] }} */
export function validateConnection(obj) {
  const errors = [];
  if (!obj || typeof obj !== 'object') return { ok: false, errors: ['not an object'] };
  if (obj.$0n?.type !== 'connection') errors.push('$0n.type must be "connection"');
  if (!obj.service || typeof obj.service !== 'string') errors.push('service is required');
  if (obj.$0n?.sealed) errors.push('record is sealed (machine-bound); unseal it before storing');
  else if (!obj.auth || typeof obj.auth !== 'object') errors.push('auth is required');
  else if (!obj.auth.credentials || typeof obj.auth.credentials !== 'object') errors.push('auth.credentials must be an object');
  return { ok: errors.length === 0, errors };
}

/** The non-secret view: same envelope, credentials removed, credential KEY NAMES kept so a UI can say what is stored. */
export function stripSecrets(env) {
  const keys = env?.auth?.credentials ? Object.keys(env.auth.credentials) : [];
  return {
    $0n: { ...(env.$0n || {}) },
    service: env.service,
    environment: env.environment,
    auth: { type: env.auth?.type, credentialKeys: keys },
    options: env.options || {},
    meta: env.meta || {},
  };
}

/** Label = the human name of a record; a service may hold several (two CRM locations, two Stripe accounts). */
export function labelOf(env) {
  return String(env?.$0n?.name || env?.service || '').trim();
}
