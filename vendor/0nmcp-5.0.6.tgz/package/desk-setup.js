/**
 * DESK SETUP — find the AI programs on a person's computer and put 0n3 inside each one (2026-11-09, Mike: "check for what
 * AIs are installed first and however you can automatically piggyback or install 0n3 into those AIs … the more programs we
 * can connect by default automated the better").
 *
 * Pure: everything that touches the machine is injected (exists, which, read) so it is testable and shared — the desktop app
 * runs it with real fs; the web app only shows the result. The SHAPES written into each AI's settings come from install.js
 * (mcpEntry) so the Install page and the installer can never disagree.
 */
import { mcpEntry } from './install.js';

export const MCP_URL = 'https://0n3.app/mcp';

/** Every AI we know how to find. Paths: `~` = home, `%APPDATA%` / `%LOCALAPPDATA%` = the Windows folders. */
export const SETUP_CLIENTS = [
  { key: 'claude_code', name: 'Claude Code', what: 'Claude in the Terminal', bins: ['claude'], dirs: ['~/.claude'], how: 'command' },
  { key: 'claude', name: 'Claude', what: 'the Claude desktop app', apps: { darwin: ['/Applications/Claude.app'], win32: ['%LOCALAPPDATA%/AnthropicClaude', '%LOCALAPPDATA%/Programs/Claude'], linux: ['~/.config/Claude'] }, config: { darwin: '~/Library/Application Support/Claude/claude_desktop_config.json', win32: '%APPDATA%/Claude/claude_desktop_config.json', linux: '~/.config/Claude/claude_desktop_config.json' }, how: 'json' },
  { key: 'codex', name: 'Codex', what: 'OpenAI Codex in the Terminal', bins: ['codex'], dirs: ['~/.codex'], config: '~/.codex/config.toml', how: 'toml' },
  { key: 'gemini_cli', name: 'Gemini CLI', what: 'Google Gemini in the Terminal', bins: ['gemini'], dirs: ['~/.gemini'], config: '~/.gemini/settings.json', how: 'json' },
  { key: 'cursor', name: 'Cursor', what: 'the Cursor editor', bins: ['cursor'], apps: { darwin: ['/Applications/Cursor.app'], win32: ['%LOCALAPPDATA%/Programs/cursor'] }, dirs: ['~/.cursor'], config: '~/.cursor/mcp.json', how: 'json' },
  { key: 'vscode', name: 'VS Code', what: 'Visual Studio Code (Copilot)', bins: ['code'], apps: { darwin: ['/Applications/Visual Studio Code.app'], win32: ['%LOCALAPPDATA%/Programs/Microsoft VS Code'] }, config: { darwin: '~/Library/Application Support/Code/User/mcp.json', win32: '%APPDATA%/Code/User/mcp.json', linux: '~/.config/Code/User/mcp.json' }, how: 'json' },
  { key: 'windsurf', name: 'Windsurf', what: 'the Windsurf editor', apps: { darwin: ['/Applications/Windsurf.app'], win32: ['%LOCALAPPDATA%/Programs/Windsurf'] }, dirs: ['~/.codeium/windsurf'], config: '~/.codeium/windsurf/mcp_config.json', how: 'json' },
  { key: 'cline', name: 'Cline', what: 'Cline inside VS Code', dirs: { darwin: ['~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev'], win32: ['%APPDATA%/Code/User/globalStorage/saoudrizwan.claude-dev'], linux: ['~/.config/Code/User/globalStorage/saoudrizwan.claude-dev'] }, config: { darwin: '~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json', win32: '%APPDATA%/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json', linux: '~/.config/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json' }, how: 'json', needsDir: true },
  { key: 'continue', name: 'Continue', what: 'the Continue extension', dirs: ['~/.continue'], config: '~/.continue/config.yaml', how: 'yaml', needsDir: true },
  { key: 'chatgpt', name: 'ChatGPT', what: 'the ChatGPT desktop app', apps: { darwin: ['/Applications/ChatGPT.app'], win32: ['%LOCALAPPDATA%/Programs/ChatGPT'] }, how: 'manual' },
  { key: 'ollama', name: 'Ollama', what: 'free models that run on this computer', bins: ['ollama'], apps: { darwin: ['/Applications/Ollama.app'], win32: ['%LOCALAPPDATA%/Programs/Ollama'] }, how: 'none' },
];

const pick = (v, platform) => (v && typeof v === 'object' && !Array.isArray(v) ? v[platform] || [] : v || []);
const one = (v, platform) => (v && typeof v === 'object' ? v[platform] || null : v || null);
/** `~`, %APPDATA% and %LOCALAPPDATA% → real folders. Forward slashes everywhere; Node accepts them on Windows. */
export function expand(p, { home, env = {} } = {}) {
  if (!p) return null;
  const appData = env.APPDATA || `${home}/AppData/Roaming`; const local = env.LOCALAPPDATA || `${home}/AppData/Local`;
  return String(p).replace(/^~(?=$|[\\/])/, home).replace(/%APPDATA%/g, appData).replace(/%LOCALAPPDATA%/g, local);
}

/**
 * Which AIs are on this computer. `exists(path)` and `which(bin)` are the machine's own answers.
 * Each result: { key, name, what, found, how, via, configPath, connectable, note }.
 */
export function detectClients({ platform = 'darwin', home = '', env = {}, exists = () => false, which = () => null } = {}) {
  const ctx = { home, env };
  return SETUP_CLIENTS.map((c) => {
    const bin = (c.bins || []).map((b) => which(b)).find(Boolean) || null;
    const app = pick(c.apps, platform).map((p) => expand(p, ctx)).find((p) => exists(p)) || null;
    const dir = pick(c.dirs, platform).map((p) => expand(p, ctx)).find((p) => exists(p)) || null;
    const configPath = expand(one(c.config, platform), ctx);
    const cfgThere = configPath ? exists(configPath) : false;
    const found = !!(bin || app || dir || cfgThere);
    const via = bin ? `program ${bin}` : app ? `app ${app}` : dir ? `folder ${dir}` : cfgThere ? `settings ${configPath}` : null;
    const connectable = found && (c.how === 'command' || c.how === 'json' || c.how === 'toml' || c.how === 'yaml') && (!c.needsDir || !!dir || cfgThere);
    const note = c.how === 'none' ? (found ? 'Found. 0n3 can use it for free, private answers.' : null) : c.how === 'manual' ? (found ? 'Found. This one needs two taps inside the app: Settings → Connectors → add 0n3 and sign in.' : null) : null;
    return { key: c.key, name: c.name, what: c.what, found, how: c.how, via, configPath: configPath || null, connectable, note };
  });
}

// ── writing 0n3 into each AI's settings ───────────────────────────────────────
const stringify = (o) => `${JSON.stringify(o, null, 2)}\n`;
/** Put/replace `name` under `root` in a JSON settings file, keeping everything else (and the file's other servers). */
export function mergeJson(existingText, root, name, entry) {
  let doc = {};
  if (existingText && existingText.trim()) { try { doc = JSON.parse(existingText); } catch { throw new Error('the settings file is not valid JSON — fix it first'); } }
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) doc = {};
  const bucket = doc[root] && typeof doc[root] === 'object' && !Array.isArray(doc[root]) ? doc[root] : {};
  doc[root] = { ...bucket, [name]: entry };
  return stringify(doc);
}
/** Replace or append a `[mcp_servers.<name>]` table in a TOML file; other tables untouched. */
export function mergeToml(existingText, name, block) {
  const text = String(existingText || '').replace(/\r\n/g, '\n');
  const head = `[mcp_servers.${name}]`;
  const lines = text.split('\n'); const out = []; let skipping = false;
  for (const line of lines) {
    if (/^\s*\[/.test(line)) skipping = line.trim() === head;
    if (!skipping) out.push(line);
  }
  const kept = out.join('\n').replace(/\n{3,}/g, '\n\n').trimEnd();
  return `${kept ? `${kept}\n\n` : ''}${block.trim()}\n`;
}
/** Replace or append the `- name: <name>` item under `mcpServers:` in a YAML file (Continue). Naive on purpose: items only. */
export function mergeYaml(existingText, name, itemBlock) {
  let text = String(existingText || '').replace(/\r\n/g, '\n');
  // drop an existing item for this name: from its "- name:" line to the next "- " at the same indent or a top-level key
  text = text.replace(new RegExp(`(^|\\n)(\\s*)- name: ${name}\\n(?:(?!\\2- |\\S)[^\\n]*\\n?)*`, 'g'), '$1');
  if (!/^mcpServers:\s*$/m.test(text)) text = `${text.trimEnd()}${text.trim() ? '\n\n' : ''}mcpServers:\n`;
  const idx = text.search(/^mcpServers:\s*$/m); const after = text.indexOf('\n', idx) + 1;
  return `${text.slice(0, after)}${itemBlock.replace(/\n?$/, '\n')}${text.slice(after)}`;
}

/**
 * What to do for one AI: a command to run, a settings file to merge into, steps for the person, or nothing.
 * `apply(existingText)` returns the new file text. Nothing here touches the disk.
 */
export function planFor(key, { platform = 'darwin', home = '', env = {}, token, mcp = MCP_URL, name = '0n3' } = {}) {
  const c = SETUP_CLIENTS.find((x) => x.key === key); if (!c) return { kind: 'none', note: 'Unknown program.' };
  const e = mcpEntry(key, { mcp, token, name });
  const file = expand(one(c.config, platform), { home, env });
  if (c.how === 'command') return { kind: 'command', bin: e.argv[0], args: e.argv.slice(1), alsoSkill: key === 'claude_code' ? expand(`~/.claude/skills/${name}/SKILL.md`, { home, env }) : null };
  if (c.how === 'json') return { kind: 'file', file, apply: (t) => mergeJson(t, e.root, name, e.entry) };
  if (c.how === 'toml') return { kind: 'file', file, apply: (t) => mergeToml(t, name, e.toml) };
  if (c.how === 'yaml') return { kind: 'file', file, apply: (t) => mergeYaml(t, name, e.yaml) };
  if (c.how === 'manual') return { kind: 'manual', steps: e.steps || [] };
  return { kind: 'none', note: 'Nothing to write for this one.' };
}
