/**
 * JOBS (2026-11-12). Mike: "Jobs is the most clear… 'Have 0n run Job #12' or 'Create a new job called ATLO Optimization'".
 * A Job is what the builder used to call a sequence: the blocks and wires stored in a Project's canvas (`canvas.sequences[]`).
 * Nothing new is stored here — this module only NAMES them: a number per account that never changes once given (kept on the
 * sequence as `no`, carried through every save by workspaces.setCanvas), and one lookup that takes a number, an id or a name.
 *
 * Running a Job is runFlow (flows.js) — the same engine as Run on the canvas. Its answer is the Return block's value
 * (or the last step's) and lands in `workspace_runs.output` next to the receipt, so the caller can grab it.
 */

/** Every Job on the account, numbered. Missing numbers are given once (oldest Project first, in canvas order) and saved. */
export async function listJobs(workspaces, accountId) {
  const projects = await workspaces.list(accountId);
  const all = [];
  for (const w of projects) {
    const c = await workspaces.getCanvas(accountId, w.id).catch(() => null);
    for (const q of (c?.v === 2 ? c.sequences : []) || []) all.push({ w, c, q });
  }
  let max = all.reduce((m, x) => Math.max(m, Number(x.q.no) || 0), 0);
  const dirty = new Map();
  for (const x of all) if (!(Number(x.q.no) > 0)) { x.q.no = ++max; dirty.set(x.w.id, x.c); }
  for (const [wid, c] of dirty) await workspaces.setCanvas(accountId, wid, c).catch(() => null);
  return all.map(({ w, q }) => shapeJob(w, q));
}

export function shapeJob(w, q) {
  const flow = (q.nodes || []).filter((n) => n.type !== 'shape');
  const start = flow.find((n) => n.type === 'trigger') || null;
  return {
    no: q.no, id: q.id, name: q.name,
    project: { id: w.id, name: w.name, slug: w.slug },
    startsWith: start ? { key: start.key, title: start.title || start.key } : null,
    steps: flow.length,
    returns: flow.some((n) => n.type === 'data' && n.key === 'return'),
    ...onPage(q),
  };
}

/**
 * HOW A JOB SHOWS ON A PAGE (Mike 2026-11-14): "Jobs that are triggered by buttons will show the button. By form, by a form.
 * If it's triggered by something that isn't visible, it will be called a Job but it will require the trigger to be connected."
 * Derived from the Job itself every time, never stored: a Page-button trigger with no fields → a button; a Page-button (or
 * Page-form) trigger whose steps read {{trigger.<field>}} → a form with exactly those fields; anything else (a schedule, an app
 * event, a webhook, an email) → 'hidden', which a page shows only to its editor, as a Job whose trigger still needs connecting.
 */
const NOT_FIELDS = new Set(['actor', 'source', 'id', 'page', 'block', 'at', 'host', 'slug', 'runId']);
export function onPage(q) {
  const flow = (q?.nodes || []).filter((n) => n.type !== 'shape');
  const start = flow.find((n) => n.type === 'trigger') || null;
  const seen = []; const add = (f) => { if (f && !NOT_FIELDS.has(f) && !seen.includes(f)) seen.push(f); };
  const scan = (v) => { if (typeof v === 'string') { for (const m of v.matchAll(/\{\{\s*trigger\.([A-Za-z_][\w]*)/g)) add(m[1]); } else if (v && typeof v === 'object') Object.values(v).forEach(scan); };
  for (const n of flow) scan(n.values || {});
  const declared = String(start?.values?.fields || '').split(/[,\n]/).map((x) => x.trim()).filter(Boolean);
  declared.forEach(add);
  const visible = start && ['page_button', 'page_form', 'button', 'form'].includes(start.key);
  const fields = seen.slice(0, 12).map((name) => ({ name, label: label(name), type: /email/i.test(name) ? 'email' : /phone|mobile/i.test(name) ? 'tel' : /message|note|details|question/i.test(name) ? 'textarea' : 'text' }));
  const showsAs = !visible ? 'hidden' : (fields.length || /form/.test(start.key) ? 'form' : 'button');
  return { showsAs, fields: showsAs === 'form' ? fields : [], buttonText: String(start?.values?.name || start?.title || q?.name || 'Go').slice(0, 40), trigger: start ? { key: start.key, title: start.title || start.key, app: start.app || null } : null };
}
const label = (f) => { const w = String(f).replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim().toLowerCase(); return w.charAt(0).toUpperCase() + w.slice(1); };

/** "12", "#12", "job 12", a Job id, or a Job's name (exact, then unique prefix, case ignored). */
export function findJob(jobs, ref) {
  const r = String(ref ?? '').trim();
  if (!r) return { error: 'Say which Job: its number (like 12), its id or its name.' };
  const num = /^(?:job\s*)?#?\s*(\d{1,6})$/i.exec(r);
  if (num) { const j = jobs.find((x) => x.no === Number(num[1])); return j ? { job: j } : { error: `There is no Job #${num[1]} on this account.` }; }
  const byId = jobs.find((x) => x.id === r); if (byId) return { job: byId };
  const low = r.toLowerCase();
  const exact = jobs.filter((x) => String(x.name).toLowerCase() === low);
  if (exact.length === 1) return { job: exact[0] };
  const pre = exact.length ? exact : jobs.filter((x) => String(x.name).toLowerCase().startsWith(low));
  if (pre.length === 1) return { job: pre[0] };
  if (pre.length > 1) return { error: `More than one Job matches "${r}": ${pre.slice(0, 6).map((x) => `#${x.no} ${x.name} (${x.project.name})`).join(', ')}. Use the number.` };
  return { error: `No Job called "${r}".` };
}

/** What a caller gets back for a run, whether it just finished or is read later. */
export function runView(row, job = null) {
  const rc = row.receipt || {};
  return {
    runId: row.run_key,
    job: job ? { no: job.no, id: job.id, name: job.name, project: job.project.name } : { id: row.job_id },
    state: row.state || 'done',
    ok: row.state === 'running' ? null : !!row.ok,
    output: row.output ?? rc.output ?? null,
    outputFrom: rc.outputFrom || null,
    outcome: rc.outcome || (row.state === 'running' ? 'Still running.' : ''),
    steps: (rc.steps || []).map((s) => ({ step: s.step, state: s.state, detail: s.detail, ms: s.ms })),
    waiting: rc.waiting || [],
    dry: !!rc.dry,
    startedAt: rc.startedAt || row.at,
    finishedAt: row.state === 'running' ? null : (rc.finishedAt || null),
  };
}

export const newRunKey = () => `run_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;

/**
 * JOB → APP (Mike 2026-11-19: "one app can hold several jobs and be able to be designed just like a drag and drop web page
 * builder. Simply dragging an entire job into a section just means we're allowing that app to have that functionality on that
 * portion of the app"). An app IS a 0n3 Pages page; each Job on it is one Job block (one section). This is the server twin of
 * the editor's jobToBlock, used when Domino's "Make it an app" starts a new app from one Job.
 */
export function jobBlock(job, theme = {}) {
  return {
    id: `block-job-${Math.random().toString(36).slice(2, 9)}`,
    type: 'job',
    content: {
      jobId: job.id, jobNo: job.no, jobName: job.name, showsAs: job.showsAs, fields: job.fields || [], triggerTitle: job.trigger?.title || '',
      buttonText: job.buttonText && job.buttonText !== job.name ? job.buttonText : 'Run it',
      title: job.name, description: '', successText: 'Done.',
    },
    styles: { backgroundColor: '#ffffff', textColor: '#18181b', accentColor: theme.brandPrimary || '#171717', buttonTextColor: '#ffffff', paddingTop: 'py-16', paddingBottom: 'py-16', borderRadius: 'rounded-full', align: 'center', shadow: 'shadow-md', layoutStyle: 'centered' },
  };
}
/** A new one-section app around one Job. Refuses a Job nobody can press (a schedule, an app event): it would be an empty app. */
export function appSite(job) {
  if (job.showsAs === 'hidden') throw new Error(`"${job.name}" starts ${job.trigger ? `from "${job.trigger.title}"` : 'from nothing yet'}, so there is nothing to press in an app. Make it start with "When I press Run", then make the app.`);
  const theme = { brandPrimary: '#171717' };
  return { title: job.name, description: '', theme, pages: [{ id: 'page-home', title: 'Home', slug: '/', parentId: null, blocks: [jobBlock(job, theme)] }], currentPageId: 'page-home' };
}
/** The app (page) in a project that already holds this Job, so "Make it an app" twice opens the same app. */
export const appHolding = (pages, jobId) => (pages || []).find((p) => p.format === 'struktur' && (p.site?.pages || []).some((x) => (x.blocks || []).some((b) => b.type === 'job' && b.content?.jobId === jobId))) || null;

/** What a visitor of an app sees as the Job's answer: only a Return block's value, never the receipt, trimmed. */
export function appOutput(job, receipt) {
  if (!job?.returns || !receipt || receipt.outputFrom !== 'return') return null;
  const v = receipt.output;
  if (v == null) return null;
  const s = typeof v === 'string' ? v : JSON.stringify(v);
  return s.length > 20000 ? s.slice(0, 20000) + '…' : v;
}
