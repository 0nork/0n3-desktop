# 0n3 — every app you own. One sign-in. AI that executes.

**0n3 is the universal hub.** One SSO connects hundreds of applications (122 today, 1,804 endpoints) and opens every one of their endpoints to the AI you trust. These are not workflows. This is not Zapier. 0n3 makes AI execute the ideas and plans you already have: in your accounts, with your permission, with a receipt for every call. No more "I think it worked."

Connected. Expert coded. A front-facing URL, user login, payments through your Stripe, and true agentic AI, in one dashboard. Patent-pending MCP integration. The last app you'll ever use to build your automated business.

- **Hosted:** `https://0n3.app/mcp` — add it to Claude, ChatGPT, Cursor, Claude Code, Codex, Gemini CLI, VS Code, Windsurf or any MCP client in one line.
- **Local:** `npx 0nmcp@5 stdio` — the same runtime on your own machine, reading `.0n` connection files.
- **No code.** Connect an app, ask your AI, done.

[0n3.app](https://0n3.app) · [Install into your AI](https://0n3.app/install) · [Connect an app](https://0n3.app/connect) · [Build a workspace](https://0n3.app/workspaces)

---

## 30 seconds to your first tool

1. Create a free account at [0n3.app](https://0n3.app) and connect one app (paste a key, or sign in through a door).
2. Open [0n3.app/install](https://0n3.app/install), pick your AI, copy the line it gives you. A key is minted for that AI alone.
3. Ask your AI: **whoami**. It answers with your email and your connected services. Now ask it to do something.

```json
{ "mcpServers": { "0n3": { "url": "https://0n3.app/mcp", "headers": { "Authorization": "Bearer 0n_…" } } } }
```

Claude Code: `claude mcp add --transport http 0n3 https://0n3.app/mcp --header "Authorization: Bearer 0n_…"`

## What your AI gets

| Tool | What it does |
|---|---|
| `whoami` · `connections` | Which account, which apps are connected. Never the secrets. |
| `services` · `service_info` · `api_call` | The catalog: 122 services, 1,804 endpoints, each callable with your own connection. |
| `apps` · `app_info` · `app_run` | Mini-apps: a whole job in one call (set Google up for a domain, launch a site), with a receipt of every step. |
| `mcp_tools` · `mcp_call` | Tools of any other MCP server you connect, through the same identity. |
| `crm_*` | 868 generated CRM tools, scoped to the location you pick. |

Every call runs with **your** stored connection. The AI never sees a provider key; 0n3 resolves it per account, per call, and audits it.

## Beyond tools

- **Workspaces** — a visual builder for pages your customers sign in to and sequences those pages fire, live at `0n3.app/w/<name>` or on your own domain. Start from a template.
- **The Desk** — an assistant that works on *your* computer with *your* coding agent, asks you on your phone when unsure, and replies with what it did. Guided setup in seven steps; one line in Terminal links the machine.
- **One identity across every 0n app** — the same account and token work on 0nTask, 0nCore and the rest.

## Security, plainly

- Connections are encrypted at rest, one record per connection, keyed to your account. Names, labels and audit are visible; secrets never leave the vault.
- Each AI gets its own scoped token. Revoke one without touching the rest. Rotate the master any time.
- The hosted server has no unauthenticated path. Clients that cannot send a header sign in through the OAuth 2.1 door.
- Nothing is pooled or shared between accounts. There is no "our key".

## Local use

```bash
npx 0nmcp@5 stdio                                   # MCP over stdio for Claude Desktop, Cursor, Claude Code
npx 0nmcp@5 doctor                                  # tool counts, services, your local records
npx 0nmcp@5 new stripe --key apiKey=sk_live_…       # write ~/.0n/connections/stripe.0n
ON3_TOKEN=0n_… npx 0nmcp@5 vault push stripe        # put it in your hosted vault
npm i -g 0nmcp@5 && 0n3 desk login                   # this computer becomes your desk
```

The package ships two commands, `0n3` and `0nmcp`; they are the same binary. Version 4.x stays on npm as `0nmcp@4`.

## Links

Website [0n3.app](https://0n3.app) · Install [0n3.app/install](https://0n3.app/install) · OpenAPI [0n3.app/api/install/openapi.json](https://0n3.app/api/install/openapi.json) · Skill file for Claude Code [0n3.app/api/install/skill](https://0n3.app/api/install/skill) · MCP Registry `io.github.0nork/0nMCP`

## License

BSL 1.1 — free for non-commercial use; commercial use requires a license. See `LICENSE`.
