/**
 * WAITING RUNS — the rest of a sequence that is waiting on a line ("2 days") or a Wait block.
 *
 * runFlow() parks a branch through park(): one row here holding which step comes next, what the run knew by then (its
 * context: the trigger, every step's output), and when it is due. The 5-minute clock (/api/cron/alerts) takes the due rows,
 * CLAIMS each one (so two ticks can never run it twice), and resumes it on the CURRENT version of the sequence with the
 * owner's own connections. A step deleted in the meantime ends the run with words, never a guess at where to go instead.
 * Nested waits simply park again.
 *
 * Table flow_waits (migration 0018), RLS on, service role only, like every 0n3 table.
 */
export const TABLE = 'flow_waits';
const now = () => new Date().toISOString();
const shape = (r) => ({ id: r.id, workspaceId: r.workspace_id, sequenceId: r.sequence_id, sequence: r.sequence_name || '', node: r.node_id, step: r.step || '', wait: r.wait || '', dueAt: r.due_at, state: r.state, actor: r.actor || '', createdAt: r.created_at, ranAt: r.ran_at || null, outcome: r.outcome || null });

export class WaitStore {
  constructor({ rest }) { if (!rest) throw new Error('WaitStore needs a rest seam'); this.rest = rest; }

  /** Park the rest of a branch. Returns the wait's id (it goes in the receipt). */
  async park(accountId, { workspaceId, sequenceId, sequenceName, node, step, from, ctx, dueAt, wait, actor, access }) {
    if (!accountId || !workspaceId || !sequenceId || !node) throw new Error('a wait needs the account, workspace, sequence and the step it continues at');
    const row = { id: `w_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`, account_id: accountId, workspace_id: workspaceId, sequence_id: sequenceId, sequence_name: String(sequenceName || '').slice(0, 120), node_id: node, from_node: from || null, step: String(step || '').slice(0, 120), ctx: ctx || {}, access: access || null, wait: String(wait || '').slice(0, 40), due_at: dueAt, state: 'waiting', actor: String(actor || '').slice(0, 200), created_at: now() };
    await this.rest.insert(TABLE, row);
    return row.id;
  }

  /** What is waiting in one workspace (no contexts: they can hold a customer's details). */
  async list(accountId, workspaceId) {
    return (await this.rest.select(TABLE, { account_id: accountId, workspace_id: workspaceId })).sort((a, b) => String(a.due_at).localeCompare(String(b.due_at))).map(shape);
  }

  async cancel(accountId, id) {
    const r = (await this.rest.select(TABLE, { id }))[0];
    if (!r || r.account_id !== accountId) return null;
    if (r.state !== 'waiting') return shape(r);
    await this.rest.update(TABLE, { id, state: 'waiting' }, { state: 'cancelled', ran_at: now(), outcome: 'Cancelled by the owner before it was due.' });
    return shape({ ...r, state: 'cancelled' });
  }

  /** Every wait that is due, across accounts, oldest first (the clock's view). */
  async due(at = Date.now()) {
    return (await this.rest.select(TABLE, { state: 'waiting' })).filter((r) => new Date(r.due_at).getTime() <= at).sort((a, b) => String(a.due_at).localeCompare(String(b.due_at)));
  }

  /** Take a due wait for this tick. Returns the full row (with its context) only if THIS call won it. */
  async claim(id) {
    const tok = Math.random().toString(36).slice(2, 12);
    await this.rest.update(TABLE, { id, state: 'waiting' }, { state: 'running', claim: tok, ran_at: now() });
    const r = (await this.rest.select(TABLE, { id }))[0];
    return r && r.state === 'running' && r.claim === tok ? r : null;
  }

  async finish(id, { ok, outcome }) {
    await this.rest.update(TABLE, { id }, { state: ok ? 'done' : 'failed', outcome: String(outcome || '').slice(0, 500), ran_at: now() });
  }
}
