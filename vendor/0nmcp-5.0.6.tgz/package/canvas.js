/**
 * THE CANVAS CHAT — an Excalidraw board a person draws on while talking to their OWN local AI.
 *
 *   canvas_boards   one board: title, the Excalidraw scene (stored as the UI saved it), the linked spreadsheet
 *
 * The AI request is not a new channel: POST /api/canvas/:id/ask makes an ordinary desk run (desk.js) with
 * source { kind: 'canvas', boardId, selection, sceneText }. The person's desk agent (desk-agent.js) claims it, works
 * it locally, posts notes and finishes, exactly like any other run. The live reply is the desk thread; the record is
 * the spreadsheet (sheet-bus.js). On done, a fenced ```0n3-canvas block in the reply is lifted out into
 * run.receipt.canvas — Excalidraw skeleton elements the UI draws back onto the board.
 */
import { buildSequence, buildPage, parseSpec, draftSystemPrompt } from './draft.js';

export const TABLE = 'canvas_boards';
export const MAX_SCENE_BYTES = 2 * 1024 * 1024;
export const MAX_CANVAS_ELEMENTS = 200;
/** The UI splits the first thread entry on this marker to show only what the person typed. */
export const BOARD_MARKER = '\n\n— What is on the board —\n';
const now = () => new Date().toISOString();
const clip = (s, n) => String(s ?? '').slice(0, n);
const num = (v) => (Number.isFinite(Number(v)) ? Math.round(Number(v) * 100) / 100 : undefined);

export class CanvasStore {
  /** @param {{ rest: any, maxSceneBytes?: number }} o */
  constructor({ rest, maxSceneBytes = MAX_SCENE_BYTES }) { if (!rest) throw new Error('CanvasStore needs a rest seam'); this.rest = rest; this.maxSceneBytes = maxSceneBytes; }

  async list(accountId) {
    const rows = await this.rest.select(TABLE, { account_id: accountId }, 'id,account_id,title,sheet,updated_at,created_at');
    return rows.sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at))).map((r) => ({ id: r.id, title: r.title, updatedAt: r.updated_at, sheet: publicSheet(r.sheet) }));
  }
  async create(accountId, { title } = {}) {
    const row = { account_id: accountId, title: cleanTitle(title), scene: {}, sheet: null, created_at: now(), updated_at: now() };
    return shape(await this.rest.upsert(TABLE, row, 'id'));
  }
  /** The raw row (sheet internals included) — for the server only. */
  async row(accountId, id) { const r = (await this.rest.select(TABLE, { id }))[0]; return r && r.account_id === accountId ? r : null; }
  async get(accountId, id) { const r = await this.row(accountId, id); return r ? shape(r) : null; }
  async update(accountId, id, { title, scene } = {}) {
    const r = await this.row(accountId, id); if (!r) return null;
    const patch = { updated_at: now() };
    if (title !== undefined) patch.title = cleanTitle(title);
    if (scene !== undefined) {
      if (!scene || typeof scene !== 'object' || Array.isArray(scene)) throw new Error('scene must be an object (the Excalidraw scene).');
      const bytes = Buffer.byteLength(JSON.stringify(scene));
      if (bytes > this.maxSceneBytes) throw new Error(`This board is too big to save: ${(bytes / 1048576).toFixed(2)} MB, the limit is ${(this.maxSceneBytes / 1048576).toFixed(0)} MB. Remove large images or split it into two boards.`);
      patch.scene = scene;
      // A save that EMPTIES a board keeps the drawing it replaces (scene_prev), so a client race (2026-11-09: Excalidraw
      // reset the scene during its own start-up and the next change saved nothing) or a slip of the hand can be undone.
      const had = Array.isArray(r.scene?.elements) ? r.scene.elements.filter((e) => e && !e.isDeleted).length : 0;
      const has = Array.isArray(scene.elements) ? scene.elements.filter((e) => e && !e.isDeleted).length : 0;
      if (had > 0 && has === 0) patch.scene_prev = r.scene;
    }
    await this.rest.update(TABLE, { id }, patch);
    return shape({ ...r, ...patch });
  }
  /** Put the drawing a wipe replaced back on the board. null = no board; false = nothing to restore. */
  async restore(accountId, id) {
    const r = await this.row(accountId, id); if (!r) return null;
    const prev = r.scene_prev; if (!prev || !Array.isArray(prev.elements) || !prev.elements.length) return false;
    const patch = { scene: prev, scene_prev: null, updated_at: now() };
    await this.rest.update(TABLE, { id }, patch);
    return shape({ ...r, ...patch });
  }
  async remove(accountId, id) { const r = await this.row(accountId, id); if (!r) return false; await this.rest.delete(TABLE, { id }); return true; }
  /** Replace the board's sheet jsonb (link, pending buffer, last error). */
  async setSheet(accountId, id, sheet) { const r = await this.row(accountId, id); if (!r) return null; await this.rest.update(TABLE, { id }, { sheet }); return { ...r, sheet }; }
}

const cleanTitle = (t) => clip(String(t ?? '').trim() || 'Untitled board', 120);
/** What a client sees of the sheet: never the pending buffer. */
export const publicSheet = (s) => (s && s.id ? { provider: s.provider, id: s.id, url: s.url, createdAt: s.created_at || null, lastError: s.last_error || null, lastErrorAt: s.last_error_at || null } : null);
const shape = (r) => ({ id: r.id, title: r.title, scene: r.scene || {}, sheet: publicSheet(r.sheet), createdAt: r.created_at, updatedAt: r.updated_at, canRestore: !!(r.scene_prev && Array.isArray(r.scene_prev.elements) && r.scene_prev.elements.length) });

// ── the ask ──────────────────────────────────────────────────────────────────
/** A selected element, as the UI sends it: plain data, bounded. */
export function cleanSelection(sel) {
  return (Array.isArray(sel) ? sel : []).slice(0, 100).map((e) => (e && typeof e === 'object' ? {
    type: clip(e.type || 'shape', 30), ...(e.text ? { text: clip(e.text, 2000) } : {}),
    x: num(e.x), y: num(e.y), width: num(e.width), height: num(e.height),
  } : null)).filter(Boolean);
}
const pos = (e) => [e.x, e.y].every((v) => v !== undefined) ? ` at (${e.x}, ${e.y})${e.width !== undefined ? ` ${e.width}×${e.height}` : ''}` : '';
/** The request text: exactly the message, then the marker, then what is selected and drawn. */
export function askRequest(message, selection = [], sceneText = '') {
  const lines = [];
  if (selection.length) { lines.push(`Selected (${selection.length}):`); for (const e of selection) lines.push(`- ${e.type}${pos(e)}${e.text ? `: "${e.text.replace(/\s+/g, ' ').slice(0, 300)}"` : ''}`); }
  else lines.push('Nothing is selected.');
  const st = clip(sceneText, 6000).trim();
  lines.push(st ? `Whole board:\n${st}` : 'The board is empty.');
  return `${String(message)}${BOARD_MARKER}${lines.join('\n')}`;
}

// ── the AI drawing back ─────────────────────────────────────────────────────
const TYPES = new Set(['rectangle', 'ellipse', 'diamond', 'arrow', 'line', 'text']);
const COLOR = /^(#[0-9a-fA-F]{3,8}|transparent|[a-zA-Z]{3,20})$/;
const color = (c) => (typeof c === 'string' && COLOR.test(c) ? c : undefined);
const prune = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined));
const ref = (r) => (r && typeof r === 'object' ? prune({ id: r.id ? clip(r.id, 60) : undefined, type: TYPES.has(r.type) ? r.type : undefined }) : undefined);
/** One skeleton element with only the keys Excalidraw's convertToExcalidrawElements accepts here; null when unusable. */
export function cleanElement(e) {
  if (!e || typeof e !== 'object' || !TYPES.has(e.type)) return null;
  const x = num(e.x), y = num(e.y); if (x === undefined || y === undefined) return null;
  const out = prune({
    type: e.type, id: e.id ? clip(e.id, 60) : undefined, x, y, width: num(e.width), height: num(e.height),
    strokeColor: color(e.strokeColor), backgroundColor: color(e.backgroundColor),
    fillStyle: ['solid', 'hachure', 'cross-hatch'].includes(e.fillStyle) ? e.fillStyle : undefined,
    strokeWidth: num(e.strokeWidth), fontSize: num(e.fontSize),
  });
  if (e.type === 'text') { if (!String(e.text ?? '').trim()) return null; out.text = clip(e.text, 2000); }
  else if (e.label && String(e.label.text ?? '').trim()) out.label = { text: clip(e.label.text, 500) };
  if (e.type === 'arrow' || e.type === 'line') {
    const s = ref(e.start), en = ref(e.end); if (s && Object.keys(s).length) out.start = s; if (en && Object.keys(en).length) out.end = en;
    if (Array.isArray(e.points)) { const pts = e.points.slice(0, 50).map((p) => (Array.isArray(p) ? [num(p[0]), num(p[1])] : null)).filter((p) => p && p[0] !== undefined && p[1] !== undefined); if (pts.length >= 2) out.points = pts; }
  }
  return out;
}
const FENCE = /```0n3-canvas[^\n]*\n([\s\S]*?)```/g;
const FENCE_MERMAID = /```mermaid[^\n]*\n([\s\S]*?)```/g;
const FENCE_SEQ = /```0n3-sequence[^\n]*\n([\s\S]*?)```/g;
/**
 * Lift what the AI drew out of a reply: ```0n3-canvas skeleton elements, a ```mermaid diagram (the board converts it to
 * hand-drawn shapes) and a ```0n3-sequence spec in the builder's vocabulary (built like Describe-it, so only real blocks
 * survive). Tolerant: an invalid block is dropped silently, never an error. The text that is left is what the person reads.
 */
export function extractCanvas(reply) {
  const text = String(reply ?? ''); let elements = []; let mermaid = null; let sequence = null;
  const stripped = text.replace(FENCE, (_, body) => {
    try { const a = JSON.parse(body.trim()); const arr = Array.isArray(a) ? a : Array.isArray(a?.elements) ? a.elements : []; elements.push(...arr.map(cleanElement).filter(Boolean)); } catch { /* ignore an invalid block */ }
    return '';
  }).replace(FENCE_MERMAID, (_, body) => { const m = body.trim(); if (m && !mermaid) mermaid = m.slice(0, 20000); return ''; })
    .replace(FENCE_SEQ, (_, body) => { if (!sequence) { const spec = parseSpec(body); sequence = spec ? buildSequence(spec) : null; } return ''; })
    .replace(/\n{3,}/g, '\n\n').trim();
  elements = elements.slice(0, MAX_CANVAS_ELEMENTS);
  return { text: stripped === text.trim() ? text : stripped, elements: elements.length ? elements : null, mermaid, sequence };
}

// ── Describe it, on the board ───────────────────────────────────────────────
/** diagram = a Mermaid flowchart/sequence/class diagram · sequence = a 0n3 sequence that runs · page = a page wireframe · sketch = free shapes (a web page, an email). */
export const DESCRIBE_KINDS = ['diagram', 'sequence', 'page', 'sketch'];
const SKELETON_KEYS = 'type rectangle|ellipse|diamond|arrow|line|text; x, y (required); width, height; text (text elements only); label {text}; strokeColor, backgroundColor, fillStyle (solid|hachure|cross-hatch), strokeWidth, fontSize; id; start/end {id} on arrows; points on lines';
export function describeSystemPrompt(kind) {
  if (kind === 'sequence') return draftSystemPrompt('sequence');
  if (kind === 'page') return draftSystemPrompt('page');
  if (kind === 'sketch') return `You sketch wireframes on a whiteboard for the 0n3 canvas. Answer with ONE JSON object and nothing else: {"elements":[ ...Excalidraw skeleton elements... ]}. Keys allowed: ${SKELETON_KEYS}. Draw the thing described — a web page, an email, a screen, a poster — as a clean wireframe: one tall rectangle for the frame (a web page about 1200 wide, an email 600), horizontal bands for the header, the hero and each section, text elements for headings and short real copy (never lorem ipsum), small dark rectangles with a white label for buttons, light grey rectangles labelled "image" for pictures. Align to a 20px grid, leave breathing room, at most 120 elements, no emoji.`;
  return `You draw diagrams for the 0n3 canvas with Mermaid. Answer with ONE JSON object and nothing else: {"mermaid":"<the mermaid definition>"}. Pick the diagram that fits: flowchart (TD for a process that flows down, LR for left to right) for steps, decisions and systems; sequenceDiagram for messages between parties over time; classDiagram for data models. Rules: short labels (6 words or fewer) in double quotes, every node declared once, a decision as a diamond {"…?"} with Yes/No edge labels, 30 nodes at most, no classDef, style, click or comments. Nothing else is supported.`;
}
/** Check an answer for one kind; never trust it. */
export function parseDescribe(kind, text) {
  const spec = parseSpec(text);
  if (!spec) return { error: 'The AI did not answer with something drawable. Try again, or say it more plainly.', raw: String(text || '').slice(0, 400) };
  if (kind === 'sequence') { const q = buildSequence(spec); return q ? { sequence: q } : { error: 'The answer had no usable blocks.' }; }
  if (kind === 'page') return { page: buildPage(spec) };
  if (kind === 'sketch') { const els = (Array.isArray(spec.elements) ? spec.elements : []).map(cleanElement).filter(Boolean).slice(0, MAX_CANVAS_ELEMENTS); return els.length ? { elements: els } : { error: 'The answer had no usable shapes.' }; }
  const m = normalizeMermaid(spec.mermaid); return m ? { mermaid: m.slice(0, 20000) } : { error: 'The answer had no diagram.' };
}
/**
 * Models hand back Mermaid with the header and the first statement on ONE line ("flowchart TD A[...] --> B") or with
 * "\n" spelled out — mermaid wants a newline after the header. Measured 2026-11-09 (claude-sonnet-5-5 via the router):
 * "Parse error on line 1: … Expecting 'NEWLINE', got 'NODE_STRING'". Fix the shape, never the words.
 */
export function normalizeMermaid(src) {
  let s = String(src || '').replace(/\r/g, '').replace(/\\n/g, '\n').trim();
  if (!s) return '';
  s = s.replace(/^```(?:mermaid)?\s*\n?/i, '').replace(/\n?```\s*$/, '').trim();
  s = s.replace(/^(flowchart|graph)[ \t]+(TD|TB|LR|RL|BT)\b[ \t]*(?=\S)/i, '$1 $2\n');
  s = s.replace(/^(sequenceDiagram|classDiagram|stateDiagram(?:-v2)?|erDiagram)\b[ \t]*(?=\S)/i, '$1\n');
  return s;
}
