/**
 * CRM TOOL FACTORY — ported from 0nMCP 4.x crm/helpers.js with two changes,
 * both of which are what makes 0n3 multi-tenant:
 *
 *  1. The registry of tool names is PER SERVER (a WeakMap), not module-level.
 *     4.x kept one Set for the whole process, so the second MCP session on the
 *     HTTP server silently got zero CRM tools.
 *  2. The access token is RESOLVED PER CALL through `options.resolveToken(args)`
 *     — in practice the account's CRM record from the vault — instead of a
 *     module-level resolver set once at boot. `access_token` in the tool input
 *     is now optional: pass it to override, omit it to use the account's own.
 *
 * Everything else — the def-object schema {name, description, method, path,
 * params, query, body, needsLocation}, path substitution, query/body shaping,
 * the response shape — is byte-for-byte the 4.x behaviour, because 862 tools
 * and every client that learned them depend on it.
 */
const CRM_API_BASE = 'https://services.leadconnectorhq.com';
const API_VERSION = '2021-07-28';

export function crmHeaders(accessToken) {
  return { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json', Version: API_VERSION };
}

const REGISTRY = new WeakMap(); // server → Set<toolName>
export function registeredCrmTools(server) { return REGISTRY.get(server) || new Set(); }

/**
 * @param {import('@modelcontextprotocol/sdk/server/mcp.js').McpServer} server
 * @param {import('zod')} z
 * @param {Array<object>} definitions
 * @param {{ resolveToken?: (args: any) => Promise<string|null>, fetch?: typeof fetch, onCall?: (info: any) => Promise<void> }} [options]
 * @returns {number} tools registered from this definition set
 */
export function registerTools(server, z, definitions, options = {}) {
  const names = REGISTRY.get(server) || new Set();
  REGISTRY.set(server, names);
  const fetchImpl = options.fetch || fetch;
  let count = 0;

  for (const def of definitions) {
    if (names.has(def.name)) continue; // generated-SDK collisions: first definition wins, same as 4.x
    names.add(def.name);
    count++;

    server.registerTool(def.name, { description: def.description, inputSchema: buildSchema(z, def) }, async (args = {}) => {
      try {
        if (options.allowTool) { const why = await options.allowTool(def, args); if (why) return { content: [{ type: 'text', text: JSON.stringify(typeof why === 'object' ? why : { error: why }) }] }; }
        if (!args.access_token && options.resolveToken) {
          const t = await options.resolveToken(args);
          if (t) args.access_token = t;
        }
        if (!args.access_token) {
          return { content: [{ type: 'text', text: JSON.stringify({ error: 'No CRM connection for this account and no access_token was passed. Add one: 0n3 vault push crm (or connect the CRM in your 0n account).' }) }] };
        }
        const headers = crmHeaders(args.access_token);
        // The CRM's 2026 API families (Managed Agents, Workflows) answer only to `Version: v3`; an execute also wants an
        // Idempotency-Key so a retried call cannot run the agent twice. Declared per definition; everything else is unchanged.
        if (def.version) headers.Version = def.version;
        if (def.idempotent) headers['Idempotency-Key'] = String(args.idempotency_key || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`);
        let url = CRM_API_BASE + def.path;
        url = url.replace(/:(\w+)/g, (_, key) => args[key] ?? args[toSnake(key)] ?? `:${key}`);

        if (def.method === 'GET' || def.query) {
          const qKeys = [...(def.query || [])];
          // ONCE. A def that already declares `locationId` in its query got it appended
          // a second time here whenever the vault supplied location_id, and the CRM
          // answers `?locationId=X&locationId=X` with "Invalid locationId format" (400)
          // or a bogus 403 — measured 2026-09-28 on links/search and emails/builder.
          if (args.location_id && !url.includes(args.location_id) && !qKeys.includes('locationId')) qKeys.push('locationId');
          const qs = new URLSearchParams();
          for (const key of qKeys) {
            const val = args[key] ?? args[toCamel(key)] ?? args[toSnake(key)];
            if (val !== undefined && val !== null) qs.append(key, String(val));
          }
          // …and the same guard here: a GET whose PATH carries the location must not get it
          // in the query too (GET /locations/:id/customFields → 422 "property locationId
          // should not exist"). Measured 2026-09-28; the fourth copy of one rule.
          if (args.location_id && !qs.has('locationId') && !url.includes(args.location_id)) qs.append('locationId', args.location_id);
          const s = qs.toString();
          if (s) url += (url.includes('?') ? '&' : '?') + s;
        }

        const init = { method: def.method, headers };
        if (def.method !== 'GET') {
          const bodyObj = {};
          // Same rule as the query: only when the path does not already carry the location.
          // POST /social-media-posting/:locationId/posts rejects a body locationId outright
          // ("property locationId should not exist", 422) — measured 2026-09-28.
          if (args.location_id && !url.includes(args.location_id)) bodyObj.locationId = args.location_id;
          for (const key of def.body || []) {
            const val = args[key] ?? args[toCamel(key)] ?? args[toSnake(key)];
            if (val !== undefined) bodyObj[key] = val;
          }
          for (const [pKey, pDef] of Object.entries(def.params || {})) if (pDef.in === 'body' && args[pKey] !== undefined) bodyObj[pKey] = args[pKey];
          // The generated v3 defs declare NO body for most POST/PUT endpoints, so a caller
          // had no way to send one: the MCP schema stripped unknown keys and the CRM answered
          // "locationId is required" to a create-link call that had passed everything.
          // Measured 2026-09-28. `body` is a declared field (see buildSchema) — explicit
          // fields still win over it, so a def that does declare its body is unchanged.
          if (args.body && typeof args.body === 'object' && !Array.isArray(args.body)) for (const [k, v] of Object.entries(args.body)) if (bodyObj[k] === undefined) bodyObj[k] = v;
          if (Object.keys(bodyObj).length) init.body = JSON.stringify(bodyObj);
        }

        const res = await fetchImpl(url, init);
        const data = await res.json().catch(() => ({ status: res.status, statusText: res.statusText }));
        if (options.onCall) await options.onCall({ service: 'crm', tool: def.name, ok: res.ok, status: res.status, locationId: args.location_id || null }).catch(() => {});
        return { content: [{ type: 'text', text: JSON.stringify({ success: res.ok, status: res.status, data }, null, 2) }] };
      } catch (err) {
        return { content: [{ type: 'text', text: JSON.stringify({ error: err.message }, null, 2) }] };
      }
    });
  }
  return count;
}

function buildSchema(z, def) {
  const schema = { access_token: z.string().optional().describe('CRM access token (optional — your connected CRM is used when omitted)') };
  if (def.method && def.method !== 'GET') schema.body = z.record(z.string(), z.any()).optional().describe('Request body fields for endpoints whose definition declares none (explicit fields win)');
  if (def.needsLocation !== false) schema.location_id = z.string().optional().describe('CRM sub-account location ID (optional — defaults to your connected location)');
  for (const [key, pDef] of Object.entries(def.params || {})) {
    let field;
    switch (pDef.type) {
      case 'number': field = z.number(); break;
      case 'boolean': field = z.boolean(); break;
      case 'object': field = z.record(z.string(), z.any()); break;
      case 'array': field = z.array(z.any()); break;
      case 'array_string': field = z.array(z.string()); break;
      default: field = z.string();
    }
    if (pDef.description) field = field.describe(pDef.description);
    if (!pDef.required) field = field.optional();
    schema[key] = field;
  }
  return schema;
}

const toCamel = (s) => s.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
const toSnake = (s) => s.replace(/[A-Z]/g, (c) => '_' + c.toLowerCase());

export { CRM_API_BASE, API_VERSION };
