// ============================================================
// 0nMCP — CRM v3.0.0 — knowledge-base
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_list",
      description: "Get all FAQs by knowledge base with pagination support. Retrieves FAQs for a knowledge base. Supports pagination using limit and lastFaqId parameters.",
      method: "GET",
      path: "/knowledge-bases/faqs",
      params: {
        knowledgeBaseId: {
          type: "string",
          description: "knowledgeBaseId (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        lastFaqId: {
          type: "string",
          description: "lastFaqId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["knowledgeBaseId", "locationId", "limit", "lastFaqId"]
    },
  {
      name: "crm_create",
      description: "Create a new FAQ inside knowledge base",
      method: "POST",
      path: "/knowledge-bases/faqs",
      params: {}
    },
  {
      name: "crm_update",
      description: "Update an existing knowledge base FAQ",
      method: "PUT",
      path: "/knowledge-bases/faqs/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_delete",
      description: "Delete an existing knowledge base FAQ",
      method: "DELETE",
      path: "/knowledge-bases/faqs/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAllWebsiteUrlsDataByKnowledgeBase",
      description: "Get all trained page links by knowledge base",
      method: "GET",
      path: "/knowledge-bases/crawler",
      params: {
        knowledgeBaseId: {
          type: "string",
          description: "knowledgeBaseId (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        pageLength: {
          type: "string",
          description: "pageLength (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["knowledgeBaseId", "locationId", "page", "pageLength", "query"]
    },
  {
      name: "crm_discoverWebsite",
      description: "Start crawling and discover pages for training",
      method: "POST",
      path: "/knowledge-bases/crawler",
      params: {}
    },
  {
      name: "crm_deleteTrainedUrlsForKnowledgeBase",
      description: "Delete trained pages",
      method: "DELETE",
      path: "/knowledge-bases/crawler",
      params: {}
    },
  {
      name: "crm_getCrawlingStatusForLatestOperation",
      description: "Get crawling status for the latest operation",
      method: "GET",
      path: "/knowledge-bases/crawler/status",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        operationId: {
          type: "string",
          description: "operationId (query param)",
          required: false,
          in: "query"
        },
        knowledgeBaseId: {
          type: "string",
          description: "knowledgeBaseId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "operationId", "knowledgeBaseId"]
    },
  {
      name: "crm_trainDiscoveredUrls",
      description: "Train discovered website pages and ingest into the knowledge base",
      method: "POST",
      path: "/knowledge-bases/crawler/train",
      params: {}
    },
  {
      name: "crm_getKnowledgeBaseById",
      description: "Get knowledge base by ID",
      method: "GET",
      path: "/knowledge-bases/:knowledgeBaseId",
      params: {
        knowledgeBaseId: {
          type: "string",
          description: "knowledgeBaseId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteKnowledgeBase",
      description: "Delete a knowledge base",
      method: "DELETE",
      path: "/knowledge-bases/:knowledgeBaseId",
      params: {
        knowledgeBaseId: {
          type: "string",
          description: "knowledgeBaseId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateKnowledgeBase",
      description: "Update a knowledge base",
      method: "PUT",
      path: "/knowledge-bases/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listAllKnowledgeBasesPaginated",
      description: "Get all knowledge bases for a location by location Id (paginated)",
      method: "GET",
      path: "/knowledge-bases/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        lastKnowledgeBaseId: {
          type: "string",
          description: "lastKnowledgeBaseId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "query", "limit", "lastKnowledgeBaseId"]
    },
  {
      name: "crm_createKnowledgeBase",
      description: "Create a new knowledge base (max 15 knowledge bases per location)",
      method: "POST",
      path: "/knowledge-bases/",
      params: {}
    }
];
