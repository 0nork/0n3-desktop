// ============================================================
// 0nMCP — CRM v3.0.0 — ad-manager
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_fbGetReporting",
      description: "Get reporting data. Retrieve aggregated Facebook ad reporting metrics for a location",
      method: "GET",
      path: "/ad-publishing/facebook/reporting",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        groupBy: {
          type: "string",
          description: "groupBy (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        fields: {
          type: "string",
          description: "fields (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "groupBy", "startDate", "endDate", "type", "fields"]
    },
  {
      name: "crm_fbGetCampaignReporting",
      description: "Get campaign reporting. Retrieve reporting metrics for a specific Facebook campaign",
      method: "GET",
      path: "/ad-publishing/facebook/reporting/campaign/:campaignId",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "startDate", "endDate"]
    },
  {
      name: "crm_fbGetReportingList",
      description: "Get reporting list. Retrieve a list of Facebook campaigns, adsets, or ads with reporting data",
      method: "GET",
      path: "/ad-publishing/facebook/reporting/list",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        listType: {
          type: "string",
          description: "listType (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "listType", "startDate", "endDate", "campaignId", "type"]
    },
  {
      name: "crm_fbGetCurrentUser",
      description: "Get current Facebook user. Retrieve the authenticated Facebook user profile for a location",
      method: "GET",
      path: "/ad-publishing/facebook/me",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbGetPages",
      description: "Get Facebook pages. Retrieve Facebook pages associated with the connected account",
      method: "GET",
      path: "/ad-publishing/facebook/pages",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        fetchExisting: {
          type: "string",
          description: "fetchExisting (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "fetchExisting"]
    },
  {
      name: "crm_fbGetInstagramAccounts",
      description: "Get Instagram accounts for page. Retrieve Instagram accounts linked to a specific Facebook page",
      method: "GET",
      path: "/ad-publishing/facebook/page/:pageId/instagram",
      params: {
        pageId: {
          type: "string",
          description: "pageId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type"]
    },
  {
      name: "crm_fbGetPageLeadForms",
      description: "Get page lead forms. Retrieve lead gen forms for a specific Facebook page",
      method: "GET",
      path: "/ad-publishing/facebook/page/:pageId/forms",
      params: {
        pageId: {
          type: "string",
          description: "pageId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbCreatePageLeadForm",
      description: "Create page lead form. Create a new lead gen form on a Facebook page",
      method: "POST",
      path: "/ad-publishing/facebook/page/:pageId/forms",
      params: {
        pageId: {
          type: "string",
          description: "pageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbGetAdAccounts",
      description: "Get ad accounts. Retrieve Facebook ad accounts available for the connected user",
      method: "GET",
      path: "/ad-publishing/facebook/ad-accounts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        next: {
          type: "string",
          description: "next (query param)",
          required: false,
          in: "query"
        },
        fetchAll: {
          type: "string",
          description: "fetchAll (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "next", "fetchAll", "limit"]
    },
  {
      name: "crm_fbGetAdAccount",
      description: "Get ad account details. Retrieve details of a specific Facebook ad account",
      method: "GET",
      path: "/ad-publishing/facebook/ad-accounts/:adAccountId",
      params: {
        adAccountId: {
          type: "string",
          description: "adAccountId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbDeleteAdAccount",
      description: "Delete ad account. Remove a Facebook ad account connection from a location",
      method: "DELETE",
      path: "/ad-publishing/facebook/ad-accounts/:adAccountId",
      params: {
        adAccountId: {
          type: "string",
          description: "adAccountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbGetConversationForms",
      description: "Get conversation forms. Retrieve Facebook conversation lead forms for a location",
      method: "GET",
      path: "/ad-publishing/facebook/conversation-forms",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbCreateConversationForm",
      description: "Create conversation form. Create a new Facebook conversation lead form",
      method: "POST",
      path: "/ad-publishing/facebook/conversation-forms",
      params: {}
    },
  {
      name: "crm_fbCreateIntegration",
      description: "Create Facebook integration. Create a Facebook ad integration for a location with page and ad account",
      method: "POST",
      path: "/ad-publishing/facebook/integration",
      params: {}
    },
  {
      name: "crm_fbGetIntegration",
      description: "Get Facebook integration. Retrieve the Facebook ad integration details for a location",
      method: "GET",
      path: "/ad-publishing/facebook/integration",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbDeleteIntegration",
      description: "Delete Facebook integration. Remove the Facebook ad integration from a location",
      method: "DELETE",
      path: "/ad-publishing/facebook/integration",
      params: {}
    },
  {
      name: "crm_fbSearchTargeting",
      description: "Search targeting options. Search Facebook geo-locations and interests for ad targeting",
      method: "GET",
      path: "/ad-publishing/facebook/targeting/search",
      params: {
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        searchType: {
          type: "string",
          description: "searchType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["type", "query", "searchType"]
    },
  {
      name: "crm_fbPublishCampaign",
      description: "Publish campaign. Publish a Facebook campaign and push it live to Facebook",
      method: "POST",
      path: "/ad-publishing/facebook/campaigns/:campaignId/publish",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDeletePage",
      description: "Delete page connection. Remove a Facebook page connection from a location",
      method: "DELETE",
      path: "/ad-publishing/facebook/page",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        pageId: {
          type: "string",
          description: "pageId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "pageId"]
    },
  {
      name: "crm_fbGetPixels",
      description: "Get conversion pixels. Retrieve Facebook conversion pixels for a location",
      method: "GET",
      path: "/ad-publishing/facebook/pixels",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        channel: {
          type: "string",
          description: "channel (query param)",
          required: false,
          in: "query"
        },
        pageId: {
          type: "string",
          description: "pageId (query param)",
          required: false,
          in: "query"
        },
        igUserId: {
          type: "string",
          description: "igUserId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "channel", "pageId", "igUserId"]
    },
  {
      name: "crm_fbUpsertPixel",
      description: "Upsert conversion pixel. Create or update a Facebook conversion pixel configuration",
      method: "PUT",
      path: "/ad-publishing/facebook/pixels",
      params: {}
    },
  {
      name: "crm_fbGetCustomAudiences",
      description: "Get custom audiences. Retrieve Facebook custom audiences for a location",
      method: "GET",
      path: "/ad-publishing/facebook/custom-audience",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        },
        adAccountId: {
          type: "string",
          description: "adAccountId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "source", "adAccountId"]
    },
  {
      name: "crm_fbDeleteCustomAudience",
      description: "Delete custom audience. Delete a Facebook custom audience by ID",
      method: "DELETE",
      path: "/ad-publishing/facebook/custom-audience/:audienceId",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbUpdateCustomAudience",
      description: "Update custom audience. Update name or description of a Facebook custom audience",
      method: "PUT",
      path: "/ad-publishing/facebook/custom-audience/:audienceId",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbGetCustomAudienceById",
      description: "Get custom audience by ID. Retrieve a specific Facebook custom audience by its ID",
      method: "GET",
      path: "/ad-publishing/facebook/custom-audience/:audienceId",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbAddCustomAudienceMember",
      description: "Add custom audience member. Add a member to a Facebook custom audience",
      method: "PUT",
      path: "/ad-publishing/facebook/custom-audience/:audienceId/member",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbRemoveCustomAudienceMember",
      description: "Remove custom audience member. Remove a member from a Facebook custom audience",
      method: "DELETE",
      path: "/ad-publishing/facebook/custom-audience/:audienceId/member",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbBatchUpdateAudienceMembers",
      description: "Batch update audience members. Add or remove members in bulk from a Facebook custom audience via CSV or smart lists",
      method: "PUT",
      path: "/ad-publishing/facebook/custom-audience/:audienceId/member/batch",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbSetDefaultPage",
      description: "Set default page. Set the default Facebook page for a location",
      method: "PUT",
      path: "/ad-publishing/facebook/page/default",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbGetLeadForm",
      description: "Get lead form by ID. Retrieve a specific Facebook lead form by its ID",
      method: "GET",
      path: "/ad-publishing/facebook/lead-form/:leadFormId",
      params: {
        leadFormId: {
          type: "string",
          description: "leadFormId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fbGetCampaign",
      description: "Get campaign with linked entities. Retrieve a Facebook campaign with its linked adsets and ads",
      method: "GET",
      path: "/ad-publishing/facebook/campaign/:campaignId",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        fields: {
          type: "string",
          description: "fields (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "fields", "source"]
    },
  {
      name: "crm_fbGetEntity",
      description: "Get entities. Retrieve Facebook campaigns, adsets, or ads based on entity type",
      method: "GET",
      path: "/ad-publishing/facebook/entity",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        next: {
          type: "string",
          description: "next (query param)",
          required: false,
          in: "query"
        },
        fetchAll: {
          type: "string",
          description: "fetchAll (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        adSetId: {
          type: "string",
          description: "adSetId (query param)",
          required: false,
          in: "query"
        },
        entityType: {
          type: "string",
          description: "entityType (query param)",
          required: false,
          in: "query"
        },
        searchId: {
          type: "string",
          description: "searchId (query param)",
          required: false,
          in: "query"
        },
        selectedAdAccountId: {
          type: "string",
          description: "selectedAdAccountId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "next", "fetchAll", "campaignId", "adSetId", "entityType", "searchId", "selectedAdAccountId"]
    },
  {
      name: "crm_fbUpsertCampaign",
      description: "Upsert campaign. Create or update a Facebook campaign",
      method: "PUT",
      path: "/ad-publishing/facebook/campaigns",
      params: {}
    },
  {
      name: "crm_fbUpsertAdset",
      description: "Upsert adset. Create or update a Facebook ad set",
      method: "PUT",
      path: "/ad-publishing/facebook/adsets",
      params: {}
    },
  {
      name: "crm_fbUpsertAd",
      description: "Upsert ad. Create or update a Facebook ad (v2)",
      method: "PUT",
      path: "/ad-publishing/facebook/ads-v2",
      params: {}
    },
  {
      name: "crm_fbPauseCampaign",
      description: "Pause campaign. Pause a running Facebook campaign",
      method: "POST",
      path: "/ad-publishing/facebook/campaigns/:campaignId/pause",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbResumeCampaign",
      description: "Resume campaign. Resume a paused Facebook campaign",
      method: "POST",
      path: "/ad-publishing/facebook/campaigns/:campaignId/resume",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDuplicateCampaign",
      description: "Duplicate campaign. Duplicate an existing Facebook campaign",
      method: "POST",
      path: "/ad-publishing/facebook/campaigns/:campaignId/duplicate",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDeleteCampaign",
      description: "Delete campaign. Delete a Facebook campaign by ID",
      method: "DELETE",
      path: "/ad-publishing/facebook/campaigns/:campaignId",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbPauseAdset",
      description: "Pause ad set. Pause a running Facebook ad set",
      method: "POST",
      path: "/ad-publishing/facebook/adsets/:adsetId/pause",
      params: {
        adsetId: {
          type: "string",
          description: "adsetId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbResumeAdset",
      description: "Resume ad set. Resume a paused Facebook ad set",
      method: "POST",
      path: "/ad-publishing/facebook/adsets/:adsetId/resume",
      params: {
        adsetId: {
          type: "string",
          description: "adsetId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDuplicateAdset",
      description: "Duplicate ad set. Duplicate an existing Facebook ad set",
      method: "POST",
      path: "/ad-publishing/facebook/adsets/:adsetId/duplicate",
      params: {
        adsetId: {
          type: "string",
          description: "adsetId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDeleteAdset",
      description: "Delete ad set. Delete a Facebook ad set by ID",
      method: "DELETE",
      path: "/ad-publishing/facebook/adsets/:adsetId",
      params: {
        adsetId: {
          type: "string",
          description: "adsetId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbPauseAd",
      description: "Pause ad. Pause a running Facebook ad",
      method: "POST",
      path: "/ad-publishing/facebook/ads/:adId/pause",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbResumeAd",
      description: "Resume ad. Resume a paused Facebook ad",
      method: "POST",
      path: "/ad-publishing/facebook/ads/:adId/resume",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDuplicateAd",
      description: "Duplicate ad. Duplicate an existing Facebook ad",
      method: "POST",
      path: "/ad-publishing/facebook/ads/:adId/duplicate",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fbDeleteAd",
      description: "Delete ad. Delete a Facebook ad by ID",
      method: "DELETE",
      path: "/ad-publishing/facebook/ads/:adId",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_googleGetReporting",
      description: "Get reporting data. Retrieve aggregated Google Ads reporting metrics for a location",
      method: "GET",
      path: "/ad-publishing/google/reporting",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        groupBy: {
          type: "string",
          description: "groupBy (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        fields: {
          type: "string",
          description: "fields (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "groupBy", "startDate", "endDate", "type", "fields"]
    },
  {
      name: "crm_googleGetReportingList",
      description: "Get reporting list. Retrieve a list of Google campaigns or ad groups with reporting data",
      method: "GET",
      path: "/ad-publishing/google/reporting/list",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        listType: {
          type: "string",
          description: "listType (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "listType", "startDate", "endDate", "campaignId", "type"]
    },
  {
      name: "crm_googleGetCampaignReporting",
      description: "Get campaign reporting. Retrieve reporting metrics for a specific Google campaign",
      method: "GET",
      path: "/ad-publishing/google/reporting/campaign/:campaignId",
      params: {
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "startDate", "endDate"]
    },
  {
      name: "crm_googleGetConversions",
      description: "Get conversions. Retrieve Google Ads conversion actions for a location",
      method: "GET",
      path: "/ad-publishing/google/conversions",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        conversionType: {
          type: "string",
          description: "conversionType (query param)",
          required: false,
          in: "query"
        },
        category: {
          type: "string",
          description: "category (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "conversionType", "category", "startDate", "endDate"]
    },
  {
      name: "crm_googleUpsertConversion",
      description: "Upsert conversion. Create or update a Google Ads conversion action",
      method: "PUT",
      path: "/ad-publishing/google/conversions",
      params: {}
    },
  {
      name: "crm_googleGetConversionById",
      description: "Get conversion by ID. Retrieve a specific Google Ads conversion action by ID",
      method: "GET",
      path: "/ad-publishing/google/conversions/:conversionId",
      params: {
        conversionId: {
          type: "string",
          description: "conversionId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleDeleteConversion",
      description: "Delete conversion. Delete a Google Ads conversion action by ID",
      method: "DELETE",
      path: "/ad-publishing/google/conversions/:conversionId",
      params: {
        conversionId: {
          type: "string",
          description: "conversionId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleGetIntegration",
      description: "Get Google integration. Retrieve the Google Ads integration details for a location",
      method: "GET",
      path: "/ad-publishing/google/integration",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleCreateIntegration",
      description: "Create Google integration. Create a Google Ads integration for a location",
      method: "POST",
      path: "/ad-publishing/google/integration",
      params: {}
    },
  {
      name: "crm_googleGetCurrentUser",
      description: "Get current Google user. Retrieve the authenticated Google user info for a location",
      method: "GET",
      path: "/ad-publishing/google/me",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleGetAdAccounts",
      description: "Get Google ad accounts. Retrieve Google Ads accounts available for the connected user",
      method: "GET",
      path: "/ad-publishing/google/ad-accounts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type"]
    },
  {
      name: "crm_googleGetAdAccountDetails",
      description: "Get ad account details. Retrieve details of a specific Google Ads account",
      method: "GET",
      path: "/ad-publishing/google/ad-accounts/:adAccountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        adAccountId: {
          type: "string",
          description: "adAccountId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleDeleteAdAccount",
      description: "Delete ad account. Remove a Google Ads account connection from a location",
      method: "DELETE",
      path: "/ad-publishing/google/ad-accounts/:adAccountId",
      params: {
        adAccountId: {
          type: "string",
          description: "adAccountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_googlePublishAd",
      description: "Publish ad. Publish a Google ad and push it live",
      method: "POST",
      path: "/ad-publishing/google/ads/:adId/publish",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_googleSearchTargeting",
      description: "Search targeting options. Search Google geo-locations for ad targeting",
      method: "GET",
      path: "/ad-publishing/google/targeting/search",
      params: {
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["type", "query", "locationId"]
    },
  {
      name: "crm_googleGetKeywordIdeas",
      description: "Get keyword ideas. Retrieve keyword suggestions for Google Ads campaigns",
      method: "POST",
      path: "/ad-publishing/google/keyword-ideas",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleGetAssets",
      description: "Get assets. Retrieve Google Ads creative assets for a location",
      method: "GET",
      path: "/ad-publishing/google/assets",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        id: {
          type: "string",
          description: "id (query param)",
          required: false,
          in: "query"
        },
        advertiserOnly: {
          type: "string",
          description: "advertiserOnly (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "id", "advertiserOnly"]
    },
  {
      name: "crm_googleUpsertAssets",
      description: "Upsert assets. Create or update Google Ads creative assets",
      method: "POST",
      path: "/ad-publishing/google/assets",
      params: {}
    },
  {
      name: "crm_googleGetEntity",
      description: "Get entities. Retrieve Google campaigns, ad groups, or ads based on entity type",
      method: "GET",
      path: "/ad-publishing/google/entity",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        adGroupId: {
          type: "string",
          description: "adGroupId (query param)",
          required: false,
          in: "query"
        },
        entityType: {
          type: "string",
          description: "entityType (query param)",
          required: false,
          in: "query"
        },
        searchId: {
          type: "string",
          description: "searchId (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        selectedAdAccountId: {
          type: "string",
          description: "selectedAdAccountId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "campaignId", "adGroupId", "entityType", "searchId", "startDate", "endDate", "selectedAdAccountId"]
    },
  {
      name: "crm_googleGetTargetInterests",
      description: "Get target interests. Retrieve affinity and in-market audience options for Google Ads targeting",
      method: "GET",
      path: "/ad-publishing/google/target-interests",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        advertisingChannelType: {
          type: "string",
          description: "advertisingChannelType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "advertisingChannelType"]
    },
  {
      name: "crm_googleGetSegments",
      description: "Get segments. Retrieve Google Ads audience segments for a location",
      method: "GET",
      path: "/ad-publishing/google/segments",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type"]
    },
  {
      name: "crm_googleUpsertSegment",
      description: "Upsert segment. Create or update a Google Ads audience segment",
      method: "PUT",
      path: "/ad-publishing/google/segments",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type"]
    },
  {
      name: "crm_googleDeleteSegment",
      description: "Delete segment. Delete a Google Ads audience segment by ID",
      method: "DELETE",
      path: "/ad-publishing/google/segments/:segmentId",
      params: {
        segmentId: {
          type: "string",
          description: "segmentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type"]
    },
  {
      name: "crm_googleGetSegmentById",
      description: "Get segment by ID. Retrieve a specific Google Ads audience segment by ID",
      method: "GET",
      path: "/ad-publishing/google/segments/:segmentId",
      params: {
        segmentId: {
          type: "string",
          description: "segmentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type"]
    },
  {
      name: "crm_googleCreateOfflineUserListJob",
      description: "Create offline user list job. Create a job to upload users to a Google customer match list",
      method: "POST",
      path: "/ad-publishing/google/segments/offline-user-list-job",
      params: {}
    },
  {
      name: "crm_googleUpsertAudience",
      description: "Upsert audience. Create or update a Google Ads combined audience",
      method: "PUT",
      path: "/ad-publishing/google/audiences",
      params: {}
    },
  {
      name: "crm_googleGetAudiences",
      description: "Get audiences. Retrieve Google Ads combined audiences for a location",
      method: "GET",
      path: "/ad-publishing/google/audiences",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleGetAudienceById",
      description: "Get audience by ID. Retrieve a specific Google Ads combined audience by ID",
      method: "GET",
      path: "/ad-publishing/google/audiences/:audienceId",
      params: {
        audienceId: {
          type: "string",
          description: "audienceId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleUpsertCampaign",
      description: "Upsert Google campaign. Create or update a full Google Ads campaign structure",
      method: "PUT",
      path: "/ad-publishing/google/ads",
      params: {}
    },
  {
      name: "crm_googleGetCampaignById",
      description: "Get Google campaign by ID. Retrieve a specific Google Ads campaign by ID",
      method: "GET",
      path: "/ad-publishing/google/ads/:adId",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_googleGetConversionGoals",
      description: "Get conversion goals. Retrieve Google Ads conversion goals for a location",
      method: "GET",
      path: "/ad-publishing/google/conversion-goals",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liGetIntegration",
      description: "Get LinkedIn integration. Retrieve the LinkedIn Ads integration details for a location",
      method: "GET",
      path: "/ad-publishing/linkedin/integration",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liCreateIntegration",
      description: "Create LinkedIn integration. Create a LinkedIn Ads integration for a location with ad account details",
      method: "POST",
      path: "/ad-publishing/linkedin/integration",
      params: {}
    },
  {
      name: "crm_liGetAdAccounts",
      description: "Get LinkedIn ad accounts. Retrieve LinkedIn Ads accounts available for the connected user",
      method: "GET",
      path: "/ad-publishing/linkedin/ad-accounts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liGetAdAccountDetails",
      description: "Get ad account details. Retrieve details of a specific LinkedIn ad account",
      method: "GET",
      path: "/ad-publishing/linkedin/ad-account",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        adAccountId: {
          type: "string",
          description: "adAccountId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "adAccountId"]
    },
  {
      name: "crm_liDeleteAdAccount",
      description: "Delete ad account. Remove a LinkedIn ad account connection from a location",
      method: "DELETE",
      path: "/ad-publishing/linkedin/ad-account",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        adAccountId: {
          type: "string",
          description: "adAccountId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "adAccountId"]
    },
  {
      name: "crm_liGetCurrentUser",
      description: "Get current LinkedIn user. Retrieve the authenticated LinkedIn user info for a location",
      method: "GET",
      path: "/ad-publishing/linkedin/me",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liGetCampaignGroup",
      description: "Get ad campaign group. Retrieve a LinkedIn ad campaign group by ID",
      method: "GET",
      path: "/ad-publishing/linkedin/ads/:adId",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liPublishCampaignGroup",
      description: "Publish ad campaign group. Publish a LinkedIn ad campaign group and push it live",
      method: "POST",
      path: "/ad-publishing/linkedin/ads/:adId/publish",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_liUpsertCampaignGroup",
      description: "Upsert ad campaign group. Create or update a LinkedIn ad campaign group with campaigns and ads",
      method: "PUT",
      path: "/ad-publishing/linkedin/ads",
      params: {}
    },
  {
      name: "crm_liSearchTargeting",
      description: "Search targeting options. Search LinkedIn targeting facets such as locations, industries, and job titles",
      method: "GET",
      path: "/ad-publishing/linkedin/targeting/search",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        facet: {
          type: "string",
          description: "facet (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        q: {
          type: "string",
          description: "q (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "facet", "query", "q"]
    },
  {
      name: "crm_liGetLeadForms",
      description: "Get lead forms. Retrieve LinkedIn lead gen forms for an ad account",
      method: "GET",
      path: "/ad-publishing/linkedin/:accountId/forms",
      params: {
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liCreateLeadForm",
      description: "Create lead form. Create a new LinkedIn lead gen form for an ad account",
      method: "POST",
      path: "/ad-publishing/linkedin/:accountId/form",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liUpdateAdStatus",
      description: "Update ad status. Pause or resume a LinkedIn ad, campaign, or ad group",
      method: "PATCH",
      path: "/ad-publishing/linkedin/:adId/status",
      params: {
        adId: {
          type: "string",
          description: "adId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_liGetAdAnalytics",
      description: "Get ad analytics. Retrieve LinkedIn Ads analytics data with configurable pivot and time grouping",
      method: "GET",
      path: "/ad-publishing/linkedin/reporting",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        pivot: {
          type: "string",
          description: "pivot (query param)",
          required: false,
          in: "query"
        },
        groupBy: {
          type: "string",
          description: "groupBy (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        entityUrns: {
          type: "string",
          description: "entityUrns (query param)",
          required: false,
          in: "query"
        },
        fields: {
          type: "string",
          description: "fields (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "pivot", "groupBy", "startDate", "endDate", "entityUrns", "fields"]
    },
  {
      name: "crm_liGetReportingList",
      description: "Get reporting list. Retrieve a list of LinkedIn campaigns or campaign groups with reporting data",
      method: "GET",
      path: "/ad-publishing/linkedin/reporting/list",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        listType: {
          type: "string",
          description: "listType (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        campaignGroupId: {
          type: "string",
          description: "campaignGroupId (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        fields: {
          type: "string",
          description: "fields (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "listType", "campaignId", "campaignGroupId", "startDate", "endDate", "fields"]
    },
  {
      name: "crm_liGetCampaignGroupReporting",
      description: "Get campaign group reporting. Retrieve reporting metrics for a specific LinkedIn campaign group",
      method: "GET",
      path: "/ad-publishing/linkedin/reporting/campaign-group/:campaignGroupId",
      params: {
        campaignGroupId: {
          type: "string",
          description: "campaignGroupId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        fields: {
          type: "string",
          description: "fields (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "startDate", "endDate", "fields"]
    }
];
