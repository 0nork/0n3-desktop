// ============================================================
// 0nMCP — CRM v3.0.0 — courses
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_importCourses",
      description: "Import Courses. Import Courses through public channels",
      method: "POST",
      path: "/courses/courses-exporter/public/import",
      params: {}
    }
];
