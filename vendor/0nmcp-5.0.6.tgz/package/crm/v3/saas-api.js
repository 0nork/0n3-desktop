// ============================================================
// 0nMCP — CRM v3.0.0 — saas-api
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_locationsDeprecated",
      description: "Get locations by stripeId with companyId. Get locations by stripeCustomerId or stripeSubscriptionId with companyId @deprecated This method is deprecated",
      method: "GET",
      path: "/saas-api/public-api/locations",
      params: {
        customerId: {
          type: "string",
          description: "customerId (query param)",
          required: false,
          in: "query"
        },
        subscriptionId: {
          type: "string",
          description: "subscriptionId (query param)",
          required: false,
          in: "query"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["customerId", "subscriptionId", "companyId"]
    },
  {
      name: "crm_updateSaasSubscriptionDeprecated",
      description: "Update SaaS subscription. Update SaaS subscription for given locationId and customerId @deprecated This method is deprecated",
      method: "PUT",
      path: "/saas-api/public-api/update-saas-subscription/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_bulkDisableSaasDeprecated",
      description: "Disable SaaS for locations. Disable SaaS for locations for given locationIds @deprecated This method is deprecated",
      method: "POST",
      path: "/saas-api/public-api/bulk-disable-saas/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_enableSaasLocationDeprecated",
      description: "Enable SaaS for Sub-Account (Formerly Location). &lt;div&gt; &lt;p&gt;Enable SaaS for Sub-Account (Formerly Location) based on the data provided&lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; This feature is only available on Agency Pro ($497) plan. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt; @deprecated This method is deprecated",
      method: "POST",
      path: "/saas-api/public-api/enable-saas/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_pauseLocationDeprecated",
      description: "Pause location. Pause Sub account for given locationId @deprecated This method is deprecated Use Sub account for given locationId instead.",
      method: "POST",
      path: "/saas-api/public-api/pause/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateRebillingDeprecated",
      description: "Update Rebilling. Bulk update rebilling for given locationIds @deprecated This method is deprecated",
      method: "POST",
      path: "/saas-api/public-api/update-rebilling/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAgencyPlansDeprecated",
      description: "Get Agency Plans. Fetch all agency subscription plans for a given company ID @deprecated This method is deprecated",
      method: "GET",
      path: "/saas-api/public-api/agency-plans/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getLocationSubscriptionDeprecated",
      description: "Get Location Subscription Details. Fetch subscription details for a specific location from location metadata @deprecated This method is deprecated",
      method: "GET",
      path: "/saas-api/public-api/get-saas-subscription/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId"]
    },
  {
      name: "crm_bulkEnableSaasDeprecated",
      description: "Bulk Enable SaaS. Enable SaaS mode for multiple locations with support for both SaaS v1 and v2 @deprecated This method is deprecated",
      method: "POST",
      path: "/saas-api/public-api/bulk-enable-saas/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getSaasLocationsDeprecated",
      description: "Get SaaS Locations. Fetch all SaaS-activated locations for a company with pagination @deprecated This method is deprecated",
      method: "GET",
      path: "/saas-api/public-api/saas-locations/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["page"]
    },
  {
      name: "crm_getSaasPlanDeprecated",
      description: "Get SaaS Plan. Fetch a specific SaaS plan by plan ID @deprecated This method is deprecated",
      method: "GET",
      path: "/saas-api/public-api/saas-plan/:planId",
      params: {
        planId: {
          type: "string",
          description: "planId (path param)",
          required: true,
          in: "path"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId"]
    },
  {
      name: "crm_locations",
      description: "Get locations by stripeId with companyId. Get locations by stripeCustomerId or stripeSubscriptionId with companyId",
      method: "GET",
      path: "/saas/locations",
      params: {
        customerId: {
          type: "string",
          description: "customerId (query param)",
          required: false,
          in: "query"
        },
        subscriptionId: {
          type: "string",
          description: "subscriptionId (query param)",
          required: false,
          in: "query"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["customerId", "subscriptionId", "companyId"]
    },
  {
      name: "crm_generatePaymentLink",
      description: "Update SaaS subscription. Update SaaS subscription for given locationId and customerId",
      method: "PUT",
      path: "/saas/update-saas-subscription/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_bulkDisableSaas",
      description: "Disable SaaS for locations. Disable SaaS for locations for given locationIds",
      method: "POST",
      path: "/saas/bulk-disable-saas/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_enableSaasLocation",
      description: "Enable SaaS for Sub-Account (Formerly Location). &lt;div&gt; &lt;p&gt;Enable SaaS for Sub-Account (Formerly Location) based on the data provided&lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; This feature is only available on Agency Pro ($497) plan. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "POST",
      path: "/saas/enable-saas/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_pauseLocation",
      description: "Pause location. Pause Sub account for given locationId",
      method: "POST",
      path: "/saas/pause/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateRebilling",
      description: "Update Rebilling. Bulk update rebilling for given locationIds",
      method: "POST",
      path: "/saas/update-rebilling/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAgencyPlans",
      description: "Get Agency Plans. Fetch all agency subscription plans for a given company ID",
      method: "GET",
      path: "/saas/agency-plans/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getLocationSubscription",
      description: "Get Location Subscription Details. Fetch subscription details for a specific location from location metadata",
      method: "GET",
      path: "/saas/get-saas-subscription/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId"]
    },
  {
      name: "crm_bulkEnableSaas",
      description: "Bulk Enable SaaS. Enable SaaS mode for multiple locations with support for both SaaS v1 and v2",
      method: "POST",
      path: "/saas/bulk-enable-saas/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getSaasLocations",
      description: "Get SaaS Locations. Fetch all SaaS-activated locations for a company with pagination",
      method: "GET",
      path: "/saas/saas-locations/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["page"]
    },
  {
      name: "crm_getSaasPlan",
      description: "Get SaaS Plan. Fetch a specific SaaS plan by plan ID",
      method: "GET",
      path: "/saas/saas-plan/:planId",
      params: {
        planId: {
          type: "string",
          description: "planId (path param)",
          required: true,
          in: "path"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId"]
    }
];
