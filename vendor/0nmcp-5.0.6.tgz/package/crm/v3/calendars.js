// ============================================================
// 0nMCP — CRM v3.0.0 — calendars
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getGroups",
      description: "Get Groups. Get all calendar groups in a location.",
      method: "GET",
      path: "/calendars/groups",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createCalendarGroup",
      description: "Create Calendar Group. Create Calendar Group",
      method: "POST",
      path: "/calendars/groups",
      params: {}
    },
  {
      name: "crm_validateGroupsSlug",
      description: "Validate group slug. Validate if group slug is available or not.",
      method: "POST",
      path: "/calendars/groups/validate-slug",
      params: {}
    },
  {
      name: "crm_deleteGroup",
      description: "Delete Group. Delete Group",
      method: "DELETE",
      path: "/calendars/groups/:groupId",
      params: {
        groupId: {
          type: "string",
          description: "groupId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_editGroup",
      description: "Update Group. Update Group by group ID",
      method: "PUT",
      path: "/calendars/groups/:groupId",
      params: {
        groupId: {
          type: "string",
          description: "groupId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_disableGroup",
      description: "Disable Group. Disable Group",
      method: "PUT",
      path: "/calendars/groups/:groupId/status",
      params: {
        groupId: {
          type: "string",
          description: "groupId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createAppointment",
      description: "Create appointment. Create appointment",
      method: "POST",
      path: "/calendars/events/appointments",
      params: {}
    },
  {
      name: "crm_editAppointment",
      description: "Update Appointment. Update appointment",
      method: "PUT",
      path: "/calendars/events/appointments/:eventId",
      params: {
        eventId: {
          type: "string",
          description: "eventId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAppointment",
      description: "Get Appointment. Get appointment by ID",
      method: "GET",
      path: "/calendars/events/appointments/:eventId",
      params: {
        eventId: {
          type: "string",
          description: "eventId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCalendarEvents",
      description: "Get Calendar Events. Get Calendar Events",
      method: "GET",
      path: "/calendars/events",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        calendarId: {
          type: "string",
          description: "calendarId (query param)",
          required: false,
          in: "query"
        },
        groupId: {
          type: "string",
          description: "groupId (query param)",
          required: false,
          in: "query"
        },
        startTime: {
          type: "string",
          description: "startTime (query param)",
          required: false,
          in: "query"
        },
        endTime: {
          type: "string",
          description: "endTime (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "calendarId", "groupId", "startTime", "endTime"]
    },
  {
      name: "crm_getBlockedSlots",
      description: "Get Blocked Slots. Get Blocked Slots",
      method: "GET",
      path: "/calendars/blocked-slots",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        calendarId: {
          type: "string",
          description: "calendarId (query param)",
          required: false,
          in: "query"
        },
        groupId: {
          type: "string",
          description: "groupId (query param)",
          required: false,
          in: "query"
        },
        startTime: {
          type: "string",
          description: "startTime (query param)",
          required: false,
          in: "query"
        },
        endTime: {
          type: "string",
          description: "endTime (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "calendarId", "groupId", "startTime", "endTime"]
    },
  {
      name: "crm_createBlockSlot",
      description: "Create Block Slot. Create block slot",
      method: "POST",
      path: "/calendars/events/block-slots",
      params: {}
    },
  {
      name: "crm_editBlockSlot",
      description: "Update Block Slot. Update block slot by ID",
      method: "PUT",
      path: "/calendars/events/block-slots/:eventId",
      params: {
        eventId: {
          type: "string",
          description: "eventId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getSlots",
      description: "Get Free Slots. Get free slots for a calendar between a date range. Optionally a consumer can also request free slots in a particular timezone and also for a particular user.",
      method: "GET",
      path: "/calendars/:calendarId/free-slots",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        timezone: {
          type: "string",
          description: "timezone (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        userIds: {
          type: "string",
          description: "userIds (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["startDate", "endDate", "timezone", "userId", "userIds"]
    },
  {
      name: "crm_updateCalendar",
      description: "Update Calendar. Update calendar by ID.",
      method: "PUT",
      path: "/calendars/:calendarId",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCalendar",
      description: "Get Calendar. Get calendar by ID",
      method: "GET",
      path: "/calendars/:calendarId",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCalendar",
      description: "Delete Calendar. Delete calendar by ID",
      method: "DELETE",
      path: "/calendars/:calendarId",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteEvent",
      description: "Delete Event. Delete event by ID",
      method: "DELETE",
      path: "/calendars/events/:eventId",
      params: {
        eventId: {
          type: "string",
          description: "eventId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAppointmentNotes",
      description: "Get Notes. Get Appointment Notes",
      method: "GET",
      path: "/calendars/appointments/:appointmentId/notes",
      params: {
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        appointmentId: {
          type: "string",
          description: "appointmentId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["limit", "offset"]
    },
  {
      name: "crm_createAppointmentNote",
      description: "Create Note. Create Note",
      method: "POST",
      path: "/calendars/appointments/:appointmentId/notes",
      params: {
        appointmentId: {
          type: "string",
          description: "appointmentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateAppointmentNote",
      description: "Update Note. Update Note",
      method: "PUT",
      path: "/calendars/appointments/:appointmentId/notes/:noteId",
      params: {
        appointmentId: {
          type: "string",
          description: "appointmentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteAppointmentNote",
      description: "Delete Note. Delete Note",
      method: "DELETE",
      path: "/calendars/appointments/:appointmentId/notes/:noteId",
      params: {
        appointmentId: {
          type: "string",
          description: "appointmentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCalendarResource",
      description: "Get Calendar Resource. Get calendar resource by ID",
      method: "GET",
      path: "/calendars/resources/:resourceType/:id",
      params: {
        resourceType: {
          type: "string",
          description: "resourceType (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateCalendarResource",
      description: "Update Calendar Resource. Update calendar resource by ID",
      method: "PUT",
      path: "/calendars/resources/:resourceType/:id",
      params: {
        resourceType: {
          type: "string",
          description: "resourceType (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCalendarResource",
      description: "Delete Calendar Resource. Delete calendar resource by ID",
      method: "DELETE",
      path: "/calendars/resources/:resourceType/:id",
      params: {
        resourceType: {
          type: "string",
          description: "resourceType (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_fetchCalendarResources",
      description: "List Calendar Resources. List calendar resources by resource type and location ID",
      method: "GET",
      path: "/calendars/resources/:resourceType",
      params: {
        resourceType: {
          type: "string",
          description: "resourceType (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "skip"]
    },
  {
      name: "crm_createCalendarResource",
      description: "Create Calendar Resource. Create calendar resource by resource type",
      method: "POST",
      path: "/calendars/resources/:resourceType",
      params: {
        resourceType: {
          type: "string",
          description: "resourceType (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getEventNotification",
      description: "Get notifications. Get calendar notifications based on query",
      method: "GET",
      path: "/calendars/:calendarId/notifications",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        },
        isActive: {
          type: "string",
          description: "isActive (query param)",
          required: false,
          in: "query"
        },
        deleted: {
          type: "boolean",
          description: "deleted (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["isActive", "deleted", "limit", "skip"]
    },
  {
      name: "crm_createEventNotification",
      description: "Create notification. Create Calendar notifications, either one or multiple. All notification settings must be for single calendar only",
      method: "POST",
      path: "/calendars/:calendarId/notifications",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_findEventNotification",
      description: "Get notification. Find Event notification by notificationId",
      method: "GET",
      path: "/calendars/:calendarId/notifications/:notificationId",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        },
        notificationId: {
          type: "string",
          description: "notificationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateEventNotification",
      description: "Update notification. Update Event notification by id",
      method: "PUT",
      path: "/calendars/:calendarId/notifications/:notificationId",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        },
        notificationId: {
          type: "string",
          description: "notificationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteEventNotification",
      description: "Delete Notification. Delete notification",
      method: "DELETE",
      path: "/calendars/:calendarId/notifications/:notificationId",
      params: {
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        },
        notificationId: {
          type: "string",
          description: "notificationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAllSchedules",
      description: "List user availability schedule. Retrieve user availability schedules based on various filters including location, calendar, and user. Supports pagination.",
      method: "GET",
      path: "/calendars/schedules/search",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        calendarId: {
          type: "string",
          description: "calendarId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "calendarId", "skip", "limit"]
    },
  {
      name: "crm_getScheduleById",
      description: "Get user availability schedule. Retrieve a specific schedule by its unique identifier. Returns detailed information including rules, timezone, and associated calendars/users.",
      method: "GET",
      path: "/calendars/schedules/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateSchedule",
      description: "Update user availability schedule. Modify an existing schedule by updating its rules, timezone, and name All fields are optional - only provided fields will be updated.",
      method: "PUT",
      path: "/calendars/schedules/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteSchedule",
      description: "Delete user availability schedule. Permanently remove a schedule and all its associated rules. This action cannot be undone.",
      method: "DELETE",
      path: "/calendars/schedules/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createSchedule",
      description: "Create user availability schedule. Create new schedule with specified rules, timezone, location, user and calendar associations.",
      method: "POST",
      path: "/calendars/schedules",
      params: {}
    },
  {
      name: "crm_addCalendarToSchedule",
      description: "Apply user availability schedule to a calendar. Associates a calendar with the given schedule by adding the calendarId to a schedule",
      method: "PUT",
      path: "/calendars/schedules/:id/associations/:calendarId",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_removeCalendarFromSchedule",
      description: "Remove user availability schedule from a calendar. Removes the association between a team calendar and the given schedule by removing the calendarId from the schedule",
      method: "DELETE",
      path: "/calendars/schedules/:id/associations/:calendarId",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        calendarId: {
          type: "string",
          description: "calendarId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCalendars",
      description: "Get Calendars. Get all calendars in a location.",
      method: "GET",
      path: "/calendars/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        groupId: {
          type: "string",
          description: "groupId (query param)",
          required: false,
          in: "query"
        },
        showDrafted: {
          type: "string",
          description: "showDrafted (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "groupId", "showDrafted"]
    },
  {
      name: "crm_createCalendar",
      description: "Create Calendar. Create calendar in a location.",
      method: "POST",
      path: "/calendars/",
      params: {}
    }
];
