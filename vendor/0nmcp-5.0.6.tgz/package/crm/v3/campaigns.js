// ============================================================
// 0nMCP — CRM v3.0.0 — campaigns
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getCampaigns",
      description: "Get Campaigns. Get Campaigns",
      method: "GET",
      path: "/campaigns/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "status"]
    }
];
