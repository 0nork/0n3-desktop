// ============================================================
// 0nMCP — CRM v3.0.0 — surveys
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getSurveysSubmissions",
      description: "Get Surveys Submissions. Get Surveys Submissions",
      method: "GET",
      path: "/surveys/submissions",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        surveyId: {
          type: "string",
          description: "surveyId (query param)",
          required: false,
          in: "query"
        },
        q: {
          type: "string",
          description: "q (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "page", "limit", "surveyId", "q", "startAt", "endAt"]
    },
  {
      name: "crm_getSurveys",
      description: "Get Surveys. Get Surveys",
      method: "GET",
      path: "/surveys/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "skip", "limit", "type"]
    }
];
