// ============================================================
// 0nMCP — CRM v3.0.0 — blogs
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_checkUrlSlugExists",
      description: "Check url slug. The &quot;Check url slug&quot; API allows check the blog slug validation which is needed before publishing any blog post. Please use blogs/check-slug.readonly. you can find the POST ID from the post edit url.",
      method: "GET",
      path: "/blogs/posts/url-slug-exists",
      params: {
        urlSlug: {
          type: "string",
          description: "urlSlug (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        postId: {
          type: "string",
          description: "postId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["urlSlug", "locationId", "postId"]
    },
  {
      name: "crm_updateBlogPost",
      description: "Update Blog Post. The &quot;Update Blog Post&quot; API allows you update blog post for any given blog site. Please use blogs/post-update.write",
      method: "PUT",
      path: "/blogs/posts/:postId",
      params: {}
    },
  {
      name: "crm_createBlogPost",
      description: "Create Blog Post. The &quot;Create Blog Post&quot; API allows you create blog post for any given blog site. Please use blogs/post.write",
      method: "POST",
      path: "/blogs/posts",
      params: {}
    },
  {
      name: "crm_getAllBlogAuthorsByLocation",
      description: "Get all authors. The &quot;Get all authors&quot; Api return the blog authors for a given location ID. Please use &quot;blogs/author.readonly&quot;",
      method: "GET",
      path: "/blogs/authors",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "offset"]
    },
  {
      name: "crm_getAllCategoriesByLocation",
      description: "Get all categories. The &quot;Get all categories&quot; Api return the blog categoies for a given location ID. Please use &quot;blogs/category.readonly&quot;",
      method: "GET",
      path: "/blogs/categories",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "offset"]
    },
  {
      name: "crm_getBlogPost",
      description: "Get Blog posts by Blog ID. The &quot;Get Blog posts by Blog ID&quot; API allows you get blog posts for any given blog site using blog ID.Please use blogs/posts.readonly",
      method: "GET",
      path: "/blogs/posts/all",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        blogId: {
          type: "string",
          description: "blogId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        searchTerm: {
          type: "string",
          description: "searchTerm (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "blogId", "limit", "offset", "searchTerm", "status"]
    },
  {
      name: "crm_getBlogs",
      description: "Get Blogs by Location ID. The &quot;Get Blogs by Location ID&quot; API allows you get blogs using Location ID.Please use blogs/list.readonly",
      method: "GET",
      path: "/blogs/site/all",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        searchTerm: {
          type: "string",
          description: "searchTerm (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "skip", "limit", "searchTerm"]
    }
];
