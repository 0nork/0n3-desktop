// ============================================================
// 0nMCP — CRM v3.0.0 — locations
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_searchLocations",
      description: "Search. Search Sub-Account (Formerly Location)",
      method: "GET",
      path: "/locations/search",
      params: {
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        order: {
          type: "string",
          description: "order (query param)",
          required: false,
          in: "query"
        },
        email: {
          type: "string",
          description: "email (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId", "skip", "limit", "order", "email"]
    },
  {
      name: "crm_getLocation",
      description: "Get Sub-Account (Formerly Location). Get details of a Sub-Account (Formerly Location) by passing the sub-account id",
      method: "GET",
      path: "/locations/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_putLocation",
      description: "Put Sub-Account (Formerly Location). Update a Sub-Account (Formerly Location) based on the data provided",
      method: "PUT",
      path: "/locations/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteLocation",
      description: "Delete Sub-Account (Formerly Location). Delete a Sub-Account (Formerly Location) from the Agency",
      method: "DELETE",
      path: "/locations/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        deleteTwilioAccount: {
          type: "string",
          description: "deleteTwilioAccount (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["deleteTwilioAccount"]
    },
  {
      name: "crm_getLocationTags",
      description: "Get Tags. Get Sub-Account (Formerly Location) Tags",
      method: "GET",
      path: "/locations/:locationId/tags",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createTag",
      description: "Create Tag. Create tag",
      method: "POST",
      path: "/locations/:locationId/tags",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getTagById",
      description: "Get tag by id. Get tag by id",
      method: "GET",
      path: "/locations/:locationId/tags/:tagId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        tagId: {
          type: "string",
          description: "tagId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateTag",
      description: "Update tag. Update tag",
      method: "PUT",
      path: "/locations/:locationId/tags/:tagId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        tagId: {
          type: "string",
          description: "tagId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteTag",
      description: "Delete tag. Delete tag",
      method: "DELETE",
      path: "/locations/:locationId/tags/:tagId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        tagId: {
          type: "string",
          description: "tagId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_taskSearch",
      description: "Task Search Filter. Task Search",
      method: "POST",
      path: "/locations/:locationId/tasks/search",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getRecurringTaskById",
      description: "Get Recurring Task By Id. Get Recurring Task By Id",
      method: "GET",
      path: "/locations/:locationId/recurring-tasks/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateRecurringTask",
      description: "Update Recurring Task. Update Recurring Task",
      method: "PUT",
      path: "/locations/:locationId/recurring-tasks/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteRecurringTask",
      description: "Delete Recurring Task. Delete Recurring Task",
      method: "DELETE",
      path: "/locations/:locationId/recurring-tasks/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createRecurringTask",
      description: "Create Recurring Task. Create Recurring Task",
      method: "POST",
      path: "/locations/:locationId/recurring-tasks",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCustomFields",
      description: "Get Custom Fields. Get Custom Fields",
      method: "GET",
      path: "/locations/:locationId/customFields",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        model: {
          type: "string",
          description: "model (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["model"]
    },
  {
      name: "crm_locations_createCustomField",
      description: "Create Custom Field. Create Custom Field",
      method: "POST",
      path: "/locations/:locationId/customFields",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCustomField",
      description: "Get Custom Field. Get Custom Field",
      method: "GET",
      path: "/locations/:locationId/customFields/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_locations_updateCustomField",
      description: "Update Custom Field. Update Custom Field",
      method: "PUT",
      path: "/locations/:locationId/customFields/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_locations_deleteCustomField",
      description: "Delete Custom Field. Delete Custom Field",
      method: "DELETE",
      path: "/locations/:locationId/customFields/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_uploadFileCustomFields",
      description: "Uploads File to customFields. Uploads File to customFields",
      method: "POST",
      path: "/locations/:locationId/customFields/upload",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCustomValues",
      description: "Get Custom Values. Get Custom Values",
      method: "GET",
      path: "/locations/:locationId/customValues",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createCustomValue",
      description: "Create Custom Value. Create Custom Value",
      method: "POST",
      path: "/locations/:locationId/customValues",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCustomValue",
      description: "Get Custom Value. Get Custom Value",
      method: "GET",
      path: "/locations/:locationId/customValues/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateCustomValue",
      description: "Update Custom Value. Update Custom Value",
      method: "PUT",
      path: "/locations/:locationId/customValues/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCustomValue",
      description: "Delete Custom Value. Delete Custom Value",
      method: "DELETE",
      path: "/locations/:locationId/customValues/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getTimezones",
      description: "Fetch Timezones. Fetch the available timezones",
      method: "GET",
      path: "/locations/:locationId/timezones",
      params: {}
    },
  {
      name: "crm_gETAllOrEmailSmsTemplates",
      description: "GET all or email/sms templates. GET all or email/sms templates",
      method: "GET",
      path: "/locations/:locationId/templates",
      params: {
        deleted: {
          type: "boolean",
          description: "deleted (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        originId: {
          type: "string",
          description: "originId (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["deleted", "skip", "limit", "type", "originId"]
    },
  {
      name: "crm_dELETEAnEmailSmsTemplate",
      description: "DELETE an email/sms template. DELETE an email/sms template",
      method: "DELETE",
      path: "/locations/:locationId/templates/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createLocation",
      description: "Create Sub-Account (Formerly Location). &lt;div&gt; &lt;p&gt;Create a new Sub-Account (Formerly Location) based on the data provided&lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; This feature is only available on Agency Pro ($497) plan. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "POST",
      path: "/locations/",
      params: {}
    }
];
