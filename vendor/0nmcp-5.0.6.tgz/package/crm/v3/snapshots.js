// ============================================================
// 0nMCP — CRM v3.0.0 — snapshots
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getCustomSnapshots",
      description: "Get Snapshots. Get a list of all own and imported Snapshots",
      method: "GET",
      path: "/snapshots/",
      params: {
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId"]
    },
  {
      name: "crm_createSnapshotShareLink",
      description: "Create Snapshot Share Link. Create a share link for snapshot",
      method: "POST",
      path: "/snapshots/share/link",
      params: {
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId"]
    },
  {
      name: "crm_getSnapshotPush",
      description: "Get Snapshot Push between Dates. Get list of sub-accounts snapshot pushed in time period",
      method: "GET",
      path: "/snapshots/snapshot-status/:snapshotId",
      params: {
        snapshotId: {
          type: "string",
          description: "snapshotId (path param)",
          required: true,
          in: "path"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        },
        from: {
          type: "string",
          description: "from (query param)",
          required: false,
          in: "query"
        },
        to: {
          type: "string",
          description: "to (query param)",
          required: false,
          in: "query"
        },
        lastDoc: {
          type: "string",
          description: "lastDoc (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId", "from", "to", "lastDoc", "limit"]
    },
  {
      name: "crm_getLatestSnapshotPush",
      description: "Get Last Snapshot Push. Get Latest Snapshot Push Status for a location id",
      method: "GET",
      path: "/snapshots/snapshot-status/:snapshotId/location/:locationId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        },
        snapshotId: {
          type: "string",
          description: "snapshotId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["companyId"]
    }
];
