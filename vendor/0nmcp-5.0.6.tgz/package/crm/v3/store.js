// ============================================================
// 0nMCP — CRM v3.0.0 — store
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_createShippingZone",
      description: "Create Shipping Zone. The &quot;Create Shipping Zone&quot; API allows adding a new shipping zone.",
      method: "POST",
      path: "/store/shipping-zone",
      params: {}
    },
  {
      name: "crm_listShippingZones",
      description: "List Shipping Zones. The &quot;List Shipping Zone&quot; API allows to retrieve a list of shipping zone.",
      method: "GET",
      path: "/store/shipping-zone",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        withShippingRate: {
          type: "string",
          description: "withShippingRate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "limit", "offset", "withShippingRate"]
    },
  {
      name: "crm_getShippingZones",
      description: "Get Shipping Zone. The &quot;List Shipping Zone&quot; API allows to retrieve a paginated list of shipping zone.",
      method: "GET",
      path: "/store/shipping-zone/:shippingZoneId",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        withShippingRate: {
          type: "string",
          description: "withShippingRate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "withShippingRate"]
    },
  {
      name: "crm_updateShippingZone",
      description: "Update Shipping Zone. The &quot;update Shipping Zone&quot; API allows update a shipping zone to the system.",
      method: "PUT",
      path: "/store/shipping-zone/:shippingZoneId",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteShippingZone",
      description: "Delete shipping zone. Delete specific shipping zone with Id :shippingZoneId",
      method: "DELETE",
      path: "/store/shipping-zone/:shippingZoneId",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_getAvailableShippingZones",
      description: "Get available shipping rates. This return available shipping rates for country based on order amount",
      method: "POST",
      path: "/store/shipping-zone/shipping-rates",
      params: {}
    },
  {
      name: "crm_createShippingRate",
      description: "Create Shipping Rate. The &quot;Create Shipping Rate&quot; API allows adding a new shipping rate.",
      method: "POST",
      path: "/store/shipping-zone/:shippingZoneId/shipping-rate",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listShippingRates",
      description: "List Shipping Rates. The &quot;List Shipping Rate&quot; API allows to retrieve a list of shipping rate.",
      method: "GET",
      path: "/store/shipping-zone/:shippingZoneId/shipping-rate",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "limit", "offset"]
    },
  {
      name: "crm_getShippingRates",
      description: "Get Shipping Rate. The &quot;List Shipping Rate&quot; API allows to retrieve a paginated list of shipping rate.",
      method: "GET",
      path: "/store/shipping-zone/:shippingZoneId/shipping-rate/:shippingRateId",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        },
        shippingRateId: {
          type: "string",
          description: "shippingRateId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateShippingRate",
      description: "Update Shipping Rate. The &quot;update Shipping Rate&quot; API allows update a shipping rate to the system.",
      method: "PUT",
      path: "/store/shipping-zone/:shippingZoneId/shipping-rate/:shippingRateId",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        },
        shippingRateId: {
          type: "string",
          description: "shippingRateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteShippingRate",
      description: "Delete shipping rate. Delete specific shipping rate with Id :shippingRateId",
      method: "DELETE",
      path: "/store/shipping-zone/:shippingZoneId/shipping-rate/:shippingRateId",
      params: {
        shippingZoneId: {
          type: "string",
          description: "shippingZoneId (path param)",
          required: true,
          in: "path"
        },
        shippingRateId: {
          type: "string",
          description: "shippingRateId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_createShippingCarrier",
      description: "Create Shipping Carrier. The &quot;Create Shipping Carrier&quot; API allows adding a new shipping carrier.",
      method: "POST",
      path: "/store/shipping-carrier",
      params: {}
    },
  {
      name: "crm_listShippingCarriers",
      description: "List Shipping Carriers. The &quot;List Shipping Carrier&quot; API allows to retrieve a list of shipping carrier.",
      method: "GET",
      path: "/store/shipping-carrier",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_getShippingCarriers",
      description: "Get Shipping Carrier. The &quot;List Shipping Carrier&quot; API allows to retrieve a paginated list of shipping carrier.",
      method: "GET",
      path: "/store/shipping-carrier/:shippingCarrierId",
      params: {
        shippingCarrierId: {
          type: "string",
          description: "shippingCarrierId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateShippingCarrier",
      description: "Update Shipping Carrier. The &quot;update Shipping Carrier&quot; API allows update a shipping carrier to the system.",
      method: "PUT",
      path: "/store/shipping-carrier/:shippingCarrierId",
      params: {
        shippingCarrierId: {
          type: "string",
          description: "shippingCarrierId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteShippingCarrier",
      description: "Delete shipping carrier. Delete specific shipping carrier with Id :shippingCarrierId",
      method: "DELETE",
      path: "/store/shipping-carrier/:shippingCarrierId",
      params: {
        shippingCarrierId: {
          type: "string",
          description: "shippingCarrierId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_createStoreSetting",
      description: "Create/Update Store Settings. Create or update store settings by altId and altType.",
      method: "POST",
      path: "/store/store-setting",
      params: {}
    },
  {
      name: "crm_getStoreSettings",
      description: "Get Store Settings. Get store settings by altId and altType.",
      method: "GET",
      path: "/store/store-setting",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    }
];
