// ============================================================
// 0nMCP — CRM v3.0.0 — medias
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_fetchMediaContent",
      description: "Get List of Files/ Folders. Fetches list of files and folders from the media storage",
      method: "GET",
      path: "/medias/files",
      params: {
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        sortBy: {
          type: "string",
          description: "sortBy (query param)",
          required: false,
          in: "query"
        },
        sortOrder: {
          type: "string",
          description: "sortOrder (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        parentId: {
          type: "string",
          description: "parentId (query param)",
          required: false,
          in: "query"
        },
        fetchAll: {
          type: "string",
          description: "fetchAll (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["offset", "limit", "sortBy", "sortOrder", "type", "query", "altType", "altId", "parentId", "fetchAll"]
    },
  {
      name: "crm_uploadMediaContent",
      description: "Upload File into Media Storage. If hosted is set to true then fileUrl is required. Else file is required. If adding a file, maximum allowed is 25 MB",
      method: "POST",
      path: "/medias/upload-file",
      params: {}
    },
  {
      name: "crm_deleteMediaContent",
      description: "Delete File or Folder. Deletes specific file or folder from the media storage",
      method: "DELETE",
      path: "/medias/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altType", "altId"]
    },
  {
      name: "crm_updateMediaObject",
      description: "Update File/ Folder. Updates a single file or folder by ID",
      method: "POST",
      path: "/medias/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createMediaFolder",
      description: "Create Folder. Creates a new folder in the media storage",
      method: "POST",
      path: "/medias/folder",
      params: {}
    },
  {
      name: "crm_bulkUpdateMediaObjects",
      description: "Bulk Update Files/ Folders. Updates metadata or status of multiple files and folders",
      method: "PUT",
      path: "/medias/update-files",
      params: {}
    },
  {
      name: "crm_bulkDeleteMediaObjects",
      description: "Bulk Delete / Trash Files or Folders. Soft-deletes or trashes multiple files and folders in a single request",
      method: "PUT",
      path: "/medias/delete-files",
      params: {}
    }
];
