// ============================================================
// 0nMCP — CRM v3.0.0 — social-media-posting
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_startGoogleOauth",
      description: "Starts OAuth For Google Account. Open the API in a window with appropriate params and headers instead of using the Curl. User is navigated to Google login OAuth screen. On successful login, listen on window object for message where event listener returns data in its callback function. ### Sample code to listen to event data: window.addEventListener(&#x27;message&#x27;, function(e) { if (e.data &amp;&amp; e.data.page &#x3D;&#x3D;&#x3D; &#x27;social_media_posting&#x27;) { const { actionType, page, platform, placement, accountId, reconnectAccounts } &#x3D; e.data } }, false) ### Event Data Response: { actionType: string, Ex: &quot;close&quot; page: string, Ex: &quot;social-media-posting&quot; platform: string, Ex: &quot;google&quot; placement: string, Ex: &quot;placement&quot; accountId: string, Ex: &quot;658a9b6833b91e0ecb8f3958&quot; reconnectAccounts: string[]] Ex: [&quot;658a9b6833b91e0ecb834acd&quot;, &quot;efd2daa9b6833b91e0ecb8f3511&quot;] } ### The accountId retrieved from above data can be used to fetch Google account details using below API - API: &#x27;/social-media-posting/oauth/google/accounts/:accountId&#x27; Method: GET",
      method: "GET",
      path: "/social-media-posting/oauth/google/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getGoogleLocations",
      description: "Get google business locations. Get google business locations",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/google/locations/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_setGoogleLocations",
      description: "Set google business locations. Set google business locations",
      method: "POST",
      path: "/social-media-posting/oauth/:locationId/google/locations/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getPosts",
      description: "Get posts. Get Posts",
      method: "POST",
      path: "/social-media-posting/:locationId/posts/list",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createPost",
      description: "Create post. Create posts for all supported platforms. It is possible to create customized posts per channel by using the same platform account IDs in a request and hitting the create post API multiple times with different summaries and account IDs per platform. The content and media limitations, as well as platform rate limiters corresponding to the respective platforms, are provided in the following reference link: Link: [Platform Limitations](https://help.leadconnectorhq.com/support/solutions/articles/48001240003-social-planner-image-video-content-and-api-limitations &quot;Social Planner Help&quot;)",
      method: "POST",
      path: "/social-media-posting/:locationId/posts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getPost",
      description: "Get post. Get post",
      method: "GET",
      path: "/social-media-posting/:locationId/posts/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_editPost",
      description: "Edit post. Create posts for all supported platforms. It is possible to create customized posts per channel by using the same platform account IDs in a request and hitting the create post API multiple times with different summaries and account IDs per platform. The content and media limitations, as well as platform rate limiters corresponding to the respective platforms, are provided in the following reference link: Link: [Platform Limitations](https://help.leadconnectorhq.com/support/solutions/articles/48001240003-social-planner-image-video-content-and-api-limitations &quot;Social Planner Help&quot;)",
      method: "PUT",
      path: "/social-media-posting/:locationId/posts/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deletePost",
      description: "Delete Post. Delete Post",
      method: "DELETE",
      path: "/social-media-posting/:locationId/posts/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_bulkDeleteSocialPlannerPosts",
      description: "Bulk Delete Social Planner Posts. Deletes multiple posts based on the provided list of post IDs. This operation is useful for clearing up large numbers of posts efficiently. Note: 1.The maximum number of posts that can be deleted in a single request is &#x27;50&#x27;. 2.However, It will only get deleted in Highlevel database but still it is recommended to be cautious of this operation.",
      method: "POST",
      path: "/social-media-posting/:locationId/posts/bulk-delete",
      params: {}
    },
  {
      name: "crm_getAccount",
      description: "Get Accounts. Get list of accounts and groups",
      method: "GET",
      path: "/social-media-posting/:locationId/accounts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteAccount",
      description: "Delete Account. Delete account and account from group",
      method: "DELETE",
      path: "/social-media-posting/:locationId/accounts/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId", "userId"]
    },
  {
      name: "crm_startFacebookOauth",
      description: "Starts OAuth For Facebook Account. Open the API in a window with appropriate params and headers instead of using the Curl. User is navigated to Facebook login OAuth screen. On successful login, listen on window object for message where event listener returns data in its callback function. ### Sample code to listen to event data: window.addEventListener(&#x27;message&#x27;, function(e) { if (e.data &amp;&amp; e.data.page &#x3D;&#x3D;&#x3D; &#x27;social_media_posting&#x27;) { const { actionType, page, platform, placement, accountId, reconnectAccounts } &#x3D; e.data } }, false) ### Event Data Response: { actionType: string, Ex: &quot;close&quot; page: string, Ex: &quot;social-media-posting&quot; platform: string, Ex: &quot;facebook&quot; placement: string, Ex: &quot;placement&quot; accountId: string, Ex: &quot;658a9b6833b91e0ecb8f3958&quot; reconnectAccounts: string[]] Ex: [&quot;658a9b6833b91e0ecb834acd&quot;, &quot;efd2daa9b6833b91e0ecb8f3511&quot;] } ### The accountId retrieved from above data can be used to fetch Facebook account details using below API - API: &#x27;/social-media-posting/oauth/facebook/accounts/:accountId&#x27; Method: GET",
      method: "GET",
      path: "/social-media-posting/oauth/facebook/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getFacebookPageGroup",
      description: "Get facebook pages. Get facebook pages",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/facebook/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_attachFacebookPageGroup",
      description: "Attach facebook pages. Attach facebook pages",
      method: "POST",
      path: "/social-media-posting/oauth/:locationId/facebook/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_startInstagramOauth",
      description: "Starts OAuth For Instagram Account. Open the API in a window with appropriate params and headers instead of using the Curl. User is navigated to Instagram login OAuth screen. On successful login, listen on window object for message where event listener returns data in its callback function. ### Sample code to listen to event data: window.addEventListener(&#x27;message&#x27;, function(e) { if (e.data &amp;&amp; e.data.page &#x3D;&#x3D;&#x3D; &#x27;social_media_posting&#x27;) { const { actionType, page, platform, placement, accountId, reconnectAccounts } &#x3D; e.data } }, false) ### Event Data Response: { actionType: string, Ex: &quot;close&quot; page: string, Ex: &quot;social-media-posting&quot; platform: string, Ex: &quot;instagram&quot; placement: string, Ex: &quot;placement&quot; accountId: string, Ex: &quot;658a9b6833b91e0ecb8f3958&quot; reconnectAccounts: string[]] Ex: [&quot;658a9b6833b91e0ecb834acd&quot;, &quot;efd2daa9b6833b91e0ecb8f3511&quot;] } ### The accountId retrieved from above data can be used to fetch Instagram account details using below API - API: &#x27;/social-media-posting/oauth/instagram/accounts/:accountId&#x27; Method: GET",
      method: "GET",
      path: "/social-media-posting/oauth/instagram/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getInstagramPageGroup",
      description: "Get Instagram Professional Accounts. Get Instagram Professional Accounts",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/instagram/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_attachInstagramPageGroup",
      description: "Attach Instagram Professional Accounts. Attach Instagram Professional Accounts",
      method: "POST",
      path: "/social-media-posting/oauth/:locationId/instagram/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_startLinkedinOauth",
      description: "Starts OAuth For LinkedIn Account. Open the API in a window with appropriate params and headers instead of using the Curl. User is navigated to LinkedIn login OAuth screen. On successful login, listen on window object for message where event listener returns data in its callback function. ### Sample code to listen to event data: window.addEventListener(&#x27;message&#x27;, function(e) { if (e.data &amp;&amp; e.data.page &#x3D;&#x3D;&#x3D; &#x27;social_media_posting&#x27;) { const { actionType, page, platform, placement, accountId, reconnectAccounts } &#x3D; e.data } }, false) ### Event Data Response: { actionType: string, Ex: &quot;close&quot; page: string, Ex: &quot;social-media-posting&quot; platform: string, Ex: &quot;linkedin&quot; placement: string, Ex: &quot;placement&quot; accountId: string, Ex: &quot;658a9b6833b91e0ecb8f3958&quot; reconnectAccounts: string[]] Ex: [&quot;658a9b6833b91e0ecb834acd&quot;, &quot;efd2daa9b6833b91e0ecb8f3511&quot;] } ### The accountId retrieved from above data can be used to fetch LinkedIn account details using below API - API: &#x27;/social-media-posting/oauth/linkedin/accounts/:accountId&#x27; Method: GET",
      method: "GET",
      path: "/social-media-posting/oauth/linkedin/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getLinkedinPageProfile",
      description: "Get Linkedin pages and profile. Get Linkedin pages and profile",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/linkedin/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_attachLinkedinPageProfile",
      description: "Attach linkedin pages and profile. Attach linkedin pages and profile",
      method: "POST",
      path: "/social-media-posting/oauth/:locationId/linkedin/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_startTwitterOauth",
      description: "Starts OAuth For Twitter Account. &lt;div&gt;&lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: red; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 20px; border: 2px solid black; border-radius: 20%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt;&lt;strong&gt;As of December 4, 2024, X (formerly Twitter) is no longer supported. We apologise for any inconvenience.&lt;/strong&gt;&lt;/span&gt; &lt;/div&gt;&lt;/div&gt; @deprecated This method is deprecated",
      method: "GET",
      path: "/social-media-posting/oauth/twitter/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getTwitterProfile",
      description: "Get Twitter profile. &lt;div&gt;&lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: red; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 20px; border: 2px solid black; border-radius: 20%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt;&lt;strong&gt;As of December 4, 2024, X (formerly Twitter) is no longer supported. We apologise for any inconvenience.&lt;/strong&gt;&lt;/span&gt; &lt;/div&gt;&lt;/div&gt; @deprecated This method is deprecated",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/twitter/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_attachTwitterProfile",
      description: "Attach Twitter profile. &lt;div&gt;&lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: red; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 20px; border: 2px solid black; border-radius: 20%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt;&lt;strong&gt;As of December 4, 2024, X (formerly Twitter) is no longer supported. We apologise for any inconvenience.&lt;/strong&gt;&lt;/span&gt; &lt;/div&gt;&lt;/div&gt; @deprecated This method is deprecated",
      method: "POST",
      path: "/social-media-posting/oauth/:locationId/twitter/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_uploadCsv",
      description: "Upload CSV",
      method: "POST",
      path: "/social-media-posting/:locationId/csv",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getUploadStatus",
      description: "Get Upload Status",
      method: "GET",
      path: "/social-media-posting/:locationId/csv",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        includeUsers: {
          type: "string",
          description: "includeUsers (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["skip", "limit", "includeUsers", "userId"]
    },
  {
      name: "crm_setAccounts",
      description: "Set Accounts",
      method: "POST",
      path: "/social-media-posting/:locationId/set-accounts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCsvPost",
      description: "Get CSV Post",
      method: "GET",
      path: "/social-media-posting/:locationId/csv/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["skip", "limit"]
    },
  {
      name: "crm_startCsvFinalize",
      description: "Start CSV Finalize",
      method: "PATCH",
      path: "/social-media-posting/:locationId/csv/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCsv",
      description: "Delete CSV",
      method: "DELETE",
      path: "/social-media-posting/:locationId/csv/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCsvPost",
      description: "Delete CSV Post",
      method: "DELETE",
      path: "/social-media-posting/:locationId/csv/:csvId/post/:postId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        postId: {
          type: "string",
          description: "postId (path param)",
          required: true,
          in: "path"
        },
        csvId: {
          type: "string",
          description: "csvId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_startTiktokOauth",
      description: "Starts OAuth For Tiktok Account. Open the API in a window with appropriate params and headers instead of using the Curl. User is navigated to Tiktok login OAuth screen. On successful login, listen on window object for message where event listener returns data in its callback function. ### Sample code to listen to event data: window.addEventListener(&#x27;message&#x27;, function(e) { if (e.data &amp;&amp; e.data.page &#x3D;&#x3D;&#x3D; &#x27;social_media_posting&#x27;) { const { actionType, page, platform, placement, accountId, reconnectAccounts } &#x3D; e.data } }, false) ### Event Data Response: { actionType: string, Ex: &quot;close&quot; page: string, Ex: &quot;social-media-posting&quot; platform: string, Ex: &quot;tiktok&quot; placement: string, Ex: &quot;placement&quot; accountId: string, Ex: &quot;658a9b6833b91e0ecb8f3958&quot; reconnectAccounts: string[]] Ex: [&quot;658a9b6833b91e0ecb834acd&quot;, &quot;efd2daa9b6833b91e0ecb8f3511&quot;] } ### The accountId retrieved from above data can be used to fetch Tiktok account details using below API - API: &#x27;/social-media-posting/oauth/tiktok/accounts/:accountId&#x27; Method: GET",
      method: "GET",
      path: "/social-media-posting/oauth/tiktok/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getTiktokProfile",
      description: "Get Tiktok profile. Get Tiktok profile",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/tiktok/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_attachTiktokProfile",
      description: "Attach Tiktok profile. Attach Tiktok profile",
      method: "POST",
      path: "/social-media-posting/oauth/:locationId/tiktok/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_startTiktokBusinessOauth",
      description: "Starts OAuth For Tiktok Business Account. Open the API in a window with appropriate params and headers instead of using the Curl. User is navigated to Tiktok-Business login OAuth screen. On successful login, listen on window object for message where event listener returns data in its callback function. ### Sample code to listen to event data: window.addEventListener(&#x27;message&#x27;, function(e) { if (e.data &amp;&amp; e.data.page &#x3D;&#x3D;&#x3D; &#x27;social_media_posting&#x27;) { const { actionType, page, platform, placement, accountId, reconnectAccounts } &#x3D; e.data } }, false) ### Event Data Response: { actionType: string, Ex: &quot;close&quot; page: string, Ex: &quot;social-media-posting&quot; platform: string, Ex: &quot;tiktok-business&quot; placement: string, Ex: &quot;placement&quot; accountId: string, Ex: &quot;658a9b6833b91e0ecb8f3958&quot; reconnectAccounts: string[]] Ex: [&quot;658a9b6833b91e0ecb834acd&quot;, &quot;efd2daa9b6833b91e0ecb8f3511&quot;] } ### The accountId retrieved from above data can be used to fetch Tiktok-Business account details using below API - API: &#x27;/social-media-posting/oauth/tiktok-business/accounts/:accountId&#x27; Method: GET",
      method: "GET",
      path: "/social-media-posting/oauth/tiktok-business/start",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        reconnect: {
          type: "string",
          description: "reconnect (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "userId", "page", "reconnect"]
    },
  {
      name: "crm_getTiktokBusinessProfile",
      description: "Get Tiktok Business profile. Get Tiktok Business profile",
      method: "GET",
      path: "/social-media-posting/oauth/:locationId/tiktok-business/accounts/:accountId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        accountId: {
          type: "string",
          description: "accountId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCategoriesLocationId",
      description: "Get categories by location id",
      method: "GET",
      path: "/social-media-posting/:locationId/categories",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        searchText: {
          type: "string",
          description: "searchText (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["searchText", "limit", "skip"]
    },
  {
      name: "crm_getCategoriesId",
      description: "Get categories by id",
      method: "GET",
      path: "/social-media-posting/:locationId/categories/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getTagsLocationId",
      description: "Get tags by location id",
      method: "GET",
      path: "/social-media-posting/:locationId/tags",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        searchText: {
          type: "string",
          description: "searchText (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["searchText", "limit", "skip"]
    },
  {
      name: "crm_getTagsByIds",
      description: "Get tags by ids",
      method: "POST",
      path: "/social-media-posting/:locationId/tags/details",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getSocialMediaStatistics",
      description: "Get Social Media Statistics. Retrieve analytics data for multiple social media accounts. Provides metrics for the last 7 days with comparison to the previous 7 days. Supports filtering by platforms and specific connected accounts.",
      method: "POST",
      path: "/social-media-posting/statistics",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    }
];
