// ============================================================
// 0nMCP — CRM v3.0.0 — companies
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getCompany",
      description: "Get Company. Get Comapny",
      method: "GET",
      path: "/companies/:companyId",
      params: {
        companyId: {
          type: "string",
          description: "companyId (path param)",
          required: true,
          in: "path"
        }
      }
    }
];
