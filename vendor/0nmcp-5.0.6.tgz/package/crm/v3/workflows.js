// ============================================================
// 0nMCP — CRM v3.0.0 — workflows
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getWorkflow",
      description: "Get Workflow. Get Workflow",
      method: "GET",
      path: "/workflows/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    }
];
