// ============================================================
// 0nMCP — CRM v3.0.0 — contacts
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_searchContactsAdvanced",
      description: "Search Contacts. Search contacts based on combinations of advanced filters. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-158396/6e629989abe7fad",
      method: "POST",
      path: "/contacts/search",
      params: {}
    },
  {
      name: "crm_getDuplicateContact",
      description: "Get Duplicate Contact. Get Duplicate Contact.&lt;br/&gt;&lt;br/&gt;If &#x60;Allow Duplicate Contact&#x60; is disabled under Settings, the global unique identifier will be used for searching the contact. If the setting is enabled, first priority for search is &#x60;email&#x60; and the second priority will be &#x60;phone&#x60;.",
      method: "GET",
      path: "/contacts/search/duplicate",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        number: {
          type: "string",
          description: "number (query param)",
          required: false,
          in: "query"
        },
        email: {
          type: "string",
          description: "email (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "number", "email"]
    },
  {
      name: "crm_getAllTasks",
      description: "Get all Tasks. Get all Tasks",
      method: "GET",
      path: "/contacts/:contactId/tasks",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createTask",
      description: "Create Task. Create Task",
      method: "POST",
      path: "/contacts/:contactId/tasks",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getTask",
      description: "Get Task. Get Task",
      method: "GET",
      path: "/contacts/:contactId/tasks/:taskId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        taskId: {
          type: "string",
          description: "taskId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateTask",
      description: "Update Task. Update Task",
      method: "PUT",
      path: "/contacts/:contactId/tasks/:taskId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        taskId: {
          type: "string",
          description: "taskId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteTask",
      description: "Delete Task. Delete Task",
      method: "DELETE",
      path: "/contacts/:contactId/tasks/:taskId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        taskId: {
          type: "string",
          description: "taskId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateTaskCompleted",
      description: "Update Task Completed. Update Task Completed",
      method: "PUT",
      path: "/contacts/:contactId/tasks/:taskId/completed",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        taskId: {
          type: "string",
          description: "taskId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAppointmentsForContact",
      description: "Get Appointments for Contact. Get Appointments for Contact",
      method: "GET",
      path: "/contacts/:contactId/appointments",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_addTags",
      description: "Add Tags. Add Tags",
      method: "POST",
      path: "/contacts/:contactId/tags",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_removeTags",
      description: "Remove Tags. Remove Tags",
      method: "DELETE",
      path: "/contacts/:contactId/tags",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAllNotes",
      description: "Get All Notes. Get All Notes",
      method: "GET",
      path: "/contacts/:contactId/notes",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createNote",
      description: "Create Note. Create Note",
      method: "POST",
      path: "/contacts/:contactId/notes",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getNote",
      description: "Get Note. Get Note",
      method: "GET",
      path: "/contacts/:contactId/notes/:id",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateNote",
      description: "Update Note. Update Note",
      method: "PUT",
      path: "/contacts/:contactId/notes/:id",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteNote",
      description: "Delete Note. Delete Note",
      method: "DELETE",
      path: "/contacts/:contactId/notes/:id",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_contactsBulkUpdateTags",
      description: "Update Contacts Tags. Allows you to update tags to multiple contacts at once, you can add or remove tags from the contacts",
      method: "POST",
      path: "/contacts/bulk/tags/update/:type",
      params: {}
    },
  {
      name: "crm_addRemoveContactFromBusiness",
      description: "Add/Remove Contacts From Business. Add/Remove Contacts From Business . Passing a &#x60;null&#x60; businessId will remove the businessId from the contacts",
      method: "POST",
      path: "/contacts/bulk/business",
      params: {}
    },
  {
      name: "crm_getContact",
      description: "Get Contact. Get Contact",
      method: "GET",
      path: "/contacts/:contactId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateContact",
      description: "Update Contact. Please find the list of acceptable values for the &#x60;country&#x60; field &lt;a href&#x3D;&quot;https://highlevel.stoplight.io/docs/integrations/ZG9jOjI4MzUzNDIy-country-list&quot; target&#x3D;&quot;_blank&quot;&gt;here&lt;/a&gt;",
      method: "PUT",
      path: "/contacts/:contactId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteContact",
      description: "Delete Contact. Delete Contact",
      method: "DELETE",
      path: "/contacts/:contactId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_upsertContact",
      description: "Upsert Contact. Please find the list of acceptable values for the &#x60;country&#x60; field &lt;a href&#x3D;&quot;https://highlevel.stoplight.io/docs/integrations/ZG9jOjI4MzUzNDIy-country-list&quot; target&#x3D;&quot;_blank&quot;&gt;here&lt;/a&gt;&lt;br/&gt;&lt;br/&gt;The Upsert API will adhere to the configuration defined under the “Allow Duplicate Contact” setting at the Location level. If the setting is configured to check both Email and Phone, the API will attempt to identify an existing contact based on the priority sequence specified in the setting, and will create or update the contact accordingly.&lt;br/&gt;&lt;br/&gt;If two separate contacts already exist—one with the same email and another with the same phone—and an upsert request includes both the email and phone, the API will update the contact that matches the first field in the configured sequence, and ignore the second field to prevent duplication.",
      method: "POST",
      path: "/contacts/upsert",
      params: {}
    },
  {
      name: "crm_getContactsByBusinessId",
      description: "Get Contacts By BusinessId. Get Contacts By BusinessId",
      method: "GET",
      path: "/contacts/business/:businessId",
      params: {
        businessId: {
          type: "string",
          description: "businessId (path param)",
          required: true,
          in: "path"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["limit", "locationId", "skip", "query"]
    },
  {
      name: "crm_addFollowersContact",
      description: "Add Followers. Add Followers",
      method: "POST",
      path: "/contacts/:contactId/followers",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_removeFollowersContact",
      description: "Remove Followers. Remove Followers",
      method: "DELETE",
      path: "/contacts/:contactId/followers",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_addContactToCampaign",
      description: "Add Contact to Campaign. Add contact to Campaign",
      method: "POST",
      path: "/contacts/:contactId/campaigns/:campaignId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_removeContactFromCampaign",
      description: "Remove Contact From Campaign. Remove Contact From Campaign",
      method: "DELETE",
      path: "/contacts/:contactId/campaigns/:campaignId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        campaignId: {
          type: "string",
          description: "campaignId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_removeContactFromEveryCampaign",
      description: "Remove Contact From Every Campaign. Remove Contact From Every Campaign",
      method: "DELETE",
      path: "/contacts/:contactId/campaigns/removeAll",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_addContactToWorkflow",
      description: "Add Contact to Workflow. Add Contact to Workflow",
      method: "POST",
      path: "/contacts/:contactId/workflow/:workflowId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        workflowId: {
          type: "string",
          description: "workflowId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteContactFromWorkflow",
      description: "Delete Contact from Workflow. Delete Contact from Workflow",
      method: "DELETE",
      path: "/contacts/:contactId/workflow/:workflowId",
      params: {
        contactId: {
          type: "string",
          description: "contactId (path param)",
          required: true,
          in: "path"
        },
        workflowId: {
          type: "string",
          description: "workflowId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createContact",
      description: "Create Contact. Please find the list of acceptable values for the &#x60;country&#x60; field &lt;a href&#x3D;&quot;https://highlevel.stoplight.io/docs/integrations/ZG9jOjI4MzUzNDIy-country-list&quot; target&#x3D;&quot;_blank&quot;&gt;here&lt;/a&gt;",
      method: "POST",
      path: "/contacts/",
      params: {}
    },
  {
      name: "crm_getContacts",
      description: "Get Contacts. Get Contacts *Note:** This API endpoint is deprecated. Please use the [Search Contacts](https://marketplace.gohighlevel.com/docs/ghl/contacts/search-contacts-advanced) endpoint instead. @deprecated deprecated. Use the [Search Contacts](https://marketplace instead.",
      method: "GET",
      path: "/contacts/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        startAfterId: {
          type: "string",
          description: "startAfterId (query param)",
          required: false,
          in: "query"
        },
        startAfter: {
          type: "string",
          description: "startAfter (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "startAfterId", "startAfter", "query", "limit"]
    }
];
