// ============================================================
// 0nMCP — CRM v3.0.0 — oauth
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getAccessToken",
      description: "Get Access Token. Use Access Tokens to access GoHighLevel resources on behalf of an authenticated location/company.",
      method: "POST",
      path: "/oauth/token",
      params: {}
    },
  {
      name: "crm_getLocationAccessToken",
      description: "Get Location Access Token from Agency Token. This API allows you to generate locationAccessToken from AgencyAccessToken",
      method: "POST",
      path: "/oauth/locationToken",
      params: {}
    },
  {
      name: "crm_getInstalledLocation",
      description: "Get Location where app is installed. This API allows you fetch location where app is installed upon",
      method: "GET",
      path: "/oauth/installedLocations",
      params: {
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        isInstalled: {
          type: "string",
          description: "isInstalled (query param)",
          required: false,
          in: "query"
        },
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        },
        appId: {
          type: "string",
          description: "appId (query param)",
          required: false,
          in: "query"
        },
        versionId: {
          type: "string",
          description: "versionId (query param)",
          required: false,
          in: "query"
        },
        onTrial: {
          type: "string",
          description: "onTrial (query param)",
          required: false,
          in: "query"
        },
        planId: {
          type: "string",
          description: "planId (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["skip", "limit", "query", "isInstalled", "companyId", "appId", "versionId", "onTrial", "planId", "locationId"]
    }
];
