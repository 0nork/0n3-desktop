// ============================================================
// 0nMCP — CRM v3.0.0 — marketplace
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_charge",
      description: "Create a new wallet charge. Create a new wallet charge",
      method: "POST",
      path: "/marketplace/billing/charges",
      params: {}
    },
  {
      name: "crm_getCharges",
      description: "Get all wallet charges. Get all wallet charges",
      method: "GET",
      path: "/marketplace/billing/charges",
      params: {
        meterId: {
          type: "string",
          description: "meterId (query param)",
          required: false,
          in: "query"
        },
        eventId: {
          type: "string",
          description: "eventId (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["meterId", "eventId", "userId", "startDate", "endDate", "skip", "limit"]
    },
  {
      name: "crm_deleteCharge",
      description: "Delete a wallet charge. Delete a wallet charge",
      method: "DELETE",
      path: "/marketplace/billing/charges/:chargeId",
      params: {
        chargeId: {
          type: "string",
          description: "chargeId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getSpecificCharge",
      description: "Get specific wallet charge details. Get specific wallet charge details",
      method: "GET",
      path: "/marketplace/billing/charges/:chargeId",
      params: {
        chargeId: {
          type: "string",
          description: "chargeId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_hasFunds",
      description: "Check if account has sufficient funds. Check if account has sufficient funds",
      method: "GET",
      path: "/marketplace/billing/charges/has-funds",
      params: {}
    },
  {
      name: "crm_uninstallApplication",
      description: "Uninstall an application. Uninstalls an application from your company or a specific location. This will remove the application&#x60;s access and stop all its functionalities",
      method: "DELETE",
      path: "/marketplace/app/:appId/installations",
      params: {
        appId: {
          type: "string",
          description: "appId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getInstallerDetails",
      description: "Get Installer Details. Fetches installer details for the authenticated user. This endpoint returns information about the company, location, user, and installation details associated with the current OAuth token.",
      method: "GET",
      path: "/marketplace/app/:appId/installations",
      params: {
        appId: {
          type: "string",
          description: "appId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getRebillingConfigForApp",
      description: "Get rebilling config for an app subscription and usage plans. Get rebilling config for an app subscription and usage plans for the authenticated sub-account. This endpoint returns the subscription and usage plans for an app.",
      method: "GET",
      path: "/marketplace/app/:appId/rebilling-config/location/:locationId",
      params: {
        appId: {
          type: "string",
          description: "appId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_migrateConnection",
      description: "Migrate external authentication connection. Migrates an external authentication connection credentials (basic or oauth2) for a specific app and location. This endpoint validates the app configuration, stores credentials safely in CRM&#x27;s native encrypted storage. With this the lifecycle of the token is managed by CRM.",
      method: "POST",
      path: "/marketplace/external-auth/migration",
      params: {}
    }
];
