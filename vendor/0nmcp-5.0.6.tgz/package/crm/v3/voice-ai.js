// ============================================================
// 0nMCP — CRM v3.0.0 — voice-ai
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_voiceAI_createAgent",
      description: "Create Agent. Create a new voice AI agent configuration and settings",
      method: "POST",
      path: "/voice-ai/agents",
      params: {}
    },
  {
      name: "crm_voiceAI_listAgents",
      description: "List Agents. Retrieve a paginated list of agents for given location.",
      method: "GET",
      path: "/voice-ai/agents",
      params: {
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        pageSize: {
          type: "string",
          description: "pageSize (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["page", "pageSize", "locationId", "query"]
    },
  {
      name: "crm_patchAgent",
      description: "Patch Agent. Partially update an existing voice AI agent",
      method: "PATCH",
      path: "/voice-ai/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_voiceAI_getAgent",
      description: "Get Agent. Retrieve detailed configuration and settings for a specific voice AI agent",
      method: "GET",
      path: "/voice-ai/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_voiceAI_deleteAgent",
      description: "Delete Agent. Delete a voice AI agent and all its configurations",
      method: "DELETE",
      path: "/voice-ai/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_getCallLogs",
      description: "List Call Logs. Returns call logs for Voice AI agents scoped to a location. Supports filtering by agent, contact, call type, action types, and date range (interpreted in the provided IANA timezone). Also supports sorting and 1-based pagination.",
      method: "GET",
      path: "/voice-ai/dashboard/call-logs",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        agentId: {
          type: "string",
          description: "agentId (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        callType: {
          type: "string",
          description: "callType (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        actionType: {
          type: "string",
          description: "actionType (query param)",
          required: false,
          in: "query"
        },
        sortBy: {
          type: "string",
          description: "sortBy (query param)",
          required: false,
          in: "query"
        },
        sort: {
          type: "string",
          description: "sort (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        pageSize: {
          type: "string",
          description: "pageSize (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "agentId", "contactId", "callType", "startDate", "endDate", "actionType", "sortBy", "sort", "page", "pageSize"]
    },
  {
      name: "crm_getCallLog",
      description: "Get Call Log. Returns a call log by callId.",
      method: "GET",
      path: "/voice-ai/dashboard/call-logs/:callId",
      params: {
        callId: {
          type: "string",
          description: "callId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_voiceAI_createAction",
      description: "Create Agent Action. Create a new action for a voice AI agent. Actions define specific behaviors and capabilities for the agent during calls.",
      method: "POST",
      path: "/voice-ai/actions",
      params: {}
    },
  {
      name: "crm_voiceAI_updateAction",
      description: "Update Agent Action. Update an existing action for a voice AI agent. Modifies the behavior and configuration of an agent action.",
      method: "PUT",
      path: "/voice-ai/actions/:actionId",
      params: {
        actionId: {
          type: "string",
          description: "actionId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAction",
      description: "Get Agent Action. Retrieve details of a specific action by its ID. Returns the action configuration including actionParameters.",
      method: "GET",
      path: "/voice-ai/actions/:actionId",
      params: {
        actionId: {
          type: "string",
          description: "actionId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_voiceAI_deleteAction",
      description: "Delete Agent Action. Delete an existing action from a voice AI agent. This permanently removes the action and its configuration.",
      method: "DELETE",
      path: "/voice-ai/actions/:actionId",
      params: {
        actionId: {
          type: "string",
          description: "actionId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        agentId: {
          type: "string",
          description: "agentId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "agentId"]
    }
];
