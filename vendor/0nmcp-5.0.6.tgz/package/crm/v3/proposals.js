// ============================================================
// 0nMCP — CRM v3.0.0 — proposals
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_listDocumentsContracts",
      description: "List documents. List documents for a location",
      method: "GET",
      path: "/proposals/document",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        paymentStatus: {
          type: "string",
          description: "paymentStatus (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        dateFrom: {
          type: "string",
          description: "dateFrom (query param)",
          required: false,
          in: "query"
        },
        dateTo: {
          type: "string",
          description: "dateTo (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "status", "paymentStatus", "limit", "skip", "query", "dateFrom", "dateTo"]
    },
  {
      name: "crm_sendDocumentsContracts",
      description: "Send document. Send document to a client",
      method: "POST",
      path: "/proposals/document/send",
      params: {}
    },
  {
      name: "crm_listDocumentsContractsTemplates",
      description: "List templates. List document contract templates for a location",
      method: "GET",
      path: "/proposals/templates",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        dateFrom: {
          type: "string",
          description: "dateFrom (query param)",
          required: false,
          in: "query"
        },
        dateTo: {
          type: "string",
          description: "dateTo (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        },
        isPublicDocument: {
          type: "string",
          description: "isPublicDocument (query param)",
          required: false,
          in: "query"
        },
        userId: {
          type: "string",
          description: "userId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "dateFrom", "dateTo", "type", "name", "isPublicDocument", "userId", "limit", "skip"]
    },
  {
      name: "crm_sendDocumentsContractsTemplate",
      description: "Send template. Send template to a client",
      method: "POST",
      path: "/proposals/templates/send",
      params: {}
    }
];
