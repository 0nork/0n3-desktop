// ============================================================
// 0nMCP — CRM v3.0.0 — custom-fields
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getCustomFieldById",
      description: "Get Custom Field / Folder By Id. &lt;div&gt; &lt;p&gt; Get Custom Field / Folder By Id.&lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "GET",
      path: "/custom-fields/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_customFields_update",
      description: "Update Custom Field By Id. &lt;div&gt; &lt;p&gt; Update Custom Field By Id &lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "PUT",
      path: "/custom-fields/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_customFields_delete",
      description: "Delete Custom Field By Id. &lt;div&gt; &lt;p&gt; Delete Custom Field By Id &lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "DELETE",
      path: "/custom-fields/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCustomFieldsByObjectKey",
      description: "Get Custom Fields By Object Key. &lt;div&gt; &lt;p&gt; Get Custom Fields By Object Key&lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "GET",
      path: "/custom-fields/object-key/:objectKey",
      params: {
        objectKey: {
          type: "string",
          description: "objectKey (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createCustomFieldFolder",
      description: "Create Custom Field Folder. &lt;div&gt; &lt;p&gt; Create Custom Field Folder &lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "POST",
      path: "/custom-fields/folder",
      params: {}
    },
  {
      name: "crm_updateCustomFieldFolder",
      description: "Update Custom Field Folder Name. &lt;div&gt; &lt;p&gt; Create Custom Field Folder &lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "PUT",
      path: "/custom-fields/folder/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCustomFieldFolder",
      description: "Delete Custom Field Folder. &lt;div&gt; &lt;p&gt; Create Custom Field Folder &lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "DELETE",
      path: "/custom-fields/folder/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_customFields_create",
      description: "Create Custom Field. &lt;div&gt; &lt;p&gt; Create Custom Field &lt;/p&gt; &lt;div&gt; &lt;span style&#x3D; &quot;display: inline-block; width: 25px; height: 25px; background-color: yellow; color: black; font-weight: bold; font-size: 24px; text-align: center; line-height: 22px; border: 2px solid black; border-radius: 10%; margin-right: 10px;&quot;&gt; ! &lt;/span&gt; &lt;span&gt; &lt;strong&gt; Only supports Custom Objects and Company (Business) today. Will be extended to other Standard Objects in the future. &lt;/strong&gt; &lt;/span&gt; &lt;/div&gt; &lt;/div&gt;",
      method: "POST",
      path: "/custom-fields/",
      params: {}
    }
];
