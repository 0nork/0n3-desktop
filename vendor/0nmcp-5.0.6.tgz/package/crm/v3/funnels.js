// ============================================================
// 0nMCP — CRM v3.0.0 — funnels
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_createRedirect",
      description: "Create Redirect. The &quot;Create Redirect&quot; API Allows adding a new url redirect to the system. Use this endpoint to create a url redirect with the specified details. Ensure that the required information is provided in the request payload.",
      method: "POST",
      path: "/funnels/lookup/redirect",
      params: {}
    },
  {
      name: "crm_updateRedirectById",
      description: "Update Redirect By Id. The &quot;Update Redirect By Id&quot; API Allows updating an existing URL redirect in the system. Use this endpoint to modify a URL redirect with the specified ID using details provided in the request payload.",
      method: "PATCH",
      path: "/funnels/lookup/redirect/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteRedirectById",
      description: "Delete Redirect By Id. The &quot;Delete Redirect By Id&quot; API Allows deletion of a URL redirect from the system using its unique identifier. Use this endpoint to delete a URL redirect with the specified ID using details provided in the request payload.",
      method: "DELETE",
      path: "/funnels/lookup/redirect/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fetchRedirectsList",
      description: "Fetch List of Redirects. Retrieves a list of all URL redirects based on the given query parameters.",
      method: "GET",
      path: "/funnels/lookup/redirect/list",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "offset", "search"]
    },
  {
      name: "crm_getFunnels",
      description: "Fetch List of Funnels. Retrieves a list of all funnels based on the given query parameters.",
      method: "GET",
      path: "/funnels/funnel/list",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        category: {
          type: "string",
          description: "category (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        parentId: {
          type: "string",
          description: "parentId (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "type", "category", "offset", "limit", "parentId", "name"]
    },
  {
      name: "crm_getPagesByFunnelId",
      description: "Fetch list of funnel pages. Retrieves a list of all funnel pages based on the given query parameters.",
      method: "GET",
      path: "/funnels/page",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        funnelId: {
          type: "string",
          description: "funnelId (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "funnelId", "name", "limit", "offset"]
    },
  {
      name: "crm_getPagesCountByFunnelId",
      description: "Fetch count of funnel pages. Retrieves count of all funnel pages based on the given query parameters.",
      method: "GET",
      path: "/funnels/page/count",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        funnelId: {
          type: "string",
          description: "funnelId (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "funnelId", "name"]
    }
];
