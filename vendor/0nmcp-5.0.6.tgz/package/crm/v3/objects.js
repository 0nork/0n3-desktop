// ============================================================
// 0nMCP — CRM v3.0.0 — objects
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getObjectSchemaByKey",
      description: "Get Object Schema by key / id. Retrieve Object Schema by key or ID. This will return the schema of the custom object, including all its fields and properties. Supported objects include contact, opportunity, business and custom objects.To understand objects and records, please have a look the documentation here : https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0",
      method: "GET",
      path: "/objects/:key",
      params: {
        key: {
          type: "string",
          description: "key (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        fetchProperties: {
          type: "string",
          description: "fetchProperties (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "fetchProperties"]
    },
  {
      name: "crm_updateCustomObject",
      description: "Update Object Schema By Key / Id. Update Custom Object Schema or standard object&#x27;s like contact, opportunity, business searchable fields. To understand objects and records, please have a look at the documentation here : https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0",
      method: "PUT",
      path: "/objects/:key",
      params: {
        key: {
          type: "string",
          description: "key (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getRecordById",
      description: "Get Record By Id. Allows you to get a Standard Object like business and custom object record by Id",
      method: "GET",
      path: "/objects/:schemaKey/records/:id",
      params: {
        schemaKey: {
          type: "string",
          description: "schemaKey (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateObjectRecord",
      description: "Update Record. Update a Custom Object Record by Id. Supported Objects are business and custom objects. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0/87cpx-376296",
      method: "PUT",
      path: "/objects/:schemaKey/records/:id",
      params: {
        schemaKey: {
          type: "string",
          description: "schemaKey (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_deleteObjectRecord",
      description: "Delete Record. Delete Record By Id . Supported Objects are business and custom objects.",
      method: "DELETE",
      path: "/objects/:schemaKey/records/:id",
      params: {
        schemaKey: {
          type: "string",
          description: "schemaKey (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createObjectRecord",
      description: "Create Record. Create a Custom Object Record. Supported Objects business and custom objects. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0/87cpx-376296",
      method: "POST",
      path: "/objects/:schemaKey/records",
      params: {
        schemaKey: {
          type: "string",
          description: "schemaKey (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_searchObjectRecords",
      description: "Search Object Records. Supported Objects are custom objects and standard objects like &quot;business&quot;. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0/87cpx-379336",
      method: "POST",
      path: "/objects/:schemaKey/records/search",
      params: {
        schemaKey: {
          type: "string",
          description: "schemaKey (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getObjectByLocationId",
      description: "Get all objects for a location. Get all objects for a location. Supported Objects are contact, opportunity, business and custom objects.To understand objects and records, please have a look at the documentation here : https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0",
      method: "GET",
      path: "/objects/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createCustomObjectSchema",
      description: "Create Custom Object. Allows you to create a custom object schema. To understand objects and records, please have a look at the documentation here : https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0",
      method: "POST",
      path: "/objects/",
      params: {}
    }
];
