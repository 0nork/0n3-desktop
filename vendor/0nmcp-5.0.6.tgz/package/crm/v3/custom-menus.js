// ============================================================
// 0nMCP — CRM v3.0.0 — custom-menus
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getCustomMenuById",
      description: "Get Custom Menu Link. Fetches a single custom menus based on id. This endpoint allows clients to retrieve custom menu configurations, which may include menu items, categories, and associated metadata",
      method: "GET",
      path: "/custom-menus/:customMenuId",
      params: {
        customMenuId: {
          type: "string",
          description: "customMenuId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteCustomMenu",
      description: "Delete Custom Menu Link. Removes a specific custom menu from the system. This operation requires authentication and proper permissions. The custom menu is identified by its unique ID, and the operation is performed within the context of a specific company.",
      method: "DELETE",
      path: "/custom-menus/:customMenuId",
      params: {
        customMenuId: {
          type: "string",
          description: "customMenuId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateCustomMenu",
      description: "Update Custom Menu Link. Updates an existing custom menu for a given company. Requires authentication and proper permissions.",
      method: "PUT",
      path: "/custom-menus/:customMenuId",
      params: {
        customMenuId: {
          type: "string",
          description: "customMenuId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getCustomMenus",
      description: "Get Custom Menu Links. Fetches a collection of custom menus based on specified criteria. This endpoint allows clients to retrieve custom menu configurations, which may include menu items, categories, and associated metadata. The response can be tailored using query parameters for filtering, sorting, and pagination.",
      method: "GET",
      path: "/custom-menus/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        showOnCompany: {
          type: "string",
          description: "showOnCompany (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "skip", "limit", "query", "showOnCompany"]
    },
  {
      name: "crm_createCustomMenu",
      description: "Create Custom Menu Link. Creates a new custom menu for a company. Requires authentication and proper permissions. For Icon Usage Details please refer to https://doc.clickup.com/8631005/d/h/87cpx-243696/d60fa70db6b92b2",
      method: "POST",
      path: "/custom-menus/",
      params: {}
    }
];
