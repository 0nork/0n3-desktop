// ============================================================
// 0nMCP — CRM v3.0.0 — opportunities
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getLostReason",
      description: "Get lost reason. Get lost reason",
      method: "GET",
      path: "/opportunities/lost-reason",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        },
        deleted: {
          type: "boolean",
          description: "deleted (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        getCount: {
          type: "string",
          description: "getCount (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "name", "deleted", "query", "skip", "limit", "getCount"]
    },
  {
      name: "crm_searchOpportunity",
      description: "Search Opportunity. Search Opportunity",
      method: "GET",
      path: "/opportunities/search",
      params: {
        q: {
          type: "string",
          description: "q (query param)",
          required: false,
          in: "query"
        },
        pipeline_id: {
          type: "string",
          description: "pipeline_id (query param)",
          required: false,
          in: "query"
        },
        pipeline_stage_id: {
          type: "string",
          description: "pipeline_stage_id (query param)",
          required: false,
          in: "query"
        },
        contact_id: {
          type: "string",
          description: "contact_id (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        assigned_to: {
          type: "string",
          description: "assigned_to (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        id: {
          type: "string",
          description: "id (query param)",
          required: false,
          in: "query"
        },
        order: {
          type: "string",
          description: "order (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        startAfter: {
          type: "string",
          description: "startAfter (query param)",
          required: false,
          in: "query"
        },
        startAfterId: {
          type: "string",
          description: "startAfterId (query param)",
          required: false,
          in: "query"
        },
        date: {
          type: "string",
          description: "date (query param)",
          required: false,
          in: "query"
        },
        country: {
          type: "string",
          description: "country (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        getTasks: {
          type: "string",
          description: "getTasks (query param)",
          required: false,
          in: "query"
        },
        getNotes: {
          type: "string",
          description: "getNotes (query param)",
          required: false,
          in: "query"
        },
        getCalendarEvents: {
          type: "string",
          description: "getCalendarEvents (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["q", "pipeline_id", "pipeline_stage_id", "contact_id", "status", "assigned_to", "campaignId", "id", "order", "endDate", "startAfter", "startAfterId", "date", "country", "page", "limit", "getTasks", "getNotes", "getCalendarEvents"]
    },
  {
      name: "crm_searchOpportunitiesAdvanced",
      description: "Search Opportunities. Search Opportunities based on combinations of advanced filters. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-424216/7bf11bc9b94f80f",
      method: "POST",
      path: "/opportunities/search",
      params: {}
    },
  {
      name: "crm_getPipelines",
      description: "Get Pipelines. Get Pipelines",
      method: "GET",
      path: "/opportunities/pipelines",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_getOpportunity",
      description: "Get Opportunity. Get Opportunity",
      method: "GET",
      path: "/opportunities/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteOpportunity",
      description: "Delete Opportunity. Delete Opportunity",
      method: "DELETE",
      path: "/opportunities/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateOpportunity",
      description: "Update Opportunity. Update Opportunity",
      method: "PUT",
      path: "/opportunities/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateOpportunityStatus",
      description: "Update Opportunity Status. Update Opportunity Status",
      method: "PUT",
      path: "/opportunities/:id/status",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_upsertOpportunity",
      description: "Upsert Opportunity. Upsert Opportunity",
      method: "POST",
      path: "/opportunities/upsert",
      params: {}
    },
  {
      name: "crm_addFollowersOpportunity",
      description: "Add Followers. Add Followers",
      method: "POST",
      path: "/opportunities/:id/followers",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_removeFollowersOpportunity",
      description: "Remove Followers. Allows removal of one or all followers from an opportunity.",
      method: "DELETE",
      path: "/opportunities/:id/followers",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        isRemoveAllFollowers: {
          type: "string",
          description: "isRemoveAllFollowers (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["isRemoveAllFollowers"]
    },
  {
      name: "crm_createOpportunity",
      description: "Create Opportunity. Create Opportunity",
      method: "POST",
      path: "/opportunities/",
      params: {}
    }
];
