// ============================================================
// 0nMCP — CRM v3.0.0 — users
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_searchUsers",
      description: "Search Users. Search Users",
      method: "GET",
      path: "/users/search",
      params: {
        companyId: {
          type: "string",
          description: "companyId (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        },
        role: {
          type: "string",
          description: "role (query param)",
          required: false,
          in: "query"
        },
        ids: {
          type: "string",
          description: "ids (query param)",
          required: false,
          in: "query"
        },
        sort: {
          type: "string",
          description: "sort (query param)",
          required: false,
          in: "query"
        },
        sortDirection: {
          type: "string",
          description: "sortDirection (query param)",
          required: false,
          in: "query"
        },
        enabled2waySync: {
          type: "string",
          description: "enabled2waySync (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["companyId", "query", "skip", "limit", "locationId", "type", "role", "ids", "sort", "sortDirection", "enabled2waySync"]
    },
  {
      name: "crm_filterUsersByEmail",
      description: "Filter Users by Email. Filter users by company ID, deleted status, and email array",
      method: "POST",
      path: "/users/search/filter-by-email",
      params: {}
    },
  {
      name: "crm_getUser",
      description: "Get User. Get User",
      method: "GET",
      path: "/users/:userId",
      params: {
        userId: {
          type: "string",
          description: "userId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateUser",
      description: "Update User. Update User",
      method: "PUT",
      path: "/users/:userId",
      params: {}
    },
  {
      name: "crm_deleteUser",
      description: "Delete User. Delete User",
      method: "DELETE",
      path: "/users/:userId",
      params: {}
    },
  {
      name: "crm_getUserByLocation",
      description: "Get User by Location. Deprecated. Use &#x60;GET /users/search&#x60; instead. Pass &#x60;locationId&#x60; as a query parameter to filter results by location, along with the required &#x60;companyId&#x60; and other search filters as needed. @deprecated Deprecated. Use &#x60;GET /users/search&#x60; instead instead.",
      method: "GET",
      path: "/users/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createUser",
      description: "Create User. Create User",
      method: "POST",
      path: "/users/",
      params: {}
    }
];
