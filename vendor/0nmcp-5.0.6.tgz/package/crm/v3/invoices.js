// ============================================================
// 0nMCP — CRM v3.0.0 — invoices
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_createInvoiceTemplate",
      description: "Create template. API to create a template",
      method: "POST",
      path: "/invoices/template",
      params: {}
    },
  {
      name: "crm_listInvoiceTemplates",
      description: "List templates. API to get list of templates",
      method: "GET",
      path: "/invoices/template",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        paymentMode: {
          type: "string",
          description: "paymentMode (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "status", "startAt", "endAt", "search", "paymentMode", "limit", "offset"]
    },
  {
      name: "crm_getInvoiceTemplate",
      description: "Get an template. API to get an template by template id",
      method: "GET",
      path: "/invoices/template/:templateId",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateInvoiceTemplate",
      description: "Update template. API to update an template by template id",
      method: "PUT",
      path: "/invoices/template/:templateId",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteInvoiceTemplate",
      description: "Delete template. API to update an template by template id",
      method: "DELETE",
      path: "/invoices/template/:templateId",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateInvoiceTemplateLateFeesConfiguration",
      description: "Update template late fees configuration. API to update template late fees configuration by template id",
      method: "PATCH",
      path: "/invoices/template/:templateId/late-fees-configuration",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateInvoicePaymentMethodsConfiguration",
      description: "Update template late fees configuration. API to update template late fees configuration by template id",
      method: "PATCH",
      path: "/invoices/template/:templateId/payment-methods-configuration",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createInvoiceSchedule",
      description: "Create Invoice Schedule. API to create an invoice Schedule",
      method: "POST",
      path: "/invoices/schedule",
      params: {}
    },
  {
      name: "crm_listInvoiceSchedules",
      description: "List schedules. API to get list of schedules",
      method: "GET",
      path: "/invoices/schedule",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        paymentMode: {
          type: "string",
          description: "paymentMode (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "status", "startAt", "endAt", "search", "paymentMode", "limit", "offset"]
    },
  {
      name: "crm_getInvoiceSchedule",
      description: "Get an schedule. API to get an schedule by schedule id",
      method: "GET",
      path: "/invoices/schedule/:scheduleId",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateInvoiceSchedule",
      description: "Update schedule. API to update an schedule by schedule id",
      method: "PUT",
      path: "/invoices/schedule/:scheduleId",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteInvoiceSchedule",
      description: "Delete schedule. API to delete an schedule by schedule id",
      method: "DELETE",
      path: "/invoices/schedule/:scheduleId",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateAndScheduleInvoiceSchedule",
      description: "Update scheduled recurring invoice. API to update scheduled recurring invoice",
      method: "POST",
      path: "/invoices/schedule/:scheduleId/updateAndSchedule",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_scheduleInvoiceSchedule",
      description: "Schedule an schedule invoice. API to schedule an schedule invoice to start sending to the customer",
      method: "POST",
      path: "/invoices/schedule/:scheduleId/schedule",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_autoPaymentInvoiceSchedule",
      description: "Manage Auto payment for an schedule invoice. API to manage auto payment for a schedule",
      method: "POST",
      path: "/invoices/schedule/:scheduleId/auto-payment",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_cancelInvoiceSchedule",
      description: "Cancel an scheduled invoice. API to cancel a scheduled invoice by schedule id",
      method: "POST",
      path: "/invoices/schedule/:scheduleId/cancel",
      params: {
        scheduleId: {
          type: "string",
          description: "scheduleId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_text2payInvoice",
      description: "Create &amp; Send. API to create or update a text2pay invoice",
      method: "POST",
      path: "/invoices/text2pay",
      params: {}
    },
  {
      name: "crm_generateInvoiceNumber",
      description: "Generate Invoice Number. Get the next invoice number for the given location",
      method: "GET",
      path: "/invoices/generate-invoice-number",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_getInvoiceSettings",
      description: "Get Invoice Settings. Get the invoice settings for the given location",
      method: "GET",
      path: "/invoices/settings",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_getInvoice",
      description: "Get invoice. API to get invoice by invoice id",
      method: "GET",
      path: "/invoices/:invoiceId",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateInvoice",
      description: "Update invoice. API to update invoice by invoice id",
      method: "PUT",
      path: "/invoices/:invoiceId",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteInvoice",
      description: "Delete invoice. API to delete invoice by invoice id",
      method: "DELETE",
      path: "/invoices/:invoiceId",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_updateInvoiceLateFeesConfiguration",
      description: "Update invoice late fees configuration. API to update invoice late fees configuration by invoice id",
      method: "PATCH",
      path: "/invoices/:invoiceId/late-fees-configuration",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_voidInvoice",
      description: "Void invoice. API to delete invoice by invoice id",
      method: "POST",
      path: "/invoices/:invoiceId/void",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_sendInvoice",
      description: "Send invoice. API to send invoice by invoice id",
      method: "POST",
      path: "/invoices/:invoiceId/send",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_recordInvoice",
      description: "Record a manual payment for an invoice. API to record manual payment for an invoice by invoice id",
      method: "POST",
      path: "/invoices/:invoiceId/record-payment",
      params: {
        invoiceId: {
          type: "string",
          description: "invoiceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateInvoiceLastVisitedAt",
      description: "Update invoice last visited at. API to update invoice last visited at by invoice id",
      method: "PATCH",
      path: "/invoices/stats/last-visited-at",
      params: {}
    },
  {
      name: "crm_createNewEstimate",
      description: "Create New Estimate. Create a new estimate with the provided details",
      method: "POST",
      path: "/invoices/estimate",
      params: {}
    },
  {
      name: "crm_updateEstimate",
      description: "Update Estimate. Update an existing estimate with new details",
      method: "PUT",
      path: "/invoices/estimate/:estimateId",
      params: {
        estimateId: {
          type: "string",
          description: "estimateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteEstimate",
      description: "Delete Estimate. Delete an existing estimate",
      method: "DELETE",
      path: "/invoices/estimate/:estimateId",
      params: {
        estimateId: {
          type: "string",
          description: "estimateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_generateEstimateNumber",
      description: "Generate Estimate Number. Get the next estimate number for the given location",
      method: "GET",
      path: "/invoices/estimate/number/generate",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_sendEstimate",
      description: "Send Estimate. API to send estimate by estimate id",
      method: "POST",
      path: "/invoices/estimate/:estimateId/send",
      params: {
        estimateId: {
          type: "string",
          description: "estimateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createInvoiceFromEstimate",
      description: "Create Invoice from Estimate. Create a new invoice from an existing estimate",
      method: "POST",
      path: "/invoices/estimate/:estimateId/invoice",
      params: {
        estimateId: {
          type: "string",
          description: "estimateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listEstimates",
      description: "List Estimates. Get a paginated list of estimates",
      method: "GET",
      path: "/invoices/estimate/list",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "startAt", "endAt", "search", "status", "contactId", "limit", "offset"]
    },
  {
      name: "crm_updateEstimateLastVisitedAt",
      description: "Update estimate last visited at. API to update estimate last visited at by estimate id",
      method: "PATCH",
      path: "/invoices/estimate/stats/last-visited-at",
      params: {}
    },
  {
      name: "crm_listEstimateTemplates",
      description: "List Estimate Templates. Get a list of estimate templates or a specific template by ID",
      method: "GET",
      path: "/invoices/estimate/template",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "search", "limit", "offset"]
    },
  {
      name: "crm_createEstimateTemplate",
      description: "Create Estimate Template. Create a new estimate template",
      method: "POST",
      path: "/invoices/estimate/template",
      params: {}
    },
  {
      name: "crm_updateEstimateTemplate",
      description: "Update Estimate Template. Update an existing estimate template",
      method: "PUT",
      path: "/invoices/estimate/template/:templateId",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteEstimateTemplate",
      description: "Delete Estimate Template. Delete an existing estimate template",
      method: "DELETE",
      path: "/invoices/estimate/template/:templateId",
      params: {
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_previewEstimateTemplate",
      description: "Preview Estimate Template. Get a preview of an estimate template",
      method: "GET",
      path: "/invoices/estimate/template/preview",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        templateId: {
          type: "string",
          description: "templateId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "templateId"]
    },
  {
      name: "crm_createInvoice",
      description: "Create Invoice. API to create an invoice",
      method: "POST",
      path: "/invoices/",
      params: {}
    },
  {
      name: "crm_listInvoices",
      description: "List invoices. API to get list of invoices",
      method: "GET",
      path: "/invoices/",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        paymentMode: {
          type: "string",
          description: "paymentMode (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        sortField: {
          type: "string",
          description: "sortField (query param)",
          required: false,
          in: "query"
        },
        sortOrder: {
          type: "string",
          description: "sortOrder (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "status", "startAt", "endAt", "search", "paymentMode", "contactId", "limit", "offset", "sortField", "sortOrder"]
    }
];
