// ============================================================
// 0nMCP — CRM v3.0.0 — agent-studio
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_agentStudio_createAgent",
      description: "Create Agent. Creates a new agent with staging version. The agent will be created with an initial staging version that can later be promoted to production.",
      method: "POST",
      path: "/agent-studio/agent",
      params: {
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["source"]
    },
  {
      name: "crm_agentStudio_listAgents",
      description: "List Agents. Lists all active agents for the specified location. locationId is required parameter to ensure optimal performance. Supports pagination using limit and offset. Optionally filter by isPublished&#x3D;true to return only agents with a published production version.",
      method: "GET",
      path: "/agent-studio/agent",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        isPublished: {
          type: "string",
          description: "isPublished (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "isPublished", "limit", "offset", "source"]
    },
  {
      name: "crm_updateAgentVersion",
      description: "Update Agent. Updates a specific agent version by versionId. Supports updating nodes, edges, variables, and configuration.",
      method: "PATCH",
      path: "/agent-studio/agent/versions/:versionId",
      params: {
        versionId: {
          type: "string",
          description: "versionId (path param)",
          required: true,
          in: "path"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["source"]
    },
  {
      name: "crm_updateAgentMetadata",
      description: "Update Agent Metadata. Updates agent metadata such as name, description, and status.",
      method: "PATCH",
      path: "/agent-studio/agent/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["source"]
    },
  {
      name: "crm_agentStudio_deleteAgent",
      description: "Delete Agent. Deletes an agent and all its versions.",
      method: "DELETE",
      path: "/agent-studio/agent/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "source"]
    },
  {
      name: "crm_getAgentById",
      description: "Get Agent. Gets a specific agent by its ID for the specified location with all its versions. Returns complete agent metadata and all non-deleted versions (draft, staging, production). locationId is required parameter. The agent must have active status.",
      method: "GET",
      path: "/agent-studio/agent/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "source"]
    },
  {
      name: "crm_promoteAndPublish",
      description: "Promote to Production. Promotes a draft version to production.",
      method: "POST",
      path: "/agent-studio/agent/versions/:versionId/publish",
      params: {
        versionId: {
          type: "string",
          description: "versionId (path param)",
          required: true,
          in: "path"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["source"]
    },
  {
      name: "crm_executeAgent",
      description: "Execute Agent. Executes the specified agent and returns a non-streaming JSON response with the complete agent output. The agent must be in active status and belong to the specified location. locationId is required in the request body. *Session Management:** - For the first message in a new session, do not include the &#x60;executionId&#x60; in the request payload. - The API will return an &#x60;executionId&#x60; along with the agent response, which uniquely identifies this conversation session. - To continue the conversation within the same session, include the &#x60;executionId&#x60; from the previous response in subsequent requests. This allows the agent to maintain conversation context and history across multiple interactions.",
      method: "POST",
      path: "/agent-studio/agent/:agentId/execute",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["source"]
    },
  {
      name: "crm_getAgentsDeprecated",
      description: "List Agents (Deprecated). **Deprecated endpoint - use GET /agent instead.** Lists all active agents that have a published production version for the specified location. locationId is required parameter. Supports pagination using limit and offset. @deprecated Deprecated endpoint - use GET /agent instead. Use GET /agent instead instead.",
      method: "GET",
      path: "/agent-studio/public-api/agents",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "offset", "source"]
    },
  {
      name: "crm_getAgentByIdDeprecated",
      description: "Get Agent (Deprecated). **Deprecated endpoint - use GET /agent/:agentId instead.** Gets a specific agent by its ID for the specified location with all its versions. locationId is required parameter. The agent must have active status. @deprecated Deprecated endpoint - use GET /agent/:agentId instead. Use GET /agent/:agentId instead instead.",
      method: "GET",
      path: "/agent-studio/public-api/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "source"]
    },
  {
      name: "crm_executeAgentDeprecated",
      description: "Execute Agent (Deprecated). **Deprecated endpoint - use POST /agent/:agentId/execute instead.** Executes the specified agent and returns a non-streaming JSON response with the complete agent output. The agent must be in active status and belong to the specified location. locationId is required in the request body. *Session Management:** - For the first message in a new session, do not include the &#x60;executionId&#x60; in the request payload. - The API will return an &#x60;executionId&#x60; along with the agent response, which uniquely identifies this conversation session. - To continue the conversation within the same session, include the &#x60;executionId&#x60; from the previous response in subsequent requests. @deprecated Deprecated endpoint - use POST /agent/:agentId/execute instead. Use POST /agent/:agentId/execute instead instead.",
      method: "POST",
      path: "/agent-studio/public-api/agents/:agentId/execute",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["source"]
    }
];
