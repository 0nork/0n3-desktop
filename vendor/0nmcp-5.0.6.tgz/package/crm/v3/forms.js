// ============================================================
// 0nMCP — CRM v3.0.0 — forms
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getFormsSubmissions",
      description: "Get Forms Submissions. Get Forms Submissions",
      method: "GET",
      path: "/forms/submissions",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        formId: {
          type: "string",
          description: "formId (query param)",
          required: false,
          in: "query"
        },
        q: {
          type: "string",
          description: "q (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "page", "limit", "formId", "q", "startAt", "endAt"]
    },
  {
      name: "crm_uploadToCustomFields",
      description: "Upload files to custom fields. Post the necessary fields for the API to upload files. The files need to be a buffer with the key &quot;&lt; custom_field_id &gt;_&lt; file_id &gt;&quot;. &lt;br /&gt; Here custom field id is the ID of your custom field and file id is a randomly generated id (or uuid) &lt;br /&gt; There is support for multiple file uploads as well. Have multiple fields in the format mentioned.&lt;br /&gt;File size is limited to 50 MB.&lt;br /&gt;&lt;br /&gt; The allowed file types are: &lt;br/&gt; &lt;ul&gt;&lt;li&gt;PDF&lt;/li&gt;&lt;li&gt;DOCX&lt;/li&gt;&lt;li&gt;DOC&lt;/li&gt;&lt;li&gt;JPG&lt;/li&gt;&lt;li&gt;JPEG&lt;/li&gt;&lt;li&gt;PNG&lt;/li&gt;&lt;li&gt;GIF&lt;/li&gt;&lt;li&gt;CSV&lt;/li&gt;&lt;li&gt;XLSX&lt;/li&gt;&lt;li&gt;XLS&lt;/li&gt;&lt;li&gt;MP4&lt;/li&gt;&lt;li&gt;MPEG&lt;/li&gt;&lt;li&gt;ZIP&lt;/li&gt;&lt;li&gt;RAR&lt;/li&gt;&lt;li&gt;TXT&lt;/li&gt;&lt;li&gt;SVG&lt;/li&gt;&lt;/ul&gt; &lt;br /&gt;&lt;br /&gt; The API will return the updated contact object.",
      method: "POST",
      path: "/forms/upload-custom-files",
      params: {
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["contactId", "locationId"]
    },
  {
      name: "crm_getForms",
      description: "Get Forms. Get Forms",
      method: "GET",
      path: "/forms/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "skip", "limit", "type"]
    }
];
