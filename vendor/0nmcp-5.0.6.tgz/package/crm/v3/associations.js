// ============================================================
// 0nMCP — CRM v3.0.0 — associations
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_createRelation",
      description: "Create Relation for you associated entities. Create Relation.Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-293776/cd0f4122abc04d3",
      method: "POST",
      path: "/associations/relations",
      params: {}
    },
  {
      name: "crm_getRelationsByRecordId",
      description: "Get all relations By record Id. Get all relations by record Id",
      method: "GET",
      path: "/associations/relations/:recordId",
      params: {
        recordId: {
          type: "string",
          description: "recordId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        associationIds: {
          type: "string",
          description: "associationIds (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "skip", "limit", "associationIds"]
    },
  {
      name: "crm_deleteRelation",
      description: "Delete Relation. Delete Relation",
      method: "DELETE",
      path: "/associations/relations/:relationId",
      params: {
        relationId: {
          type: "string",
          description: "relationId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_getAssociationKeyByKeyName",
      description: "Get association key by key name. Using this api you can get standard / user defined association by key",
      method: "GET",
      path: "/associations/key/:key_name",
      params: {
        key_name: {
          type: "string",
          description: "key_name (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_getAssociationByObjectKeys",
      description: "Get association by object keys. Get association by object keys like contacts, custom objects and opportunities. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-293776/cd0f4122abc04d3",
      method: "GET",
      path: "/associations/objectKey/:objectKey",
      params: {
        objectKey: {
          type: "string",
          description: "objectKey (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_updateAssociation",
      description: "Update Association By Id. Update Association , Allows you to update labels of an associations. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-293776/cd0f4122abc04d3",
      method: "PUT",
      path: "/associations/:associationId",
      params: {
        associationId: {
          type: "string",
          description: "associationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteAssociation",
      description: "Delete Association. Delete USER_DEFINED Association By Id, deleting an association will also all the relations for that association",
      method: "DELETE",
      path: "/associations/:associationId",
      params: {
        associationId: {
          type: "string",
          description: "associationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAssociationByID",
      description: "Get association by ID. Using this api you can get SYSTEM_DEFINED / USER_DEFINED association by id",
      method: "GET",
      path: "/associations/:associationId",
      params: {
        associationId: {
          type: "string",
          description: "associationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createAssociation",
      description: "Create Association. Allow you to create contact - contact , contact - custom objects associations, will add more in the future.Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-293776/cd0f4122abc04d3",
      method: "POST",
      path: "/associations/",
      params: {}
    },
  {
      name: "crm_findAssociations",
      description: "Get all associations for a sub-account / location. Get all Associations",
      method: "GET",
      path: "/associations/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "skip", "limit"]
    }
];
