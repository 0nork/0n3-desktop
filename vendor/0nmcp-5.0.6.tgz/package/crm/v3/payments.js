// ============================================================
// 0nMCP — CRM v3.0.0 — payments
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_createIntegrationProvider",
      description: "Create White-label Integration Provider. The &quot;Create White-label Integration Provider&quot; API allows adding a new payment provider integration to the system which is built on top of Authorize.net or NMI. Use this endpoint to create a integration provider with the specified details. Ensure that the required information is provided in the request payload. This endpoint can be only invoked using marketplace-app token",
      method: "POST",
      path: "/payments/integrations/provider/whitelabel",
      params: {}
    },
  {
      name: "crm_listIntegrationProviders",
      description: "List White-label Integration Providers. The &quot;List White-label Integration Providers&quot; API allows to retrieve a paginated list of integration providers. Customize your results by filtering whitelabel integration providers(which are built directly on top of Authorize.net or NMI) based on name or paginate through the list using the provided query parameters. This endpoint provides a straightforward way to explore and retrieve integration provider information.",
      method: "GET",
      path: "/payments/integrations/provider/whitelabel",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "limit", "offset"]
    },
  {
      name: "crm_listOrders",
      description: "List Orders. The &quot;List Orders&quot; API allows to retrieve a paginated list of orders. Customize your results by filtering orders based on name, alt type, order status, payment mode, date range, type of source, contact, funnel products or paginate through the list using the provided query parameters. This endpoint provides a straightforward way to explore and retrieve order information.",
      method: "GET",
      path: "/payments/orders",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        paymentStatus: {
          type: "string",
          description: "paymentStatus (query param)",
          required: false,
          in: "query"
        },
        paymentMode: {
          type: "string",
          description: "paymentMode (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        funnelProductIds: {
          type: "string",
          description: "funnelProductIds (query param)",
          required: false,
          in: "query"
        },
        sourceId: {
          type: "string",
          description: "sourceId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "altId", "status", "paymentStatus", "paymentMode", "startAt", "endAt", "search", "contactId", "funnelProductIds", "sourceId", "limit", "offset"]
    },
  {
      name: "crm_getOrderById",
      description: "Get Order by ID. The &quot;Get Order by ID&quot; API allows to retrieve information for a specific order using its unique identifier. Use this endpoint to fetch details for a single order based on the provided order ID.",
      method: "GET",
      path: "/payments/orders/:orderId",
      params: {
        orderId: {
          type: "string",
          description: "orderId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "altId"]
    },
  {
      name: "crm_recordOrderPayment",
      description: "Record Order Payment. The &quot;Record Order Payment&quot; API allows to record a payment for an order. Use this endpoint to record payment for an order and update the order status to &quot;Paid&quot;.",
      method: "POST",
      path: "/payments/orders/:orderId/record-payment",
      params: {
        orderId: {
          type: "string",
          description: "orderId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createOrderFulfillment",
      description: "Create order fulfillment. The &quot;Order Fulfillment&quot; API facilitates the process of fulfilling an order.",
      method: "POST",
      path: "/payments/orders/:orderId/fulfillments",
      params: {
        orderId: {
          type: "string",
          description: "orderId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listOrderFulfillment",
      description: "List fulfillment. List all fulfillment history of an order",
      method: "GET",
      path: "/payments/orders/:orderId/fulfillments",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        orderId: {
          type: "string",
          description: "orderId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_listOrderNotes",
      description: "List Order Notes. List all notes of an order",
      method: "GET",
      path: "/payments/orders/:orderId/notes",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        orderId: {
          type: "string",
          description: "orderId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_listTransactions",
      description: "List Transactions. The &quot;List Transactions&quot; API allows to retrieve a paginated list of transactions. Customize your results by filtering transactions based on name, alt type, transaction status, payment mode, date range, type of source, contact, subscription id, entity id or paginate through the list using the provided query parameters. This endpoint provides a straightforward way to explore and retrieve transaction information.",
      method: "GET",
      path: "/payments/transactions",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        paymentMode: {
          type: "string",
          description: "paymentMode (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        entitySourceType: {
          type: "string",
          description: "entitySourceType (query param)",
          required: false,
          in: "query"
        },
        entitySourceSubType: {
          type: "string",
          description: "entitySourceSubType (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        subscriptionId: {
          type: "string",
          description: "subscriptionId (query param)",
          required: false,
          in: "query"
        },
        entityId: {
          type: "string",
          description: "entityId (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "altId", "altType", "paymentMode", "startAt", "endAt", "entitySourceType", "entitySourceSubType", "search", "subscriptionId", "entityId", "contactId", "limit", "offset"]
    },
  {
      name: "crm_getTransactionById",
      description: "Get Transaction by ID. The &quot;Get Transaction by ID&quot; API allows to retrieve information for a specific transaction using its unique identifier. Use this endpoint to fetch details for a single transaction based on the provided transaction ID.",
      method: "GET",
      path: "/payments/transactions/:transactionId",
      params: {
        transactionId: {
          type: "string",
          description: "transactionId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "altId", "altType"]
    },
  {
      name: "crm_listSubscriptions",
      description: "List Subscriptions. The &quot;List Subscriptions&quot; API allows to retrieve a paginated list of subscriptions. Customize your results by filtering subscriptions based on name, alt type, subscription status, payment mode, date range, type of source, contact, subscription id, entity id, contact or paginate through the list using the provided query parameters. This endpoint provides a straightforward way to explore and retrieve subscription information.",
      method: "GET",
      path: "/payments/subscriptions",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        entityId: {
          type: "string",
          description: "entityId (query param)",
          required: false,
          in: "query"
        },
        paymentMode: {
          type: "string",
          description: "paymentMode (query param)",
          required: false,
          in: "query"
        },
        startAt: {
          type: "string",
          description: "startAt (query param)",
          required: false,
          in: "query"
        },
        endAt: {
          type: "string",
          description: "endAt (query param)",
          required: false,
          in: "query"
        },
        entitySourceType: {
          type: "string",
          description: "entitySourceType (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        id: {
          type: "string",
          description: "id (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        getPaymentsCollectedCount: {
          type: "string",
          description: "getPaymentsCollectedCount (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "entityId", "paymentMode", "startAt", "endAt", "entitySourceType", "search", "contactId", "id", "limit", "offset", "getPaymentsCollectedCount"]
    },
  {
      name: "crm_getSubscriptionById",
      description: "Get Subscription by ID. The &quot;Get Subscription by ID&quot; API allows to retrieve information for a specific subscription using its unique identifier. Use this endpoint to fetch details for a single subscription based on the provided subscription ID.",
      method: "GET",
      path: "/payments/subscriptions/:subscriptionId",
      params: {
        subscriptionId: {
          type: "string",
          description: "subscriptionId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_listCoupons",
      description: "List Coupons. The &quot;List Coupons&quot; API allows you to retrieve a list of all coupons available in your location. Use this endpoint to view all promotional offers and special discounts for your customers.",
      method: "GET",
      path: "/payments/coupon/list",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "limit", "offset", "status", "search"]
    },
  {
      name: "crm_createCoupon",
      description: "Create Coupon. The &quot;Create Coupon&quot; API allows you to create a new promotional coupon with customizable parameters such as discount amount, validity period, usage limits, and applicable products. Use this endpoint to set up promotional offers and special discounts for your customers.",
      method: "POST",
      path: "/payments/coupon",
      params: {}
    },
  {
      name: "crm_updateCoupon",
      description: "Update Coupon. The &quot;Update Coupon&quot; API enables you to modify existing coupon details such as discount values, validity periods, usage limits, and other promotional parameters. Use this endpoint to adjust or extend promotional offers for your customers.",
      method: "PUT",
      path: "/payments/coupon",
      params: {}
    },
  {
      name: "crm_deleteCoupon",
      description: "Delete Coupon. The &quot;Delete Coupon&quot; API allows you to permanently remove a coupon from your system using its unique identifier. Use this endpoint to discontinue promotional offers or clean up unused coupons. Note that this action cannot be undone.",
      method: "DELETE",
      path: "/payments/coupon",
      params: {}
    },
  {
      name: "crm_getCoupon",
      description: "Fetch Coupon. The &quot;Get Coupon Details&quot; API enables you to retrieve comprehensive information about a specific coupon using either its unique identifier or promotional code. Use this endpoint to view coupon parameters, usage statistics, validity periods, and other promotional details.",
      method: "GET",
      path: "/payments/coupon",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        id: {
          type: "string",
          description: "id (query param)",
          required: false,
          in: "query"
        },
        code: {
          type: "string",
          description: "code (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "id", "code"]
    },
  {
      name: "crm_createIntegration",
      description: "Create new integration. API to create a new association for an app and location",
      method: "POST",
      path: "/payments/custom-provider/provider",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_deleteIntegration",
      description: "Deleting an existing integration. API to delete an association for an app and location",
      method: "DELETE",
      path: "/payments/custom-provider/provider",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_fetchConfig",
      description: "Fetch given provider config. API for fetching an existing payment config for given location",
      method: "GET",
      path: "/payments/custom-provider/connect",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createConfig",
      description: "Create new provider config. API to create a new payment config for given location",
      method: "POST",
      path: "/payments/custom-provider/connect",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_disconnectConfig",
      description: "Disconnect existing provider config. API to disconnect an existing payment config for given location",
      method: "POST",
      path: "/payments/custom-provider/disconnect",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_customProviderMarketplaceAppUpdateCapabilities",
      description: "Custom-provider marketplace app update capabilities. Toggle capabilities for the marketplace app tied to the OAuth client",
      method: "PUT",
      path: "/payments/custom-provider/capabilities",
      params: {}
    }
];
