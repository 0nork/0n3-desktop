// ============================================================
// 0nMCP — CRM v3.0.0 — affiliate-manager
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_listAffiliates",
      description: "List Affiliates. Retrieve the list of affiliates for a location.",
      method: "GET",
      path: "/affiliate-manager/:locationId/affiliates",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        active: {
          type: "boolean",
          description: "active (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        fromDate: {
          type: "string",
          description: "fromDate (query param)",
          required: false,
          in: "query"
        },
        toDate: {
          type: "string",
          description: "toDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["query", "active", "campaignId", "skip", "limit", "fromDate", "toDate"]
    },
  {
      name: "crm_getAffiliate",
      description: "Get Affiliate. Retrieve a single affiliate by id for a location.",
      method: "GET",
      path: "/affiliate-manager/:locationId/affiliates/:affiliateId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        affiliateId: {
          type: "string",
          description: "affiliateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listPayouts",
      description: "List Payouts. Retrieve the list of payouts for a location.",
      method: "GET",
      path: "/affiliate-manager/:locationId/payouts",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        affiliateId: {
          type: "string",
          description: "affiliateId (query param)",
          required: false,
          in: "query"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        start: {
          type: "string",
          description: "start (query param)",
          required: false,
          in: "query"
        },
        end: {
          type: "string",
          description: "end (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["status", "query", "affiliateId", "campaignId", "skip", "limit", "start", "end"]
    },
  {
      name: "crm_listCommissions",
      description: "List Commissions. Retrieve the list of commissions for a location.",
      method: "GET",
      path: "/affiliate-manager/:locationId/commissions",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        campaignId: {
          type: "string",
          description: "campaignId (query param)",
          required: false,
          in: "query"
        },
        affiliateId: {
          type: "string",
          description: "affiliateId (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        fromDate: {
          type: "string",
          description: "fromDate (query param)",
          required: false,
          in: "query"
        },
        toDate: {
          type: "string",
          description: "toDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["campaignId", "affiliateId", "status", "query", "skip", "limit", "fromDate", "toDate"]
    }
];
