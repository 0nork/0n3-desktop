// ============================================================
// 0nMCP — CRM v3.0.0 — products
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_bulkUpdate",
      description: "Bulk Update Products. API to bulk update products (price, availability, collections, delete)",
      method: "POST",
      path: "/products/bulk-update",
      params: {}
    },
  {
      name: "crm_bulkEdit",
      description: "Bulk Edit Products and Prices. API to bulk edit products and their associated prices (max 30 entities)",
      method: "POST",
      path: "/products/bulk-update/edit",
      params: {}
    },
  {
      name: "crm_createPriceForProduct",
      description: "Create Price for a Product. The &quot;Create Price for a Product&quot; API allows adding a new price associated with a specific product to the system. Use this endpoint to create a price with the specified details for a particular product. Ensure that the required information is provided in the request payload.",
      method: "POST",
      path: "/products/:productId/price",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listPricesForProduct",
      description: "List Prices for a Product. The &quot;List Prices for a Product&quot; API allows retrieving a paginated list of prices associated with a specific product. Customize your results by filtering prices or paginate through the list using the provided query parameters.",
      method: "GET",
      path: "/products/:productId/price",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        ids: {
          type: "string",
          description: "ids (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["limit", "offset", "locationId", "ids"]
    },
  {
      name: "crm_getListInventory",
      description: "List Inventory. The &quot;List Inventory API allows the user to retrieve a paginated list of inventory items. Use this endpoint to fetch details for multiple items in the inventory based on the provided query parameters.",
      method: "GET",
      path: "/products/inventory",
      params: {
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["limit", "offset", "altId", "altType", "search"]
    },
  {
      name: "crm_updateInventory",
      description: "Update Inventory. The Update Inventory API allows the user to bulk update the inventory for multiple items. Use this endpoint to update the available quantity and out-of-stock purchase settings for multiple items in the inventory.",
      method: "POST",
      path: "/products/inventory",
      params: {}
    },
  {
      name: "crm_getPriceByIdForProduct",
      description: "Get Price by ID for a Product. The &quot;Get Price by ID for a Product&quot; API allows retrieving information for a specific price associated with a particular product using its unique identifier. Use this endpoint to fetch details for a single price based on the provided price ID and product ID.",
      method: "GET",
      path: "/products/:productId/price/:priceId",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        },
        priceId: {
          type: "string",
          description: "priceId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_updatePriceByIdForProduct",
      description: "Update Price by ID for a Product. The &quot;Update Price by ID for a Product&quot; API allows modifying information for a specific price associated with a particular product using its unique identifier. Use this endpoint to update details for a single price based on the provided price ID and product ID.",
      method: "PUT",
      path: "/products/:productId/price/:priceId",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        },
        priceId: {
          type: "string",
          description: "priceId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deletePriceByIdForProduct",
      description: "Delete Price by ID for a Product. The &quot;Delete Price by ID for a Product&quot; API allows deleting a specific price associated with a particular product using its unique identifier. Use this endpoint to remove a price from the system.",
      method: "DELETE",
      path: "/products/:productId/price/:priceId",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        },
        priceId: {
          type: "string",
          description: "priceId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_getProductStoreStats",
      description: "Fetch Product Store Stats. API to fetch the total number of products, included in the store, and excluded from the store and other stats",
      method: "GET",
      path: "/products/store/:storeId/stats",
      params: {
        storeId: {
          type: "string",
          description: "storeId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        collectionIds: {
          type: "string",
          description: "collectionIds (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "search", "collectionIds"]
    },
  {
      name: "crm_updateStoreStatus",
      description: "Action to include/exclude the product in store. API to update the status of products in a particular store",
      method: "POST",
      path: "/products/store/:storeId",
      params: {
        storeId: {
          type: "string",
          description: "storeId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateDisplayPriority",
      description: "Update product display priorities in store. API to set the display priority of products in a store",
      method: "POST",
      path: "/products/store/:storeId/priority",
      params: {
        storeId: {
          type: "string",
          description: "storeId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getProductCollection",
      description: "Fetch Product Collections. Internal API to fetch the Product Collections",
      method: "GET",
      path: "/products/collections",
      params: {
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        collectionIds: {
          type: "string",
          description: "collectionIds (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["limit", "offset", "altId", "altType", "collectionIds", "name"]
    },
  {
      name: "crm_createProductCollection",
      description: "Create Product Collection. Create a new Product Collection for a specific location",
      method: "POST",
      path: "/products/collections",
      params: {}
    },
  {
      name: "crm_getProductCollectionId",
      description: "Get Details about individual product collection. Get Details about individual product collection",
      method: "GET",
      path: "/products/collections/:collectionId",
      params: {
        collectionId: {
          type: "string",
          description: "collectionId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId"]
    },
  {
      name: "crm_updateProductCollection",
      description: "Update Product Collection. Update a specific product collection with Id :collectionId",
      method: "PUT",
      path: "/products/collections/:collectionId",
      params: {
        collectionId: {
          type: "string",
          description: "collectionId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteProductCollection",
      description: "Delete Product Collection. Delete specific product collection with Id :collectionId",
      method: "DELETE",
      path: "/products/collections/:collectionId",
      params: {
        collectionId: {
          type: "string",
          description: "collectionId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType"]
    },
  {
      name: "crm_getProductReviews",
      description: "Fetch Product Reviews. API to fetch the Product Reviews",
      method: "GET",
      path: "/products/reviews",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        sortField: {
          type: "string",
          description: "sortField (query param)",
          required: false,
          in: "query"
        },
        sortOrder: {
          type: "string",
          description: "sortOrder (query param)",
          required: false,
          in: "query"
        },
        rating: {
          type: "string",
          description: "rating (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        productId: {
          type: "string",
          description: "productId (query param)",
          required: false,
          in: "query"
        },
        storeId: {
          type: "string",
          description: "storeId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "limit", "offset", "sortField", "sortOrder", "rating", "startDate", "endDate", "productId", "storeId"]
    },
  {
      name: "crm_getReviewsCount",
      description: "Fetch Review Count as per status. API to fetch the Review Count as per status",
      method: "GET",
      path: "/products/reviews/count",
      params: {
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        rating: {
          type: "string",
          description: "rating (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        },
        productId: {
          type: "string",
          description: "productId (query param)",
          required: false,
          in: "query"
        },
        storeId: {
          type: "string",
          description: "storeId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "rating", "startDate", "endDate", "productId", "storeId"]
    },
  {
      name: "crm_updateProductReview",
      description: "Update Product Reviews. Update status, reply, etc of a particular review",
      method: "PUT",
      path: "/products/reviews/:reviewId",
      params: {
        reviewId: {
          type: "string",
          description: "reviewId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteProductReview",
      description: "Delete Product Review. Delete specific product review",
      method: "DELETE",
      path: "/products/reviews/:reviewId",
      params: {
        reviewId: {
          type: "string",
          description: "reviewId (path param)",
          required: true,
          in: "path"
        },
        altId: {
          type: "string",
          description: "altId (query param)",
          required: false,
          in: "query"
        },
        altType: {
          type: "string",
          description: "altType (query param)",
          required: false,
          in: "query"
        },
        productId: {
          type: "string",
          description: "productId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["altId", "altType", "productId"]
    },
  {
      name: "crm_bulkUpdateProductReview",
      description: "Update Product Reviews. Update one or multiple product reviews: status, reply, etc.",
      method: "POST",
      path: "/products/reviews/bulk-update",
      params: {}
    },
  {
      name: "crm_getProductById",
      description: "Get Product by ID. The &quot;Get Product by ID&quot; API allows to retrieve information for a specific product using its unique identifier. Use this endpoint to fetch details for a single product based on the provided product ID.",
      method: "GET",
      path: "/products/:productId",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        sendWishlistStatus: {
          type: "string",
          description: "sendWishlistStatus (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "sendWishlistStatus"]
    },
  {
      name: "crm_deleteProductById",
      description: "Delete Product by ID. The &quot;Delete Product by ID&quot; API allows deleting a specific product using its unique identifier. Use this endpoint to remove a product from the system.",
      method: "DELETE",
      path: "/products/:productId",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        sendWishlistStatus: {
          type: "string",
          description: "sendWishlistStatus (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "sendWishlistStatus"]
    },
  {
      name: "crm_updateProductById",
      description: "Update Product by ID. The &quot;Update Product by ID&quot; API allows modifying information for a specific product using its unique identifier. Use this endpoint to update details for a single product based on the provided product ID.",
      method: "PUT",
      path: "/products/:productId",
      params: {
        productId: {
          type: "string",
          description: "productId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createProduct",
      description: "Create Product. The &quot;Create Product&quot; API allows adding a new product to the system. Use this endpoint to create a product with the specified details. Ensure that the required information is provided in the request payload.",
      method: "POST",
      path: "/products/",
      params: {}
    },
  {
      name: "crm_listProducts",
      description: "List Products. The &quot;List Products&quot; API allows to retrieve a paginated list of products. Customize your results by filtering products based on name or paginate through the list using the provided query parameters. This endpoint provides a straightforward way to explore and retrieve product information.",
      method: "GET",
      path: "/products/",
      params: {
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        collectionIds: {
          type: "string",
          description: "collectionIds (query param)",
          required: false,
          in: "query"
        },
        collectionSlug: {
          type: "string",
          description: "collectionSlug (query param)",
          required: false,
          in: "query"
        },
        expand: {
          type: "string",
          description: "expand (query param)",
          required: false,
          in: "query"
        },
        productIds: {
          type: "string",
          description: "productIds (query param)",
          required: false,
          in: "query"
        },
        storeId: {
          type: "string",
          description: "storeId (query param)",
          required: false,
          in: "query"
        },
        includedInStore: {
          type: "string",
          description: "includedInStore (query param)",
          required: false,
          in: "query"
        },
        availableInStore: {
          type: "string",
          description: "availableInStore (query param)",
          required: false,
          in: "query"
        },
        sortOrder: {
          type: "string",
          description: "sortOrder (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["limit", "offset", "locationId", "search", "collectionIds", "collectionSlug", "expand", "productIds", "storeId", "includedInStore", "availableInStore", "sortOrder"]
    }
];
