// ============================================================
// 0nMCP — CRM v3.0.0 — conversation-ai
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_conversationAI_createAction",
      description: "Attach Action to Agent. Creates and attach a new action for an AI agent. Actions define specific tasks or behaviors that the agent can perform, such as booking appointments, sending follow-ups, or collecting information.",
      method: "POST",
      path: "/conversation-ai/agents/:agentId/actions",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_listActions",
      description: "List Actions for an Agent. List for actions for an agent",
      method: "GET",
      path: "/conversation-ai/agents/:agentId/actions/list",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getActionById",
      description: "Get Action by ID. Retrieves detailed information about a specific action using its unique identifier. Returns the action configuration, associated agents, and performance metrics.",
      method: "GET",
      path: "/conversation-ai/agents/:agentId/actions/:actionId",
      params: {
        actionId: {
          type: "string",
          description: "actionId (path param)",
          required: true,
          in: "path"
        },
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_conversationAI_updateAction",
      description: "Update Action. Updates an existing action&#x27;s configuration. This includes modifying the action name, description, trigger conditions, and behavior settings.",
      method: "PUT",
      path: "/conversation-ai/agents/:agentId/actions/:actionId",
      params: {
        actionId: {
          type: "string",
          description: "actionId (path param)",
          required: true,
          in: "path"
        },
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_conversationAI_deleteAction",
      description: "Remove Action from Agent. Permanently deletes an action. This will remove the action from all associated agents and cannot be undone.",
      method: "DELETE",
      path: "/conversation-ai/agents/:agentId/actions/:actionId",
      params: {
        actionId: {
          type: "string",
          description: "actionId (path param)",
          required: true,
          in: "path"
        },
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateFollowupSettings",
      description: "Update Followup Settings. Update the followup settings for an action",
      method: "PATCH",
      path: "/conversation-ai/agents/:agentId/followup-settings",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_conversationAI_createAgent",
      description: "Create an Agent. Creates a new AI agent for the location. The agent will be created with the specified configuration including name, role, actions, and behavior settings.",
      method: "POST",
      path: "/conversation-ai/agents",
      params: {}
    },
  {
      name: "crm_searchAgent",
      description: "Search Agents. Searches for AI agents based on various criteria including name, status, and configuration. Supports advanced filtering and full-text search capabilities.",
      method: "GET",
      path: "/conversation-ai/agents/search",
      params: {
        startAfter: {
          type: "string",
          description: "startAfter (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["startAfter", "limit", "query"]
    },
  {
      name: "crm_updateAgent",
      description: "Update Agent. Updates an existing AI agent&#x27;s configuration. All fields in the agent configuration can be updated including name, status, actions, and behavior settings.",
      method: "PUT",
      path: "/conversation-ai/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_conversationAI_getAgent",
      description: "Get Agent. Retrieves a specific AI agent by its ID. Returns the complete agent configuration including name, status, actions, and settings.",
      method: "GET",
      path: "/conversation-ai/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_conversationAI_deleteAgent",
      description: "Delete Agent. Deletes an AI agent permanently. This action cannot be undone. All associated configurations and conversation history will be removed.",
      method: "DELETE",
      path: "/conversation-ai/agents/:agentId",
      params: {
        agentId: {
          type: "string",
          description: "agentId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getGenerationDetails",
      description: "Get the generation details. Retrieves detailed information about AI responses including the System Prompt, Conversation history, Knowledge base, website, FAQ chunks, and Rich Text chunks.",
      method: "GET",
      path: "/conversation-ai/generations",
      params: {
        messageId: {
          type: "string",
          description: "messageId (query param)",
          required: false,
          in: "query"
        },
        source: {
          type: "string",
          description: "source (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["messageId", "source"]
    }
];
