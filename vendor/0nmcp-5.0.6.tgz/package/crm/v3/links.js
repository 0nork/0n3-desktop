// ============================================================
// 0nMCP — CRM v3.0.0 — links
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getLinkById",
      description: "Get Link by ID. Get a single link by its ID",
      method: "GET",
      path: "/links/id/:linkId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        linkId: {
          type: "string",
          description: "linkId (path param)",
          required: true,
          in: "path"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_updateLink",
      description: "Update Link. Update Link",
      method: "PUT",
      path: "/links/:linkId",
      params: {
        linkId: {
          type: "string",
          description: "linkId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteLink",
      description: "Delete Link. Delete Link",
      method: "DELETE",
      path: "/links/:linkId",
      params: {
        linkId: {
          type: "string",
          description: "linkId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_searchTriggerLinks",
      description: "Search Trigger Links. Get list of links by searching",
      method: "GET",
      path: "/links/search",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "query", "skip", "limit"]
    },
  {
      name: "crm_getLinks",
      description: "Get Links. Get Links",
      method: "GET",
      path: "/links/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createLink",
      description: "Create Link. Create Link",
      method: "POST",
      path: "/links/",
      params: {}
    }
];
