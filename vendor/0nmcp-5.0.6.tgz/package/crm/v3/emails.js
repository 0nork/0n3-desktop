// ============================================================
// 0nMCP — CRM v3.0.0 — emails
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_fetchCampaigns",
      description: "Get Campaigns. Get Campaigns",
      method: "GET",
      path: "/emails/schedule",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        emailStatus: {
          type: "string",
          description: "emailStatus (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        },
        parentId: {
          type: "string",
          description: "parentId (query param)",
          required: false,
          in: "query"
        },
        limitedFields: {
          type: "string",
          description: "limitedFields (query param)",
          required: false,
          in: "query"
        },
        archived: {
          type: "boolean",
          description: "archived (query param)",
          required: false,
          in: "query"
        },
        campaignsOnly: {
          type: "string",
          description: "campaignsOnly (query param)",
          required: false,
          in: "query"
        },
        showStats: {
          type: "string",
          description: "showStats (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "offset", "status", "emailStatus", "name", "parentId", "limitedFields", "archived", "campaignsOnly", "showStats"]
    },
  {
      name: "crm_createTemplate",
      description: "Create a new template. Create a new template",
      method: "POST",
      path: "/emails/builder",
      params: {}
    },
  {
      name: "crm_fetchTemplate",
      description: "Fetch email templates. Fetch email templates by location id",
      method: "GET",
      path: "/emails/builder",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        sortByDate: {
          type: "string",
          description: "sortByDate (query param)",
          required: false,
          in: "query"
        },
        archived: {
          type: "boolean",
          description: "archived (query param)",
          required: false,
          in: "query"
        },
        builderVersion: {
          type: "string",
          description: "builderVersion (query param)",
          required: false,
          in: "query"
        },
        name: {
          type: "string",
          description: "name (query param)",
          required: false,
          in: "query"
        },
        parentId: {
          type: "string",
          description: "parentId (query param)",
          required: false,
          in: "query"
        },
        originId: {
          type: "string",
          description: "originId (query param)",
          required: false,
          in: "query"
        },
        templatesOnly: {
          type: "string",
          description: "templatesOnly (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "offset", "search", "sortByDate", "archived", "builderVersion", "name", "parentId", "originId", "templatesOnly"]
    },
  {
      name: "crm_deleteTemplate",
      description: "Delete a template. Delete a template",
      method: "DELETE",
      path: "/emails/builder/:locationId/:templateId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        templateId: {
          type: "string",
          description: "templateId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateTemplate",
      description: "Update a template. Update a template",
      method: "POST",
      path: "/emails/builder/data",
      params: {}
    }
];
