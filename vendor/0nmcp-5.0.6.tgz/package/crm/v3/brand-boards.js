// ============================================================
// 0nMCP — CRM v3.0.0 — brand-boards
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getBrandBoardsByLocation",
      description: "Get Brand Boards. Retrieves all Brand Boards for a specific location",
      method: "GET",
      path: "/brand-boards/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        offset: {
          type: "number",
          description: "offset (query param)",
          required: false,
          in: "query"
        },
        search: {
          type: "string",
          description: "search (query param)",
          required: false,
          in: "query"
        },
        deleted: {
          type: "boolean",
          description: "deleted (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["limit", "offset", "search", "deleted"]
    },
  {
      name: "crm_getBrandBoardById",
      description: "Get Brand Board. Retrieves a specific Brand Board by its ID",
      method: "GET",
      path: "/brand-boards/:locationId/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateBrandBoard",
      description: "Update a Brand Board. Updates an existing Brand Board",
      method: "PATCH",
      path: "/brand-boards/:locationId/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteBrandBoard",
      description: "Delete a Brand Board. Deletes a Brand Board",
      method: "DELETE",
      path: "/brand-boards/:locationId/:id",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_createBrandBoard",
      description: "Create a new brand board. Creates a new brand board with logos, colors, and fonts",
      method: "POST",
      path: "/brand-boards/",
      params: {}
    }
];
