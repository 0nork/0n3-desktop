// ============================================================
// 0nMCP — CRM v3.0.0 — conversations
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_searchConversation",
      description: "Search Conversations. Returns a list of all conversations matching the search criteria along with the sort and filter options selected.",
      method: "GET",
      path: "/conversations/search",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        assignedTo: {
          type: "string",
          description: "assignedTo (query param)",
          required: false,
          in: "query"
        },
        followers: {
          type: "string",
          description: "followers (query param)",
          required: false,
          in: "query"
        },
        mentions: {
          type: "string",
          description: "mentions (query param)",
          required: false,
          in: "query"
        },
        query: {
          type: "string",
          description: "query (query param)",
          required: false,
          in: "query"
        },
        sort: {
          type: "string",
          description: "sort (query param)",
          required: false,
          in: "query"
        },
        startAfterDate: {
          type: "string",
          description: "startAfterDate (query param)",
          required: false,
          in: "query"
        },
        id: {
          type: "string",
          description: "id (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        lastMessageType: {
          type: "string",
          description: "lastMessageType (query param)",
          required: false,
          in: "query"
        },
        lastMessageAction: {
          type: "string",
          description: "lastMessageAction (query param)",
          required: false,
          in: "query"
        },
        lastMessageDirection: {
          type: "string",
          description: "lastMessageDirection (query param)",
          required: false,
          in: "query"
        },
        status: {
          type: "string",
          description: "status (query param)",
          required: false,
          in: "query"
        },
        sortBy: {
          type: "string",
          description: "sortBy (query param)",
          required: false,
          in: "query"
        },
        sortScoreProfile: {
          type: "string",
          description: "sortScoreProfile (query param)",
          required: false,
          in: "query"
        },
        scoreProfile: {
          type: "string",
          description: "scoreProfile (query param)",
          required: false,
          in: "query"
        },
        scoreProfileMin: {
          type: "string",
          description: "scoreProfileMin (query param)",
          required: false,
          in: "query"
        },
        scoreProfileMax: {
          type: "string",
          description: "scoreProfileMax (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "contactId", "assignedTo", "followers", "mentions", "query", "sort", "startAfterDate", "id", "limit", "lastMessageType", "lastMessageAction", "lastMessageDirection", "status", "sortBy", "sortScoreProfile", "scoreProfile", "scoreProfileMin", "scoreProfileMax", "startDate", "endDate"]
    },
  {
      name: "crm_getConversation",
      description: "Get Conversation. Get the conversation details based on the conversation ID",
      method: "GET",
      path: "/conversations/:conversationId",
      params: {
        conversationId: {
          type: "string",
          description: "conversationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_updateConversation",
      description: "Update Conversation. Update the conversation details based on the conversation ID",
      method: "PUT",
      path: "/conversations/:conversationId",
      params: {
        conversationId: {
          type: "string",
          description: "conversationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteConversation",
      description: "Delete Conversation. Delete the conversation details based on the conversation ID",
      method: "DELETE",
      path: "/conversations/:conversationId",
      params: {
        conversationId: {
          type: "string",
          description: "conversationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getAllCustomSubtypes",
      description: "Get All Custom Subtypes. Get all custom subtypes for a location",
      method: "GET",
      path: "/conversations/preferences/custom-subtypes",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_createCustomSubtype",
      description: "Create Custom Subtype. Create a new custom subtype for a location. Requires agency or account admin role.",
      method: "POST",
      path: "/conversations/preferences/custom-subtypes",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_updateCustomSubtype",
      description: "Update Custom Subtype. Update or archive a custom subtype. Requires agency or account admin role.",
      method: "PUT",
      path: "/conversations/preferences/custom-subtypes/:id",
      params: {
        id: {
          type: "string",
          description: "id (path param)",
          required: true,
          in: "path"
        },
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_getContactUnsubscriptionStatus",
      description: "Get Contact Unsubscription Status. Get all subscription statuses for a contact (all emails or specific email)",
      method: "GET",
      path: "/conversations/preferences/unsubscriptions/status",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        email: {
          type: "string",
          description: "email (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "contactId", "email"]
    },
  {
      name: "crm_userSubscriptionChange",
      description: "User Subscription Change. Process subscription change initiated by a user (admin/agent). Supports individual custom subscription changes and resub all functionality. Legal forms are automatically created for user-initiated resubscribe actions on custom subscriptions.",
      method: "POST",
      path: "/conversations/preferences/unsubscriptions/user-change",
      params: {}
    },
  {
      name: "crm_getEmailById",
      description: "Get email by Id. Get email by Id",
      method: "GET",
      path: "/conversations/messages/email/:id",
      params: {}
    },
  {
      name: "crm_cancelScheduledEmailMessage",
      description: "Cancel a scheduled email message. Post the messageId for the API to delete a scheduled email message. &lt;br /&gt;",
      method: "DELETE",
      path: "/conversations/messages/email/:emailMessageId/schedule",
      params: {
        emailMessageId: {
          type: "string",
          description: "emailMessageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_exportMessagesByLocation",
      description: "Export messages by location ID. Export messages for a specific location with cursor-based pagination support. Response includes messageType (string), source, and subType fields. The channel parameter is optional - if not provided, all non-email message types will be returned including activity messages (opportunity updates, appointments, etc.).",
      method: "GET",
      path: "/conversations/messages/export",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        cursor: {
          type: "string",
          description: "cursor (query param)",
          required: false,
          in: "query"
        },
        sortBy: {
          type: "string",
          description: "sortBy (query param)",
          required: false,
          in: "query"
        },
        sortOrder: {
          type: "string",
          description: "sortOrder (query param)",
          required: false,
          in: "query"
        },
        conversationId: {
          type: "string",
          description: "conversationId (query param)",
          required: false,
          in: "query"
        },
        contactId: {
          type: "string",
          description: "contactId (query param)",
          required: false,
          in: "query"
        },
        channel: {
          type: "string",
          description: "channel (query param)",
          required: false,
          in: "query"
        },
        startDate: {
          type: "string",
          description: "startDate (query param)",
          required: false,
          in: "query"
        },
        endDate: {
          type: "string",
          description: "endDate (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "cursor", "sortBy", "sortOrder", "conversationId", "contactId", "channel", "startDate", "endDate"]
    },
  {
      name: "crm_getMessage",
      description: "Get message by message id. Get message by message id.",
      method: "GET",
      path: "/conversations/messages/:id",
      params: {}
    },
  {
      name: "crm_getMessages",
      description: "Get messages by conversation id. Get messages by conversation id.",
      method: "GET",
      path: "/conversations/:conversationId/messages",
      params: {
        conversationId: {
          type: "string",
          description: "conversationId (path param)",
          required: true,
          in: "path"
        },
        lastMessageId: {
          type: "string",
          description: "lastMessageId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        type: {
          type: "string",
          description: "type (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["lastMessageId", "limit", "type"]
    },
  {
      name: "crm_sendANewMessage",
      description: "Send a new message. Post the necessary fields for the API to send a new message.",
      method: "POST",
      path: "/conversations/messages",
      params: {}
    },
  {
      name: "crm_addAnInboundMessage",
      description: "Add an inbound message. Post the necessary fields for the API to add a new inbound message. &lt;br /&gt;",
      method: "POST",
      path: "/conversations/messages/inbound",
      params: {}
    },
  {
      name: "crm_addAnOutboundMessage",
      description: "Add an external outbound call. Post the necessary fields for the API to add a new outbound call.",
      method: "POST",
      path: "/conversations/messages/outbound",
      params: {}
    },
  {
      name: "crm_sendReviewReply",
      description: "Send a review reply to Google My Business. Post a reply to a customer review on Google My Business",
      method: "POST",
      path: "/conversations/messages/review-reply",
      params: {}
    },
  {
      name: "crm_cancelScheduledMessage",
      description: "Cancel a scheduled message. Post the messageId for the API to delete a scheduled message. &lt;br /&gt;",
      method: "DELETE",
      path: "/conversations/messages/:messageId/schedule",
      params: {
        messageId: {
          type: "string",
          description: "messageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_uploadFileAttachments",
      description: "Upload file attachments. Post the necessary fields for the API to upload files. The files need to be a buffer with the key &quot;fileAttachment&quot;. &lt;br /&gt;&lt;br /&gt; The allowed file types are: &lt;br/&gt; &lt;ul&gt;&lt;li&gt;JPG&lt;/li&gt;&lt;li&gt;JPEG&lt;/li&gt;&lt;li&gt;PNG&lt;/li&gt;&lt;li&gt;MP4&lt;/li&gt;&lt;li&gt;MPEG&lt;/li&gt;&lt;li&gt;ZIP&lt;/li&gt;&lt;li&gt;RAR&lt;/li&gt;&lt;li&gt;PDF&lt;/li&gt;&lt;li&gt;DOC&lt;/li&gt;&lt;li&gt;DOCX&lt;/li&gt;&lt;li&gt;TXT&lt;/li&gt;&lt;li&gt;MP3&lt;/li&gt;&lt;li&gt;WAV&lt;/li&gt;&lt;/ul&gt; &lt;br /&gt;&lt;br /&gt; The API will return an object with the URLs",
      method: "POST",
      path: "/conversations/messages/upload",
      params: {}
    },
  {
      name: "crm_initiateFileUpload",
      description: "Initiate file upload to GCS. Generates a signed URL for direct file upload to Google Cloud Storage. Returns a signed URL valid for 15 minutes. Upload file via PUT request, then call /complete to finalize.",
      method: "POST",
      path: "/conversations/messages/upload/initiate",
      params: {}
    },
  {
      name: "crm_completeFileUpload",
      description: "Complete file upload. Validates the uploaded file in GCS and returns the public URL. Call this endpoint after successfully uploading the file to the signed URL.",
      method: "POST",
      path: "/conversations/messages/upload/complete",
      params: {}
    },
  {
      name: "crm_updateMessageStatus",
      description: "Update message status. Post the necessary fields for the API to update message status.",
      method: "PUT",
      path: "/conversations/messages/:messageId/status",
      params: {
        messageId: {
          type: "string",
          description: "messageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_addMessageAttachments",
      description: "Add message attachments. Set attachments on an existing message (replaces existing). Maximum 5 URLs. Supported for TYPE_CUSTOM_CALL (34) and TYPE_CALL (1) with subType EXTERNAL_CALL.",
      method: "PUT",
      path: "/conversations/messages/:messageId/attachments",
      params: {
        messageId: {
          type: "string",
          description: "messageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getMessageRecording",
      description: "Get Recording by Message ID. Get the recording for a message by passing the message id",
      method: "GET",
      path: "/conversations/messages/:messageId/locations/:locationId/recording",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        messageId: {
          type: "string",
          description: "messageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getMessageTranscription",
      description: "Get transcription by Message ID. Get the recording transcription for a message by passing the message id",
      method: "GET",
      path: "/conversations/locations/:locationId/messages/:messageId/transcription",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        messageId: {
          type: "string",
          description: "messageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_downloadMessageTranscription",
      description: "Download transcription by Message ID. Download the recording transcription for a message by passing the message id",
      method: "GET",
      path: "/conversations/locations/:locationId/messages/:messageId/transcription/download",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        messageId: {
          type: "string",
          description: "messageId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_liveChatAgentTyping",
      description: "Agent/Ai-Bot is typing a message indicator for live chat. Agent/AI-Bot will call this when they are typing a message in live chat message",
      method: "POST",
      path: "/conversations/providers/live-chat/typing",
      params: {}
    },
  {
      name: "crm_createConversation",
      description: "Create Conversation. Creates a new conversation with the data provided",
      method: "POST",
      path: "/conversations/",
      params: {}
    }
];
