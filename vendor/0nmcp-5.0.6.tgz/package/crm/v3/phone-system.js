// ============================================================
// 0nMCP — CRM v3.0.0 — phone-system
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_getNumberPoolList",
      description: "List Number Pools. Get list of number pools",
      method: "GET",
      path: "/phone-system/number-pools",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId"]
    },
  {
      name: "crm_availableNumbers",
      description: "List available phone numbers. Search for available phone numbers to purchase for a specific location. Supports filtering by number pattern, type, and capabilities.",
      method: "GET",
      path: "/phone-system/numbers/location/:locationId/available",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        countryCode: {
          type: "string",
          description: "countryCode (query param)",
          required: false,
          in: "query"
        },
        numberTypes: {
          type: "string",
          description: "numberTypes (query param)",
          required: false,
          in: "query"
        },
        firstPart: {
          type: "string",
          description: "firstPart (query param)",
          required: false,
          in: "query"
        },
        lastPart: {
          type: "string",
          description: "lastPart (query param)",
          required: false,
          in: "query"
        },
        anywhere: {
          type: "string",
          description: "anywhere (query param)",
          required: false,
          in: "query"
        },
        smsEnabled: {
          type: "string",
          description: "smsEnabled (query param)",
          required: false,
          in: "query"
        },
        mmsEnabled: {
          type: "string",
          description: "mmsEnabled (query param)",
          required: false,
          in: "query"
        },
        voiceEnabled: {
          type: "string",
          description: "voiceEnabled (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["countryCode", "numberTypes", "firstPart", "lastPart", "anywhere", "smsEnabled", "mmsEnabled", "voiceEnabled"]
    },
  {
      name: "crm_purchasePhoneNumber",
      description: "Purchase a phone number. Purchase a phone number for a specific location.",
      method: "POST",
      path: "/phone-system/numbers/location/:locationId/purchase",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_activeNumbers",
      description: "List active numbers. Retrieve a paginated list of active phone numbers for a specific location. Supports filtering, pagination, and optional exclusion of number pool assignments.",
      method: "GET",
      path: "/phone-system/numbers/location/:locationId",
      params: {
        locationId: {
          type: "string",
          description: "locationId (path param)",
          required: true,
          in: "path"
        },
        pageSize: {
          type: "string",
          description: "pageSize (query param)",
          required: false,
          in: "query"
        },
        page: {
          type: "number",
          description: "page (query param)",
          required: false,
          in: "query"
        },
        searchFilter: {
          type: "string",
          description: "searchFilter (query param)",
          required: false,
          in: "query"
        },
        skipNumberPool: {
          type: "string",
          description: "skipNumberPool (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["pageSize", "page", "searchFilter", "skipNumberPool"]
    }
];
