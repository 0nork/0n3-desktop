// ============================================================
// 0nMCP — CRM v3.0.0 — businesses
// ============================================================
// AUTO-GENERATED from HighLevel SDK v3.0.0.
// Do not edit by hand — re-run scripts/gen-crm-v3.mjs to refresh.
// ============================================================

export default [
  {
      name: "crm_updateBusiness",
      description: "Update Business. Update Business",
      method: "PUT",
      path: "/businesses/:businessId",
      params: {
        businessId: {
          type: "string",
          description: "businessId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_deleteBusiness",
      description: "Delete Business. Delete Business",
      method: "DELETE",
      path: "/businesses/:businessId",
      params: {
        businessId: {
          type: "string",
          description: "businessId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getBusiness",
      description: "Get Business. Get Business",
      method: "GET",
      path: "/businesses/:businessId",
      params: {
        businessId: {
          type: "string",
          description: "businessId (path param)",
          required: true,
          in: "path"
        }
      }
    },
  {
      name: "crm_getBusinessesByLocation",
      description: "Get Businesses by Location. Get Businesses by Location",
      method: "GET",
      path: "/businesses/",
      params: {
        locationId: {
          type: "string",
          description: "locationId (query param)",
          required: false,
          in: "query"
        },
        limit: {
          type: "number",
          description: "limit (query param)",
          required: false,
          in: "query"
        },
        skip: {
          type: "number",
          description: "skip (query param)",
          required: false,
          in: "query"
        }
      },
      query: ["locationId", "limit", "skip"]
    },
  {
      name: "crm_createBusiness",
      description: "Create Business. Create Business",
      method: "POST",
      path: "/businesses/",
      params: {}
    }
];
