// ============================================================
// 0n3 — the CRM's MANAGED AGENTS + the WORKFLOWS API (2026-11-10)
// ============================================================
// Managed Agents (the CRM's own always-on agents, launched 2026-10-27): list, read, and EXECUTE one turn — the agent's
// tools run during the turn and the reply names which fired. Measured live 2026-11-10 with a location token:
// GET /agent-studio/managed-agents → 200 { agents: [], total: 0 } (Version: v3). A token without the
// managed-agents scope answers 401 "The token is not authorized for this scope."
// Workflows API: Private Beta per sub-account. Measured the same day: GET /workflows/step-types → 403
// WORKFLOW_API_NOT_ENABLED_FOR_LOCATION ("not a token or scope problem"). The reads are here so the day a location is
// enabled they answer; create/update are NOT defined until their bodies have been seen working.
// ============================================================
const V = 'v3';
export default [
  {
    name: 'crm_list_managed_agents', version: V, method: 'GET', path: '/agent-studio/managed-agents',
    description: "List the location's Managed Agents (the CRM's own always-on agents). Needs the managed-agents.readonly scope.",
    params: { locationId: { type: 'string', description: 'Location ID', required: false, in: 'query' }, limit: { type: 'number', description: 'Results per page (25 by default)', required: false, in: 'query' }, skip: { type: 'number', description: 'How many to skip', required: false, in: 'query' } },
    query: ['locationId', 'limit', 'skip'],
  },
  {
    name: 'crm_get_managed_agent', version: V, method: 'GET', path: '/agent-studio/managed-agents/:agentId',
    description: 'Read one Managed Agent.',
    params: { agentId: { type: 'string', description: 'Managed Agent ID', required: true, in: 'path' }, locationId: { type: 'string', description: 'Location ID', required: false, in: 'query' } },
    query: ['locationId'],
  },
  {
    name: 'crm_execute_managed_agent', version: V, idempotent: true, method: 'POST', path: '/agent-studio/managed-agents/:agentId/execute',
    description: "Send one message to a Managed Agent and get its answer. Its tools run during the turn; the reply carries finalText and toolsFired. Pass sessionId to continue a conversation and contactId to act for a contact. Needs the managed-agents.write scope.",
    params: {
      agentId: { type: 'string', description: 'Managed Agent ID', required: true, in: 'path' },
      message: { type: 'string', description: 'What to say or ask', required: true, in: 'body' },
      sessionId: { type: 'string', description: 'Continue an earlier conversation', required: false, in: 'body' },
      contactId: { type: 'string', description: 'The contact this turn is about', required: false, in: 'body' },
      extraVariables: { type: 'object', description: 'Named values the agent can use', required: false, in: 'body' },
      idempotency_key: { type: 'string', description: 'Reuse to make a retry safe (one is made when omitted)', required: false },
    },
    body: ['message', 'sessionId', 'contactId', 'extraVariables'],
  },
  {
    name: 'crm_workflow_step_types', version: V, method: 'GET', path: '/workflows/step-types',
    description: 'The step types a workflow can be built from (Workflows API, Private Beta: a location that is not enabled answers 403 WORKFLOW_API_NOT_ENABLED_FOR_LOCATION).',
    params: { locationId: { type: 'string', description: 'Location ID', required: false, in: 'query' } }, query: ['locationId'],
  },
  {
    name: 'crm_workflow_logs', version: V, method: 'GET', path: '/workflows/:workflowId/logs',
    description: "One workflow's execution logs (Workflows API, Private Beta per location).",
    params: { workflowId: { type: 'string', description: 'Workflow ID', required: true, in: 'path' }, locationId: { type: 'string', description: 'Location ID', required: false, in: 'query' } }, query: ['locationId'],
  },
];
