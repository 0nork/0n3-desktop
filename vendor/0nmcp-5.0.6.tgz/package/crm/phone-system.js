// ============================================================
// 0nMCP — CRM Phone System API Tool Definitions
// ============================================================
// Phone number purchasing, management, and number pools.
// Scopes: phonenumbers.read, phonenumbers.write, numberpools.read
// ============================================================

export default [
  {
    name: "crm_purchase_phone_number",
    description: "Purchase a phone number for a CRM location. Specify country, capabilities (voice/sms), and optionally an area code or contains pattern.",
    method: "POST",
    path: "/phone-number/purchase",
    params: {
      locationId: { type: "string", description: "Location ID", required: true, in: "body" },
      number: { type: "string", description: "Specific phone number to purchase (E.164 format, e.g. +14155551234)", required: false, in: "body" },
      country: { type: "string", description: "Country code (US, CA, GB, etc.)", required: false, in: "body" },
      areaCode: { type: "string", description: "Desired area code (e.g. 412, 724)", required: false, in: "body" },
      contains: { type: "string", description: "Pattern the number should contain", required: false, in: "body" },
      capabilities: { type: "array", description: "Capabilities: ['voice', 'sms', 'mms']", required: false, in: "body" },
    },
    body: ["locationId", "number", "country", "areaCode", "contains", "capabilities"],
  },

  {
    name: "crm_search_phone_numbers",
    description: "Search available phone numbers to purchase by area code, country, or pattern.",
    method: "GET",
    path: "/phone-number/search",
    params: {
      locationId: { type: "string", description: "Location ID", required: true, in: "query" },
      country: { type: "string", description: "Country code (US, CA, GB, etc.)", required: false, in: "query" },
      areaCode: { type: "string", description: "Area code to search (e.g. 412)", required: false, in: "query" },
      contains: { type: "string", description: "Pattern to search for", required: false, in: "query" },
      type: { type: "string", description: "Number type: local, tollfree, mobile", required: false, in: "query" },
      limit: { type: "number", description: "Max results", required: false, in: "query" },
    },
  },

  {
    name: "crm_list_active_numbers",
    description: "List all active phone numbers for a location with pagination.",
    method: "GET",
    path: "/phone-number/active",
    params: {
      locationId: { type: "string", description: "Location ID", required: true, in: "query" },
      page: { type: "number", description: "Page number", required: false, in: "query" },
      pageSize: { type: "number", description: "Results per page", required: false, in: "query" },
      searchFilter: { type: "string", description: "Filter by number or label", required: false, in: "query" },
    },
  },

  {
    name: "crm_release_phone_number",
    description: "Release (cancel) a phone number from a location.",
    method: "DELETE",
    path: "/phone-number/:phoneNumberId",
    params: {
      phoneNumberId: { type: "string", description: "Phone number ID to release", required: true, in: "path" },
      locationId: { type: "string", description: "Location ID", required: true, in: "query" },
    },
  },

  {
    name: "crm_update_phone_number",
    description: "Update phone number settings — label, forwarding, voicemail, call recording.",
    method: "PUT",
    path: "/phone-number/:phoneNumberId",
    params: {
      phoneNumberId: { type: "string", description: "Phone number ID", required: true, in: "path" },
      locationId: { type: "string", description: "Location ID", required: true, in: "body" },
      name: { type: "string", description: "Label/name for the number", required: false, in: "body" },
      forwardingNumber: { type: "string", description: "Forward calls to this number", required: false, in: "body" },
      callRecording: { type: "boolean", description: "Enable call recording", required: false, in: "body" },
    },
    body: ["locationId", "name", "forwardingNumber", "callRecording"],
  },

  {
    name: "crm_list_number_pools",
    description: "List number pools for a location (used for call tracking).",
    method: "GET",
    path: "/phone-number/number-pool",
    params: {
      locationId: { type: "string", description: "Location ID", required: true, in: "query" },
    },
  },
]
