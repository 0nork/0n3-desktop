/**
 * Every data-driven CRM definition set, in the order 4.x registered them (so a
 * name collision resolves to the same winner). The bespoke 4.x modules
 * (oauth-store with its committed secret, course generator, billing, media,
 * agent builder…) are NOT ported: they were single-tenant by construction and
 * each one becomes a catalog endpoint or a vault-aware tool on its own merits.
 */
import { registerTools } from './helpers.js';
import contacts from './contacts.js';
import conversations from './conversations.js';
import calendars from './calendars.js';
import opportunities from './opportunities.js';
import invoices from './invoices.js';
import payments from './payments.js';
import products from './products.js';
import locations from './locations.js';
import social from './social.js';
import users from './users.js';
import objects from './objects.js';
import knowledgeBase from './knowledge-base.js';
import voiceAi from './voice-ai.js';
import saas from './saas.js';
import funnels from './funnels.js';
import phoneSystem from './phone-system.js';
import agentStudio from './agent-studio.js';
import managedAgents from './managed-agents.js';
import v3Tools, { V3_MODULES } from './v3/index.js';

export const CRM_DEFINITION_SETS = [
  ['Contacts', contacts], ['Conversations', conversations], ['Calendars', calendars], ['Opportunities', opportunities],
  ['Invoices', invoices], ['Payments', payments], ['Products', products], ['Locations', locations], ['Social', social],
  ['Users', users], ['Objects', objects], ['Knowledge Base', knowledgeBase], ['Voice AI', voiceAi], ['SaaS', saas],
  ['Funnels', funnels], ['Phone System', phoneSystem], ['Agent Studio', agentStudio], ['Managed Agents + Workflows API', managedAgents], ['v3 (generated)', v3Tools],
];
export { V3_MODULES };

/** @returns {number} CRM tools registered on this server */
export function registerCrmTools(server, z, options) {
  let n = 0;
  for (const [, defs] of CRM_DEFINITION_SETS) n += registerTools(server, z, defs, options);
  return n;
}
