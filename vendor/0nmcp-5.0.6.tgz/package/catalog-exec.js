/**
 * Execute one catalog endpoint with one credential set. Pure request building
 * is separated from the network call so it can be tested without a network.
 *
 * Catalog contract (catalog.js, ported verbatim from 0nMCP):
 *   service.baseUrl, service.authHeader(creds) → headers, service.endpoints[key] = { method, path, body?, query? }
 * Path params are written `:id` or `{id}`. Unused params go to the query
 * string on GET/DELETE and to the body otherwise. Services whose APIs speak
 * form encoding (Stripe, Twilio, Mailgun) get bracketed form bodies.
 */
import { getService } from './catalog.js';

const FORM_SERVICES = new Set(['stripe', 'twilio', 'mailgun', 'overpass']); // Overpass takes data=<query> as a form

function flattenForm(obj, prefix = '', out = new URLSearchParams()) {
  for (const [k, v] of Object.entries(obj || {})) {
    const key = prefix ? `${prefix}[${k}]` : k;
    if (v === undefined || v === null) continue;
    if (Array.isArray(v)) v.forEach((x, i) => (typeof x === 'object' ? flattenForm(x, `${key}[${i}]`, out) : out.append(`${key}[${i}]`, String(x))));
    else if (typeof v === 'object') flattenForm(v, key, out);
    else out.append(key, String(v));
  }
  return out;
}


/**
 * A PATH VALUE IS NOT A STRING — IT IS A PATH, AND THE SLASHES MEAN SOMETHING.
 *
 * `encodeURIComponent` escapes "/" to "%2F", which is correct per RFC 3986 and
 * destroys the value. Half the modern APIs in this catalog address things by
 * HIERARCHICAL RESOURCE NAME (Google's AIP-122: `properties/547156881`,
 * `accounts/1/dataStreams/9`), so the encoder turned
 *
 *   GET /v1beta/properties/547156881/metadata      (what was meant)
 *   GET /v1beta/properties%2F547156881/metadata    (what was sent)
 *
 * and Google answered with an HTML 404 page — not even a JSON API error,
 * because the request never reached the API surface at all. Measured live
 * 2026-09-19 on `api_call ga4 get_metadata`, and it would have silently broken
 * every GA4 step of the google_site_setup mini-app the same way: create_property
 * takes `parent: accounts/…`, create_data_stream takes `parent: properties/…`.
 *
 * So: escape each SEGMENT, keep the separators. Everything that made
 * encodeURIComponent right — spaces, #, ?, & — is still escaped; only the "/"
 * survives, because in these APIs it is structure, not content.
 *
 * `..` is refused outright. A path parameter that can climb the path can make
 * one endpoint call another, which turns an allowlisted endpoint into an
 * arbitrary one against credentials the caller never chose to spend there.
 */
export function encodePathValue(value, where = 'path parameter') {
  const segments = value.split('/');
  for (const seg of segments) {
    if (seg === '..' || seg === '.') throw new Error(`Refusing ${where}: path traversal ("${value}")`);
  }
  return segments.map(encodeURIComponent).join('/');
}

export function buildRequest(serviceKey, endpointKey, params = {}, creds = {}) {
  const svc = getService(serviceKey);
  if (!svc) throw new Error(`Unknown service: ${serviceKey}`);
  const ep = svc.endpoints?.[endpointKey];
  if (!ep) throw new Error(`Unknown endpoint "${endpointKey}" for ${serviceKey}. Available: ${Object.keys(svc.endpoints || {}).join(', ')}`);
  const used = new Set();
  const path = String(ep.path || '').replace(/(?::([A-Za-z0-9_]+))|(?:\{([A-Za-z0-9_]+)\})/g, (m, a, b) => {
    const k = a || b;
    if (params[k] === undefined || params[k] === null) return m;
    used.add(k);
    // Some APIs take a WHOLE URL as one path segment (Search Console: /sites/{siteUrl}/sitemaps/{feedpath}, where
    // siteUrl is "sc-domain:x.com" or "https://x.com/" and feedpath is "https://x.com/sitemap.xml"). Keeping "/" there
    // splits the URL into path segments → Google 404. Endpoints list those params in `wholeSegment`.
    if ((ep.wholeSegment || svc.wholeSegment || []).includes(k)) { const v = String(params[k]); if (v.includes('..')) throw new Error(`Refusing ${serviceKey}.${endpointKey} param "${k}": path traversal`); return encodeURIComponent(v) }
    return encodePathValue(String(params[k]), `${serviceKey}.${endpointKey} param "${k}"`);
  });
  const rest = Object.fromEntries(Object.entries(params).filter(([k]) => !used.has(k)));
  const method = String(ep.method || 'GET').toUpperCase();
  const headers = { ...(typeof svc.authHeader === 'function' ? svc.authHeader(creds) : {}) };
  // An endpoint may live on a sibling host (eBay's identity + finances sit on apiz.ebay.com while the rest is api.ebay.com).
  // A service whose host is per ACCOUNT (DocuSign spreads accounts over na1/na2/eu… servers) names it from the record.
  const ownBase = typeof svc.baseUrlFor === 'function' ? svc.baseUrlFor(creds) : null;
  // An empty path means "the base URL itself" (a Grok Bot routine webhook is one full URL); never add a trailing slash to it.
  let url = String(ep.baseUrl || ownBase || svc.baseUrl || '').replace(/\/$/, '') + (path ? '/' + path.replace(/^\//, '') : '');
  let body;

  /**
   * AN ENDPOINT'S DECLARED `query` APPLIES ON EVERY METHOD, NOT JUST GET.
   *
   * This only ever built a query string for GET and DELETE, so on a body
   * method every declared query parameter was swept into the JSON body
   * instead — silently, since the catalog entry looked correct and the
   * declaration was simply never read.
   *
   * Measured 2026-09-19 across the catalog: 55 endpoints in 11 services
   * declare `query` on a POST/PUT/PATCH. Three shapes of damage, all quiet:
   *   site_verification.verify  → "Missing required field verification_type"
   *   google_sheets.append      → valueInputOption ignored, so values land RAW
   *   smartlead.*               → api_key in the body is not auth; 401
   * and the one that is not merely broken but dangerous:
   *   supabase.update_row       → `id` is a PostgREST FILTER. In the body it
   *                               filters nothing, and the PATCH rewrites
   *                               EVERY ROW IN THE TABLE.
   *
   * Declared query params are therefore pulled out before the body is built.
   */
  const declared = Array.isArray(ep.query) ? ep.query : [];
  const qs = new URLSearchParams();
  for (const k of declared) {
    const v = rest[k];
    if (v === undefined || v === null) continue;
    qs.append(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
    delete rest[k];
  }
  // A service may scope EVERY call by one of its credentials (Vercel: ?teamId= from the vault record). Added only when the
  // caller did not pass that parameter themselves, so a call can still target another team explicitly.
  const scoped = typeof svc.defaultQuery === 'function' ? (svc.defaultQuery(creds) || {}) : {};
  for (const [k, v] of Object.entries(scoped)) {
    if (v === undefined || v === null || v === '' || qs.has(k) || rest[k] !== undefined) continue;
    qs.append(k, String(v));
  }

  if (method === 'GET' || method === 'DELETE') {
    for (const [k, v] of Object.entries(rest)) if (v !== undefined && v !== null) qs.append(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
    const s = qs.toString();
    if (s) url += (url.includes('?') ? '&' : '?') + s;
  } else if (FORM_SERVICES.has(serviceKey)) {
    const s = qs.toString();
    if (s) url += (url.includes('?') ? '&' : '?') + s;
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
    body = flattenForm(rest).toString();
  } else {
    const s = qs.toString();
    if (s) url += (url.includes('?') ? '&' : '?') + s;
    if (!Object.keys(headers).some((h) => h.toLowerCase() === 'content-type')) headers['Content-Type'] = 'application/json';
    body = JSON.stringify(rest);
  }
  return { url, method, headers, body };
}

export async function executeEndpoint(serviceKey, endpointKey, params, creds, fetchImpl = fetch) {
  const req = buildRequest(serviceKey, endpointKey, params, creds);
  // A service may cap how long one call may take (Overpass). The cap is reported as that service not answering in time.
  const cap = Number(getService(serviceKey)?.timeoutMs) || 0;
  let r;
  try { r = await fetchImpl(req.url, { method: req.method, headers: req.headers, body: req.body, ...(cap ? { signal: AbortSignal.timeout(cap) } : {}) }); }
  catch (e) { if (cap && (e?.name === 'TimeoutError' || e?.name === 'AbortError')) return { ok: false, status: 0, data: { message: `${getService(serviceKey).name} did not answer within ${Math.round(cap / 1000)} seconds` } }; throw e; }
  const text = await r.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  // A service that meters its calls (GraphHopper's daily credits) says what this call cost, read from ITS OWN response headers.
  const svc = getService(serviceKey); let usage = null;
  try { usage = typeof svc?.usage === 'function' && r.headers && typeof r.headers.get === 'function' ? svc.usage(r.headers) : null; } catch { usage = null; }
  return { ok: r.ok, status: r.status, data, ...(usage ? { usage } : {}) };
}
