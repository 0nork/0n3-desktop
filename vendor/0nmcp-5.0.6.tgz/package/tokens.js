/**
 * tokens.js — short-lived access tokens minted from long-lived credentials,
 * at call time, so a vault record never has to hold a token that dies in an
 * hour.
 *
 * A record's credentials are the durable thing (a refresh token, or an app
 * registration's tenant + client id + secret). This turns them into the
 * `access_token` the catalog's header builders expect, and caches it in
 * memory until just before it expires. Nothing is written back to the vault.
 *
 * One table entry per provider family is the whole protocol:
 *   match(service)         → does this minter apply to the service being called
 *   scope(service)         → the resource the token must be minted FOR
 *   tokenUrl(creds)        → where to mint it
 *   grant(creds, env)      → the form body (refresh_token or client_credentials)
 */
import { createHash, createSign } from 'node:crypto';
import { REDDIT_UA } from './oauth-doors.js';

const GOOGLE_FAMILY = /^(google(_[a-z_]+)?|gmail|youtube|ga4|search_console|site_verification|gcloud)$/;
const MICROSOFT_FAMILY = /^(microsoft|azure|outlook|teams|onedrive)$/;


/**
 * DEFAULT SCOPES FOR A GOOGLE SERVICE ACCOUNT.
 *
 * A service account signs its OWN assertion, so it can ask for any scope
 * without a consent screen — which means the scope list is a decision made
 * HERE, not by a human clicking Allow, and getting it wrong is silent.
 *
 * Measured 2026-09-19: `analytics.edit` does NOT cover the GA4 *Data* API.
 * With edit alone, creating a property works and `runReport` answers 403
 * ACCESS_TOKEN_SCOPE_INSUFFICIENT — the admin half live and the read half
 * dead, which reads like a broken property rather than a missing scope.
 * `analytics.readonly` is listed alongside it for that reason.
 */
export const SA_SCOPES = [
  'https://www.googleapis.com/auth/siteverification',
  'https://www.googleapis.com/auth/webmasters',
  'https://www.googleapis.com/auth/analytics.edit',
  'https://www.googleapis.com/auth/analytics.readonly',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/drive',
];

/**
 * A signed JWT assertion — the service-account grant.
 *
 * This is the whole reason a service account is worth supporting: there is no
 * consent screen, no redirect URI to register, and no refresh token to go
 * stale. The key signs a claim and Google hands back a token. `sub` performs
 * domain-wide delegation when a record sets it; without it the account acts as
 * itself, which is what a GA4/Search Console grant to its email expects.
 */
export function saAssertion(creds, { now = Date.now } = {}) {
  const scopes = Array.isArray(creds.scopes) && creds.scopes.length ? creds.scopes : SA_SCOPES;
  const t = Math.floor(now() / 1000);
  const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const head = b64({ alg: 'RS256', typ: 'JWT', ...(creds.private_key_id ? { kid: creds.private_key_id } : {}) });
  const claim = b64({
    iss: creds.client_email, scope: scopes.join(' '),
    aud: 'https://oauth2.googleapis.com/token', iat: t, exp: t + 3600,
    ...(creds.subject ? { sub: creds.subject } : {}),
  });
  const signing = `${head}.${claim}`;
  // Keys pasted through JSON or an env var arrive with literal \n.
  const pem = String(creds.private_key || '').replace(/\\n/g, '\n');
  return `${signing}.${createSign('RSA-SHA256').update(signing).end().sign(pem).toString('base64url')}`;
}

export const MINTERS = [
  {
    key: 'ebay',
    match: (s) => s === 'ebay',
    tokenUrl: (c) => (String(c.env || '').toUpperCase() === 'SANDBOX' ? 'https://api.sandbox.ebay.com/identity/v1/oauth2/token' : 'https://api.ebay.com/identity/v1/oauth2/token'),
    // eBay authenticates the APP with HTTP Basic on the token call and refuses client_id/secret in the body.
    headers: (c) => ({ Authorization: `Basic ${Buffer.from(`${c.client_id || ''}:${c.client_secret || ''}`).toString('base64')}` }),
    grant: (c) => (c.refresh_token ? { grant_type: 'refresh_token', refresh_token: c.refresh_token, ...(c.scopes ? { scope: c.scopes } : {}) } : null),
  },
  {
    key: 'google',
    match: (s) => GOOGLE_FAMILY.test(s),
    tokenUrl: () => 'https://oauth2.googleapis.com/token',
    grant: (c, env) => {
      if (c.refresh_token) return {
        grant_type: 'refresh_token', refresh_token: c.refresh_token,
        client_id: c.client_id || env.GOOGLE_CLIENT_ID || '', client_secret: c.client_secret || env.GOOGLE_CLIENT_SECRET || '',
      };
      // A service account: signs its own assertion, so no consent screen and
      // no registered redirect URI stand between the vault and a live token.
      if (c.type === 'service_account' && c.client_email && c.private_key) return {
        grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: saAssertion(c),
      };
      return null;
    },
  },
  {
    key: 'microsoft',
    match: (s) => MICROSOFT_FAMILY.test(s),
    scope: (s) => (s === 'azure' ? 'https://management.azure.com/.default' : 'https://graph.microsoft.com/.default'),
    tokenUrl: (c) => `https://login.microsoftonline.com/${encodeURIComponent(c.tenant_id || 'common')}/oauth2/v2.0/token`,
    grant: (c, env, scope) => {
      const client_id = c.client_id || env.MICROSOFT_CLIENT_ID || '', client_secret = c.client_secret || env.MICROSOFT_CLIENT_SECRET || '';
      if (c.refresh_token) return { grant_type: 'refresh_token', refresh_token: c.refresh_token, client_id, client_secret, scope };
      // An app registration with its own secret (the Azure path for a project): no user, no refresh token.
      if (c.tenant_id && c.client_id && c.client_secret) return { grant_type: 'client_credentials', client_id, client_secret, scope };
      return null;
    },
  },
  // The sign-in doors of oauth-doors.js. Each mints only from a record the door wrote (client_id + refresh_token), so an
  // older record holding a pasted token is left exactly as it was. `field` is the credential key the catalog's header
  // builder reads, when it is not access_token.
  ...[
    { key: 'quickbooks', url: 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer', basic: true },
    { key: 'xero', url: 'https://identity.xero.com/connect/token', basic: true, field: 'accessToken' },
    { key: 'zoom', url: 'https://zoom.us/oauth/token', basic: true },
    { key: 'docusign', url: (c) => `${c.token_host || 'https://account.docusign.com'}/oauth/token`, basic: true, field: 'accessToken' },
    { key: 'dropbox', url: 'https://api.dropboxapi.com/oauth2/token' },
    { key: 'twitter', url: 'https://api.x.com/2/oauth2/token', basic: true, field: 'bearerToken' },
    { key: 'reddit', url: 'https://www.reddit.com/api/v1/access_token', basic: true, field: 'accessToken', headers: { 'User-Agent': REDDIT_UA } },
    { key: 'twitch', url: 'https://id.twitch.tv/oauth2/token', field: 'accessToken' },
    { key: 'ticktick', url: 'https://ticktick.com/oauth/token', basic: true },
    { key: 'mulesoft', url: 'https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token', field: 'token' },
  ].map((d) => ({
    key: d.key, field: d.field,
    match: (s) => s === d.key,
    tokenUrl: (c) => (typeof d.url === 'function' ? d.url(c) : d.url),
    headers: (c) => ({ ...(d.headers || {}), ...(d.basic ? { Authorization: `Basic ${Buffer.from(`${c.client_id || ''}:${c.client_secret || ''}`).toString('base64')}` } : {}) }),
    grant: (c) => (c.refresh_token && c.client_id ? { grant_type: 'refresh_token', refresh_token: c.refresh_token, ...(d.basic ? {} : { client_id: c.client_id, client_secret: c.client_secret || '' }) } : null),
  })),
];

const cache = new Map();
const inflight = new Map();
const keyOf = (service, creds) => `${service}:${createHash('sha256').update(JSON.stringify(creds)).digest('hex').slice(0, 24)}`;

/** Returns credentials with a live `access_token`, or the input untouched when no minter applies. Throws with the provider's words when minting fails. */
/**
 * `onRotate(creds)` is called when the provider hands back a NEW refresh token (QuickBooks, Xero, Zoom and X rotate on
 * every refresh and kill the old one). Without writing it back, the next refresh after a cold start would use a dead
 * token and the connection would silently die a day later. Runtime passes resolver.save.
 */
export async function freshCredentials(service, creds = {}, { fetchImpl = fetch, env = process.env, now = Date.now, onRotate = null } = {}) {
  // A MANAGED CRM record holds no token: 0nCore owns the agency credential and mints a location token on request.
  if (service === 'crm' && creds && creds.managed_by === '0ncore' && creds.location_id) {
    const k = keyOf(`crm:managed:${creds.location_id}`, creds);
    const hit = cache.get(k);
    if (hit && hit.exp - 60_000 > now()) return { ...creds, access_token: hit.token };
    const base = (env.ONCORE_URL || 'https://www.0ncore.com').replace(/\/$/, ''); const secret = env.ONCORE_INTERNAL_SECRET || '';
    if (!secret) throw new Error('crm token: ONCORE_INTERNAL_SECRET is not set on this deployment');
    const r = await fetchImpl(`${base}/api/bridge/crm-location`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-bridge-secret': secret }, body: JSON.stringify({ locationId: creds.location_id, source: '0n3' }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.token) throw new Error(`crm token: 0ncore ${d.error || `HTTP ${r.status}`}`);
    const exp = d.expiresAt ? Date.parse(d.expiresAt) : now() + 50 * 60_000;
    cache.set(k, { token: d.token, exp: Number.isFinite(exp) ? exp : now() + 50 * 60_000 });
    return { ...creds, access_token: d.token };
  }
  // An APP BUILDER sign-in (appstudio.js): the CRM connector's own OAuth, renewed at its /mcp/token with the public client id.
  if (service === 'crm' && creds && creds.via === 'appbuilder' && creds.refresh_token && creds.client_id) {
    if (creds.access_token && Number(creds.expires_at || 0) - 60_000 > now()) return creds;
    const k = keyOf('crm:appbuilder', { c: creds.client_id, r: creds.refresh_token });
    const hit = cache.get(k);
    if (hit && hit.exp - 60_000 > now()) return { ...creds, access_token: hit.token };
    if (inflight.has(k)) return { ...creds, access_token: await inflight.get(k) };
    const p = (async () => {
      const r = await fetchImpl('https://services.leadconnectorhq.com/mcp/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' }, body: new URLSearchParams({ grant_type: 'refresh_token', refresh_token: creds.refresh_token, client_id: creds.client_id, resource: 'https://services.leadconnectorhq.com/mcp/v2' }).toString() });
      const d = await r.json().catch(() => ({}));
      if (!r.ok || !d.access_token) throw new Error(`crm token: ${d.error_description || d.error || `HTTP ${r.status}`} — connect the app builder again`);
      const exp = now() + (Number(d.expires_in) || 3600) * 1000;
      if (onRotate) { try { await onRotate({ ...creds, access_token: d.access_token, refresh_token: d.refresh_token || creds.refresh_token, expires_at: exp }); } catch (e) { console.error('[tokens] crm appbuilder: could not save the renewed sign-in:', e.message); } }
      cache.set(k, { token: d.access_token, exp });
      return d.access_token;
    })();
    inflight.set(k, p);
    try { return { ...creds, access_token: await p }; } finally { inflight.delete(k); }
  }
  const m = MINTERS.find((x) => x.match(service));
  if (!m) return creds;
  const scope = m.scope ? m.scope(service) : undefined;
  const body = m.grant(creds, env, scope);
  if (!body) return creds; // a pasted access_token, or nothing we can mint from — leave it to the call
  const k = keyOf(`${service}:${scope || ''}`, creds);
  // Catalog header builders read access_token or accessToken (YouTube, Xero, DocuSign…) — fill both, plus a door's own field.
  const as = (t) => ({ ...creds, access_token: t, accessToken: t, ...(m.field ? { [m.field]: t } : {}) });
  const hit = cache.get(k);
  if (hit && hit.exp - 60_000 > now()) return as(hit.token);
  // Two calls at once must not both spend a refresh token that only works once.
  if (inflight.has(k)) return as(await inflight.get(k));
  const p = (async () => {
    const r = await fetchImpl(m.tokenUrl(creds), { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json', ...(m.headers ? m.headers(creds) : {}) }, body: new URLSearchParams(body).toString() });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.access_token) throw new Error(`${m.key} token: ${d.error_description || d.error || `HTTP ${r.status}`}`);
    if (d.refresh_token && creds.refresh_token && d.refresh_token !== creds.refresh_token && onRotate) {
      try { await onRotate({ ...creds, refresh_token: d.refresh_token }); } catch (e) { console.error(`[tokens] ${m.key}: could not save the new refresh token:`, e.message); }
    }
    cache.set(k, { token: d.access_token, exp: now() + Math.max(60, Number(d.expires_in) || 3600) * 1000 });
    return d.access_token;
  })();
  inflight.set(k, p);
  try { return as(await p); } finally { inflight.delete(k); }
}

/**
 * The FAMILY PARENTS — credential records, not callable services.
 *
 * There is no catalog service called "google": it is the record that gmail,
 * search_console, google_analytics and the rest authenticate THROUGH. Listing
 * it as "not a catalog service, so api_call cannot reach it" is true of the
 * key and wrong about the record — it says the connection doing all the work
 * is broken. Named here so the services tool can tell an identity from an
 * orphan.
 */
export const FAMILY_PARENTS = new Set(['google', 'microsoft', 'azure']);

/** The vault record a service reads when it has none of its own: gmail → google, outlook → microsoft. */
export function familyOf(service) {
  if (GOOGLE_FAMILY.test(service) && service !== 'google') return 'google';
  if (MICROSOFT_FAMILY.test(service) && service !== 'microsoft' && service !== 'azure') return 'microsoft';
  return null;
}

export function _clearTokenCache() { cache.clear(); inflight.clear(); }
