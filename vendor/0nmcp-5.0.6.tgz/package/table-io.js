/**
 * UPDATE A TABLE — the calls around blocks.js planTable(), for an Excel workbook (Microsoft 365) or a Google Sheet.
 *
 * `api(service, endpoint, params)` is the engine's own api_call seam, so every request is the person's own connection,
 * audited like any other step. Order: find the file → find the tab (by the name as the file spells it NOW: a renamed tab
 * "Guided Logistics Load Board" → "Guided Load Board" stopped a live job for a morning) → read it → plan → write ONE
 * rectangle with null in every cell that must not be touched → read it back → remember what the sheet holds.
 * A dry run stops after the plan and says what it would have written.
 */
import { planTable, rememberFrom, graphShareId, googleSheetId, tabMatch, colLetter } from './blocks.js';

const words = (r) => String(r?.error || r?.data?.error?.message || r?.data?.message || (typeof r?.data === 'string' ? r.data : '') || `answered ${r?.status}`).slice(0, 300);
const pad = (rows, width) => (rows || []).map((r) => { const x = [...(r || [])]; while (x.length < width) x.push(''); return x; });

export async function updateTable({ api, app, values: v, dry = false, memory = null }) {
  const fail = (detail) => ({ state: 'failed', detail });
  const link = String(v.workbook || '').trim(); const wantTab = String(v.tab || '').trim();
  if (!link) return fail('No file was given. Paste the link to the Excel workbook or the Google Sheet.');
  if (!wantTab) return fail('No tab was named.');
  let io;
  if (app === 'google_sheets') {
    const id = googleSheetId(link); if (!id) return fail('That is not a Google Sheets link (…/spreadsheets/d/<id>/…).');
    const meta = await api('google_sheets', 'get_spreadsheet', { spreadsheetId: id, fields: 'properties.title,sheets.properties.title' });
    if (!meta.ok) return meta.notConnected ? { state: 'skipped', detail: 'Google Sheets is not in your vault — connect it first' } : fail(`Google Sheets: ${words(meta)}`);
    const names = (meta.data?.sheets || []).map((s) => s.properties?.title).filter(Boolean); const tab = tabMatch(names, wantTab);
    if (!tab) return fail(`"${meta.data?.properties?.title || 'The sheet'}" has no tab called "${wantTab}". Its tabs are: ${names.join(', ')}.`);
    const q = `'${tab.replace(/'/g, "''")}'`;
    io = {
      file: meta.data?.properties?.title || 'Google Sheet', tab, target: `google_sheets:${id}:${tab.toLowerCase()}`,
      read: async () => { const r = await api('google_sheets', 'get_values', { spreadsheetId: id, range: q, valueRenderOption: 'UNFORMATTED_VALUE' }); if (!r.ok) throw new Error(words(r)); const f = await api('google_sheets', 'get_values', { spreadsheetId: id, range: q }); return { grid: r.data?.values || [], text: f.ok ? f.data?.values || [] : null }; },
      write: async (address, vals) => { const r = await api('google_sheets', 'update_values', { spreadsheetId: id, range: `${q}!${address}`, valueInputOption: 'USER_ENTERED', values: vals }); if (!r.ok) throw new Error(words(r)); },
      back: async (address) => { const r = await api('google_sheets', 'get_values', { spreadsheetId: id, range: `${q}!${address}`, valueRenderOption: 'UNFORMATTED_VALUE' }); return r.ok ? r.data?.values || [] : null; },
    };
  } else if (app === 'microsoft') {
    const item = await api('microsoft', 'resolve_share', { encodedUrl: graphShareId(link) });
    if (!item.ok) return item.notConnected ? { state: 'skipped', detail: 'Microsoft 365 is not in your vault — connect it first' } : fail(`Microsoft 365 could not open that link: ${words(item)}`);
    const driveId = item.data?.parentReference?.driveId; const itemId = item.data?.id;
    if (!driveId || !itemId) return fail('Microsoft 365 opened the link but did not say which file it is.');
    const ws = await api('microsoft', 'list_worksheets', { driveId, itemId }); if (!ws.ok) return fail(`"${item.data?.name || 'The file'}" could not be opened as a workbook: ${words(ws)}`);
    const names = (ws.data?.value || []).map((s) => s.name); const tab = tabMatch(names, wantTab);
    if (!tab) return fail(`"${item.data?.name || 'The workbook'}" has no tab called "${wantTab}". Its tabs are: ${names.join(', ')}.`);
    const sheet = tab.replace(/'/g, "''");
    io = {
      file: item.data?.name || 'workbook', tab, target: `microsoft:${itemId}:${tab.toLowerCase()}`,
      read: async () => {
        const r = await api('microsoft', 'get_used_range', { driveId, itemId, sheet }); if (!r.ok) throw new Error(words(r));
        const r0 = Number(r.data?.rowIndex) || 0, c0 = Number(r.data?.columnIndex) || 0;
        const shift = (g) => [...Array.from({ length: r0 }, () => []), ...(g || []).map((row) => [...new Array(c0).fill(''), ...row])];
        return { grid: shift(r.data?.values), text: r.data?.text ? shift(r.data.text) : null };
      },
      write: async (address, vals) => { const r = await api('microsoft', 'update_range', { driveId, itemId, sheet, address, values: vals }); if (!r.ok) throw new Error(words(r)); },
      back: async (address) => { const r = await api('microsoft', 'get_range', { driveId, itemId, sheet, address }); return r.ok ? r.data?.values || [] : null; },
    };
  } else return { state: 'skipped', detail: `Update a table works with Excel (Microsoft 365) and Google Sheets, not ${app}.` };

  let now; try { now = await io.read(); } catch (e) { return fail(`“${io.tab}” could not be read: ${e.message}`); }
  const width = Math.max(0, ...(now.grid || []).map((r) => (r || []).length));
  const mem = memory ? await memory.load(io.target).catch(() => ({})) : {};
  const plan = planTable({ grid: pad(now.grid, width), text: now.text ? pad(now.text, width) : null, rows: v.rows, key: v.key, map: v.map, memory: mem });
  if (!plan.ok) return fail(plan.error);
  const counts = `${plan.added} added, ${plan.updated} updated, ${plan.unchanged} already right`;
  const kept = plan.kept.length ? ` · kept ${plan.kept.length} cell${plan.kept.length === 1 ? '' : 's'} a person changed (${plan.kept.slice(0, 3).map((k) => `${k.key} · ${k.column}`).join('; ')}${plan.kept.length > 3 ? '; …' : ''})` : '';
  const lost = plan.noColumn.length ? ` · the tab has no column for: ${plan.noColumn.slice(0, 6).join(', ')}` : '';
  const out = { file: io.file, tab: io.tab, added: plan.added, updated: plan.updated, unchanged: plan.unchanged, kept: plan.kept.slice(0, 100), noColumn: plan.noColumn, skipped: plan.skipped, range: plan.patch?.address || null };
  if (dry) return { state: 'ok', detail: `Dry run — would write to “${io.tab}” in ${io.file}: ${counts}${kept}${lost}. Nothing was sent.`, out: { ...out, dry: true }, extra: { dry: true, account: io.file, would: { tab: io.tab, range: plan.patch?.address || 'nothing to write', added: plan.added, updated: plan.updated, kept: plan.kept.length } } };
  let back = null;
  if (plan.patch) {
    try { await io.write(plan.patch.address, plan.patch.values); } catch (e) { return fail(`“${io.tab}” refused the write: ${e.message}`); }
    back = await io.back(plan.patch.address).catch(() => null);
  }
  if (memory) { try { await memory.save(io.target, rememberFrom(plan, back ? pad(back, width) : null, mem)); } catch (e) { return { state: 'ok', detail: `“${io.tab}” in ${io.file}: ${counts}${kept}${lost} · BUT what was written could not be remembered (${e.message}), so the next run cannot tell its own cells from a person's and will leave them alone.`, out }; } }
  return { state: 'ok', detail: `“${io.tab}” in ${io.file}: ${counts}${kept}${lost}`, out };
}
export { colLetter };
