/**
 * AUTOMATED ALERTS — "when a new lead hits the CRM, email me" (Mike, 2026-10-25).
 *
 * A person types a sentence on the Alerts page. It becomes a RULE: a WATCH (one catalog endpoint, polled with the
 * account's own connection, diffed by id) and an ACTION (email through the account's own email connection, a text
 * through its Twilio, or a push to the phones). A cron runs every rule that is due, with that account's runtime, and
 * records exactly what happened: how many new things, what was sent, or the provider's own words when it failed.
 *
 * The first run of a rule only learns what is already there; it never alerts on the backlog. Nothing here invents a
 * result: a rule that could not check says so on its row.
 *
 * APPS WORKING TOGETHER (Mike, 2026-11-06: "make one app work with another, especially on mobile"). A rule's action can
 * also be a SEQUENCE: "when a payment lands in Stripe → run 'Log the sale'" — the watch's new item becomes the sequence's
 * {{trigger.*}}. And a rule can watch the CLOCK instead of an app, which is what makes "every morning at 8" real. These
 * rules are never typed by hand: they are DERIVED from the sequences' trigger blocks every time a canvas is saved
 * (syncSequences), so the canvas stays the one source of truth and deleting a sequence deletes its rule.
 */
import { TASKS, nameOf } from './flow-defs.js';

export const TABLE = 'alert_rules';
const now = () => new Date().toISOString();
const clip = (s, n) => String(s ?? '').slice(0, n);

/** What can be watched, by the words people use for it. `list` is where the items sit in the answer; `id` the field. */
export const WATCHES = [
  { key: 'crm_contact', words: /\b(lead|contact|prospect|opportunit)/, service: 'crm', endpoint: 'list_contacts', params: () => ({ limit: 100 }), list: ['contacts', 'data'], id: 'id', what: 'new contacts in your CRM', label: (c) => c.email || c.name || `${c.firstName || ''} ${c.lastName || ''}`.trim() || c.id, needsLocation: true },
  { key: 'hubspot_contact', words: /\bhubspot\b/, service: 'hubspot', endpoint: 'list_contacts', params: () => ({ limit: 50 }), list: ['results'], id: 'id', what: 'new HubSpot contacts', label: (c) => c.properties?.email || c.id },
  { key: 'stripe_payment', words: /\b(payment|paid|charge|sale|purchase)/, service: 'stripe', endpoint: 'list_payments', params: () => ({ limit: 50 }), list: ['data'], id: 'id', what: 'new payments in Stripe', label: (c) => `${((c.amount || 0) / 100).toFixed(2)} ${(c.currency || '').toUpperCase()} ${c.receipt_email || c.description || ''}`.trim() },
  { key: 'stripe_customer', words: /\bstripe\b.*\bcustomer|\bcustomer\b.*\bstripe\b/, service: 'stripe', endpoint: 'list_customers', params: () => ({ limit: 50 }), list: ['data'], id: 'id', what: 'new Stripe customers', label: (c) => c.email || c.name || c.id },
  { key: 'stripe_invoice', words: /\binvoice/, service: 'stripe', endpoint: 'list_invoices', params: () => ({ limit: 50 }), list: ['data'], id: 'id', what: 'new invoices in Stripe', label: (c) => `${c.customer_email || c.customer || ''} ${((c.total || 0) / 100).toFixed(2)}`.trim() },
  { key: 'shopify_order', words: /\border/, service: 'shopify', endpoint: 'list_orders', params: () => ({ limit: 50, status: 'any' }), list: ['orders'], id: 'id', what: 'new Shopify orders', label: (c) => `#${c.order_number || c.name || c.id} ${c.email || ''} ${c.total_price || ''}`.trim() },
  { key: 'woo_order', words: /\bwoo(commerce)?\b/, service: 'woocommerce', endpoint: 'list_orders', params: () => ({ per_page: 50 }), list: [], id: 'id', what: 'new WooCommerce orders', label: (c) => `#${c.number || c.id} ${c.billing?.email || ''} ${c.total || ''}`.trim() },
  { key: 'github_issue', words: /\bissue|pull request|\bPR\b/, service: 'github', endpoint: 'list_issues', params: (m) => ({ owner: m.owner, repo: m.repo, per_page: 50, state: 'open' }), list: [], id: 'id', what: 'new GitHub issues', label: (c) => `#${c.number} ${c.title}`, needsRepo: true },
  { key: 'calendly_event', words: /\bbooking|appointment|meeting|calendly/, service: 'calendly', endpoint: 'list_events', params: () => ({ count: 50 }), list: ['collection'], id: 'uri', what: 'new Calendly bookings', label: (c) => `${c.name || ''} ${c.start_time || ''}`.trim() },
  { key: 'square_payment', words: /\bsquare\b/, service: 'square', endpoint: 'list_payments', params: () => ({ limit: 50 }), list: ['payments'], id: 'id', what: 'new Square payments', label: (c) => `${((c.amount_money?.amount || 0) / 100).toFixed(2)} ${c.amount_money?.currency || ''}`.trim() },
  // A mailbox of a connected Microsoft 365 account (the "Email arrives" trigger block names the mailbox and, optionally, words
  // the subject must contain). Never matched from a typed sentence: it needs a mailbox, which only the block carries.
  { key: 'microsoft_mail', words: /(?!)/, needsMailbox: true, service: 'microsoft', endpoint: 'list_mailbox_messages', params: (m) => ({ mailbox: m.mailbox, $top: 25, $orderby: 'receivedDateTime desc', $select: 'id,subject,from,receivedDateTime,hasAttachments' }), list: ['value'], id: 'id', what: 'new emails', label: (c) => `${c.subject || '(no subject)'} — ${c.from?.emailAddress?.address || ''}`,
    keep: (c, watch) => !watch?.subject || String(c.subject || '').toLowerCase().includes(String(watch.subject).toLowerCase()) },
  { key: 'typeform_response', words: /\bform\b|typeform|submission|response/, service: 'typeform', endpoint: 'list_responses', params: (m) => ({ form_id: m.form, page_size: 50 }), list: ['items'], id: 'response_id', what: 'new form responses', label: (c) => c.response_id, needsForm: true },
];
const SERVICE_WORDS = { crm: /\bcrm\b/, stripe: /\bstripe\b/, shopify: /\bshopify\b/, github: /\bgithub\b/, calendly: /\bcalendly\b/, square: /\bsquare\b/, typeform: /\btypeform\b/, hubspot: /\bhubspot\b/, woocommerce: /\bwoo(commerce)?\b/ };

/** Minutes from "every 15 minutes" / "hourly" / "every day" / "each morning". Default 5. */
export function cadenceOf(text) {
  const t = text.toLowerCase();
  const m = /every\s+(\d+)\s*(min|minute|hour|hr|day)/.exec(t);
  if (m) { const n = Number(m[1]); return m[2].startsWith('h') ? n * 60 : m[2].startsWith('d') ? n * 1440 : Math.max(5, n); }
  if (/\b(hourly|every hour|each hour)\b/.test(t)) return 60;
  if (/\b(daily|every day|each day|every morning|each morning|once a day)\b/.test(t)) return 1440;
  if (/\b(weekly|every week)\b/.test(t)) return 10080;
  return 5;
}

/**
 * Plain words → a rule, deterministically. Returns { ok, rule } or { ok:false, error, hint }.
 * `connected` = the services the account holds; `email` = the account's own address (the default "me").
 */
export function parseAlert(text, { connected = [], email = '' } = {}) {
  const t = String(text || '').trim(); const low = t.toLowerCase();
  if (!t) return { ok: false, error: 'Say what to watch and what to do.' };
  // which service, if named
  const named = Object.keys(SERVICE_WORDS).filter((k) => SERVICE_WORDS[k].test(low));
  // which watch: a named service narrows first, then the words
  let w = WATCHES.find((x) => (!named.length || named.includes(x.service)) && x.words.test(low)) || null;
  if (!w && named.length === 1) w = WATCHES.find((x) => x.service === named[0]) || null;
  if (!w) return { ok: false, error: 'I could not tell what to watch.', hint: 'Try: "when a new lead hits the CRM", "when a payment lands in Stripe", "when a Shopify order comes in", "when an issue is opened in github owner/repo".' };
  const m = {};
  if (w.needsRepo) { const r = /([a-z0-9_.-]+)\/([a-z0-9_.-]+)/i.exec(t); if (!r) return { ok: false, error: 'Which repo? Name it like owner/repo.', hint: 'e.g. "when an issue is opened in 0nork/0nMCP, email me"' }; m.owner = r[1]; m.repo = r[2]; }
  if (w.needsForm) { const r = /form\s+([A-Za-z0-9]{6,})/i.exec(t); if (!r) return { ok: false, error: 'Which form? Give its id.', hint: 'e.g. "when form AbC123xy gets a response, email me"' }; m.form = r[1]; }
  // action
  const emailAt = /\b([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})\b/.exec(t);
  const phone = /\+?\d[\d\s().-]{8,}\d/.exec(t.replace(/every \d+/g, ''));
  let action;
  if (/\b(text|sms)\b/.test(low) && phone) action = { kind: 'sms', to: phone[0].replace(/[\s().-]/g, '') };
  else if (/\b(push|notify|alert|ping)\b/.test(low) && !/\bemail\b/.test(low)) action = { kind: 'push' };
  else if (/\b(e-?mail|mail)\b/.test(low) || emailAt) action = { kind: 'email', to: emailAt ? emailAt[1] : email };
  else action = { kind: 'push' };
  if (action.kind === 'email' && !action.to) return { ok: false, error: 'Email whom? Add the address.', hint: 'e.g. "… email me at you@company.com"' };
  const every = cadenceOf(t);
  const rule = { text: clip(t, 500), watch: { key: w.key, service: w.service, endpoint: w.endpoint, params: w.params(m), what: w.what, needsLocation: !!w.needsLocation }, action, every, state: 'active' };
  const notConnected = !connected.includes(w.service);
  return { ok: true, rule, summary: summarize(rule), warning: notConnected ? `${nameOf(w.service)} is not connected yet. The rule is saved; it starts checking once you connect ${nameOf(w.service)}.` : null };
}

export function summarize(rule) {
  const a = rule.action;
  if (rule.watch?.key === 'clock') return `Run "${a.name || 'the sequence'}" ${clockWords(rule.watch)}.`;
  const act = a.kind === 'sequence' ? `run "${a.name || 'the sequence'}"` : a.kind === 'email' ? `email ${a.to}` : a.kind === 'sms' ? `text ${a.to}` : 'send a push alert to your phones';
  const ev = rule.every >= 1440 ? `once a day` : rule.every >= 60 ? `every ${Math.round(rule.every / 60)} hour${rule.every >= 120 ? 's' : ''}` : `every ${rule.every} minutes`;
  return `Check for ${rule.watch.what} ${ev}; for each new one, ${act}.`;
}

// ── the store ──────────────────────────────────────────────────────────────
export class AlertStore {
  constructor({ rest }) { if (!rest) throw new Error('AlertStore needs a rest seam'); this.rest = rest; }
  async list(accountId) { return (await this.rest.select(TABLE, { account_id: accountId })).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at))).map(shape); }
  async get(accountId, id) { const r = (await this.rest.select(TABLE, { id }))[0]; return r && r.account_id === accountId ? shape(r) : null; }
  async create(accountId, rule) {
    const row = { account_id: accountId, text: clip(rule.text, 500), watch: rule.watch, action: rule.action, every_min: Math.max(5, Number(rule.every) || 5), state: 'active', cursor: rule.cursor || { ids: [], seeded: false }, fires: 0, last_run_at: null, last_result: null, created_at: now(), updated_at: now() };
    return shape(await this.rest.upsert(TABLE, row, 'id'));
  }
  async update(accountId, id, patch) {
    const r = (await this.rest.select(TABLE, { id }))[0]; if (!r || r.account_id !== accountId) return null;
    const p = { updated_at: now() };
    if (patch.state && ['active', 'paused'].includes(patch.state)) p.state = patch.state;
    if (patch.text !== undefined) p.text = clip(patch.text, 500);
    if (patch.action && typeof patch.action === 'object') p.action = patch.action;
    if (patch.every) p.every_min = Math.max(5, Number(patch.every) || 5);
    await this.rest.update(TABLE, { id }, p); return shape({ ...r, ...p });
  }
  async remove(accountId, id) { const r = (await this.rest.select(TABLE, { id }))[0]; if (!r || r.account_id !== accountId) return false; await this.rest.delete(TABLE, { id }); return true; }
  /** Every active rule whose next check is due, across accounts (the cron's view). */
  async due(at = Date.now()) {
    const rows = await this.rest.select(TABLE, { state: 'active' });
    return rows.filter((r) => (r.watch?.key === 'clock' && r.cursor?.nextAt ? new Date(r.cursor.nextAt).getTime() <= at : !r.last_run_at || new Date(r.last_run_at).getTime() + (r.every_min || 5) * 60000 <= at)).map(shape);
  }

  /**
   * Make this workspace's automation rules match its sequences: one rule per sequence whose trigger is "an app event"
   * (values.m_trigger 'app' + m_watch) or "a schedule" (m_trigger 'schedule' + m_when). A rule whose watch did not change
   * keeps its cursor, so saving a canvas never re-fires the backlog; a sequence that is gone takes its rule with it.
   * Returns what it did, for the canvas save to report.
   */
  async syncSequences(accountId, workspaceId, sequences = [], { now: at = Date.now() } = {}) {
    const want = new Map();
    for (const q of Array.isArray(sequences) ? sequences : []) { const r = ruleForSequence(q, workspaceId, at); if (r) want.set(q.id, r); }
    const mine = (await this.rest.select(TABLE, { account_id: accountId })).filter((r) => r.action?.kind === 'sequence' && r.action.workspaceId === workspaceId);
    const out = { created: 0, updated: 0, removed: 0, kept: 0 };
    for (const r of mine) {
      const w = want.get(r.action.sequenceId);
      if (!w) { await this.rest.delete(TABLE, { id: r.id }); out.removed++; continue; }
      want.delete(r.action.sequenceId);
      const sameWatch = JSON.stringify(watchKey(r.watch)) === JSON.stringify(watchKey(w.watch));
      const state = w.state || r.state;
      const p = { text: w.text, action: w.action, every_min: w.every, state, updated_at: now() };
      if (!sameWatch) { p.watch = w.watch; p.cursor = w.cursor; p.last_result = null; }
      if (sameWatch && r.text === w.text && r.state === state && JSON.stringify(r.action) === JSON.stringify(w.action)) { out.kept++; continue; }
      await this.rest.update(TABLE, { id: r.id }, p); out.updated++;
    }
    for (const w of want.values()) { const made = await this.create(accountId, w); if (made && w.state === 'paused') await this.rest.update(TABLE, { id: made.id }, { state: 'paused' }); out.created++; }
    return out;
  }
  /** The automation rules of one workspace, by sequence id (what the phone shows under each sequence). */
  async forWorkspace(accountId, workspaceId) {
    return (await this.list(accountId)).filter((r) => r.action?.kind === 'sequence' && r.action.workspaceId === workspaceId);
  }
  async record(id, { cursor, result, fired = 0 }) {
    const r = (await this.rest.select(TABLE, { id }))[0]; if (!r) return;
    await this.rest.update(TABLE, { id }, { cursor: cursor || r.cursor, last_result: result, fires: (r.fires || 0) + fired, last_run_at: now(), updated_at: now() });
  }
}
// ── sequences as actions, the clock as a watch ─────────────────────────────
/** The things a phone can say "when this happens" about: the watches that need no extra id (repo, form) to run. */
const SAY = { crm_contact: 'a new lead comes into the CRM', hubspot_contact: 'a new contact lands in HubSpot', stripe_payment: 'a payment comes into Stripe', stripe_customer: 'a new customer signs up in Stripe', stripe_invoice: 'a new invoice is made in Stripe', shopify_order: 'a Shopify order comes in', woo_order: 'a WooCommerce order comes in', calendly_event: 'someone books on Calendly', square_payment: 'a Square payment comes in' };
export const APP_EVENTS = () => WATCHES.filter((w) => !w.needsRepo && !w.needsForm && !w.needsMailbox).map((w) => ({ key: w.key, service: w.service, what: w.what, say: SAY[w.key] || w.what }));

/** The schedules the phone offers, in words a 4th grader reads. `days` = allowed weekdays (0 = Sunday); none = every day. */
export const SCHEDULES = {
  hourly: { label: 'Every hour', every: 60 },
  daily: { label: 'Every day', every: 1440, at: true },
  weekdays: { label: 'Every weekday (Mon–Fri)', every: 1440, at: true, days: [1, 2, 3, 4, 5] },
  weekly: { label: 'Every Monday', every: 10080, at: true, days: [1] },
};
const HHMM = /^([01]?\d|2[0-3]):([0-5]\d)$/;
const clockWords = (w) => { const s = SCHEDULES[w.when] || {}; return `${(s.label || 'on a schedule').toLowerCase()}${w.at ? ` at ${w.at}` : ''}${w.tz && w.at ? ` (${w.tz})` : ''}`; };
const watchKey = (w) => (w?.key === 'clock' ? { key: 'clock', when: w.when, at: w.at || null, tz: w.tz || null } : { key: w?.key, params: w?.params || {}, ...(w?.subject ? { subject: w.subject } : {}) });

/** The wall clock in a time zone, as numbers. Falls back to UTC for a zone this runtime does not know. */
function partsIn(tz, ms) {
  let f; try { f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', weekday: 'short' }); } catch { f = new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', weekday: 'short' }); }
  const o = Object.fromEntries(f.formatToParts(new Date(ms)).map((x) => [x.type, x.value]));
  return { y: +o.year, m: +o.month, d: +o.day, h: +o.hour % 24, min: +o.minute, dow: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(o.weekday) };
}
/** The next moment a clock watch is due after `from`. Daylight saving is handled by asking the zone, not by adding hours. */
export function nextClock(w, from = Date.now()) {
  const s = SCHEDULES[w.when] || { every: Math.max(5, Number(w.every) || 1440) };
  if (!s.at || !HHMM.test(String(w.at || ''))) return from + s.every * 60000;
  const [hh, mm] = String(w.at).split(':').map(Number); const tz = w.tz || 'UTC';
  const today = partsIn(tz, from);
  for (let k = 0; k < 9; k++) {
    // A first guess as if the zone were UTC, then shift by the zone's real offset at that guess (twice, for the DST edge).
    let t = Date.UTC(today.y, today.m - 1, today.d + k, hh, mm);
    for (let i = 0; i < 2; i++) { const p = partsIn(tz, t); t += (Date.UTC(today.y, today.m - 1, today.d + k, hh, mm) - Date.UTC(p.y, p.m - 1, p.d, p.h, p.min)); }
    const p = partsIn(tz, t);
    if (t > from + 30000 && (!s.days || s.days.includes(p.dow))) return t;
  }
  return from + s.every * 60000;
}

/** One sequence's trigger block → the rule that makes it run by itself, or null for a tap/form/button sequence. */
export function ruleForSequence(q, workspaceId, at = Date.now()) {
  const t = (q?.nodes || []).find((n) => n.type === 'trigger'); const v = t?.values || {};
  const name = String(q?.name || t?.title || 'Sequence').slice(0, 80);
  const action = { kind: 'sequence', workspaceId, sequenceId: q.id, name };
  // Paused/unpaused lives on the rule (the Alerts page and the phone both toggle it) unless the trigger block says so itself.
  const state = v.m_paused === undefined ? null : (v.m_paused ? 'paused' : 'active');
  // "Email arrives": the block itself says which mailbox and which subjects — no phone settings needed.
  if (t?.key === 'email') {
    const mailbox = String(v.mailbox || '').trim(); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mailbox)) return null;
    const w = WATCHES.find((x) => x.key === 'microsoft_mail'); const subject = String(v.subject || '').trim().slice(0, 120);
    const watch = { key: w.key, service: w.service, endpoint: w.endpoint, params: w.params({ mailbox }), what: `new emails in ${mailbox}${subject ? ` with “${subject}” in the subject` : ''}`, ...(subject ? { subject } : {}) };
    const rule = { watch, action, every: 5, state, cursor: { ids: [], seeded: false } };
    return { ...rule, text: clip(`When there are ${watch.what}, run "${name}"`, 500) };
  }
  if (v.m_trigger === 'app' && v.m_watch) {
    const w = WATCHES.find((x) => x.key === v.m_watch && !x.needsRepo && !x.needsForm); if (!w) return null;
    const watch = { key: w.key, service: w.service, endpoint: w.endpoint, params: w.params({}), what: w.what, needsLocation: !!w.needsLocation };
    const rule = { watch, action, every: 5, state, cursor: { ids: [], seeded: false } };
    return { ...rule, text: clip(`When there are ${w.what}, run "${name}"`, 500) };
  }
  if (v.m_trigger === 'schedule' && SCHEDULES[v.m_when]) {
    const s = SCHEDULES[v.m_when];
    const watch = { key: 'clock', service: null, when: v.m_when, at: s.at ? (HHMM.test(String(v.m_at || '')) ? v.m_at : '08:00') : null, tz: v.m_tz || 'UTC', what: 'the schedule' };
    const rule = { watch, action, every: s.every, state, cursor: { ids: [], seeded: true, nextAt: new Date(nextClock(watch, at)).toISOString() } };
    return { ...rule, text: clip(summarize(rule), 500) };
  }
  return null;
}

/**
 * What an app's new item looks like to a sequence: the same {{trigger.name}} / email / phone / amount every phone step
 * already offers, whatever the app called them, plus `item` (the app's own record, bounded) for anything else.
 */
export function asTrigger(item, w) {
  const it = item || {}; const pr = it.properties || {}; const bl = it.billing || it.billing_address || {}; const cu = it.customer || {};
  const first = (...v) => v.find((x) => x !== undefined && x !== null && String(x).trim() !== '');
  const name = first(it.name, [it.firstName, it.lastName].filter(Boolean).join(' '), [pr.firstname, pr.lastname].filter(Boolean).join(' '), [bl.first_name, bl.last_name].filter(Boolean).join(' '), typeof cu === 'object' ? cu.name : null);
  const email = first(it.email, it.receipt_email, it.customer_email, pr.email, bl.email, typeof cu === 'object' ? cu.email : null, it.contact?.email);
  const phone = first(it.phone, pr.phone, bl.phone, typeof cu === 'object' ? cu.phone : null);
  const cents = first(it.amount_money?.amount, w?.service === 'stripe' ? first(it.amount, it.total) : null);
  const amount = cents !== undefined ? (Number(cents) / 100).toFixed(2) : first(it.total_price, it.total, it.amount);
  // A big record keeps only its plain top-level fields, so a run's stored inputs stay small.
  let raw = it; try { if (JSON.stringify(it).length > 8000) raw = Object.fromEntries(Object.entries(it).filter(([, x]) => x === null || typeof x !== 'object').map(([k, x]) => [k, typeof x === 'string' ? x.slice(0, 500) : x])); } catch { raw = {}; }
  const mail = it.subject !== undefined && it.receivedDateTime ? { subject: String(it.subject || ''), from: it.from?.emailAddress?.address || '', receivedAt: it.receivedDateTime } : {};
  return { ...mail, id: String(it[w?.id || 'id'] ?? ''), label: w ? clip(w.label(it), 160) : '', what: w?.what || '', name: name || '', email: email || '', phone: phone || '', amount: amount ?? '', answer: first(it.answer, it.title, it.description, w ? w.label(it) : '') || '', item: raw };
}

const shape = (r) => ({ id: r.id, accountId: r.account_id, text: r.text, cursor: r.cursor || { ids: [], seeded: false }, watch: r.watch, action: r.action, every: r.every_min, state: r.state, fires: r.fires || 0, lastRunAt: r.last_run_at || null, lastResult: r.last_result || null, seeded: !!r.cursor?.seeded, createdAt: r.created_at, updatedAt: r.updated_at, summary: summarize({ watch: r.watch, action: r.action, every: r.every_min }) });

// ── one check of one rule, with that account's runtime ────────────────────
const pick = (data, paths) => { if (Array.isArray(data)) return data; for (const p of paths) if (Array.isArray(data?.[p])) return data[p]; for (const v of Object.values(data || {})) if (Array.isArray(v)) return v; return []; };

/**
 * @param {{ rule, call: (tool: string, args: object) => Promise<any>, connected: string[], locationId?: string|null, email?: string, notify?: (payload) => Promise<any>, store: AlertStore }} o
 */
export async function runRule({ rule, call, connected, locationId = null, label = null, candidates = null, email = '', notify = null, store, runSequence = null }) {
  const at = now();
  if (rule.watch?.key === 'clock') {
    // The clock has no backlog: it is due, so it runs once, and the next time is worked out from now.
    const result = { at, checked: 'the schedule', found: 1, new: 1, sent: [], skipped: null, error: null };
    const out = runSequence ? await runSequence({ at, scheduled: true, name: '', email: '', phone: '', answer: '', datetime: at }).catch((e) => ({ ok: false, error: clip(e.message, 240) })) : { ok: false, error: 'This rule runs a sequence, and nothing here can run one.' };
    result.sent.push(out);
    await store.record(rule.id, { cursor: { ...(rule.cursor || {}), seeded: true, nextAt: new Date(nextClock(rule.watch, Date.now())).toISOString() }, result, fired: out.ok ? 1 : 0 });
    return result;
  }
  const w = WATCHES.find((x) => x.key === rule.watch.key);
  const result = { at, checked: rule.watch.what, found: 0, new: 0, sent: [], skipped: null, error: null };
  if (!w || !connected.includes(rule.watch.service)) { result.skipped = `${nameOf(rule.watch.service)} is not connected; nothing was checked.`; await store.record(rule.id, { result }); return result; }
  const params = { ...(rule.watch.params || {}) };
  const failed = (x) => !x || x.ok === false || x.error || (Number(x.status) >= 400);
  const words = (x) => clip(x?.error || x?.data?.error?.message || x?.data?.message || JSON.stringify(x?.data || {}), 240);
  let r; let usedLabel = null;
  if (w.needsLocation) {
    // Several CRM records (an agency token, per-location tokens, OAuth mirrors) may name the same location, and only some
    // can read it. Try them in order — the one that worked last time first — and remember the winner on the rule.
    const row0 = await store.get(rule.accountId, rule.id).catch(() => null);
    let list = Array.isArray(candidates) && candidates.length ? candidates : (locationId ? [{ label, locationId }] : []);
    const remembered = row0?.cursor?.crmLabel || rule.cursor?.crmLabel || null;
    if (remembered) list = [...list.filter((c) => c.label === remembered), ...list.filter((c) => c.label !== remembered)];
    if (!list.length) { result.skipped = 'Your CRM connection has no location id; nothing was checked.'; await store.record(rule.id, { result }); return result; }
    const tried = []; result.candidates = list.map((c) => c.label || 'default');
    for (const c of list) {
      let x; try { x = await call('api_call', { service: rule.watch.service, endpoint: rule.watch.endpoint, params: { ...params, locationId: c.locationId }, ...(c.label ? { label: c.label } : {}) }); } catch (e) { x = { ok: false, error: e.message }; }
      if (!failed(x)) { r = x; usedLabel = c.label || null; break; }
      tried.push(list.length > 1 ? `${c.label || 'default'}: ${words(x)}` : words(x));
      if (![401, 403].includes(Number(x?.status))) { r = x; break; }
    }
    if (!r || failed(r)) { result.tried = tried; result.error = `${nameOf(rule.watch.service)} answered: ${tried.join(' · ')}`.slice(0, 600); await store.record(rule.id, { result }); return result; }
  } else {
    try { r = await call('api_call', { service: rule.watch.service, endpoint: rule.watch.endpoint, params }); } catch (e) { r = { ok: false, error: e.message }; }
    if (failed(r)) { result.error = `${nameOf(rule.watch.service)} answered: ${words(r)}`; await store.record(rule.id, { result }); return result; }
  }
  if (usedLabel) result.via = usedLabel;
  const items = pick(r.data ?? r, w.list).filter((x) => x && (x[w.id] !== undefined)).filter((x) => (w.keep ? w.keep(x, rule.watch) : true)); result.found = items.length;
  const ids = items.map((x) => String(x[w.id]));
  const seen = new Set((rule.cursorIds || []));
  // The store's cursor is read fresh (rule.cursorIds is for tests); fall back to the row.
  const row = await store.get(rule.accountId, rule.id).catch(() => null);
  const cursor = rule.cursor || row?.cursor || { ids: [], seeded: false };
  for (const id of cursor.ids || []) seen.add(id);
  const fresh = cursor.seeded ? items.filter((x) => !seen.has(String(x[w.id]))) : [];
  result.new = fresh.length;
  if (!cursor.seeded) result.skipped = `First check: learned ${items.length} existing ${items.length === 1 ? 'item' : 'items'}; ${rule.action?.kind === 'sequence' ? 'it runs' : 'alerts start'} with the next new one.`;
  let fired = 0;
  if (rule.action?.kind === 'sequence') {
    // Oldest first, so a sequence that writes rows writes them in the order they happened. Ten per check keeps a burst inside one function's time.
    for (const item of fresh.slice(0, 10).reverse()) {
      const payload = { ...asTrigger(item, w), ...(rule.watch.params?.mailbox ? { mailbox: rule.watch.params.mailbox } : {}) };
      const out = runSequence ? await runSequence(payload).catch((e) => ({ ok: false, error: clip(e.message, 240) })) : { ok: false, error: 'This rule runs a sequence, and nothing here can run one.' };
      result.sent.push({ ...out, label: payload.label }); if (out.ok) fired++;
    }
    if (fresh.length > 10) result.skipped = `${fresh.length} new at once; ran the first 10 and left the rest unrun (they are not retried).`;
  }
  for (const item of rule.action?.kind === 'sequence' ? [] : fresh.slice(0, 20)) {
    const label = clip(w.label(item), 160) || String(item[w.id]);
    const subject = `New: ${label} — ${rule.watch.what}`;
    const body = `${rule.watch.what}: ${label}\n\nRule: ${rule.text}\n\nSent by 0n3 Automated Alerts at ${at}.`;
    const out = await act({ rule, call, connected, notify, subject, body, label, email });
    result.sent.push(out); if (out.ok) fired++;
  }
  const nextIds = [...new Set([...ids, ...(cursor.ids || [])])].slice(0, 2000);
  await store.record(rule.id, { cursor: { ids: nextIds, seeded: true, ...(usedLabel ? { crmLabel: usedLabel } : {}) }, result, fired });
  return result;
}

/** Gmail wants one base64url RFC 822 message; everything else takes fields. */
const gmailRaw = ({ to, from, subject, html }) => Buffer.from(`From: ${from}\r\nTo: ${to}\r\nSubject: ${subject}\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n${html}`).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
/** A Google sign-in covers Gmail (the resolver maps gmail → google). */
const hasApp = (connected, k) => connected.includes(k) || (k === 'gmail' && connected.includes('google'));

async function act({ rule, call, connected, notify, subject, body, label }) {
  const a = rule.action || { kind: 'push' };
  try {
    if (a.kind === 'email') {
      const app = TASKS.send_email.apps.find((k) => hasApp(connected, k));
      if (!app) { if (notify) { await notify({ title: subject, body: label }); return { ok: true, via: 'push', note: 'No email app is connected (Resend, SendGrid, Postmark, Mailgun, Gmail or Brevo); sent a push alert instead.' }; } return { ok: false, error: 'No email app is connected; connect Resend, SendGrid, Postmark, Mailgun, Gmail or Brevo.' }; }
      const v = { to: a.to, subject, html: body.replace(/\n/g, '<br>'), from: a.from || (app === 'gmail' ? 'me' : 'alerts@0n3.app') };
      const params = app === 'gmail' ? { raw: gmailRaw(v) } : TASKS.send_email.params?.[app] ? TASKS.send_email.params[app](v) : v;
      const r = await call('api_call', { service: app, endpoint: TASKS.send_email.ep[app], params });
      if (r && r.ok !== false && !r.error && !(Number(r.status) >= 400)) return { ok: true, via: app, to: a.to, label };
      return { ok: false, via: app, error: clip(r?.error || r?.data?.message || JSON.stringify(r?.data || r), 240) };
    }
    if (a.kind === 'sms') {
      if (!connected.includes('twilio')) return { ok: false, error: 'Texting needs Twilio connected.' };
      const r = await call('api_call', { service: 'twilio', endpoint: 'send_sms', params: { to: a.to, body: `${subject}\n${label}` } });
      return r && r.ok !== false && !r.error && !(Number(r.status) >= 400) ? { ok: true, via: 'twilio', to: a.to, label } : { ok: false, via: 'twilio', error: clip(r?.error || JSON.stringify(r?.data || r), 240) };
    }
    if (!notify) return { ok: false, error: 'Push is not configured on this deployment.' };
    const n = await notify({ title: subject, body: label });
    return n && n.sent > 0 ? { ok: true, via: 'push', label } : { ok: false, via: 'push', error: n?.reason || 'No phone has alerts on. Turn them on at the top of this page.' };
  } catch (e) { return { ok: false, error: clip(e.message, 240) }; }
}
