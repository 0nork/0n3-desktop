/**
 * MORE OAUTH DOORS (2026-11-06) — the apps whose guides used to end in "send a hand-made web request" or "the key dies
 * in an hour". Each one becomes a "Sign in with X" button, so a person never copies a token at all (Mike: every step a
 * 4th–5th grader can follow). Same protocol as the doors in hub.js (docs/OAUTH-DOOR-PROTOCOL.md), plus a few declared
 * quirks instead of special cases in the flow:
 *
 *   needs        env var names that must be set for the door to show (Dex registers the app, sets these, plain type)
 *   scopeSep     how the provider joins scopes (default ' ')
 *   pkce         S256 PKCE. The verifier is derived from the signed state (HMAC), so nothing is stored between the
 *                two legs of the flow — the callback recomputes it.
 *   tokenHeaders extra headers on the token call (Reddit refuses a request without a User-Agent)
 *   codeParam    the query name the provider sends the code under (TikTok Business sends auth_code)
 *   noRefresh    'keep-access' = the provider issues a long-lived access token and no refresh token; store it
 *   exchange     the whole code → credentials step, for a provider that is not OAuth2-shaped (TikTok Business, Meta)
 *   identity     first call with the fresh token → the record's name, meta, and any ids the catalog needs
 *                (Xero's tenantId, QuickBooks' realmId, DocuSign's account + base URI) — the ids people used to dig out
 *                with a hand-made request
 *   alsoAs       other catalog services the same record serves (TikTok's tiktok + tiktok_ads)
 *
 * Every scope list can be overridden with <KEY>_SCOPES on the deployment, because providers rename scopes and a
 * redeploy should not be needed to follow them. Refresh tokens that ROTATE are written back by tokens.js (onRotate).
 */
const J = async (r) => r.json().catch(() => ({}));
const bearer = (t, more = {}) => ({ headers: { Authorization: `Bearer ${t}`, ...more } });
export const REDDIT_UA = '0n3:connect:1.0 (by /u/0n3app)';
// OpenStreetMap's services ask every client to identify itself (operations.osmfoundation.org/policies/api, /nominatim).
export const OSM_UA = '0n3/1.0 (+https://0n3.app; mike@rocketopp.com)';

const DS_HOST = (e) => (String(e.DOCUSIGN_ENV || '').toUpperCase() === 'DEMO' ? 'https://account-d.docusign.com' : 'https://account.docusign.com');

export const MORE_DOORS = {
  quickbooks: {
    name: 'QuickBooks', grant: 'Invoices · customers · payments · reports', needs: ['QUICKBOOKS_CLIENT_ID', 'QUICKBOOKS_CLIENT_SECRET'],
    service: 'quickbooks', authType: 'oauth',
    clientId: (e) => e.QUICKBOOKS_CLIENT_ID, clientSecret: (e) => e.QUICKBOOKS_CLIENT_SECRET,
    authorizeUrl: 'https://appcenter.intuit.com/connect/oauth2', tokenUrl: 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
    tokenAuth: 'basic', tokenHeaders: { Accept: 'application/json' },
    scope: 'com.intuit.quickbooks.accounting openid email',
    // QuickBooks names the company on the callback URL (?realmId=…), not in the token.
    identity: async (_f, _t, _e, query) => ({ name: query.realmId ? `QuickBooks · ${query.realmId}` : 'QuickBooks', meta: { realm_id: query.realmId || null }, credentials: { realmId: query.realmId || '' } }),
  },
  xero: {
    name: 'Xero', grant: 'Invoices · contacts · bank · settings', needs: ['XERO_CLIENT_ID', 'XERO_CLIENT_SECRET'],
    service: 'xero', authType: 'oauth',
    clientId: (e) => e.XERO_CLIENT_ID, clientSecret: (e) => e.XERO_CLIENT_SECRET,
    authorizeUrl: 'https://login.xero.com/identity/connect/authorize', tokenUrl: 'https://identity.xero.com/connect/token', tokenAuth: 'basic',
    scope: 'openid profile email offline_access accounting.transactions accounting.contacts accounting.settings.read',
    // The tenant id people used to fetch by hand from GET /connections.
    identity: async (f, t) => {
      const list = await J(await f('https://api.xero.com/connections', bearer(t)));
      const orgs = (Array.isArray(list) ? list : []).filter((c) => c.tenantType === 'ORGANISATION' || !c.tenantType);
      const first = orgs[0];
      return { name: first ? `Xero · ${first.tenantName}` : 'Xero', meta: { organisations: orgs.map((o) => ({ id: o.tenantId, name: o.tenantName })) }, credentials: { tenantId: first?.tenantId || '' } };
    },
  },
  zoom: {
    name: 'Zoom', grant: 'Meetings · recordings · users', needs: ['ZOOM_CLIENT_ID', 'ZOOM_CLIENT_SECRET'],
    service: 'zoom', authType: 'oauth',
    clientId: (e) => e.ZOOM_CLIENT_ID, clientSecret: (e) => e.ZOOM_CLIENT_SECRET,
    authorizeUrl: 'https://zoom.us/oauth/authorize', tokenUrl: 'https://zoom.us/oauth/token', tokenAuth: 'basic',
    scope: '', // Zoom takes the scopes from the app's own settings page
    identity: async (f, t) => { const me = await J(await f('https://api.zoom.us/v2/users/me', bearer(t))); return { name: me.email ? `Zoom · ${me.email}` : 'Zoom', meta: { email: me.email || null, account_id: me.account_id || null } }; },
  },
  docusign: {
    name: 'DocuSign', grant: 'Envelopes · templates · signing', needs: ['DOCUSIGN_CLIENT_ID', 'DOCUSIGN_CLIENT_SECRET'],
    service: 'docusign', authType: 'oauth',
    clientId: (e) => e.DOCUSIGN_CLIENT_ID, clientSecret: (e) => e.DOCUSIGN_CLIENT_SECRET,
    authorizeUrl: (e) => `${DS_HOST(e)}/oauth/auth`, tokenUrl: (e) => `${DS_HOST(e)}/oauth/token`, tokenAuth: 'basic',
    scope: 'signature extended', // "extended" is what makes the refresh token last
    // The account id AND the server it lives on — DocuSign accounts are spread over several hosts.
    identity: async (f, t, e) => {
      const u = await J(await f(`${DS_HOST(e)}/oauth/userinfo`, bearer(t)));
      const acc = (u.accounts || []).find((a) => a.is_default) || (u.accounts || [])[0];
      return { name: u.email ? `DocuSign · ${u.email}` : 'DocuSign', meta: { email: u.email || null, account_name: acc?.account_name || null }, credentials: { accountId: acc?.account_id || '', baseUri: acc?.base_uri || '', token_host: DS_HOST(e) } };
    },
  },
  dropbox: {
    name: 'Dropbox', grant: 'Files · folders · sharing', needs: ['DROPBOX_CLIENT_ID', 'DROPBOX_CLIENT_SECRET'],
    service: 'dropbox', authType: 'oauth',
    clientId: (e) => e.DROPBOX_CLIENT_ID, clientSecret: (e) => e.DROPBOX_CLIENT_SECRET,
    authorizeUrl: 'https://www.dropbox.com/oauth2/authorize', tokenUrl: 'https://api.dropboxapi.com/oauth2/token',
    scope: 'account_info.read files.metadata.read files.metadata.write files.content.read files.content.write sharing.read sharing.write',
    extra: { token_access_type: 'offline' },
    identity: async (f, t) => { const me = await J(await f('https://api.dropboxapi.com/2/users/get_current_account', { method: 'POST', headers: { Authorization: `Bearer ${t}` } })); return { name: me.email ? `Dropbox · ${me.email}` : 'Dropbox', meta: { email: me.email || null, account_id: me.account_id || null } }; },
  },
  twitter: {
    name: 'X (Twitter)', grant: 'Post · reply · like · lists · messages', needs: ['X_CLIENT_ID', 'X_CLIENT_SECRET'],
    service: 'twitter', authType: 'oauth',
    clientId: (e) => e.X_CLIENT_ID, clientSecret: (e) => e.X_CLIENT_SECRET,
    authorizeUrl: 'https://x.com/i/oauth2/authorize', tokenUrl: 'https://api.x.com/2/oauth2/token', tokenAuth: 'basic', pkce: true,
    scope: 'tweet.read tweet.write users.read follows.read like.read like.write list.read list.write dm.read dm.write offline.access',
    identity: async (f, t) => { const me = await J(await f('https://api.x.com/2/users/me', bearer(t))); const u = me.data || {}; return { name: u.username ? `X · @${u.username}` : 'X', meta: { username: u.username || null, user_id: u.id || null } }; },
  },
  reddit: {
    name: 'Reddit', grant: 'Read · post · comment · vote · messages', needs: ['REDDIT_CLIENT_ID', 'REDDIT_CLIENT_SECRET'],
    service: 'reddit', authType: 'oauth',
    clientId: (e) => e.REDDIT_CLIENT_ID, clientSecret: (e) => e.REDDIT_CLIENT_SECRET,
    authorizeUrl: 'https://www.reddit.com/api/v1/authorize', tokenUrl: 'https://www.reddit.com/api/v1/access_token', tokenAuth: 'basic',
    tokenHeaders: { 'User-Agent': REDDIT_UA },
    scope: 'identity read submit edit history mysubreddits privatemessages vote',
    extra: { duration: 'permanent' },
    identity: async (f, t, e) => { const me = await J(await f('https://oauth.reddit.com/api/v1/me', bearer(t, { 'User-Agent': REDDIT_UA }))); return { name: me.name ? `Reddit · u/${me.name}` : 'Reddit', meta: { username: me.name || null }, credentials: { username: me.name || '', clientId: e.REDDIT_CLIENT_ID, clientSecret: e.REDDIT_CLIENT_SECRET } }; },
  },
  twitch: {
    name: 'Twitch', grant: 'Streams · channels · clips', needs: ['TWITCH_CLIENT_ID', 'TWITCH_CLIENT_SECRET'],
    service: 'twitch', authType: 'oauth',
    clientId: (e) => e.TWITCH_CLIENT_ID, clientSecret: (e) => e.TWITCH_CLIENT_SECRET,
    authorizeUrl: 'https://id.twitch.tv/oauth2/authorize', tokenUrl: 'https://id.twitch.tv/oauth2/token',
    scope: 'user:read:email clips:edit channel:read:subscriptions',
    identity: async (f, t, e) => { const r = await J(await f('https://api.twitch.tv/helix/users', bearer(t, { 'Client-Id': e.TWITCH_CLIENT_ID || '' }))); const u = (r.data || [])[0] || {}; return { name: u.login ? `Twitch · ${u.login}` : 'Twitch', meta: { login: u.login || null, user_id: u.id || null }, credentials: { clientId: e.TWITCH_CLIENT_ID } }; },
  },
  ticktick: {
    name: 'TickTick', grant: 'Tasks · lists', needs: ['TICKTICK_CLIENT_ID', 'TICKTICK_CLIENT_SECRET'],
    service: 'ticktick', authType: 'oauth',
    clientId: (e) => e.TICKTICK_CLIENT_ID, clientSecret: (e) => e.TICKTICK_CLIENT_SECRET,
    authorizeUrl: 'https://ticktick.com/oauth/authorize', tokenUrl: 'https://ticktick.com/oauth/token', tokenAuth: 'basic',
    scope: 'tasks:read tasks:write',
    noRefresh: 'keep-access', // TickTick issues a long-lived access token (about 180 days) and no refresh token
    identity: async () => ({ name: 'TickTick', meta: {} }),
  },
  mulesoft: {
    name: 'MuleSoft Anypoint', grant: 'APIs · applications · environments', needs: ['MULESOFT_CLIENT_ID', 'MULESOFT_CLIENT_SECRET'],
    service: 'mulesoft', authType: 'oauth',
    clientId: (e) => e.MULESOFT_CLIENT_ID, clientSecret: (e) => e.MULESOFT_CLIENT_SECRET,
    authorizeUrl: 'https://anypoint.mulesoft.com/accounts/api/v2/oauth2/authorize', tokenUrl: 'https://anypoint.mulesoft.com/accounts/api/v2/oauth2/token',
    scope: 'profile full offline_access',
    identity: async (f, t) => { const me = await J(await f('https://anypoint.mulesoft.com/accounts/api/me', bearer(t))); const u = me.user || {}; return { name: u.username ? `MuleSoft · ${u.username}` : 'MuleSoft', meta: { username: u.username || null, organization: u.organization?.name || null } }; },
  },
  // OpenStreetMap (Mike 2026-11-10: "our own builtin mapping that we can build just for trucking"). OAuth 2.0 per
  // wiki.openstreetmap.org/wiki/OAuth: authorization code, client id + secret as form parameters on the token call, and
  // "the access tokens currently do not expire automatically" — there is no refresh token, so the access token is kept.
  // Scopes asked: who the person is (read_prefs), their GPS traces (read_gpx / write_gpx) and map notes (write_notes —
  // "this bridge is 12 ft 6, not 13 ft 6"). NOT write_api: 0n3 never edits the map itself.
  openstreetmap: {
    name: 'OpenStreetMap', grant: 'Your map account · GPS traces · map notes', needs: ['OPENSTREETMAP_CLIENT_ID', 'OPENSTREETMAP_CLIENT_SECRET'],
    service: 'openstreetmap', authType: 'oauth',
    clientId: (e) => e.OPENSTREETMAP_CLIENT_ID, clientSecret: (e) => e.OPENSTREETMAP_CLIENT_SECRET,
    authorizeUrl: 'https://www.openstreetmap.org/oauth2/authorize', tokenUrl: 'https://www.openstreetmap.org/oauth2/token',
    scope: 'read_prefs read_gpx write_gpx write_notes',
    noRefresh: 'keep-access',
    identity: async (f, t) => { const r = await J(await f('https://api.openstreetmap.org/api/0.6/user/details.json', bearer(t, { 'User-Agent': OSM_UA }))); const u = r.user || {}; return { name: u.display_name ? `OpenStreetMap · ${u.display_name}` : 'OpenStreetMap', meta: { display_name: u.display_name || null, user_id: u.id ?? null } }; },
  },
  // TikTok API for Business: not OAuth2-shaped. The advertiser authorises on TikTok's portal, TikTok sends back an
  // auth_code, and one JSON call trades it for a long-term access token plus the advertiser ids. No refresh needed.
  tiktok: {
    name: 'TikTok for Business', grant: 'Ads · campaigns · reports · audiences', needs: ['TIKTOK_APP_ID', 'TIKTOK_APP_SECRET'],
    service: 'tiktok_ads', alsoAs: ['tiktok'], authType: 'access_token',
    clientId: (e) => e.TIKTOK_APP_ID, clientSecret: (e) => e.TIKTOK_APP_SECRET,
    codeParam: 'auth_code',
    authorize: (e, { state, redirect }) => `https://business-api.tiktok.com/portal/auth?${new URLSearchParams({ app_id: e.TIKTOK_APP_ID || '', state, redirect_uri: redirect })}`,
    exchange: async (f, { code, e }) => {
      const r = await f('https://business-api.tiktok.com/open_api/v1.3/oauth2/access_token/', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ app_id: e.TIKTOK_APP_ID, secret: e.TIKTOK_APP_SECRET, auth_code: code }) });
      const d = await J(r);
      if (!r.ok || d.code !== 0 || !d.data?.access_token) throw new Error(d.message || `TikTok answered ${r.status}`);
      const ids = d.data.advertiser_ids || [];
      return { name: ids[0] ? `TikTok Ads · ${ids[0]}` : 'TikTok Ads', meta: { advertiser_ids: ids, scope: d.data.scope || null }, credentials: { accessToken: d.data.access_token, advertiserId: ids[0] ? String(ids[0]) : '' } };
    },
  },
  // Instagram through Facebook Login (the catalog speaks graph.facebook.com with an Instagram business account id).
  // A Page token derived from a LONG-LIVED user token does not expire, so the record never needs refreshing, and the
  // Instagram account id people used to find in Graph API Explorer is read here.
  instagram: {
    name: 'Instagram', grant: 'Posts · comments · insights', needs: ['META_APP_ID', 'META_APP_SECRET'],
    service: 'instagram', authType: 'access_token',
    clientId: (e) => e.META_APP_ID, clientSecret: (e) => e.META_APP_SECRET,
    authorizeUrl: 'https://www.facebook.com/v19.0/dialog/oauth', scopeSep: ',',
    scope: 'instagram_basic,instagram_content_publish,instagram_manage_comments,instagram_manage_insights,pages_show_list,pages_read_engagement,business_management',
    exchange: async (f, { code, e, redirect }) => {
      const G = 'https://graph.facebook.com/v19.0';
      const short = await J(await f(`${G}/oauth/access_token?${new URLSearchParams({ client_id: e.META_APP_ID || '', client_secret: e.META_APP_SECRET || '', redirect_uri: redirect, code })}`));
      if (!short.access_token) throw new Error(short.error?.message || 'Facebook refused the code');
      const long = await J(await f(`${G}/oauth/access_token?${new URLSearchParams({ grant_type: 'fb_exchange_token', client_id: e.META_APP_ID || '', client_secret: e.META_APP_SECRET || '', fb_exchange_token: short.access_token })}`));
      const user = long.access_token || short.access_token;
      const pages = await J(await f(`${G}/me/accounts?${new URLSearchParams({ fields: 'name,access_token,instagram_business_account{id,username}', access_token: user })}`));
      const page = (pages.data || []).find((p) => p.instagram_business_account);
      if (!page) throw new Error('No Facebook Page with an Instagram business account was shared. Link Instagram to a Facebook Page, then try again and tick that Page.');
      const ig = page.instagram_business_account;
      return { name: ig.username ? `Instagram · @${ig.username}` : `Instagram · ${page.name}`, meta: { username: ig.username || null, page: page.name, page_id: page.id }, credentials: { accessToken: page.access_token, igUserId: ig.id } };
    },
  },
};

/**
 * GOOGLE, ASKED FOR MORE ONLY WHEN IT IS NEEDED. The base Google door asks for calendar, drive, sheets, analytics and
 * Search Console. Gmail, Google Ads, Apps Script and YouTube need their own permissions; asking everyone for them would
 * put Google's scariest warning in front of people who only wanted a calendar. So connecting one of those apps asks for
 * its scopes ON TOP of what was already granted (include_granted_scopes), and Google hands back one refresh token that
 * covers both.
 */
export const GOOGLE_EXTRA = {
  gmail: ['https://www.googleapis.com/auth/gmail.modify', 'https://www.googleapis.com/auth/gmail.send'],
  google_ads: ['https://www.googleapis.com/auth/adwords'],
  google_apps_script: ['https://www.googleapis.com/auth/script.projects', 'https://www.googleapis.com/auth/script.deployments', 'https://www.googleapis.com/auth/drive.file'],
  youtube: ['https://www.googleapis.com/auth/youtube'],
  // Cloud Storage acts with the person's own IAM roles on their project.
  gcloud: ['https://www.googleapis.com/auth/devstorage.read_write'],
};
