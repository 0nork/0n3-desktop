/**
 * THE PROJECT KEEPER — keeps this computer's code folder small and nothing in it unsaved (Mike, 2026-11-06: "we need
 * 0n3 to set this up and manage it AUTOMATICALLY"). Runs on the person's own machine, beside the desk agent.
 *
 *   0n3 desk projects            what every folder is: working on it · safe on GitHub · needs saving
 *   0n3 desk projects tidy       apply the rules below (--dry: only say what it would do)
 *   0n3 desk projects bring      clone or update what you pushed to GitHub lately, so it is ready to edit here
 *   0n3 desk projects open <x>   bring one project here (from GitHub or the removed list) and put its files back
 *   0n3 desk projects install    run tidy + bring every day (launchd / systemd)
 *
 * The rules, in this order:
 *   1. A folder that is NOT on GitHub (no git, no remote) or has anything GitHub does not have (edited files, new files,
 *      commits not pushed, stashes) is never removed. A folder GitHub lacks entirely is mirrored to Google Drive, .git
 *      included; a repo GitHub mostly has sends only what is missing (the changed files + a bundle of unpushed commits).
 *   2. A folder that matches GitHub exactly and has not changed in `staleDays` is removed from this computer. Its
 *      git-ignored files (.env.local, .vercel/project.json …) are kept in ~/.0n/repo-leftovers first, and a line in the
 *      removed list says how to bring it back. GitHub must have been reachable this run: no fetch, no removal.
 *   3. Folders not touched in `staleDays` lose node_modules (npm install brings it back).
 *   4. `keepLocal` folders (0n-bridge) are never moved, removed or git-touched; they are only mirrored.
 * Secrets never go to Drive: .env*, *.pem and *.key are left out of the mirror; they stay in the leftovers folder here.
 */
import { readFileSync, writeFileSync, appendFileSync, mkdirSync, existsSync, readdirSync, statSync, rmSync, chmodSync, lstatSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { homedir, platform } from 'node:os';
import { spawnSync, execSync } from 'node:child_process';

const HOME = homedir();
export const PROJECTS_CONFIG = join(HOME, '.0n', 'projects.json');
export const LEFTOVERS = join(HOME, '.0n', 'repo-leftovers');
export const REMOVED = join(HOME, '.0n', 'projects-removed.jsonl');
export const REPORT = join(HOME, '.0n', 'projects-report.json');
const DAY = 86_400_000;
/** Dependency and build folders: rebuildable, never worth a backup, never counted as "changed". */
export const REBUILDABLE = ['node_modules', '.next', 'dist', 'build', 'out', '.turbo', '.cache', 'coverage', '.venv', '__pycache__', '.vercel/output', '.svelte-kit', '.parcel-cache'];
const SECRET = ['.env*', '*.pem', '*.key'];

export function findDrive() {
  const cs = join(HOME, 'Library', 'CloudStorage');
  try { const g = readdirSync(cs).find((n) => n.startsWith('GoogleDrive-')); return g ? join(cs, g, 'My Drive') : null; } catch { return null; }
}
export function loadProjectsConfig() {
  let j = {}; try { j = JSON.parse(readFileSync(PROJECTS_CONFIG, 'utf8')); } catch { /* defaults */ }
  return { root: join(HOME, 'Github'), staleDays: 30, activeDays: 14, maxBring: 15, owners: [], keepLocal: ['0n-bridge'], alsoLookIn: [HOME], driveFolder: '0n3 Projects', drive: findDrive(), ...j };
}

const git = (dir, args, timeout = 30_000) => spawnSync('git', ['-C', dir, '-c', 'core.quotepath=off', ...args], { encoding: 'utf8', timeout, env: { ...process.env, GIT_TERMINAL_PROMPT: '0' } });
const lines = (s) => String(s || '').split('\n').filter(Boolean);
const prune = new Set(['node_modules', '.git', '.next', 'dist', '.turbo', '.vercel', '.venv', '__pycache__']);
/** Newest change to a real file in the folder (dependency and build folders do not count). */
function newestFile(dir) {
  let newest = 0; const stack = [dir];
  while (stack.length) {
    const d = stack.pop(); let ents = []; try { ents = readdirSync(d, { withFileTypes: true }); } catch { continue; }
    for (const e of ents) {
      if (e.isSymbolicLink()) continue;
      const p = join(d, e.name);
      if (e.isDirectory()) { if (!prune.has(e.name)) stack.push(p); } else { try { const m = statSync(p).mtimeMs; if (m > newest) newest = m; } catch { /* */ } }
    }
  }
  return newest;
}

/** One folder's facts. `fetch:false` is for tests and for `status` when offline. */
export function inspect(dir, { fetch = true, now = Date.now() } = {}) {
  const name = dir.split('/').pop();
  const row = { name, dir, git: existsSync(join(dir, '.git')) };
  let changed = newestFile(dir);
  if (row.git) {
    row.remote = git(dir, ['remote', 'get-url', 'origin']).stdout.trim() || null;
    row.fetched = row.remote ? (fetch ? git(dir, ['fetch', '--all', '--quiet'], 60_000).status === 0 : false) : false;
    const st = lines(git(dir, ['status', '--porcelain']).stdout);
    row.edited = st.filter((l) => !l.startsWith('??')).length;
    row.untracked = st.filter((l) => l.startsWith('??')).length;
    row.unpushed = row.remote ? lines(git(dir, ['log', '--branches', '--not', '--remotes', '--oneline']).stdout).length : null;
    row.stashes = lines(git(dir, ['stash', 'list']).stdout).length;
    row.branch = git(dir, ['rev-parse', '--abbrev-ref', 'HEAD']).stdout.trim();
    row.head = git(dir, ['rev-parse', 'HEAD']).stdout.trim();
    const lc = Number(git(dir, ['log', '-1', '--format=%ct']).stdout.trim()) * 1000 || 0;
    if (lc > changed) changed = lc;
  }
  row.days = Math.floor((now - changed) / DAY);
  return row;
}

/** The rules, as a pure function of one folder's facts. */
export function classify(row, cfg) {
  if (cfg.keepLocal.includes(row.name)) return { state: 'protect', why: ['stays on this computer on purpose — mirrored to Drive'] };
  const why = [];
  if (!row.git) why.push('not a git repo');
  else if (!row.remote) why.push('no GitHub remote');
  else {
    if (row.edited) why.push(`${row.edited} edited file(s)`);
    if (row.untracked) why.push(`${row.untracked} new file(s)`);
    if (row.unpushed) why.push(`${row.unpushed} commit(s) not pushed`);
    if (row.stashes) why.push(`${row.stashes} stash(es)`);
  }
  if (why.length) return { state: row.days >= cfg.staleDays ? 'examine' : 'protect', why: [...why, row.days >= cfg.staleDays ? `untouched ${row.days} days — decide: push it or let it go` : 'mirrored to Drive until it is pushed'] };
  if (row.days < cfg.staleDays) return { state: 'active', why: [`changed ${row.days} day(s) ago`] };
  if (!row.fetched) return { state: 'active', why: ['GitHub was not reachable this run, so it stays'] };
  return { state: 'remove', why: [`matches GitHub, untouched ${row.days} days`] };
}

export function scan(cfg = loadProjectsConfig(), opts = {}) {
  let names = []; try { names = readdirSync(cfg.root).filter((n) => !n.startsWith('.')); } catch { return []; }
  return names.map((n) => join(cfg.root, n)).filter((p) => { try { return lstatSync(p).isDirectory(); } catch { return false; } })
    .map((dir) => { const row = inspect(dir, opts); return { ...row, ...classify(row, cfg) }; });
}

/** Git-ignored files that are not rebuildable — the .env.local a GitHub clone would not have. */
export function leftoverFiles(dir) {
  const skip = new RegExp(`(^|/)(${REBUILDABLE.map((x) => x.replace(/[.]/g, '\\.')).join('|')}|\\.DS_Store)(/|$)|tsbuildinfo$|next-env\\.d\\.ts$`);
  return lines(git(dir, ['ls-files', '--others', '--ignored', '--exclude-standard']).stdout).filter((f) => !skip.test(f));
}

export function mirrorArgs(src, dest, backupDir) {
  return ['-a', '--delete', '--backup', `--backup-dir=${backupDir}`, ...[...REBUILDABLE, ...SECRET, '.DS_Store'].flatMap((x) => ['--exclude', x]), `${src}/`, `${dest}/`];
}

/**
 * A repo GitHub mostly has: copy only what GitHub lacks — the edited and new files, and a git bundle of commits not pushed
 * (and stashes). A whole-repo copy would send gigabytes of .git to Drive to protect three files. The last 5 days are kept.
 */
export function saveUnsaved(r, dest, stamp) {
  const skip = new RegExp(`(^|/)(${REBUILDABLE.map((x) => x.replace(/[.]/g, '\\.')).join('|')})(/|$)|(^|/)\\.env|\\.(pem|key)$`);
  const z = git(r.dir, ['status', '--porcelain', '-z', '--untracked-files=all']).stdout.split('\0').filter(Boolean);
  const files = []; for (let i = 0; i < z.length; i++) { const st = z[i].slice(0, 2); const f = z[i].slice(3); if (st[0] === 'R') i++; if (!st.includes('D') && !skip.test(f)) files.push(f); }
  const made = [];
  if (files.length) {
    const t = spawnSync('tar', ['-czf', join(dest, `changes-${stamp}.tgz`), '-C', r.dir, '-T', '-'], { input: files.join('\n'), encoding: 'utf8' });
    if (t.status !== 0) throw new Error(`could not save the edited files: ${t.stderr.trim()}`); made.push(`changes-${stamp}.tgz`);
  }
  const refs = [...(r.unpushed ? ['--branches'] : []), ...(r.stashes ? ['refs/stash'] : [])];
  if (refs.length) {
    const b = git(r.dir, ['bundle', 'create', join(dest, `commits-${stamp}.bundle`), ...refs, '--not', '--remotes'], 300_000);
    if (b.status !== 0) throw new Error(`could not bundle the unpushed commits: ${b.stderr.trim().split('\n').pop()}`); made.push(`commits-${stamp}.bundle`);
  }
  writeFileSync(join(dest, 'README.txt'), `${r.name} — what GitHub did not have on ${stamp}\nGitHub: ${r.remote} (${r.branch} @ ${r.head})\n\nchanges-<date>.tgz  the edited and new files. Restore: clone the repo, then  tar -xzf changes-<date>.tgz -C <repo>\ncommits-<date>.bundle  commits not pushed / stashes. Restore:  git -C <repo> fetch commits-<date>.bundle 'refs/*:refs/saved/*'\n.env files are NOT here on purpose (secrets); they stay in ~/.0n/repo-leftovers on the computer.\n`);
  const old = readdirSync(dest).filter((n) => /^(changes|commits)-\d{4}-\d{2}-\d{2}\./.test(n)).sort().reverse();
  const keepDays = [...new Set(old.map((n) => n.match(/\d{4}-\d{2}-\d{2}/)[0]))].slice(0, 5);
  for (const n of old) if (!keepDays.includes(n.match(/\d{4}-\d{2}-\d{2}/)[0])) rmSync(join(dest, n), { force: true });
  return made;
}

/** Apply the rules. Returns what happened, folder by folder; with dry:true nothing on disk changes. */
export function tidy({ cfg = loadProjectsConfig(), dry = false, rows = null, now = Date.now() } = {}) {
  rows = rows || scan(cfg, { now });
  const done = { removed: [], slimmed: [], mirrored: [], examine: [], kept: [], errors: [] };
  const mirrorRoot = cfg.drive ? join(cfg.drive, cfg.driveFolder) : null;
  const stamp = new Date(now).toISOString().slice(0, 10);
  for (const r of rows) {
    try {
      if (r.state === 'remove') {
        if (dry) { done.removed.push(r.name); continue; }
        const again = inspect(r.dir, { fetch: false, now }); // nothing may have changed between the scan and the delete
        if (classify({ ...again, fetched: r.fetched }, cfg).state !== 'remove') { done.kept.push(`${r.name} (changed during tidy)`); continue; }
        let lo = null; const files = leftoverFiles(r.dir);
        if (files.length) {
          mkdirSync(LEFTOVERS, { recursive: true, mode: 0o700 });
          lo = join(LEFTOVERS, `${r.name}-${stamp}.tgz`);
          const t = spawnSync('tar', ['-czf', lo, '-C', r.dir, '-T', '-'], { input: files.join('\n'), encoding: 'utf8' });
          if (t.status !== 0) throw new Error(`could not keep its ignored files: ${t.stderr.trim()}`);
          chmodSync(lo, 0o600);
        }
        mkdirSync(dirname(REMOVED), { recursive: true });
        appendFileSync(REMOVED, JSON.stringify({ name: r.name, remote: r.remote, branch: r.branch, head: r.head, removedAt: new Date(now).toISOString(), leftovers: lo }) + '\n');
        rmSync(r.dir, { recursive: true, force: true });
        done.removed.push(r.name);
        continue;
      }
      if (r.days >= cfg.staleDays && !cfg.keepLocal.includes(r.name) && existsSync(join(r.dir, 'node_modules'))) {
        if (!dry) spawnSync('find', [r.dir, '-name', 'node_modules', '-type', 'd', '-prune', '-exec', 'rm', '-rf', '{}', '+']);
        done.slimmed.push(r.name);
      }
      if (r.state === 'protect' || r.state === 'examine') {
        if (r.state === 'examine') done.examine.push({ name: r.name, why: r.why });
        if (!mirrorRoot) { done.errors.push(`${r.name}: Google Drive for desktop is not installed, so it is not mirrored`); continue; }
        if (!dry) {
          const dest = join(mirrorRoot, r.name); mkdirSync(dest, { recursive: true });
          if (r.git && r.remote && !cfg.keepLocal.includes(r.name)) saveUnsaved(r, dest, stamp);
          else {
            const m = spawnSync('rsync', mirrorArgs(r.dir, dest, join(mirrorRoot, '_replaced', stamp, r.name)), { encoding: 'utf8', timeout: 900_000 });
            if (m.status !== 0) throw new Error(`mirror failed: ${(m.stderr || '').trim().split('\n').slice(-2).join(' ')}`);
          }
        }
        done.mirrored.push(r.name);
        continue;
      }
      done.kept.push(r.name);
    } catch (e) { done.errors.push(`${r.name}: ${e.message}`); }
  }
  if (!dry) writeFileSync(REPORT, JSON.stringify({ at: new Date(now).toISOString(), root: cfg.root, mirror: mirrorRoot, ...done, rows: rows.map(({ name, state, why, days }) => ({ name, state, why, days })) }, null, 2));
  return done;
}

export function removedList() { try { return lines(readFileSync(REMOVED, 'utf8')).map((l) => JSON.parse(l)); } catch { return []; } }

/** Clone `name` (a removed project, a folder name under an owner, or owner/repo) into the root and put its kept files back. */
export function open(name, { cfg = loadProjectsConfig(), install = true } = {}) {
  const gone = removedList().reverse().find((x) => x.name === name || x.remote?.endsWith(`/${name}.git`) || x.remote?.endsWith(`/${name}`));
  const slug = name.includes('/') ? name : null;
  const folderName = slug ? slug.split('/')[1] : (gone?.name || name);
  const dir = join(cfg.root, folderName);
  if (existsSync(join(dir, '.git'))) {
    const p = git(dir, ['pull', '--ff-only'], 120_000);
    return { dir, cloned: false, pulled: p.status === 0, note: p.status === 0 ? 'already here — updated from GitHub' : `already here — not updated: ${p.stderr.trim().split('\n').pop()}` };
  }
  const url = gone?.remote || (slug ? `https://github.com/${slug}.git` : null);
  let r;
  if (url) r = spawnSync('git', ['clone', url, dir], { encoding: 'utf8', timeout: 600_000 });
  else r = spawnSync('gh', ['repo', 'clone', name, dir], { encoding: 'utf8', timeout: 600_000 });
  if (r.status !== 0) return { error: `could not clone ${name}: ${(r.stderr || '').trim().split('\n').pop()}` };
  let restored = 0;
  if (gone?.leftovers && existsSync(gone.leftovers)) {
    const t = spawnSync('tar', ['-xzf', gone.leftovers, '-C', dir, '-k'], { encoding: 'utf8' });
    if (t.status === 0) restored = lines(spawnSync('tar', ['-tzf', gone.leftovers], { encoding: 'utf8' }).stdout).length;
  }
  let installed = null;
  if (install && existsSync(join(dir, 'package.json'))) {
    const pm = existsSync(join(dir, 'pnpm-lock.yaml')) ? ['pnpm', ['install']] : existsSync(join(dir, 'package-lock.json')) ? ['npm', ['ci']] : ['npm', ['install']];
    installed = spawnSync(pm[0], pm[1], { cwd: dir, encoding: 'utf8', timeout: 900_000 }).status === 0 ? pm[0] : `${pm[0]} failed — run it in ${dir}`;
  }
  return { dir, cloned: true, restoredFiles: restored, installed };
}

/** What you pushed lately, on GitHub — the projects you are working on. Owners default to every org gh can see. */
export function recentRepos({ cfg = loadProjectsConfig(), now = Date.now() } = {}) {
  let owners = cfg.owners;
  if (!owners.length) {
    const me = spawnSync('gh', ['api', 'user', '--jq', '.login'], { encoding: 'utf8' }).stdout.trim();
    const orgs = lines(spawnSync('gh', ['api', 'user/orgs', '--jq', '.[].login'], { encoding: 'utf8' }).stdout);
    owners = [me, ...orgs].filter(Boolean);
  }
  const since = now - cfg.activeDays * DAY; const out = [];
  for (const o of owners) {
    const r = spawnSync('gh', ['repo', 'list', o, '--limit', '200', '--no-archived', '--json', 'nameWithOwner,pushedAt,isFork'], { encoding: 'utf8', timeout: 60_000 });
    if (r.status !== 0) continue;
    for (const x of JSON.parse(r.stdout || '[]')) if (!x.isFork && Date.parse(x.pushedAt) >= since) out.push({ repo: x.nameWithOwner, pushedAt: x.pushedAt });
  }
  return out.sort((a, b) => b.pushedAt.localeCompare(a.pushedAt)).slice(0, cfg.maxBring);
}

/** Make sure every recently pushed project is here and current. A folder with local changes is never pulled. */
export function bring({ cfg = loadProjectsConfig(), dry = false } = {}) {
  const res = { cloned: [], updated: [], current: [], skipped: [], errors: [] };
  for (const { repo } of recentRepos({ cfg })) {
    const name = repo.split('/')[1]; const dir = join(cfg.root, name);
    if (cfg.keepLocal.includes(name)) continue;
    const elsewhere = (cfg.alsoLookIn || []).map((d) => join(d, name)).find((d) => existsSync(join(d, '.git')));
    if (!existsSync(dir) && elsewhere) { res.skipped.push(`${name} (already at ${elsewhere})`); continue; }
    if (!existsSync(dir)) {
      if (dry) { res.cloned.push(repo); continue; }
      const o = open(repo, { cfg, install: false });
      (o.error ? res.errors : res.cloned).push(o.error || repo);
      continue;
    }
    if (!existsSync(join(dir, '.git'))) { res.skipped.push(`${name} (a folder with that name is not a git repo)`); continue; }
    if (lines(git(dir, ['status', '--porcelain', '--untracked-files=no']).stdout).length) { res.skipped.push(`${name} (has edits — not pulled)`); continue; }
    git(dir, ['fetch', '--quiet'], 60_000);
    const behind = Number(git(dir, ['rev-list', '--count', 'HEAD..@{u}']).stdout.trim() || 0);
    if (!behind) { res.current.push(name); continue; }
    if (dry) { res.updated.push(name); continue; }
    (git(dir, ['pull', '--ff-only'], 120_000).status === 0 ? res.updated : res.skipped).push(name);
  }
  return res;
}

/** Every day at 03:30: tidy, then bring. Absolute paths — a scheduled job has no PATH. */
export function installProjectsService({ node = process.execPath, cli = new URL('./cli.js', import.meta.url).pathname, pathExtra = [] } = {}) {
  const PATH = [dirname(node), `${HOME}/.local/bin`, '/opt/homebrew/bin', '/usr/local/bin', '/usr/bin', '/bin', ...pathExtra].join(':');
  const logDir = join(HOME, '.0n', 'desk'); mkdirSync(logDir, { recursive: true });
  if (platform() === 'darwin') {
    const plist = join(HOME, 'Library', 'LaunchAgents', 'com.0n3.projects.plist');
    mkdirSync(dirname(plist), { recursive: true });
    writeFileSync(plist, `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.0n3.projects</string>
  <key>ProgramArguments</key><array><string>${node}</string><string>${cli}</string><string>desk</string><string>projects</string><string>daily</string></array>
  <key>StartCalendarInterval</key><dict><key>Hour</key><integer>3</integer><key>Minute</key><integer>30</integer></dict>
  <key>StandardOutPath</key><string>${join(logDir, 'projects.out')}</string><key>StandardErrorPath</key><string>${join(logDir, 'projects.err')}</string>
  <key>EnvironmentVariables</key><dict><key>PATH</key><string>${PATH}</string><key>HOME</key><string>${HOME}</string></dict>
</dict></plist>
`);
    try { execSync(`launchctl unload "${plist}" 2>/dev/null; launchctl load "${plist}"`); } catch (e) { return { file: plist, loaded: false, error: e.message }; }
    return { file: plist, loaded: true, runs: 'every day at 03:30' };
  }
  if (platform() === 'linux') {
    const dir = join(HOME, '.config', 'systemd', 'user'); mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, '0n3-projects.service'), `[Unit]\nDescription=0n3 project keeper\n\n[Service]\nType=oneshot\nExecStart=${node} ${cli} desk projects daily\nEnvironment=PATH=${PATH}\nEnvironment=HOME=${HOME}\n`);
    writeFileSync(join(dir, '0n3-projects.timer'), `[Unit]\nDescription=0n3 project keeper, daily\n\n[Timer]\nOnCalendar=*-*-* 03:30\nPersistent=true\n\n[Install]\nWantedBy=timers.target\n`);
    try { execSync('systemctl --user daemon-reload && systemctl --user enable --now 0n3-projects.timer'); } catch (e) { return { loaded: false, error: e.message }; }
    return { loaded: true, runs: 'every day at 03:30' };
  }
  return { loaded: false, error: `No scheduler for ${platform()} yet. Run "0n3 desk projects daily" yourself.` };
}

const LABEL = { active: 'working on it', remove: 'safe on GitHub — will be removed', protect: 'not all on GitHub — mirrored to Drive', examine: 'needs a decision' };
export function render(rows) {
  const by = (s) => rows.filter((r) => r.state === s);
  return ['active', 'protect', 'examine', 'remove'].map((s) => { const g = by(s); return g.length ? `${LABEL[s]} (${g.length})\n${g.map((r) => `  ${r.name.padEnd(30)} ${r.why.join(' · ')}`).join('\n')}` : null; }).filter(Boolean).join('\n\n');
}

export const PROJECTS_HELP = `0n3 desk projects — keep this computer's code folder small, and nothing in it unsaved
  0n3 desk projects [--offline]   what every folder is
  0n3 desk projects tidy [--dry]  remove what matches GitHub and sat ${30} days, slim old folders, mirror the rest to Drive
  0n3 desk projects bring [--dry] clone or update what you pushed in the last 14 days
  0n3 desk projects open <name>   bring one project here and put its .env files back
  0n3 desk projects removed       what was removed, and how to bring it back
  0n3 desk projects install       do tidy + bring every day at 03:30
  settings: ~/.0n/projects.json  { root, staleDays, activeDays, owners, keepLocal, alsoLookIn, driveFolder }`;

export async function projectsCommand(argv, { out }) {
  const sub = argv[0]; const has = (n) => argv.includes(`--${n}`);
  const cfg = loadProjectsConfig();
  if (sub === 'help' || has('help')) { out(PROJECTS_HELP); return 0; }
  if (!sub || sub === 'status') { out(render(scan(cfg, { fetch: !has('offline') }))); return 0; }
  if (sub === 'tidy') { out(tidy({ cfg, dry: has('dry') })); return 0; }
  if (sub === 'bring') { out(bring({ cfg, dry: has('dry') })); return 0; }
  if (sub === 'daily') { out({ at: new Date().toISOString(), tidy: tidy({ cfg }), bring: bring({ cfg }) }); return 0; }
  if (sub === 'open') { if (!argv[1]) { out('Which one? 0n3 desk projects open <name>'); return 1; } const r = open(argv[1], { cfg, install: !has('no-install') }); out(r); return r.error ? 1 : 0; }
  if (sub === 'removed') { out(removedList().map((x) => `${x.name.padEnd(30)} ${x.removedAt.slice(0, 10)}  ${x.leftovers ? 'files kept' : ''}`).join('\n') || 'Nothing removed yet.'); return 0; }
  if (sub === 'install') { out(installProjectsService()); return 0; }
  out(PROJECTS_HELP); return 1;
}
