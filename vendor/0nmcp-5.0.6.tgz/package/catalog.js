// ============================================================
// 0nMCP — Service Catalog
// ============================================================
// Every service the orchestrator can connect to.
// Add new services here to expand capabilities.
// ============================================================

import { HOSTINGER } from './catalog-hostinger.js';

export const SERVICE_CATALOG = {
  hostinger: HOSTINGER,

  // ── CRM ───────────────────────────────────────────────────
  crm: {
    name: "CRM",
    type: "crm",
    description: "The agency CRM — full agency + sub-account API: contacts, pipelines, opportunities, workflows, SMS, email campaigns, calendars, forms, funnels, SaaS mode. Powers the 0nCore Agency Dashboard's CRM–connected UI.",
    baseUrl: "https://services.leadconnectorhq.com",
    authType: "oauth",
    credentialKeys: ["access_token", "location_id"],
    capabilities: [
      { name: "manage_contacts", actions: ["create", "update", "search", "delete"], description: "Create, update, search, and manage contacts" },
      { name: "manage_pipelines", actions: ["create", "list"], description: "Create and manage sales pipelines with stages" },
      { name: "manage_opportunities", actions: ["create", "update", "list"], description: "Track deals and opportunities through pipeline stages" },
      { name: "manage_tags", actions: ["create", "list"], description: "Create and assign tags for segmentation" },
      { name: "manage_custom_values", actions: ["create", "list"], description: "Create and manage custom values" },
      { name: "manage_workflows", actions: ["list"], description: "List and inspect automation workflows" },
      { name: "send_sms", actions: ["send"], description: "Send SMS messages to contacts" },
      { name: "send_email", actions: ["send"], description: "Send emails via CRM" },
      { name: "manage_calendars", actions: ["list", "create"], description: "Book and manage appointments" },
      { name: "manage_campaigns", actions: ["list"], description: "View marketing campaigns" },
    ],
    endpoints: {
      // 2026-10-29: the actions a sequence needs (Mike: "email / texting / voicemail drop … it does a lot").
      upsert_contact:          { method: "POST", path: "/contacts/upsert", body: { locationId: "", email: "", phone: "", firstName: "", lastName: "", tags: [] } },
      send_message:            { method: "POST", path: "/conversations/messages", body: { type: "SMS", contactId: "", message: "", subject: "", html: "", emailFrom: "" } },
      add_contact_tags:        { method: "POST", path: "/contacts/{contactId}/tags", body: { tags: [] } },
      remove_contact_tags:     { method: "DELETE", path: "/contacts/{contactId}/tags", body: { tags: [] } },
      add_contact_to_workflow: { method: "POST", path: "/contacts/{contactId}/workflow/{workflowId}", body: {} },
      add_contact_to_campaign: { method: "POST", path: "/contacts/{contactId}/campaigns/{campaignId}", body: {} },
      create_contact_note:     { method: "POST", path: "/contacts/{contactId}/notes", body: { body: "" } },
      create_contact_task:     { method: "POST", path: "/contacts/{contactId}/tasks", body: { title: "", dueDate: "", completed: false } },
      create_appointment:      { method: "POST", path: "/calendars/events/appointments", body: { calendarId: "", locationId: "", contactId: "", startTime: "", endTime: "", title: "" } },
      list_pipelines:          { method: "GET", path: "/opportunities/pipelines", query: ["locationId"] },
      create_contact:    { method: "POST", path: "/contacts/", body: { firstName: "", lastName: "", email: "", phone: "", locationId: "" } },
      list_contacts:     { method: "GET",  path: "/contacts/", query: ["locationId", "limit", "startAfterId", "query"] },
      search_contacts:   { method: "POST", path: "/contacts/search", body: { locationId: "", query: "", pageLimit: 50 } },
      get_contact:       { method: "GET",  path: "/contacts/{contactId}" },
      update_contact:    { method: "PUT",  path: "/contacts/{contactId}", body: {} },
      delete_contact:    { method: "DELETE", path: "/contacts/{contactId}" },
      create_pipeline:   { method: "POST", path: "/opportunities/pipelines", body: { name: "", stages: [] } },
      list_pipelines:    { method: "GET",  path: "/opportunities/pipelines", query: ["locationId"] },
      create_opportunity:{ method: "POST", path: "/opportunities/", body: { pipelineId: "", name: "", stageId: "", locationId: "" } },
      create_tag:        { method: "POST", path: "/locations/{locationId}/tags", body: { name: "" } },
      list_tags:         { method: "GET",  path: "/locations/{locationId}/tags" },
      create_custom_value:{ method: "POST", path: "/locations/{locationId}/customValues", body: { name: "", value: "" } },
      list_custom_values:{ method: "GET",  path: "/locations/{locationId}/customValues" },
      list_workflows:    { method: "GET",  path: "/workflows/", query: ["locationId"] },
      list_calendars:    { method: "GET",  path: "/calendars/", query: ["locationId"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
      "Version": "2021-07-28",
    }),
  },

  // ── Stripe ────────────────────────────────────────────────
  stripe: {
    name: "Stripe",
    type: "payments",
    description: "Payment processing — customers, charges, subscriptions, invoices, payouts",
    baseUrl: "https://api.stripe.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_customers", actions: ["create", "list", "get"], description: "Create and manage customers" },
      { name: "create_charge", actions: ["create"], description: "Charge a customer's payment method" },
      { name: "manage_invoices", actions: ["create", "send", "list"], description: "Create and send invoices" },
      { name: "manage_subscriptions", actions: ["create", "cancel", "list"], description: "Set up recurring billing" },
      { name: "get_balance", actions: ["get"], description: "Check account balance" },
      { name: "list_payments", actions: ["list"], description: "List recent payment intents" },
      { name: "manage_products", actions: ["create", "list"], description: "Create and manage products" },
      { name: "manage_prices", actions: ["create", "list"], description: "Create and manage prices" },
    ],
    endpoints: {
      create_customer:    { method: "POST", path: "/customers", contentType: "application/x-www-form-urlencoded" },
      list_customers:     { method: "GET",  path: "/customers" },
      get_customer:       { method: "GET",  path: "/customers/{id}" },
      create_charge:      { method: "POST", path: "/charges", contentType: "application/x-www-form-urlencoded" },
      create_invoice:     { method: "POST", path: "/invoices", contentType: "application/x-www-form-urlencoded" },
      send_invoice:       { method: "POST", path: "/invoices/{id}/send", contentType: "application/x-www-form-urlencoded" },
      list_invoices:      { method: "GET",  path: "/invoices" },
      create_subscription:{ method: "POST", path: "/subscriptions", contentType: "application/x-www-form-urlencoded" },
      get_balance:        { method: "GET",  path: "/balance" },
      list_payments:      { method: "GET",  path: "/payment_intents" },
      create_product:     { method: "POST", path: "/products", contentType: "application/x-www-form-urlencoded" },
      create_price:       { method: "POST", path: "/prices", contentType: "application/x-www-form-urlencoded" },
      list_prices:            { method: "GET", path: "/prices", query: ["active", "product", "limit", "lookup_keys[]"] },
      list_webhook_endpoints: { method: "GET", path: "/webhook_endpoints", query: ["limit"] },
      list_events:            { method: "GET", path: "/events", query: ["limit", "type", "delivery_success", "starting_after", "created[gte]"] },
      delete_webhook_endpoint:{ method: "DELETE", path: "/webhook_endpoints/{id}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
    }),
  },

  // ── InstaWP ───────────────────────────────────────────────
  instawp: {
    name: "InstaWP",
    type: "hosting",
    description: "Instant WordPress site provisioning — create sites from templates/snapshots, poll status, list sites & templates, migrate. The auto-provisioning engine for the web0n site factory.",
    baseUrl: "https://app.instawp.io/api/v2",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "create_site", actions: ["create"], description: "Provision a fresh WordPress site" },
      { name: "create_from_template", actions: ["create"], description: "Clone a golden template/snapshot into a new site" },
      { name: "list_sites", actions: ["list"], description: "List your WordPress sites" },
      { name: "get_site", actions: ["get"], description: "Get a site's details (URL, credentials)" },
      { name: "task_status", actions: ["get"], description: "Poll an async provisioning task" },
      { name: "list_templates", actions: ["list"], description: "List your site templates" },
    ],
    endpoints: {
      create_site:               { method: "POST", path: "/sites", body: { site_name: "", wp_version: "6.8.1", php_version: "8.0", plan_id: 2 } },
      create_site_from_template: { method: "POST", path: "/sites/template", body: { slug: "", is_shared: true, is_reserved: true } },
      list_sites:                { method: "GET",  path: "/sites" },
      get_site:                  { method: "GET",  path: "/sites/{id}" },
      task_status:               { method: "GET",  path: "/tasks/{taskId}/status" },
      list_templates:            { method: "GET",  path: "/templates" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
    }),
  },

  // ── SendGrid ──────────────────────────────────────────────
  sendgrid: {
    name: "SendGrid",
    type: "email",
    description: "Transactional and marketing email — send, templates, contacts",
    baseUrl: "https://api.sendgrid.com/v3",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "send_email", actions: ["send"], description: "Send transactional emails" },
      { name: "manage_contacts", actions: ["create", "list", "search"], description: "Manage email contacts and lists" },
      { name: "manage_templates", actions: ["list"], description: "List email templates" },
    ],
    endpoints: {
      send_email:       { method: "POST", path: "/mail/send", body: { personalizations: [], from: {}, subject: "", content: [] } },
      add_contacts:     { method: "PUT",  path: "/marketing/contacts", body: { contacts: [] } },
      search_contacts:  { method: "POST", path: "/marketing/contacts/search", body: { query: "" } },
      list_templates:   { method: "GET",  path: "/templates" },
      list_lists:       { method: "GET",  path: "/marketing/lists" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Resend ────────────────────────────────────────────────
  resend: {
    name: "Resend",
    type: "email",
    description: "Developer-first email API — transactional emails, broadcasts, contacts, domains, templates, segments, webhooks",
    baseUrl: "https://api.resend.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "send_email", actions: ["send"], description: "Send transactional emails with HTML, React templates, scheduling, and attachments" },
      { name: "batch_emails", actions: ["send"], description: "Send up to 100 emails in a single batch request" },
      { name: "manage_emails", actions: ["list", "get", "update", "cancel"], description: "List, retrieve, update scheduled, and cancel emails" },
      { name: "receive_emails", actions: ["list", "get"], description: "List and retrieve received inbound emails" },
      { name: "manage_attachments", actions: ["list", "get"], description: "List and retrieve attachments from sent and received emails" },
      { name: "manage_domains", actions: ["create", "list", "get", "update", "verify", "delete"], description: "Create, list, verify, update, and delete email domains" },
      { name: "manage_api_keys", actions: ["create", "list", "delete"], description: "Create, list, and delete API keys" },
      { name: "manage_audiences", actions: ["create", "list", "get", "delete"], description: "Create, list, get, and delete audiences (deprecated — use segments)" },
      { name: "manage_contacts", actions: ["create", "list", "get", "update", "delete"], description: "Create, list, get, update, and delete contacts" },
      { name: "manage_contact_segments", actions: ["add", "remove", "list"], description: "Add, remove, and list segment memberships for contacts" },
      { name: "manage_contact_topics", actions: ["get", "update"], description: "Get and update topic subscriptions for contacts" },
      { name: "manage_broadcasts", actions: ["create", "list", "get", "update", "send", "delete"], description: "Create, list, get, update, send, and delete broadcasts" },
      { name: "manage_segments", actions: ["create", "list", "get", "delete"], description: "Create, list, get, and delete segments" },
      { name: "manage_contact_properties", actions: ["create", "list", "get", "update", "delete"], description: "Create, list, get, update, and delete contact properties" },
      { name: "manage_templates", actions: ["create", "list", "get", "update", "delete", "duplicate", "publish"], description: "Create, list, get, update, delete, duplicate, and publish email templates" },
      { name: "manage_topics", actions: ["create", "list", "get", "update", "delete"], description: "Create, list, get, update, and delete email topics" },
      { name: "manage_webhooks", actions: ["create", "list", "get", "update", "delete"], description: "Create, list, get, update, and delete webhooks" },
    ],
    endpoints: {
      // ── Emails ──
      send_email:               { method: "POST",   path: "/emails", body: { from: "", to: [], subject: "", html: "" } },
      send_batch_emails:        { method: "POST",   path: "/emails/batch", body: [] },
      list_emails:              { method: "GET",    path: "/emails" },
      get_email:                { method: "GET",    path: "/emails/{email_id}" },
      update_email:             { method: "PATCH",  path: "/emails/{email_id}" },
      cancel_email:             { method: "POST",   path: "/emails/{email_id}/cancel" },
      // ── Received Emails ──
      list_received_emails:     { method: "GET",    path: "/emails/receiving" },
      get_received_email:       { method: "GET",    path: "/emails/receiving/{email_id}" },
      // ── Attachments ──
      list_email_attachments:   { method: "GET",    path: "/emails/{email_id}/attachments" },
      get_email_attachment:     { method: "GET",    path: "/emails/{email_id}/attachments/{attachment_id}" },
      list_received_attachments:{ method: "GET",    path: "/emails/receiving/{email_id}/attachments" },
      get_received_attachment:  { method: "GET",    path: "/emails/receiving/{email_id}/attachments/{attachment_id}" },
      // ── Domains ──
      create_domain:            { method: "POST",   path: "/domains", body: { name: "" } },
      list_domains:             { method: "GET",    path: "/domains" },
      get_domain:               { method: "GET",    path: "/domains/{domain_id}" },
      update_domain:            { method: "PATCH",  path: "/domains/{domain_id}" },
      verify_domain:            { method: "POST",   path: "/domains/{domain_id}/verify" },
      delete_domain:            { method: "DELETE", path: "/domains/{domain_id}" },
      // ── API Keys ──
      create_api_key:           { method: "POST",   path: "/api-keys", body: { name: "" } },
      list_api_keys:            { method: "GET",    path: "/api-keys" },
      delete_api_key:           { method: "DELETE", path: "/api-keys/{api_key_id}" },
      // ── Audiences (deprecated) ──
      create_audience:          { method: "POST",   path: "/audiences", body: { name: "" } },
      list_audiences:           { method: "GET",    path: "/audiences" },
      get_audience:             { method: "GET",    path: "/audiences/{audience_id}" },
      delete_audience:          { method: "DELETE", path: "/audiences/{audience_id}" },
      // ── Contacts ──
      create_contact:           { method: "POST",   path: "/contacts", body: { email: "" } },
      list_contacts:            { method: "GET",    path: "/contacts" },
      get_contact:              { method: "GET",    path: "/contacts/{contact_id}" },
      update_contact:           { method: "PATCH",  path: "/contacts/{contact_id}" },
      delete_contact:           { method: "DELETE", path: "/contacts/{contact_id}" },
      add_contact_to_segment:   { method: "POST",   path: "/contacts/{contact_id}/segments/{segment_id}" },
      remove_contact_from_segment: { method: "DELETE", path: "/contacts/{contact_id}/segments/{segment_id}" },
      list_contact_segments:    { method: "GET",    path: "/contacts/{contact_id}/segments" },
      get_contact_topics:       { method: "GET",    path: "/contacts/{contact_id}/topics" },
      update_contact_topics:    { method: "PATCH",  path: "/contacts/{contact_id}/topics" },
      // ── Broadcasts ──
      create_broadcast:         { method: "POST",   path: "/broadcasts", body: { segment_id: "", from: "", subject: "" } },
      list_broadcasts:          { method: "GET",    path: "/broadcasts" },
      get_broadcast:            { method: "GET",    path: "/broadcasts/{broadcast_id}" },
      update_broadcast:         { method: "PATCH",  path: "/broadcasts/{broadcast_id}" },
      send_broadcast:           { method: "POST",   path: "/broadcasts/{broadcast_id}/send" },
      delete_broadcast:         { method: "DELETE", path: "/broadcasts/{broadcast_id}" },
      // ── Segments ──
      create_segment:           { method: "POST",   path: "/segments", body: { name: "" } },
      list_segments:            { method: "GET",    path: "/segments" },
      get_segment:              { method: "GET",    path: "/segments/{segment_id}" },
      delete_segment:           { method: "DELETE", path: "/segments/{segment_id}" },
      // ── Contact Properties ──
      create_contact_property:  { method: "POST",   path: "/contact-properties", body: { name: "", type: "string" } },
      list_contact_properties:  { method: "GET",    path: "/contact-properties" },
      get_contact_property:     { method: "GET",    path: "/contact-properties/{property_id}" },
      update_contact_property:  { method: "PATCH",  path: "/contact-properties/{property_id}" },
      delete_contact_property:  { method: "DELETE", path: "/contact-properties/{property_id}" },
      // ── Templates ──
      create_template:          { method: "POST",   path: "/templates", body: { name: "", html: "" } },
      list_templates:           { method: "GET",    path: "/templates" },
      get_template:             { method: "GET",    path: "/templates/{template_id}" },
      update_template:          { method: "PATCH",  path: "/templates/{template_id}" },
      delete_template:          { method: "DELETE", path: "/templates/{template_id}" },
      duplicate_template:       { method: "POST",   path: "/templates/{template_id}/duplicate" },
      publish_template:         { method: "POST",   path: "/templates/{template_id}/publish" },
      // ── Topics ──
      create_topic:             { method: "POST",   path: "/topics", body: { name: "" } },
      list_topics:              { method: "GET",    path: "/topics" },
      get_topic:                { method: "GET",    path: "/topics/{topic_id}" },
      update_topic:             { method: "PATCH",  path: "/topics/{topic_id}" },
      delete_topic:             { method: "DELETE", path: "/topics/{topic_id}" },
      // ── Webhooks ──
      create_webhook:           { method: "POST",   path: "/webhooks", body: { endpoint_url: "", events: [] } },
      list_webhooks:            { method: "GET",    path: "/webhooks" },
      get_webhook:              { method: "GET",    path: "/webhooks/{webhook_id}" },
      update_webhook:           { method: "PATCH",  path: "/webhooks/{webhook_id}" },
      delete_webhook:           { method: "DELETE", path: "/webhooks/{webhook_id}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Twilio ────────────────────────────────────────────────
  twilio: {
    name: "Twilio",
    type: "sms",
    description: "SMS and voice — send text messages, make calls",
    baseUrl: "https://api.twilio.com/2010-04-01",
    authType: "basic",
    credentialKeys: ["accountSid", "authToken"],
    capabilities: [
      { name: "send_sms", actions: ["send"], description: "Send SMS messages" },
      { name: "make_call", actions: ["create"], description: "Initiate phone calls" },
      { name: "list_messages", actions: ["list"], description: "List sent messages" },
    ],
    endpoints: {
      send_sms:       { method: "POST", path: "/Accounts/{accountSid}/Messages.json", contentType: "application/x-www-form-urlencoded" },
      list_messages:  { method: "GET",  path: "/Accounts/{accountSid}/Messages.json" },
      make_call:      { method: "POST", path: "/Accounts/{accountSid}/Calls.json", contentType: "application/x-www-form-urlencoded" },
    },
    authHeader: (creds) => ({
      "Authorization": "Basic " + Buffer.from(`${creds.accountSid}:${creds.authToken}`).toString("base64"),
    }),
  },

  // ── Slack ─────────────────────────────────────────────────
  slack: {
    name: "Slack",
    type: "communication",
    description: "Team messaging — channels, messages, threads, users, files, reactions, bookmarks, reminders, canvases, search, scheduled messages, pins",
    baseUrl: "https://slack.com/api",
    mcpServer: "https://mcp.slack.com/mcp",
    authType: "bot_token",
    credentialKeys: ["botToken"],
    capabilities: [
      { name: "send_message", actions: ["send", "update", "delete", "schedule"], description: "Post, update, delete, and schedule messages" },
      { name: "manage_channels", actions: ["list", "create", "archive", "rename", "set_topic", "set_purpose", "invite", "kick"], description: "Full channel lifecycle management" },
      { name: "manage_threads", actions: ["reply", "list_replies"], description: "Thread replies and conversation management" },
      { name: "manage_users", actions: ["list", "get", "set_status"], description: "List users, get profiles, set status" },
      { name: "manage_files", actions: ["upload", "list", "delete", "share"], description: "Upload, list, delete, and share files" },
      { name: "manage_reactions", actions: ["add", "remove", "list"], description: "Emoji reactions on messages" },
      { name: "manage_pins", actions: ["add", "remove", "list"], description: "Pin and unpin messages in channels" },
      { name: "manage_bookmarks", actions: ["add", "remove", "list"], description: "Channel bookmarks" },
      { name: "manage_reminders", actions: ["add", "list", "delete"], description: "Set and manage reminders" },
      { name: "search", actions: ["messages", "files", "users"], description: "Search across messages, files, and users" },
      { name: "manage_canvases", actions: ["create", "update", "read"], description: "Create and edit Slack canvases" },
    ],
    endpoints: {
      // Messages
      send_message:         { method: "POST", path: "/chat.postMessage", body: { channel: "", text: "" } },
      update_message:       { method: "POST", path: "/chat.update", body: { channel: "", ts: "", text: "" } },
      delete_message:       { method: "POST", path: "/chat.delete", body: { channel: "", ts: "" } },
      schedule_message:     { method: "POST", path: "/chat.scheduleMessage", body: { channel: "", text: "", post_at: 0 } },
      get_permalink:        { method: "GET",  path: "/chat.getPermalink", query: ["channel", "message_ts"] },
      // Threads
      reply_to_thread:      { method: "POST", path: "/chat.postMessage", body: { channel: "", thread_ts: "", text: "" } },
      get_thread_replies:   { method: "GET",  path: "/conversations.replies", query: ["channel", "ts"] },
      // Channels
      list_channels:        { method: "GET",  path: "/conversations.list", query: ["types", "limit", "cursor"] },
      create_channel:       { method: "POST", path: "/conversations.create", body: { name: "" } },
      archive_channel:      { method: "POST", path: "/conversations.archive", body: { channel: "" } },
      unarchive_channel:    { method: "POST", path: "/conversations.unarchive", body: { channel: "" } },
      rename_channel:       { method: "POST", path: "/conversations.rename", body: { channel: "", name: "" } },
      set_channel_topic:    { method: "POST", path: "/conversations.setTopic", body: { channel: "", topic: "" } },
      set_channel_purpose:  { method: "POST", path: "/conversations.setPurpose", body: { channel: "", purpose: "" } },
      invite_to_channel:    { method: "POST", path: "/conversations.invite", body: { channel: "", users: "" } },
      kick_from_channel:    { method: "POST", path: "/conversations.kick", body: { channel: "", user: "" } },
      channel_history:      { method: "GET",  path: "/conversations.history", query: ["channel", "limit", "oldest", "latest"] },
      channel_info:         { method: "GET",  path: "/conversations.info", query: ["channel"] },
      join_channel:         { method: "POST", path: "/conversations.join", body: { channel: "" } },
      leave_channel:        { method: "POST", path: "/conversations.leave", body: { channel: "" } },
      // Users
      list_users:           { method: "GET",  path: "/users.list", query: ["limit", "cursor"] },
      get_user:             { method: "GET",  path: "/users.info", query: ["user"] },
      get_user_profile:     { method: "GET",  path: "/users.profile.get", query: ["user"] },
      set_user_status:      { method: "POST", path: "/users.profile.set", body: { profile: { status_text: "", status_emoji: "" } } },
      // Files
      upload_file:          { method: "POST", path: "/files.upload", body: { channels: "", filename: "", content: "" } },
      list_files:           { method: "GET",  path: "/files.list", query: ["channel", "types", "count"] },
      delete_file:          { method: "POST", path: "/files.delete", body: { file: "" } },
      share_file:           { method: "POST", path: "/files.sharedPublicURL", body: { file: "" } },
      // Reactions
      add_reaction:         { method: "POST", path: "/reactions.add", body: { channel: "", timestamp: "", name: "" } },
      remove_reaction:      { method: "POST", path: "/reactions.remove", body: { channel: "", timestamp: "", name: "" } },
      list_reactions:       { method: "GET",  path: "/reactions.get", query: ["channel", "timestamp"] },
      // Pins
      pin_message:          { method: "POST", path: "/pins.add", body: { channel: "", timestamp: "" } },
      unpin_message:        { method: "POST", path: "/pins.remove", body: { channel: "", timestamp: "" } },
      list_pins:            { method: "GET",  path: "/pins.list", query: ["channel"] },
      // Bookmarks
      add_bookmark:         { method: "POST", path: "/bookmarks.add", body: { channel_id: "", title: "", type: "link", link: "" } },
      remove_bookmark:      { method: "POST", path: "/bookmarks.remove", body: { bookmark_id: "", channel_id: "" } },
      list_bookmarks:       { method: "GET",  path: "/bookmarks.list", query: ["channel_id"] },
      // Reminders
      add_reminder:         { method: "POST", path: "/reminders.add", body: { text: "", time: "" } },
      list_reminders:       { method: "GET",  path: "/reminders.list" },
      delete_reminder:      { method: "POST", path: "/reminders.delete", body: { reminder: "" } },
      // Search
      search_messages:      { method: "GET",  path: "/search.messages", query: ["query", "count", "sort", "sort_dir"] },
      search_files:         { method: "GET",  path: "/search.files", query: ["query", "count"] },
      // Canvases
      create_canvas:        { method: "POST", path: "/canvases.create", body: { title: "", document_content: { type: "markdown", markdown: "" } } },
      update_canvas:        { method: "POST", path: "/canvases.edit", body: { canvas_id: "", changes: [] } },
      // Team info
      get_team_info:        { method: "GET",  path: "/team.info" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.botToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Discord ───────────────────────────────────────────────
  discord: {
    name: "Discord",
    type: "communication",
    description: "Community messaging — servers, channels, messages",
    baseUrl: "https://discord.com/api/v10",
    authType: "bot_token",
    credentialKeys: ["botToken"],
    capabilities: [
      { name: "send_message", actions: ["send"], description: "Send messages to channels" },
      { name: "manage_channels", actions: ["list"], description: "List server channels" },
    ],
    endpoints: {
      send_message:    { method: "POST", path: "/channels/{channelId}/messages", body: { content: "" } },
      list_channels:   { method: "GET",  path: "/guilds/{guildId}/channels" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bot ${creds.botToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── OpenAI ────────────────────────────────────────────────
  openai: {
    name: "OpenAI",
    type: "ai",
    description: "AI completions, embeddings, image generation, TTS",
    baseUrl: "https://api.openai.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "generate_text", actions: ["create"], description: "Generate text completions" },
      { name: "generate_image", actions: ["create"], description: "Generate images with DALL-E" },
      { name: "create_embedding", actions: ["create"], description: "Create text embeddings" },
      { name: "text_to_speech", actions: ["create"], description: "Convert text to speech" },
    ],
    endpoints: {
      chat_completion:  { method: "POST", path: "/chat/completions", body: { model: "gpt-4o", messages: [] } },
      create_image:     { method: "POST", path: "/images/generations", body: { prompt: "", model: "dall-e-3" } },
      create_embedding: { method: "POST", path: "/embeddings", body: { model: "text-embedding-3-small", input: "" } },
      text_to_speech:   { method: "POST", path: "/audio/speech", body: { model: "tts-1", voice: "alloy", input: "" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Airtable ──────────────────────────────────────────────
  airtable: {
    name: "Airtable",
    type: "database",
    description: "Spreadsheet-database — bases, tables, records",
    baseUrl: "https://api.airtable.com/v0",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_records", actions: ["create", "list", "update", "delete"], description: "CRUD operations on table records" },
      { name: "list_bases", actions: ["list"], description: "List available bases" },
    ],
    endpoints: {
      list_bases:      { method: "GET",  path: "https://api.airtable.com/v0/meta/bases" },
      list_records:    { method: "GET",  path: "/{baseId}/{tableId}" },
      create_record:   { method: "POST", path: "/{baseId}/{tableId}", body: { fields: {} } },
      update_record:   { method: "PATCH", path: "/{baseId}/{tableId}/{recordId}", body: { fields: {} } },
      delete_record:   { method: "DELETE", path: "/{baseId}/{tableId}/{recordId}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Notion ────────────────────────────────────────────────
  notion: {
    name: "Notion",
    type: "database",
    description: "Workspace — pages, databases, blocks",
    baseUrl: "https://api.notion.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_pages", actions: ["create", "get", "update"], description: "Create and manage pages" },
      { name: "manage_databases", actions: ["query", "list"], description: "Query and manage databases" },
      { name: "search", actions: ["search"], description: "Search across workspace" },
    ],
    endpoints: {
      search:           { method: "POST", path: "/search", body: { query: "" } },
      create_page:      { method: "POST", path: "/pages", body: { parent: {}, properties: {} } },
      get_page:         { method: "GET",  path: "/pages/{pageId}" },
      query_database:   { method: "POST", path: "/databases/{databaseId}/query", body: {} },
      list_databases:   { method: "GET",  path: "/databases" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
      "Notion-Version": "2022-06-28",
    }),
  },

  // ── GitHub ────────────────────────────────────────────────
  github: {
    name: "GitHub",
    type: "code",
    description: "Code hosting — repos, issues, pull requests, actions",
    baseUrl: "https://api.github.com",
    authType: "token",
    credentialKeys: ["token"],
    capabilities: [
      { name: "manage_issues", actions: ["create", "list", "update"], description: "Create and manage issues" },
      { name: "manage_repos", actions: ["list", "create"], description: "List and create repositories" },
      { name: "manage_prs", actions: ["list", "create"], description: "List and create pull requests" },
    ],
    endpoints: {
      list_repos:      { method: "GET",  path: "/user/repos" },
      create_issue:    { method: "POST", path: "/repos/{owner}/{repo}/issues", body: { title: "", body: "" } },
      list_issues:     { method: "GET",  path: "/repos/{owner}/{repo}/issues" },
      create_pr:       { method: "POST", path: "/repos/{owner}/{repo}/pulls", body: { title: "", body: "", head: "", base: "" } },
      list_prs:        { method: "GET",  path: "/repos/{owner}/{repo}/pulls" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.token}`,
      "Accept": "application/vnd.github+json",
    }),
  },

  // ── eBay ─────────────────────────────────────────────────
  // The seller's own account, connected once through the 0n3 door (refresh
  // token in the vault, access token minted per call). CardFlow lists
  // through this; the Browse endpoints price cards from live listings.
  ebay: {
    name: "eBay",
    type: "commerce",
    description: "eBay Sell + Browse APIs on the connected seller account — inventory items, offers (list / publish / withdraw), orders and fulfillment, business policies, marketing campaigns, finances, and Browse search (keyword + image) for comps. Connect with Sign in with eBay on 0n3.app/connect.",
    baseUrl: "https://api.ebay.com",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "inventory", actions: ["get_item", "put_item", "list_items", "delete_item"], description: "Inventory items keyed by SKU (the listing's product side)" },
      { name: "offers", actions: ["create", "update", "get", "list", "publish", "withdraw"], description: "Offers turn an inventory item into a listing: format, price, policies, then publish" },
      { name: "orders", actions: ["list", "get", "ship"], description: "Orders and shipping fulfillment" },
      { name: "account", actions: ["fulfillment_policies", "payment_policies", "return_policies", "merchant_locations"], description: "Business policies and the ship-from location an offer needs" },
      { name: "browse", actions: ["search", "search_by_image", "get_item"], description: "Live listings for comps — keyword or a photo" },
      { name: "marketing", actions: ["campaigns", "create_campaign"], description: "Promoted Listings campaigns" },
      { name: "finances", actions: ["transactions", "payouts"], description: "What eBay paid out and took" },
      { name: "identity", actions: ["me"], description: "Which eBay user this record is" },
    ],
    endpoints: {
      me:                   { method: "GET",    path: "/commerce/identity/v1/user/", baseUrl: "https://apiz.ebay.com" },
      inventory_items:      { method: "GET",    path: "/sell/inventory/v1/inventory_item", query: { limit: 25, offset: 0 } },
      inventory_item:       { method: "GET",    path: "/sell/inventory/v1/inventory_item/{sku}" },
      put_inventory_item:   { method: "PUT",    path: "/sell/inventory/v1/inventory_item/{sku}", body: {} },
      delete_inventory_item:{ method: "DELETE", path: "/sell/inventory/v1/inventory_item/{sku}" },
      offers:               { method: "GET",    path: "/sell/inventory/v1/offer", query: { sku: "" } },
      offer:                { method: "GET",    path: "/sell/inventory/v1/offer/{offerId}" },
      create_offer:         { method: "POST",   path: "/sell/inventory/v1/offer", body: {} },
      update_offer:         { method: "PUT",    path: "/sell/inventory/v1/offer/{offerId}", body: {} },
      publish_offer:        { method: "POST",   path: "/sell/inventory/v1/offer/{offerId}/publish", body: {} },
      withdraw_offer:       { method: "POST",   path: "/sell/inventory/v1/offer/{offerId}/withdraw", body: {} },
      orders:               { method: "GET",    path: "/sell/fulfillment/v1/order", query: { limit: 50, filter: "" } },
      order:                { method: "GET",    path: "/sell/fulfillment/v1/order/{orderId}" },
      ship_order:           { method: "POST",   path: "/sell/fulfillment/v1/order/{orderId}/shipping_fulfillment", body: {} },
      fulfillment_policies: { method: "GET",    path: "/sell/account/v1/fulfillment_policy", query: { marketplace_id: "EBAY_US" } },
      payment_policies:     { method: "GET",    path: "/sell/account/v1/payment_policy", query: { marketplace_id: "EBAY_US" } },
      return_policies:      { method: "GET",    path: "/sell/account/v1/return_policy", query: { marketplace_id: "EBAY_US" } },
      merchant_locations:   { method: "GET",    path: "/sell/inventory/v1/location", query: { limit: 20 } },
      browse_search:        { method: "GET",    path: "/buy/browse/v1/item_summary/search", query: { q: "", category_ids: "", limit: 25 } },
      browse_search_image:  { method: "POST",   path: "/buy/browse/v1/item_summary/search_by_image", query: { category_ids: "", limit: 25 }, body: { image: "" } },
      browse_item:          { method: "GET",    path: "/buy/browse/v1/item/{itemId}" },
      campaigns:            { method: "GET",    path: "/sell/marketing/v1/ad_campaign", query: { limit: 25 } },
      create_campaign:      { method: "POST",   path: "/sell/marketing/v1/ad_campaign", body: {} },
      transactions:         { method: "GET",    path: "/sell/finances/v1/transaction", query: { limit: 50 }, baseUrl: "https://apiz.ebay.com" },
      payouts:              { method: "GET",    path: "/sell/finances/v1/payout", query: { limit: 50 }, baseUrl: "https://apiz.ebay.com" },
      // ── Application settings & insights (Mike 2026-11-05: developer.ebay.com/develop/application-settings-and-insights) ──
      // Developer Analytics (v1_beta): the app's own call limits and usage — rate_limit/ with the app token scope, user_rate_limit/ per seller.
      rate_limits:          { method: "GET",    path: "/developer/analytics/v1_beta/rate_limit/", query: ["api_context", "api_name"] },
      user_rate_limits:     { method: "GET",    path: "/developer/analytics/v1_beta/user_rate_limit/", query: ["api_context", "api_name"] },
      // Key Management: ED25519 signing keys for calls that need a digital signature (finances calls for EU/UK sellers).
      signing_keys:         { method: "GET",    path: "/developer/key_management/v1/signing_key", baseUrl: "https://apiz.ebay.com" },
      create_signing_key:   { method: "POST",   path: "/developer/key_management/v1/signing_key", body: { signingKeyCipher: "ED25519" }, baseUrl: "https://apiz.ebay.com" },
      signing_key:          { method: "GET",    path: "/developer/key_management/v1/signing_key/{signing_key_id}", baseUrl: "https://apiz.ebay.com" },
      // ── Deeper selling ──
      default_category_tree:{ method: "GET",    path: "/commerce/taxonomy/v1/get_default_category_tree_id", query: { marketplace_id: "EBAY_US" } },
      category_suggestions: { method: "GET",    path: "/commerce/taxonomy/v1/category_tree/{category_tree_id}/get_category_suggestions", query: ["q"] },
      item_aspects:         { method: "GET",    path: "/commerce/taxonomy/v1/category_tree/{category_tree_id}/get_item_aspects_for_category", query: ["category_id"] },
      traffic_report:       { method: "GET",    path: "/sell/analytics/v1/traffic_report", query: ["dimension", "filter", "metric", "sort"] },
      seller_standards:     { method: "GET",    path: "/sell/analytics/v1/seller_standards_profile" },
      offer_eligible_items: { method: "GET",    path: "/sell/negotiation/v1/find_eligible_items", query: { limit: 200 } },
      send_offer_to_buyers: { method: "POST",   path: "/sell/negotiation/v1/send_offer_to_interested_buyers", body: { allowCounterOffer: false, message: "", offerDuration: { unit: "DAY", value: 2 }, offeredItems: [] } },
      notification_topics:  { method: "GET",    path: "/commerce/notification/v1/topic", query: { limit: 100 } },
      notification_destinations: { method: "GET", path: "/commerce/notification/v1/destination" },
      create_notification_destination: { method: "POST", path: "/commerce/notification/v1/destination", body: { name: "", status: "ENABLED", deliveryConfig: { endpoint: "", verificationToken: "" } } },
      notification_subscriptions: { method: "GET", path: "/commerce/notification/v1/subscription" },
      create_notification_subscription: { method: "POST", path: "/commerce/notification/v1/subscription", body: { topicId: "", status: "ENABLED", destinationId: "", payload: { format: "JSON", schemaVersion: "1.0", deliveryProtocol: "HTTPS" } } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
      "Content-Language": "en-US",
      // Node's fetch sends "Accept-Language: *" when none is set, and the Inventory API refuses it: every inventory/offer
      // call answered 400 errorId 25709 "Invalid value for header Accept-Language" (2026-11-08) while orders worked.
      "Accept-Language": "en-US",
      "X-EBAY-C-MARKETPLACE-ID": creds.marketplace_id || "EBAY_US",
    }),
  },

  // ── 0nTask ────────────────────────────────────────────────
  // An 0n product inside the 0n orchestrator — 0nMCP calling 0nTask's own
  // public API. This is the "MCP within an MCP": 0nTask ships a plain REST API,
  // and 0nMCP wraps it as tools like any third-party service, so every agent
  // that already speaks 0nMCP gets task management with no new client.
  cro9: {
    name: "CRO9",
    type: "seo",
    description: "CRO9 — site score, real-visitor behaviour, the five gates + open recommendations, briefs, and the human approve/dismiss/release/receipt verbs; plus scan, AI visibility and usage. Account key (cro9_sk_) or a site-scoped key.",
    baseUrl: "https://www.cro9.com/api/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "site_reports", actions: ["sites", "site_score", "behavior", "analysis"], description: "Where a site stands: score by category, live traffic + forms + friction, the five gates and the bottleneck" },
      { name: "briefs", actions: ["list", "approve", "dismiss", "release", "receipt"], description: "CRO9's proposed changes and the human decision on each — approval is a person's act, recorded as such" },
      { name: "scans", actions: ["scan", "ai_visibility"], description: "Scan any URL; AI-visibility score for a page" },
      { name: "usage", actions: ["get"], description: "This key's quota" },
    ],
    endpoints: {
      sites:            { method: "GET",  path: "/sites" },
      site_score:       { method: "POST", path: "/site-score", body: { site: "" } },
      behavior:         { method: "POST", path: "/behavior", body: { site: "", days: 30 } },
      analysis:         { method: "GET",  path: "/analysis", query: { window: "30d", site: "" } },
      briefs:           { method: "POST", path: "/briefs", body: { site: "", status: "" } },
      approve_brief:    { method: "POST", path: "/recommendations/{id}/approve", body: {} },
      dismiss_brief:    { method: "POST", path: "/recommendations/{id}/dismiss", body: {} },
      release_brief:    { method: "POST", path: "/recommendations/{id}/release", body: {} },
      receipt_brief:    { method: "POST", path: "/recommendations/{id}/receipt", body: {} },
      scan:             { method: "POST", path: "/scan", body: { url: "", checks: "full" } },
      ai_visibility:    { method: "POST", path: "/ai-visibility", body: { url: "" } },
      usage:            { method: "GET",  path: "/usage" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },
  cardflow: {
    name: "CardFlow",
    type: "commerce",
    description: "CardFlow (cardflow.mykidcard.com) — the family card-selling app on top of eBay: the inventory, the scan engine (identify a card from photos), open eBay orders grouped into envelopes, ship an envelope (one tracking → every order), and the kids' thank-you notes waiting for a grown-up. Key = the owner's CardFlow API key.",
    baseUrl: "https://cardflow.mykidcard.com/api/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "inventory", actions: ["cards", "card"], description: "Every card with status, tier, comps, eBay ids and photo URLs" },
      { name: "scan", actions: ["scan"], description: "Identify a card from a photo URL (front, optional back) — the same engine MyKidCard uses" },
      { name: "orders", actions: ["orders", "packing", "ship"], description: "eBay orders from the mirror, the packing list (one envelope per buyer, overdue first), and shipping an envelope with one tracking number" },
      { name: "messages", actions: ["thank_yous", "decide_thank_you"], description: "Kids' custom thank-you notes waiting for a grown-up; send or drop one" },
    ],
    endpoints: {
      cards:            { method: "GET",  path: "/cards", query: ["status", "limit"] },
      card:             { method: "GET",  path: "/cards/{sku}" },
      scan:             { method: "POST", path: "/scan", body: { frontUrl: "", backUrl: "" } },
      orders:           { method: "GET",  path: "/orders", query: ["stage"] },
      packing:          { method: "GET",  path: "/packing" },
      ship:             { method: "POST", path: "/ship", body: { orderIds: [], carrier: "USPS", tracking: "" } },
      thank_yous:       { method: "GET",  path: "/thank-yous" },
      decide_thank_you: { method: "POST", path: "/thank-yous/{id}", body: { decision: "send" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },
  sxo: {
    name: "SXO (sxowebsite.com)",
    type: "seo",
    description: "sxowebsite.com — per-site metrics, per-page opportunity ranking and A/B results for a site tracked by SXO. One per-site key (cro9_live_) per record; several sites = several records.",
    baseUrl: "https://sxowebsite.com/api/v1/cro9",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "site_reports", actions: ["metrics", "pages", "ab"], description: "The site's overview, its pages ranked by opportunity, and A/B winners" },
    ],
    endpoints: {
      metrics: { method: "GET", path: "/metrics", query: { period: "7d" } },
      pages:   { method: "GET", path: "/pages", query: { period: "7d", limit: 20 } },
      ab:      { method: "GET", path: "/ab", query: { period: "30d" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },
  ontask: {
    name: "0nTask",
    type: "productivity",
    description: "AI task manager — create, list, update and delete tasks; outbound webhooks; the AI work queue (claim → do → report → finish honestly)",
    baseUrl: "https://app.0ntask.com/api/v1",
    authType: "token",
    credentialKeys: ["token"],
    capabilities: [
      { name: "manage_tasks", actions: ["create", "list", "update", "delete"], description: "Full task CRUD" },
      { name: "manage_webhooks", actions: ["list", "create", "delete"], description: "Outbound event webhooks" },
      // THE WORK QUEUE. Tasks the person assigned to their AI, worked by whatever
      // agent holds this connection. The queue logic — leases, two attempts then a
      // human, blocked-by exclusion, honest outcomes — lives in 0nTask's server
      // and NOWHERE else; these are pass-throughs to its MCP tools so an agent
      // connected through 0nMCP gets exactly the queue a directly-connected
      // Claude gets. Two implementations of "who may have this task" is how two
      // agents end up working the same task.
      { name: "work_queue", actions: ["get_briefing", "claim_next_task", "report_progress", "complete_task"], description: "Work the tasks assigned to the AI, with leases and honest completion" },
    ],
    endpoints: {
      list_tasks:   { method: "GET",    path: "/tasks" },
      list_projects: { method: "GET",   path: "/projects" },
      list_clients: { method: "GET",    path: "/clients" },
      create_task:  { method: "POST",   path: "/tasks", body: { title: "", notes: "", priority: "medium", category: "", project: "", dueDate: "" } },
      update_task:  { method: "PATCH",  path: "/tasks", body: { id: "", title: "", status: "", priority: "", notes: "" } },
      delete_task:  { method: "DELETE", path: "/tasks", body: { id: "" } },
      quick_add:    { method: "GET",    path: "/quick" },
      // JSON-RPC over POST to 0nTask's own MCP endpoint — same body shape an MCP
      // client sends, same auth. The four `name`s are the queue tools; the
      // response is MCP's { content: [{ type: "text", text }] }.
      get_briefing:    { method: "POST", path: "/mcp", body: { jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "get_briefing", arguments: {} } } },
      claim_next_task: { method: "POST", path: "/mcp", body: { jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "claim_next_task", arguments: { agent: "0nMCP", ttlMinutes: 30 } } } },
      report_progress: { method: "POST", path: "/mcp", body: { jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "report_progress", arguments: { id: "", note: "" } } } },
      complete_task:   { method: "POST", path: "/mcp", body: { jsonrpc: "2.0", id: 1, method: "tools/call", params: { name: "complete_task", arguments: { id: "", outcome: "done", result: "", evidence: "", needs: "" } } } },
      skill:           { method: "GET",  path: "/skill", query: ["platform", "format"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Linear ────────────────────────────────────────────────
  linear: {
    name: "Linear",
    type: "project",
    description: "Issue tracking — teams, projects, issues, cycles",
    baseUrl: "https://api.linear.app",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_issues", actions: ["create", "list", "update"], description: "Create and manage issues" },
      { name: "manage_projects", actions: ["list"], description: "List projects" },
    ],
    endpoints: {
      graphql: { method: "POST", path: "/graphql", body: { query: "" } },
    },
    authHeader: (creds) => ({
      "Authorization": creds.apiKey,
      "Content-Type": "application/json",
    }),
  },

  // ── Shopify ───────────────────────────────────────────────
  shopify: {
    name: "Shopify",
    type: "ecommerce",
    description: "E-commerce — products, orders, customers, inventory",
    baseUrl: "https://{store}.myshopify.com/admin/api/2024-01",
    authType: "access_token",
    credentialKeys: ["accessToken", "store"],
    capabilities: [
      { name: "manage_products", actions: ["create", "list", "update"], description: "Manage products and variants" },
      { name: "manage_orders", actions: ["list", "get"], description: "View and manage orders" },
      { name: "manage_customers", actions: ["create", "list", "search"], description: "Manage customers" },
    ],
    endpoints: {
      list_products:    { method: "GET",  path: "/products.json" },
      create_product:   { method: "POST", path: "/products.json", body: { product: {} } },
      list_orders:      { method: "GET",  path: "/orders.json" },
      get_order:        { method: "GET",  path: "/orders/{orderId}.json" },
      list_customers:   { method: "GET",  path: "/customers.json" },
      create_customer:  { method: "POST", path: "/customers.json", body: { customer: {} } },
    },
    authHeader: (creds) => ({
      "X-Shopify-Access-Token": creds.accessToken,
      "Content-Type": "application/json",
    }),
  },

  // ── HubSpot ───────────────────────────────────────────────
  hubspot: {
    name: "HubSpot",
    type: "crm",
    description: "CRM and marketing — contacts, companies, deals, emails",
    baseUrl: "https://api.hubapi.com",
    authType: "access_token",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_contacts", actions: ["create", "list", "search"], description: "Manage contacts" },
      { name: "manage_companies", actions: ["create", "list"], description: "Manage companies" },
      { name: "manage_deals", actions: ["create", "list"], description: "Manage deals" },
    ],
    endpoints: {
      create_contact:   { method: "POST", path: "/crm/v3/objects/contacts", body: { properties: {} } },
      list_contacts:    { method: "GET",  path: "/crm/v3/objects/contacts" },
      search_contacts:  { method: "POST", path: "/crm/v3/objects/contacts/search", body: { query: "" } },
      create_company:   { method: "POST", path: "/crm/v3/objects/companies", body: { properties: {} } },
      create_deal:      { method: "POST", path: "/crm/v3/objects/deals", body: { properties: {} } },
      list_deals:       { method: "GET",  path: "/crm/v3/objects/deals" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Supabase ──────────────────────────────────────────────
  supabase: {
    name: "Supabase",
    type: "database",
    description: "Backend-as-a-service — database, auth, storage, edge functions",
    baseUrl: "https://{projectRef}.supabase.co",
    authType: "api_key",
    credentialKeys: ["apiKey", "projectRef"],
    capabilities: [
      { name: "manage_data", actions: ["select", "insert", "update", "delete"], description: "CRUD on database tables" },
      { name: "manage_auth", actions: ["list"], description: "Manage auth users" },
      { name: "manage_storage", actions: ["list", "upload"], description: "Manage file storage" },
    ],
    endpoints: {
      query_table:      { method: "GET",  path: "/rest/v1/{table}" },
      insert_row:       { method: "POST", path: "/rest/v1/{table}", body: {} },
      update_row:       { method: "PATCH", path: "/rest/v1/{table}", query: ["id"] },
      delete_row:       { method: "DELETE", path: "/rest/v1/{table}", query: ["id"] },
      list_users:       { method: "GET",  path: "/auth/v1/admin/users" },
      list_buckets:     { method: "GET",  path: "/storage/v1/bucket" },
    },
    authHeader: (creds) => ({
      "apikey": creds.apiKey,
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Calendly ──────────────────────────────────────────────
  calendly: {
    name: "Calendly",
    type: "scheduling",
    description: "Scheduling — event types, bookings, availability",
    baseUrl: "https://api.calendly.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_events", actions: ["list"], description: "List scheduled events" },
      { name: "manage_event_types", actions: ["list"], description: "List event types" },
    ],
    endpoints: {
      list_events:      { method: "GET",  path: "/scheduled_events", query: ["user", "count"] },
      list_event_types: { method: "GET",  path: "/event_types", query: ["user"] },
      get_user:         { method: "GET",  path: "/users/me" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Calendar ───────────────────────────────────────
  google_calendar: {
    name: "Google Calendar",
    type: "scheduling",
    description: "Calendar management — events, schedules, availability",
    baseUrl: "https://www.googleapis.com/calendar/v3",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_events", actions: ["create", "list", "update", "delete"], description: "Manage calendar events" },
      { name: "manage_calendars", actions: ["list"], description: "List calendars" },
    ],
    endpoints: {
      list_calendars:   { method: "GET",  path: "/users/me/calendarList" },
      list_events:      { method: "GET",  path: "/calendars/{calendarId}/events" },
      create_event:     { method: "POST", path: "/calendars/{calendarId}/events", body: { summary: "", start: {}, end: {} } },
      update_event:     { method: "PUT",  path: "/calendars/{calendarId}/events/{eventId}", body: {} },
      delete_event:     { method: "DELETE", path: "/calendars/{calendarId}/events/{eventId}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Gmail ───────────────────────────────────────────────────
  gmail: {
    name: "Gmail",
    type: "email",
    description: "Email — send, receive, labels, threads, drafts, search",
    baseUrl: "https://gmail.googleapis.com/gmail/v1",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "send_email", actions: ["send"], description: "Send emails" },
      { name: "manage_messages", actions: ["list", "get", "delete", "trash"], description: "Read, search, and manage messages" },
      { name: "manage_drafts", actions: ["create", "list", "send"], description: "Create and manage drafts" },
      { name: "manage_labels", actions: ["list", "create", "update"], description: "Organize with labels" },
      { name: "manage_threads", actions: ["list", "get"], description: "View conversation threads" },
    ],
    endpoints: {
      list_messages:    { method: "GET",  path: "/users/me/messages", query: ["q", "maxResults", "labelIds", "pageToken"] },
      get_message:      { method: "GET",  path: "/users/me/messages/{messageId}", query: ["format"] },
      send_message:     { method: "POST", path: "/users/me/messages/send", body: { raw: "" } },
      trash_message:    { method: "POST", path: "/users/me/messages/{messageId}/trash" },
      untrash_message:  { method: "POST", path: "/users/me/messages/{messageId}/untrash" },
      list_threads:     { method: "GET",  path: "/users/me/threads", query: ["q", "maxResults", "pageToken"] },
      get_thread:       { method: "GET",  path: "/users/me/threads/{threadId}" },
      create_draft:     { method: "POST", path: "/users/me/drafts", body: { message: { raw: "" } } },
      list_drafts:      { method: "GET",  path: "/users/me/drafts" },
      send_draft:       { method: "POST", path: "/users/me/drafts/send", body: { id: "" } },
      list_labels:      { method: "GET",  path: "/users/me/labels" },
      create_label:     { method: "POST", path: "/users/me/labels", body: { name: "" } },
      get_profile:      { method: "GET",  path: "/users/me/profile" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Sheets ───────────────────────────────────────────
  google_sheets: {
    name: "Google Sheets",
    type: "database",
    description: "Spreadsheets — read, write, append, create, format cells",
    baseUrl: "https://sheets.googleapis.com/v4",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_spreadsheets", actions: ["create", "get"], description: "Create and get spreadsheet metadata" },
      { name: "manage_values", actions: ["get", "update", "append", "clear"], description: "Read, write, and append cell values" },
      { name: "manage_sheets", actions: ["create", "delete"], description: "Add and remove sheets within a spreadsheet" },
    ],
    endpoints: {
      create_spreadsheet:   { method: "POST", path: "/spreadsheets", body: { properties: { title: "" } } },
      get_spreadsheet:      { method: "GET",  path: "/spreadsheets/{spreadsheetId}" },
      get_values:           { method: "GET",  path: "/spreadsheets/{spreadsheetId}/values/{range}" },
      update_values:        { method: "PUT",  path: "/spreadsheets/{spreadsheetId}/values/{range}", query: ["valueInputOption"], body: { values: [] } },
      append_values:        { method: "POST", path: "/spreadsheets/{spreadsheetId}/values/{range}:append", query: ["valueInputOption"], body: { values: [] } },
      clear_values:         { method: "POST", path: "/spreadsheets/{spreadsheetId}/values/{range}:clear" },
      batch_get:            { method: "GET",  path: "/spreadsheets/{spreadsheetId}/values:batchGet", query: ["ranges"] },
      batch_update:         { method: "POST", path: "/spreadsheets/{spreadsheetId}/values:batchUpdate", body: { data: [], valueInputOption: "USER_ENTERED" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Search Console ───────────────────────────────────
  //
  // WRITE, not readonly. `add_site` + `verify` are what a "set this domain up
  // for me" mini-app needs; the readonly scope this OAuth door used to request
  // could list properties and nothing else.
  //
  // The service key is `search_console` because tokens.js GOOGLE_FAMILY already
  // names it — so it reads the account's own `google` record with no extra
  // connection and no extra consent.
  search_console: {
    name: "Google Search Console",
    type: "marketing",
    description: "Sites, sitemaps, verification and search analytics for a domain",
    baseUrl: "https://www.googleapis.com/webmasters/v3",
    wholeSegment: ["siteUrl", "feedpath"], // whole URLs in one path segment (catalog-exec buildRequest)
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_sites", actions: ["list", "add", "get", "delete"], description: "Add and remove properties" },
      { name: "manage_sitemaps", actions: ["list", "submit", "get", "delete"], description: "Submit and inspect sitemaps" },
      { name: "search_analytics", actions: ["query"], description: "Clicks, impressions, CTR and position by query, page, country or device" },
    ],
    endpoints: {
      list_sites:      { method: "GET",    path: "/sites" },
      get_site:        { method: "GET",    path: "/sites/{siteUrl}" },
      add_site:        { method: "PUT",    path: "/sites/{siteUrl}" },
      delete_site:     { method: "DELETE", path: "/sites/{siteUrl}" },
      list_sitemaps:   { method: "GET",    path: "/sites/{siteUrl}/sitemaps" },
      submit_sitemap:  { method: "PUT",    path: "/sites/{siteUrl}/sitemaps/{feedpath}" },
      delete_sitemap:  { method: "DELETE", path: "/sites/{siteUrl}/sitemaps/{feedpath}" },
      search_analytics:{ method: "POST",   path: "/sites/{siteUrl}/searchAnalytics/query", body: { startDate: "", endDate: "", dimensions: [] } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Site Verification ────────────────────────────────
  //
  // Its own API and its own host. A Search Console property cannot be added
  // until the domain is verified, and the token to verify with comes from here.
  site_verification: {
    name: "Google Site Verification",
    type: "marketing",
    description: "Get a verification token for a domain and verify ownership",
    baseUrl: "https://www.googleapis.com/siteVerification/v1",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "verify_ownership", actions: ["get_token", "insert", "list"], description: "Issue a DNS/meta/file token and claim the domain" },
    ],
    endpoints: {
      // verificationMethod: DNS_TXT | DNS_CNAME | META | FILE | ANALYTICS | TAG_MANAGER
      get_token:  { method: "POST", path: "/token", body: { site: { type: "INET_DOMAIN", identifier: "" }, verificationMethod: "DNS_TXT" } },
      verify:     { method: "POST", path: "/webResource", query: ["verificationMethod"], body: { site: { type: "INET_DOMAIN", identifier: "" } } },
      list_owned: { method: "GET",  path: "/webResource" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Analytics Admin (GA4) ────────────────────────────
  //
  // The ADMIN API, which creates things — distinct from the Data API, which
  // reads reports. A property and a web data stream are what produce a
  // measurement ID, and a measurement ID is the deliverable of "set up GA4
  // for this domain".
  google_analytics_admin: {
    name: "Google Analytics Admin (GA4)",
    type: "marketing",
    description: "Create and manage GA4 accounts, properties, data streams and measurement IDs",
    baseUrl: "https://analyticsadmin.googleapis.com/v1beta",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_properties", actions: ["list", "create", "get", "update"], description: "GA4 properties under an account" },
      { name: "manage_data_streams", actions: ["list", "create", "get"], description: "Web data streams and their measurement IDs" },
      { name: "manage_key_events", actions: ["list", "create"], description: "Key events (conversions) a property counts" },
    ],
    endpoints: {
      list_accounts:      { method: "GET",  path: "/accounts" },
      list_account_summaries: { method: "GET", path: "/accountSummaries" },
      list_properties:    { method: "GET",  path: "/properties", query: ["filter", "pageSize"] },
      get_property:       { method: "GET",  path: "/{name}" },
      delete_property:    { method: "DELETE", path: "/{name}" },
      create_property:    { method: "POST", path: "/properties", body: { parent: "", displayName: "", timeZone: "America/New_York", currencyCode: "USD" } },
      list_data_streams:  { method: "GET",  path: "/{parent}/dataStreams" },
      create_data_stream: { method: "POST", path: "/{parent}/dataStreams", body: { type: "WEB_DATA_STREAM", displayName: "", webStreamData: { defaultUri: "" } } },
      get_data_stream:    { method: "GET",  path: "/{name}" },
      // Key events (GA4's "conversions"): what a property counts as a goal — sign_up, purchase …
      list_key_events:    { method: "GET",  path: "/{parent}/keyEvents" },
      create_key_event:   { method: "POST", path: "/{parent}/keyEvents", body: { eventName: "", countingMethod: "ONCE_PER_EVENT" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Analytics Data (GA4) ─────────────────────────────
  //
  // THE READ HALF. `google_analytics_admin` creates properties; this one asks
  // them questions, and without it a `ga4` credential in the vault had nowhere
  // in the catalog to land — `whoami` called it connected and `api_call ga4`
  // answered "Unknown service". `ga4` is aliased onto this service so the
  // records already sitting in people's vaults start working rather than
  // needing to be reconnected under a new name.
  //
  // Property ids go in the PATH, not a query string, and carry the
  // `properties/` prefix: `property: "properties/547156881"`.
  google_analytics: {
    name: "Google Analytics Data (GA4)",
    type: "marketing",
    aliases: ["ga4"],
    description: "Query GA4 reports — sessions, users, conversions, realtime, by any dimension",
    baseUrl: "https://analyticsdata.googleapis.com/v1beta",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "run_reports", actions: ["report", "batch", "realtime"], description: "Report on any GA4 metric by any dimension" },
      { name: "describe", actions: ["metadata"], description: "Which dimensions and metrics this property has" },
    ],
    endpoints: {
      run_report:          { method: "POST", path: "/{property}:runReport", body: { dateRanges: [{ startDate: "28daysAgo", endDate: "today" }], dimensions: [], metrics: [] } },
      run_realtime_report: { method: "POST", path: "/{property}:runRealtimeReport", body: { dimensions: [], metrics: [] } },
      batch_run_reports:   { method: "POST", path: "/{property}:batchRunReports", body: { requests: [] } },
      get_metadata:        { method: "GET",  path: "/{property}/metadata" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Drive ────────────────────────────────────────────
  google_drive: {
    name: "Google Drive",
    type: "storage",
    description: "Cloud storage — files, folders, sharing, search, permissions",
    baseUrl: "https://www.googleapis.com/drive/v3",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_files", actions: ["list", "get", "create", "delete", "copy"], description: "Upload, download, and manage files" },
      { name: "manage_permissions", actions: ["create", "list", "delete"], description: "Share files and manage access" },
      { name: "search_files", actions: ["search"], description: "Search across Drive" },
    ],
    endpoints: {
      list_files:           { method: "GET",  path: "/files", query: ["q", "pageSize", "orderBy", "fields", "pageToken"] },
      get_file:             { method: "GET",  path: "/files/{fileId}", query: ["fields"] },
      create_file:          { method: "POST", path: "/files", body: { name: "", mimeType: "", parents: [] } },
      copy_file:            { method: "POST", path: "/files/{fileId}/copy", body: { name: "" } },
      update_file:          { method: "PATCH", path: "/files/{fileId}", body: { name: "" } },
      delete_file:          { method: "DELETE", path: "/files/{fileId}" },
      create_permission:    { method: "POST", path: "/files/{fileId}/permissions", body: { role: "", type: "", emailAddress: "" } },
      list_permissions:     { method: "GET",  path: "/files/{fileId}/permissions" },
      delete_permission:    { method: "DELETE", path: "/files/{fileId}/permissions/{permissionId}" },
      generate_ids:         { method: "GET",  path: "/files/generateIds", query: ["count"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Jira ────────────────────────────────────────────────────
  jira: {
    name: "Jira",
    type: "project",
    description: "Project management — issues, sprints, boards, projects, epics, JQL search",
    baseUrl: "https://{domain}.atlassian.net/rest/api/3",
    authType: "basic",
    credentialKeys: ["email", "apiToken", "domain"],
    capabilities: [
      { name: "manage_issues", actions: ["create", "get", "update", "delete", "search", "transition"], description: "Full issue lifecycle management" },
      { name: "manage_projects", actions: ["list", "get"], description: "List and view projects" },
      { name: "manage_sprints", actions: ["list"], description: "View sprints and boards" },
      { name: "manage_comments", actions: ["create", "list"], description: "Add and view issue comments" },
    ],
    endpoints: {
      search_issues:        { method: "POST", path: "/search", body: { jql: "", maxResults: 50 } },
      create_issue:         { method: "POST", path: "/issue", body: { fields: { project: {}, summary: "", issuetype: {}, description: {} } } },
      get_issue:            { method: "GET",  path: "/issue/{issueIdOrKey}", query: ["fields", "expand"] },
      update_issue:         { method: "PUT",  path: "/issue/{issueIdOrKey}", body: { fields: {} } },
      delete_issue:         { method: "DELETE", path: "/issue/{issueIdOrKey}" },
      transition_issue:     { method: "POST", path: "/issue/{issueIdOrKey}/transitions", body: { transition: { id: "" } } },
      get_transitions:      { method: "GET",  path: "/issue/{issueIdOrKey}/transitions" },
      add_comment:          { method: "POST", path: "/issue/{issueIdOrKey}/comment", body: { body: {} } },
      list_comments:        { method: "GET",  path: "/issue/{issueIdOrKey}/comment" },
      list_projects:        { method: "GET",  path: "/project", query: ["maxResults", "startAt"] },
      get_project:          { method: "GET",  path: "/project/{projectIdOrKey}" },
      assign_issue:         { method: "PUT",  path: "/issue/{issueIdOrKey}/assignee", body: { accountId: "" } },
    },
    authHeader: (creds) => ({
      "Authorization": "Basic " + Buffer.from(`${creds.email}:${creds.apiToken}`).toString("base64"),
      "Content-Type": "application/json",
    }),
  },

  // ── Zendesk ─────────────────────────────────────────────────
  zendesk: {
    name: "Zendesk",
    type: "support",
    description: "Customer support — tickets, users, organizations, search, macros",
    baseUrl: "https://{subdomain}.zendesk.com/api/v2",
    authType: "basic",
    credentialKeys: ["email", "apiToken", "subdomain"],
    capabilities: [
      { name: "manage_tickets", actions: ["create", "list", "get", "update", "delete"], description: "Full ticket lifecycle" },
      { name: "manage_users", actions: ["create", "list", "search"], description: "Manage end-users and agents" },
      { name: "manage_organizations", actions: ["list", "get"], description: "View organizations" },
      { name: "search", actions: ["search"], description: "Full-text search across tickets, users, orgs" },
    ],
    endpoints: {
      list_tickets:         { method: "GET",  path: "/tickets.json", query: ["page", "per_page", "sort_by", "sort_order"] },
      get_ticket:           { method: "GET",  path: "/tickets/{ticketId}.json" },
      create_ticket:        { method: "POST", path: "/tickets.json", body: { ticket: { subject: "", description: "", priority: "" } } },
      update_ticket:        { method: "PUT",  path: "/tickets/{ticketId}.json", body: { ticket: {} } },
      delete_ticket:        { method: "DELETE", path: "/tickets/{ticketId}.json" },
      list_ticket_comments: { method: "GET",  path: "/tickets/{ticketId}/comments.json" },
      search:               { method: "GET",  path: "/search.json", query: ["query", "sort_by", "sort_order"] },
      list_users:           { method: "GET",  path: "/users.json", query: ["role", "page", "per_page"] },
      create_user:          { method: "POST", path: "/users.json", body: { user: { name: "", email: "" } } },
      get_user:             { method: "GET",  path: "/users/{userId}.json" },
      list_organizations:   { method: "GET",  path: "/organizations.json" },
      list_macros:          { method: "GET",  path: "/macros.json" },
    },
    authHeader: (creds) => ({
      "Authorization": "Basic " + Buffer.from(`${creds.email}/token:${creds.apiToken}`).toString("base64"),
      "Content-Type": "application/json",
    }),
  },

  // ── Mailchimp ───────────────────────────────────────────────
  mailchimp: {
    name: "Mailchimp",
    type: "marketing",
    description: "Email marketing — audiences, campaigns, automations, templates, analytics",
    baseUrl: "https://{dc}.api.mailchimp.com/3.0",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_audiences", actions: ["list", "get"], description: "View and manage audiences/lists" },
      { name: "manage_members", actions: ["create", "update", "list", "search"], description: "Add and manage subscribers" },
      { name: "manage_campaigns", actions: ["create", "list", "send"], description: "Create and send email campaigns" },
      { name: "manage_templates", actions: ["list"], description: "View email templates" },
    ],
    endpoints: {
      list_audiences:       { method: "GET",  path: "/lists", query: ["count", "offset"] },
      get_audience:         { method: "GET",  path: "/lists/{listId}" },
      add_member:           { method: "POST", path: "/lists/{listId}/members", body: { email_address: "", status: "subscribed" } },
      update_member:        { method: "PATCH", path: "/lists/{listId}/members/{subscriberHash}", body: {} },
      list_members:         { method: "GET",  path: "/lists/{listId}/members", query: ["count", "offset", "status"] },
      search_members:       { method: "GET",  path: "/search-members", query: ["query", "list_id"] },
      list_campaigns:       { method: "GET",  path: "/campaigns", query: ["count", "offset", "status", "type"] },
      create_campaign:      { method: "POST", path: "/campaigns", body: { type: "regular", recipients: {}, settings: {} } },
      send_campaign:        { method: "POST", path: "/campaigns/{campaignId}/actions/send" },
      get_campaign_report:  { method: "GET",  path: "/reports/{campaignId}" },
      list_templates:       { method: "GET",  path: "/templates", query: ["count", "type"] },
      list_automations:     { method: "GET",  path: "/automations" },
    },
    authHeader: (creds) => {
      const dc = creds.apiKey.split("-").pop();
      return {
        "Authorization": "Basic " + Buffer.from(`anystring:${creds.apiKey}`).toString("base64"),
        "Content-Type": "application/json",
      };
    },
  },

  // ── Zoom ────────────────────────────────────────────────────
  zoom: {
    name: "Zoom",
    type: "communication",
    description: "Video conferencing — meetings, webinars, recordings, users",
    baseUrl: "https://api.zoom.us/v2",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_meetings", actions: ["create", "list", "get", "update", "delete"], description: "Schedule and manage meetings" },
      { name: "manage_recordings", actions: ["list", "get", "delete"], description: "Access meeting recordings" },
      { name: "manage_users", actions: ["list", "get"], description: "View Zoom users" },
      { name: "manage_webinars", actions: ["list", "create"], description: "Schedule webinars" },
    ],
    endpoints: {
      list_meetings:        { method: "GET",  path: "/users/{userId}/meetings", query: ["type", "page_size", "page_number"] },
      create_meeting:       { method: "POST", path: "/users/{userId}/meetings", body: { topic: "", type: 2, start_time: "", duration: 60 } },
      get_meeting:          { method: "GET",  path: "/meetings/{meetingId}" },
      update_meeting:       { method: "PATCH", path: "/meetings/{meetingId}", body: {} },
      delete_meeting:       { method: "DELETE", path: "/meetings/{meetingId}" },
      list_recordings:      { method: "GET",  path: "/users/{userId}/recordings", query: ["from", "to", "page_size"] },
      get_recording:        { method: "GET",  path: "/meetings/{meetingId}/recordings" },
      delete_recording:     { method: "DELETE", path: "/meetings/{meetingId}/recordings" },
      list_users:           { method: "GET",  path: "/users", query: ["status", "page_size", "page_number"] },
      get_user:             { method: "GET",  path: "/users/{userId}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Microsoft Graph (Outlook, Teams, OneDrive) ──────────────
  microsoft: {
    name: "Microsoft 365",
    type: "productivity",
    description: "Outlook mail, Teams messages, OneDrive files, calendar — via Microsoft Graph API",
    baseUrl: "https://graph.microsoft.com/v1.0",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_mail", actions: ["send", "list", "get", "delete"], description: "Send and manage Outlook email" },
      { name: "manage_events", actions: ["create", "list", "update", "delete"], description: "Manage Outlook calendar events" },
      { name: "manage_files", actions: ["list", "get", "upload", "download", "resolve_share"], description: "OneDrive and SharePoint files, including items shared by link from another user's drive" },
      { name: "manage_teams", actions: ["send", "list"], description: "Send Teams messages and list channels" },
      { name: "manage_users", actions: ["list", "get"], description: "View organization users" },
    ],
    endpoints: {
      send_mail:            { method: "POST", path: "/me/sendMail", body: { message: { subject: "", body: {}, toRecipients: [] } } },
      list_messages:        { method: "GET",  path: "/me/messages", query: ["$top", "$skip", "$filter", "$select", "$orderby"] },
      get_message:          { method: "GET",  path: "/me/messages/{messageId}" },
      delete_message:       { method: "DELETE", path: "/me/messages/{messageId}" },
      list_events:          { method: "GET",  path: "/me/events", query: ["$top", "$filter", "$orderby"] },
      create_event:         { method: "POST", path: "/me/events", body: { subject: "", start: {}, end: {}, attendees: [] } },
      update_event:         { method: "PATCH", path: "/me/events/{eventId}", body: {} },
      delete_event:         { method: "DELETE", path: "/me/events/{eventId}" },
      list_drive_items:     { method: "GET",  path: "/me/drive/root/children" },
      get_drive_item:       { method: "GET",  path: "/me/drive/items/{itemId}" },
      search_drive:         { method: "GET",  path: "/me/drive/root/search(q='{query}')" },
      // — files that are NOT in the signed-in user's own drive root —
      // resolve_share takes a sharing URL encoded as: "u!" + base64(url), "=" stripped, "/"->"_", "+"->"-"
      resolve_share:        { method: "GET",  path: "/shares/{encodedUrl}/driveItem" },
      list_shared_with_me:  { method: "GET",  path: "/me/drive/sharedWithMe" },
      get_item_content:     { method: "GET",  path: "/drives/{driveId}/items/{itemId}/content" },
      get_site:             { method: "GET",  path: "/sites/{hostname}:/sites/{sitePath}" },
      list_site_items:      { method: "GET",  path: "/sites/{siteId}/drive/root/children" },
      list_teams:           { method: "GET",  path: "/me/joinedTeams" },
      list_channels:        { method: "GET",  path: "/teams/{teamId}/channels" },
      send_channel_message: { method: "POST", path: "/teams/{teamId}/channels/{channelId}/messages", body: { body: { content: "" } } },
      get_user:             { method: "GET",  path: "/me" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── MongoDB Atlas ───────────────────────────────────────────
  mongodb: {
    name: "MongoDB",
    type: "database",
    description: "NoSQL database — find, insert, update, delete, aggregate via Atlas Data API",
    baseUrl: "https://data.mongodb-api.com/app/{appId}/endpoint/data/v1",
    authType: "api_key",
    credentialKeys: ["apiKey", "appId"],
    capabilities: [
      { name: "manage_documents", actions: ["find", "insert", "update", "delete"], description: "CRUD operations on documents" },
      { name: "aggregate", actions: ["aggregate"], description: "Run aggregation pipelines" },
    ],
    endpoints: {
      find_one:             { method: "POST", path: "/action/findOne", body: { dataSource: "", database: "", collection: "", filter: {} } },
      find_many:            { method: "POST", path: "/action/find", body: { dataSource: "", database: "", collection: "", filter: {}, limit: 100 } },
      insert_one:           { method: "POST", path: "/action/insertOne", body: { dataSource: "", database: "", collection: "", document: {} } },
      insert_many:          { method: "POST", path: "/action/insertMany", body: { dataSource: "", database: "", collection: "", documents: [] } },
      update_one:           { method: "POST", path: "/action/updateOne", body: { dataSource: "", database: "", collection: "", filter: {}, update: {} } },
      update_many:          { method: "POST", path: "/action/updateMany", body: { dataSource: "", database: "", collection: "", filter: {}, update: {} } },
      delete_one:           { method: "POST", path: "/action/deleteOne", body: { dataSource: "", database: "", collection: "", filter: {} } },
      aggregate:            { method: "POST", path: "/action/aggregate", body: { dataSource: "", database: "", collection: "", pipeline: [] } },
    },
    authHeader: (creds) => ({
      "api-key": creds.apiKey,
      "Content-Type": "application/json",
      "Access-Control-Request-Headers": "*",
    }),
  },

  // ── QuickBooks ──────────────────────────────────────────────
  quickbooks: {
    name: "QuickBooks",
    type: "accounting",
    description: "Accounting — invoices, customers, payments, bills, estimates, items, reports",
    baseUrl: "https://quickbooks.api.intuit.com/v3",
    authType: "oauth",
    credentialKeys: ["access_token", "realmId"],
    capabilities: [
      { name: "manage_invoices", actions: ["create", "list", "get", "send"], description: "Create and send invoices" },
      { name: "manage_customers", actions: ["create", "list", "get", "update"], description: "Manage customers" },
      { name: "manage_payments", actions: ["create", "list"], description: "Record and list payments" },
      { name: "manage_accounts", actions: ["list", "get"], description: "Chart of accounts management" },
      { name: "manage_bills", actions: ["create", "list"], description: "Create and track bills" },
      { name: "manage_estimates", actions: ["create", "list", "send"], description: "Create and send estimates" },
      { name: "manage_items", actions: ["create", "list", "get", "update"], description: "Manage products and services" },
      { name: "manage_reports", actions: ["get"], description: "Generate financial reports" },
    ],
    endpoints: {
      create_invoice:       { method: "POST", path: "/company/{realmId}/invoice", body: { Line: [], CustomerRef: {} } },
      list_invoices:        { method: "GET",  path: "/company/{realmId}/query", query: ["query"] },
      get_invoice:          { method: "GET",  path: "/company/{realmId}/invoice/{invoiceId}" },
      send_invoice:         { method: "POST", path: "/company/{realmId}/invoice/{invoiceId}/send", query: ["sendTo"] },
      create_customer:      { method: "POST", path: "/company/{realmId}/customer", body: { DisplayName: "", PrimaryEmailAddr: {} } },
      list_customers:       { method: "GET",  path: "/company/{realmId}/query", query: ["query"] },
      get_customer:         { method: "GET",  path: "/company/{realmId}/customer/{customerId}" },
      update_customer:      { method: "POST", path: "/company/{realmId}/customer", body: { Id: "", SyncToken: "" } },
      create_payment:       { method: "POST", path: "/company/{realmId}/payment", body: { TotalAmt: 0, CustomerRef: {} } },
      list_payments:        { method: "GET",  path: "/company/{realmId}/query", query: ["query"] },
      list_accounts:        { method: "GET",  path: "/company/{realmId}/query", query: ["query"] },
      get_account:          { method: "GET",  path: "/company/{realmId}/account/{accountId}" },
      create_bill:          { method: "POST", path: "/company/{realmId}/bill", body: { VendorRef: {}, Line: [] } },
      list_bills:           { method: "GET",  path: "/company/{realmId}/query", query: ["query"] },
      create_estimate:      { method: "POST", path: "/company/{realmId}/estimate", body: { Line: [], CustomerRef: {} } },
      send_estimate:        { method: "POST", path: "/company/{realmId}/estimate/{estimateId}/send", query: ["sendTo"] },
      create_item:          { method: "POST", path: "/company/{realmId}/item", body: { Name: "", Type: "Service" } },
      list_items:           { method: "GET",  path: "/company/{realmId}/query", query: ["query"] },
      get_item:             { method: "GET",  path: "/company/{realmId}/item/{itemId}" },
      profit_loss_report:   { method: "GET",  path: "/company/{realmId}/reports/ProfitAndLoss", query: ["start_date", "end_date"] },
      balance_sheet:        { method: "GET",  path: "/company/{realmId}/reports/BalanceSheet", query: ["start_date", "end_date"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Accept": "application/json",
      "Content-Type": "application/json",
    }),
  },

  // ── Asana ───────────────────────────────────────────────────
  asana: {
    name: "Asana",
    type: "project",
    description: "Project management — tasks, projects, sections, workspaces, tags, teams",
    baseUrl: "https://app.asana.com/api/1.0",
    authType: "token",
    credentialKeys: ["token"],
    capabilities: [
      { name: "manage_tasks", actions: ["create", "list", "get", "update", "delete"], description: "Full task lifecycle management" },
      { name: "manage_projects", actions: ["create", "list", "get"], description: "Create and manage projects" },
      { name: "manage_sections", actions: ["create", "list"], description: "Organize projects with sections" },
      { name: "manage_workspaces", actions: ["list"], description: "List available workspaces" },
      { name: "manage_tags", actions: ["create", "list"], description: "Create and manage tags" },
      { name: "manage_teams", actions: ["list"], description: "List organization teams" },
    ],
    endpoints: {
      create_task:          { method: "POST", path: "/tasks", body: { data: { name: "", workspace: "", projects: [] } } },
      list_tasks:           { method: "GET",  path: "/tasks", query: ["project", "assignee", "workspace", "completed_since"] },
      get_task:             { method: "GET",  path: "/tasks/{taskGid}" },
      update_task:          { method: "PUT",  path: "/tasks/{taskGid}", body: { data: {} } },
      delete_task:          { method: "DELETE", path: "/tasks/{taskGid}" },
      create_project:       { method: "POST", path: "/projects", body: { data: { name: "", workspace: "" } } },
      list_projects:        { method: "GET",  path: "/projects", query: ["workspace", "team"] },
      get_project:          { method: "GET",  path: "/projects/{projectGid}" },
      create_section:       { method: "POST", path: "/projects/{projectGid}/sections", body: { data: { name: "" } } },
      list_sections:        { method: "GET",  path: "/projects/{projectGid}/sections" },
      list_workspaces:      { method: "GET",  path: "/workspaces" },
      create_tag:           { method: "POST", path: "/tags", body: { data: { name: "", workspace: "" } } },
      list_tags:            { method: "GET",  path: "/tags", query: ["workspace"] },
      list_teams:           { method: "GET",  path: "/organizations/{organizationGid}/teams" },
      add_task_to_project:  { method: "POST", path: "/tasks/{taskGid}/addProject", body: { data: { project: "" } } },
      search_tasks:         { method: "GET",  path: "/workspaces/{workspaceGid}/tasks/search", query: ["text", "completed"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── TickTick ────────────────────────────────────────────────
  ticktick: {
    name: "TickTick",
    type: "project",
    description: "To-do list & task manager — tasks, projects (lists), subtasks, due dates, priorities, reminders",
    baseUrl: "https://api.ticktick.com/open/v1",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_tasks", actions: ["create", "get", "update", "complete", "delete"], description: "Full task lifecycle — create, read, update, complete, and delete tasks" },
      { name: "manage_projects", actions: ["create", "list", "get", "update", "delete"], description: "Create and manage projects (lists)" },
      { name: "get_project_data", actions: ["get"], description: "Fetch a project with all of its tasks and columns" },
    ],
    endpoints: {
      // Projects (lists)
      list_projects:   { method: "GET",    path: "/project" },
      get_project:     { method: "GET",    path: "/project/{projectId}" },
      get_project_data:{ method: "GET",    path: "/project/{projectId}/data" },
      create_project:  { method: "POST",   path: "/project", body: { name: "", color: "", viewMode: "list", kind: "TASK" } },
      update_project:  { method: "POST",   path: "/project/{projectId}", body: { name: "" } },
      delete_project:  { method: "DELETE", path: "/project/{projectId}" },
      // Tasks
      get_task:        { method: "GET",    path: "/project/{projectId}/task/{taskId}" },
      create_task:     { method: "POST",   path: "/task", body: { title: "", projectId: "", content: "", desc: "", isAllDay: false, startDate: "", dueDate: "", timeZone: "", priority: 0, reminders: [], repeatFlag: "", items: [] } },
      update_task:     { method: "POST",   path: "/task/{taskId}", body: { id: "", projectId: "", title: "", content: "", priority: 0, dueDate: "" } },
      complete_task:   { method: "POST",   path: "/project/{projectId}/task/{taskId}/complete" },
      delete_task:     { method: "DELETE", path: "/project/{projectId}/task/{taskId}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── RDAP (public domain registration data) ───────────────────
  // The registries' own replacement for WHOIS (RFC 9082/9083): registrar, status (e.g. "redemption period"), created /
  // expires / last-changed events, nameservers. rdap.org redirects each query to the authoritative registry server
  // (IANA bootstrap), which covers every gTLD and the ccTLDs that run RDAP (.ai included). No key; public data only.
  rdap: {
    name: "RDAP (domain lookup)",
    type: "domains",
    description: "Public domain registration data — registrar, status, created/expiry dates, nameservers — straight from the registry (the modern WHOIS)",
    baseUrl: "https://rdap.org",
    authType: "none",
    credentialKeys: [],
    capabilities: [
      { name: "lookup", actions: ["domain", "nameserver", "ip", "asn"], description: "Look up a domain, nameserver, IP network or autonomous system" },
    ],
    endpoints: {
      domain:     { method: "GET", path: "/domain/{domain}" },
      nameserver: { method: "GET", path: "/nameserver/{nameserver}" },
      ip:         { method: "GET", path: "/ip/{ip}" },
      asn:        { method: "GET", path: "/autnum/{asn}" },
    },
    // rdap.org refuses requests without a User-Agent (403); it then 302s to the registry.
    authHeader: () => ({ "Accept": "application/rdap+json, application/json", "User-Agent": "0n3-rdap/1.0 (+https://0n3.app)" }),
  },

  // ── Substack ────────────────────────────────────────────────
  substack: {
    name: "Substack",
    type: "content",
    description: "Newsletter & publishing platform — read a publication's posts, archive, and search (public content API)",
    baseUrl: "https://{subdomain}.substack.com/api/v1",
    authType: "none",
    credentialKeys: ["subdomain"],
    capabilities: [
      { name: "read_posts", actions: ["list", "get"], description: "List a publication's posts (archive) and fetch a single post by slug" },
      { name: "search_posts", actions: ["search"], description: "Search posts within a publication" },
    ],
    endpoints: {
      list_posts:   { method: "GET", path: "/archive", query: ["sort", "limit", "offset"] },
      get_post:     { method: "GET", path: "/posts/{slug}" },
      search_posts: { method: "GET", path: "/post/search", query: ["query", "limit"] },
    },
    authHeader: () => ({
      "User-Agent": "Mozilla/5.0 (0nMCP)",
      "Accept": "application/json",
    }),
  },

  // ── Intercom ────────────────────────────────────────────────
  intercom: {
    name: "Intercom",
    type: "support",
    description: "Customer messaging — contacts, conversations, companies, tags, articles",
    baseUrl: "https://api.intercom.io",
    authType: "access_token",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_contacts", actions: ["create", "list", "search", "update"], description: "Manage contacts and leads" },
      { name: "manage_conversations", actions: ["create", "list", "reply", "close"], description: "Handle customer conversations" },
      { name: "manage_companies", actions: ["create", "list"], description: "Manage companies" },
      { name: "manage_tags", actions: ["create", "list"], description: "Create and assign tags" },
      { name: "manage_articles", actions: ["create", "list"], description: "Manage help center articles" },
    ],
    endpoints: {
      create_contact:       { method: "POST", path: "/contacts", body: { role: "user", email: "" } },
      list_contacts:        { method: "GET",  path: "/contacts" },
      search_contacts:      { method: "POST", path: "/contacts/search", body: { query: {} } },
      update_contact:       { method: "PUT",  path: "/contacts/{contactId}", body: {} },
      create_conversation:  { method: "POST", path: "/conversations", body: { from: {}, body: "" } },
      list_conversations:   { method: "GET",  path: "/conversations" },
      reply_to_conversation:{ method: "POST", path: "/conversations/{conversationId}/reply", body: { message_type: "comment", type: "admin", body: "" } },
      close_conversation:   { method: "POST", path: "/conversations/{conversationId}/parts", body: { message_type: "close", type: "admin" } },
      create_company:       { method: "POST", path: "/companies", body: { name: "", company_id: "" } },
      list_companies:       { method: "GET",  path: "/companies" },
      create_tag:           { method: "POST", path: "/tags", body: { name: "" } },
      tag_contact:          { method: "POST", path: "/contacts/{contactId}/tags", body: { id: "" } },
      list_tags:            { method: "GET",  path: "/tags" },
      create_article:       { method: "POST", path: "/articles", body: { title: "", body: "", author_id: "" } },
      list_articles:        { method: "GET",  path: "/articles" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Intercom-Version": "2.10",
    }),
  },

  // ── Dropbox ─────────────────────────────────────────────────
  dropbox: {
    name: "Dropbox",
    type: "storage",
    description: "Cloud storage — files, folders, sharing, search",
    baseUrl: "https://api.dropboxapi.com/2",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_files", actions: ["upload", "download", "list", "move", "delete", "search"], description: "Upload, download, and manage files" },
      { name: "manage_folders", actions: ["create", "list"], description: "Create and list folders" },
      { name: "manage_sharing", actions: ["create_link", "list_shared"], description: "Share files and folders" },
    ],
    endpoints: {
      list_folder:          { method: "POST", path: "/files/list_folder", body: { path: "", recursive: false, limit: 100 } },
      list_folder_continue: { method: "POST", path: "/files/list_folder/continue", body: { cursor: "" } },
      get_metadata:         { method: "POST", path: "/files/get_metadata", body: { path: "" } },
      create_folder:        { method: "POST", path: "/files/create_folder_v2", body: { path: "", autorename: false } },
      delete:               { method: "POST", path: "/files/delete_v2", body: { path: "" } },
      move:                 { method: "POST", path: "/files/move_v2", body: { from_path: "", to_path: "" } },
      copy:                 { method: "POST", path: "/files/copy_v2", body: { from_path: "", to_path: "" } },
      search:               { method: "POST", path: "/files/search_v2", body: { query: "", options: { max_results: 100 } } },
      create_shared_link:   { method: "POST", path: "/sharing/create_shared_link_with_settings", body: { path: "" } },
      list_shared_links:    { method: "POST", path: "/sharing/list_shared_links", body: { path: "" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── WhatsApp Business ───────────────────────────────────────
  whatsapp: {
    name: "WhatsApp Business",
    type: "communication",
    description: "Business messaging — send texts, templates, media via WhatsApp Business API",
    baseUrl: "https://graph.facebook.com/v19.0",
    authType: "access_token",
    credentialKeys: ["accessToken", "phoneNumberId"],
    capabilities: [
      { name: "send_message", actions: ["send_text", "send_template", "send_media"], description: "Send messages via WhatsApp" },
      { name: "manage_templates", actions: ["list", "get"], description: "Manage message templates" },
      { name: "manage_media", actions: ["upload", "get"], description: "Upload and retrieve media" },
    ],
    endpoints: {
      send_text_message:     { method: "POST", path: "/{phoneNumberId}/messages", body: { messaging_product: "whatsapp", to: "", type: "text", text: { body: "" } } },
      send_template_message: { method: "POST", path: "/{phoneNumberId}/messages", body: { messaging_product: "whatsapp", to: "", type: "template", template: { name: "", language: { code: "en" } } } },
      send_media_message:    { method: "POST", path: "/{phoneNumberId}/messages", body: { messaging_product: "whatsapp", to: "", type: "image", image: { link: "" } } },
      list_templates:        { method: "GET",  path: "/{businessId}/message_templates" },
      upload_media:          { method: "POST", path: "/{phoneNumberId}/media", contentType: "multipart/form-data" },
      get_media_url:         { method: "GET",  path: "/{mediaId}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Instagram ───────────────────────────────────────────────
  instagram: {
    name: "Instagram",
    type: "social",
    description: "Social media — posts, comments, insights, stories via Instagram Graph API",
    baseUrl: "https://graph.facebook.com/v19.0",
    authType: "access_token",
    credentialKeys: ["accessToken", "igUserId"],
    capabilities: [
      { name: "manage_media", actions: ["create", "list", "get"], description: "Create and manage media posts" },
      { name: "manage_comments", actions: ["list", "reply", "delete"], description: "Moderate comments" },
      { name: "manage_insights", actions: ["get"], description: "View account and media insights" },
      { name: "manage_stories", actions: ["list"], description: "List active stories" },
    ],
    endpoints: {
      list_media:             { method: "GET",  path: "/{igUserId}/media", query: ["fields", "limit"] },
      get_media:              { method: "GET",  path: "/{mediaId}", query: ["fields"] },
      create_media_container: { method: "POST", path: "/{igUserId}/media", body: { image_url: "", caption: "" } },
      publish_media:          { method: "POST", path: "/{igUserId}/media_publish", body: { creation_id: "" } },
      list_comments:          { method: "GET",  path: "/{mediaId}/comments", query: ["fields"] },
      reply_to_comment:       { method: "POST", path: "/{commentId}/replies", body: { message: "" } },
      delete_comment:         { method: "DELETE", path: "/{commentId}" },
      get_insights:           { method: "GET",  path: "/{igUserId}/insights", query: ["metric", "period"] },
      list_stories:           { method: "GET",  path: "/{igUserId}/stories", query: ["fields"] },
      get_profile:            { method: "GET",  path: "/{igUserId}", query: ["fields"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── X (Twitter) ─────────────────────────────────────────────
  twitter: {
    name: "X (Twitter)",
    type: "social",
    description: "Social platform — tweets, users, followers, lists, direct messages",
    baseUrl: "https://api.x.com/2",
    authType: "oauth",
    credentialKeys: ["bearerToken"],
    capabilities: [
      { name: "manage_tweets", actions: ["create", "list", "delete", "search"], description: "Post and manage tweets" },
      { name: "manage_users", actions: ["get", "list_followers", "list_following"], description: "View user profiles and connections" },
      { name: "manage_lists", actions: ["create", "list"], description: "Create and manage lists" },
      { name: "manage_dm", actions: ["send"], description: "Send direct messages" },
    ],
    endpoints: {
      create_tweet:         { method: "POST",   path: "/tweets", body: { text: "" } },
      delete_tweet:         { method: "DELETE", path: "/tweets/{tweetId}" },
      get_tweet:            { method: "GET",    path: "/tweets/{tweetId}", query: ["tweet.fields", "expansions"] },
      search_tweets:        { method: "GET",    path: "/tweets/search/recent", query: ["query", "max_results", "tweet.fields"] },
      get_user:             { method: "GET",    path: "/users/{userId}", query: ["user.fields"] },
      get_user_by_username: { method: "GET",    path: "/users/by/username/{username}", query: ["user.fields"] },
      get_user_tweets:      { method: "GET",    path: "/users/{userId}/tweets", query: ["max_results", "tweet.fields"] },
      get_followers:        { method: "GET",    path: "/users/{userId}/followers", query: ["max_results", "user.fields"] },
      get_following:        { method: "GET",    path: "/users/{userId}/following", query: ["max_results", "user.fields"] },
      create_list:          { method: "POST",   path: "/lists", body: { name: "", description: "" } },
      get_lists:            { method: "GET",    path: "/users/{userId}/owned_lists" },
      send_dm:              { method: "POST",   path: "/dm_conversations/with/{participantId}/messages", body: { text: "" } },
      like_tweet:           { method: "POST",   path: "/users/{userId}/likes", body: { tweet_id: "" } },
      unlike_tweet:         { method: "DELETE", path: "/users/{userId}/likes/{tweetId}" },
      retweet:              { method: "POST",   path: "/users/{userId}/retweets", body: { tweet_id: "" } },
      unretweet:            { method: "DELETE", path: "/users/{userId}/retweets/{tweetId}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.bearerToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── TikTok Business ─────────────────────────────────────────
  tiktok: {
    name: "TikTok Business",
    type: "social",
    description: "Social video — videos, ads, campaigns, reports via TikTok Business API",
    baseUrl: "https://business-api.tiktok.com/open_api/v1.3",
    authType: "access_token",
    credentialKeys: ["accessToken", "advertiserId"],
    capabilities: [
      { name: "manage_videos", actions: ["list", "get"], description: "View video content" },
      { name: "manage_ads", actions: ["create", "list", "get", "update"], description: "Manage ad creatives" },
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage ad campaigns" },
      { name: "manage_reports", actions: ["get"], description: "Pull performance reports" },
    ],
    endpoints: {
      list_videos:          { method: "GET",  path: "/video/list/", query: ["advertiser_id"] },
      get_video_info:       { method: "GET",  path: "/video/info/", query: ["advertiser_id", "video_ids"] },
      create_campaign:      { method: "POST", path: "/campaign/create/", body: { advertiser_id: "", campaign_name: "", objective_type: "", budget_mode: "" } },
      list_campaigns:       { method: "GET",  path: "/campaign/get/", query: ["advertiser_id", "page", "page_size"] },
      get_campaign:         { method: "GET",  path: "/campaign/get/", query: ["advertiser_id", "campaign_ids"] },
      update_campaign:      { method: "POST", path: "/campaign/update/", body: { advertiser_id: "", campaign_id: "" } },
      create_ad_group:      { method: "POST", path: "/adgroup/create/", body: { advertiser_id: "", campaign_id: "", adgroup_name: "" } },
      list_ad_groups:       { method: "GET",  path: "/adgroup/get/", query: ["advertiser_id", "page", "page_size"] },
      create_ad:            { method: "POST", path: "/ad/create/", body: { advertiser_id: "", adgroup_id: "", creatives: [] } },
      list_ads:             { method: "GET",  path: "/ad/get/", query: ["advertiser_id", "page", "page_size"] },
      get_report:           { method: "POST", path: "/report/integrated/get/", body: { advertiser_id: "", report_type: "", dimensions: [], metrics: [] } },
    },
    authHeader: (creds) => ({
      "Access-Token": creds.accessToken,
      "Content-Type": "application/json",
    }),
  },

  // ── Google Ads ──────────────────────────────────────────────
  google_ads: {
    name: "Google Ads",
    type: "advertising",
    description: "Search and display advertising — campaigns, ad groups, ads, keywords, reports",
    baseUrl: "https://googleads.googleapis.com/v26", // v16–v21 answer 404 (sunset); v26 is the newest live version, measured 2026-11-06
    authType: "oauth",
    credentialKeys: ["access_token", "developerToken", "customerId"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage ad campaigns" },
      { name: "manage_ad_groups", actions: ["create", "list"], description: "Manage ad groups" },
      { name: "manage_ads", actions: ["create", "list"], description: "Manage ad creatives" },
      { name: "manage_keywords", actions: ["create", "list"], description: "Manage keywords and targeting" },
      { name: "get_reports", actions: ["get"], description: "Pull campaign performance reports" },
    ],
    endpoints: {
      search:               { method: "POST", path: "/customers/{customerId}/googleAds:searchStream", body: { query: "" } },
      mutate_campaigns:     { method: "POST", path: "/customers/{customerId}/campaigns:mutate", body: { operations: [] } },
      list_campaigns:       { method: "POST", path: "/customers/{customerId}/googleAds:search", body: { query: "SELECT campaign.id, campaign.name, campaign.status FROM campaign" } },
      create_campaign:      { method: "POST", path: "/customers/{customerId}/campaigns:mutate", body: { operations: [{ create: {} }] } },
      list_ad_groups:       { method: "POST", path: "/customers/{customerId}/googleAds:search", body: { query: "SELECT ad_group.id, ad_group.name FROM ad_group" } },
      create_ad_group:      { method: "POST", path: "/customers/{customerId}/adGroups:mutate", body: { operations: [{ create: {} }] } },
      list_ads:             { method: "POST", path: "/customers/{customerId}/googleAds:search", body: { query: "SELECT ad_group_ad.ad.id, ad_group_ad.ad.name FROM ad_group_ad" } },
      create_ad:            { method: "POST", path: "/customers/{customerId}/adGroupAds:mutate", body: { operations: [{ create: {} }] } },
      get_report:           { method: "POST", path: "/customers/{customerId}/googleAds:searchStream", body: { query: "" } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "developer-token": creds.developerToken,
      "Content-Type": "application/json",
    }),
  },

  // ── Facebook Ads ────────────────────────────────────────────
  facebook_ads: {
    name: "Facebook Ads",
    type: "advertising",
    description: "Social advertising — campaigns, ad sets, ads, insights, audiences",
    baseUrl: "https://graph.facebook.com/v19.0",
    authType: "access_token",
    credentialKeys: ["accessToken", "adAccountId"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage ad campaigns" },
      { name: "manage_adsets", actions: ["create", "list", "get", "update"], description: "Manage ad sets and targeting" },
      { name: "manage_ads", actions: ["create", "list", "get"], description: "Manage ad creatives" },
      { name: "manage_insights", actions: ["get"], description: "View performance insights" },
      { name: "manage_audiences", actions: ["create", "list"], description: "Create and manage custom audiences" },
    ],
    endpoints: {
      create_campaign:      { method: "POST", path: "/act_{adAccountId}/campaigns", body: { name: "", objective: "", status: "PAUSED", special_ad_categories: [] } },
      list_campaigns:       { method: "GET",  path: "/act_{adAccountId}/campaigns", query: ["fields", "limit"] },
      get_campaign:         { method: "GET",  path: "/{campaignId}", query: ["fields"] },
      update_campaign:      { method: "POST", path: "/{campaignId}", body: {} },
      create_adset:         { method: "POST", path: "/act_{adAccountId}/adsets", body: { name: "", campaign_id: "", daily_budget: 0, targeting: {}, status: "PAUSED" } },
      list_adsets:          { method: "GET",  path: "/act_{adAccountId}/adsets", query: ["fields", "limit"] },
      create_ad:            { method: "POST", path: "/act_{adAccountId}/ads", body: { name: "", adset_id: "", creative: {}, status: "PAUSED" } },
      list_ads:             { method: "GET",  path: "/act_{adAccountId}/ads", query: ["fields", "limit"] },
      get_insights:         { method: "GET",  path: "/act_{adAccountId}/insights", query: ["fields", "date_preset", "level", "time_range"] },
      create_audience:      { method: "POST", path: "/act_{adAccountId}/customaudiences", body: { name: "", subtype: "CUSTOM", description: "" } },
      list_audiences:       { method: "GET",  path: "/act_{adAccountId}/customaudiences", query: ["fields", "limit"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Facebook Marketplace (partner Item + Seller APIs) ───────
  // Mike, 2026-11-05. developers.facebook.com/docs/marketplace/partnerships/{itemAPI,sellerAPI} — a Marketplace PARTNER lists
  // items from its own product catalog. Sellers first (a product whose partner_seller_id has no seller is never distributed),
  // then items. Seller API ≤ 200 calls/hour, ≤ 5,000 sellers per call; Item API ≤ 30 calls/minute, ≤ 300 items per call.
  // Both answer with a handle/session id: poll the status endpoint until "finished" / "completed" and read its errors.
  facebook_marketplace: {
    name: "Facebook Marketplace (partner)",
    type: "commerce",
    description: "Marketplace partner listings — sellers and items in your product catalog, batch upload, status, catalog products",
    baseUrl: "https://graph.facebook.com/v20.0",
    authType: "access_token",
    credentialKeys: ["accessToken", "catalogId"],
    capabilities: [
      { name: "manage_sellers", actions: ["create", "update", "delete", "status"], description: "Partner sellers (seller_id, seller_name, ratings) — upload before their items" },
      { name: "manage_items", actions: ["create", "update", "delete", "status"], description: "Marketplace items via items_batch (PRODUCT_ITEM)" },
      { name: "read_catalog", actions: ["get", "list"], description: "The catalog and its products" },
    ],
    endpoints: {
      // requests: [{ method: "CREATE"|"UPDATE"|"DELETE", data: { seller_id, seller_name, seller_review_count?, seller_positive_ratings_pct?, seller_member_since? } }]
      sellers_batch:        { method: "POST", path: "/{catalogId}/marketplace_partner_sellers_details", body: { requests: [] } },
      sellers_status:       { method: "GET",  path: "/{catalogId}/check_marketplace_partner_sellers_status", query: ["session_id"] },
      // requests: [{ method: "CREATE"|"UPDATE"|"DELETE", data: { id, title, description, condition, brand, price, availability, link, image_link,
      //   partner_seller_id, partner_item_country, partner_item_latitude/longitude (in_person), partner_shipping_type/cost, … } }]
      items_batch:          { method: "POST", path: "/{catalogId}/items_batch", body: { item_type: "PRODUCT_ITEM", requests: [] } },
      items_status:         { method: "GET",  path: "/{catalogId}/check_batch_request_status", query: ["handle"] },
      get_catalog:          { method: "GET",  path: "/{catalogId}", query: ["fields"] },
      list_products:        { method: "GET",  path: "/{catalogId}/products", query: ["fields", "limit", "filter", "after"] },
      list_business_catalogs: { method: "GET", path: "/{businessId}/owned_product_catalogs", query: ["fields", "limit"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Plaid ───────────────────────────────────────────────────
  plaid: {
    name: "Plaid",
    type: "finance",
    description: "Financial data — bank accounts, transactions, identity, auth via Plaid API",
    baseUrl: "https://production.plaid.com",
    authType: "api_key",
    credentialKeys: ["clientId", "secret"],
    capabilities: [
      { name: "manage_links", actions: ["create", "exchange"], description: "Create link tokens and exchange public tokens" },
      { name: "manage_accounts", actions: ["list", "get_balance"], description: "List accounts and get balances" },
      { name: "manage_transactions", actions: ["list", "sync"], description: "List and sync transactions" },
      { name: "manage_identity", actions: ["get"], description: "Retrieve identity information" },
      { name: "manage_auth", actions: ["get"], description: "Get account and routing numbers" },
    ],
    endpoints: {
      create_link_token:    { method: "POST", path: "/link/token/create", body: { client_id: "", secret: "", user: { client_user_id: "" }, client_name: "", products: [], country_codes: ["US"], language: "en" } },
      exchange_public_token:{ method: "POST", path: "/item/public_token/exchange", body: { client_id: "", secret: "", public_token: "" } },
      get_accounts:         { method: "POST", path: "/accounts/get", body: { client_id: "", secret: "", access_token: "" } },
      get_balance:          { method: "POST", path: "/accounts/balance/get", body: { client_id: "", secret: "", access_token: "" } },
      get_transactions:     { method: "POST", path: "/transactions/get", body: { client_id: "", secret: "", access_token: "", start_date: "", end_date: "" } },
      sync_transactions:    { method: "POST", path: "/transactions/sync", body: { client_id: "", secret: "", access_token: "" } },
      get_identity:         { method: "POST", path: "/identity/get", body: { client_id: "", secret: "", access_token: "" } },
      get_auth:             { method: "POST", path: "/auth/get", body: { client_id: "", secret: "", access_token: "" } },
      get_institutions:     { method: "POST", path: "/institutions/get", body: { client_id: "", secret: "", count: 10, offset: 0, country_codes: ["US"] } },
    },
    authHeader: (creds) => ({
      "Content-Type": "application/json",
    }),
  },

  // ── Square ──────────────────────────────────────────────────
  square: {
    name: "Square",
    type: "payments",
    description: "Payments, commerce, POS, invoices, subscriptions, loyalty, gift cards, bookings, team, locations — full Square ecosystem",
    baseUrl: "https://connect.squareup.com/v2",
    authType: "access_token",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_payments", actions: ["create", "list", "get", "refund", "complete"], description: "Process payments, refunds, and completions" },
      { name: "manage_customers", actions: ["create", "list", "get", "update", "delete", "search"], description: "Full customer directory management" },
      { name: "manage_orders", actions: ["create", "list", "get", "update", "pay"], description: "Create, manage, and pay orders" },
      { name: "manage_catalog", actions: ["create", "list", "search", "update", "delete"], description: "Product catalog lifecycle" },
      { name: "manage_inventory", actions: ["get", "adjust", "transfer"], description: "Inventory tracking and transfers" },
      { name: "manage_invoices", actions: ["create", "list", "get", "update", "publish", "cancel"], description: "Create and send invoices" },
      { name: "manage_subscriptions", actions: ["create", "list", "get", "update", "cancel"], description: "Recurring billing subscriptions" },
      { name: "manage_loyalty", actions: ["create_account", "list_accounts", "accumulate", "redeem"], description: "Loyalty program management" },
      { name: "manage_gift_cards", actions: ["create", "list", "get", "link", "unlink"], description: "Gift card operations" },
      { name: "manage_bookings", actions: ["create", "list", "get", "update", "cancel"], description: "Appointment scheduling" },
      { name: "manage_team", actions: ["create", "list", "get", "update"], description: "Team member management" },
      { name: "manage_locations", actions: ["list", "get", "create", "update"], description: "Multi-location management" },
    ],
    endpoints: {
      // Payments
      create_payment:       { method: "POST", path: "/payments", body: { source_id: "", idempotency_key: "", amount_money: { amount: 0, currency: "USD" } } },
      list_payments:        { method: "GET",  path: "/payments", query: ["begin_time", "end_time", "sort_order", "cursor", "limit"] },
      get_payment:          { method: "GET",  path: "/payments/{paymentId}" },
      complete_payment:     { method: "POST", path: "/payments/{paymentId}/complete" },
      create_refund:        { method: "POST", path: "/refunds", body: { idempotency_key: "", payment_id: "", amount_money: {} } },
      list_refunds:         { method: "GET",  path: "/refunds", query: ["begin_time", "end_time", "cursor", "limit"] },
      // Customers
      create_customer:      { method: "POST", path: "/customers", body: { given_name: "", family_name: "", email_address: "" } },
      list_customers:       { method: "GET",  path: "/customers", query: ["cursor", "limit", "sort_field", "sort_order"] },
      get_customer:         { method: "GET",  path: "/customers/{customerId}" },
      update_customer:      { method: "PUT",  path: "/customers/{customerId}", body: {} },
      delete_customer:      { method: "DELETE", path: "/customers/{customerId}" },
      search_customers:     { method: "POST", path: "/customers/search", body: { query: {} } },
      // Orders
      create_order:         { method: "POST", path: "/orders", body: { order: { location_id: "", line_items: [] }, idempotency_key: "" } },
      search_orders:        { method: "POST", path: "/orders/search", body: { location_ids: [], query: {} } },
      get_order:            { method: "GET",  path: "/orders/{orderId}" },
      update_order:         { method: "PUT",  path: "/orders/{orderId}", body: { order: {} } },
      pay_order:            { method: "POST", path: "/orders/{orderId}/pay", body: { idempotency_key: "" } },
      // Catalog
      create_catalog_object:{ method: "POST", path: "/catalog/object", body: { idempotency_key: "", object: {} } },
      list_catalog:         { method: "GET",  path: "/catalog/list", query: ["types", "cursor"] },
      search_catalog:       { method: "POST", path: "/catalog/search", body: { object_types: [], query: {} } },
      update_catalog_object:{ method: "POST", path: "/catalog/object", body: { idempotency_key: "", object: {} } },
      delete_catalog_object:{ method: "DELETE", path: "/catalog/object/{objectId}" },
      // Inventory
      get_inventory:        { method: "POST", path: "/inventory/counts/batch-retrieve", body: { catalog_object_ids: [] } },
      adjust_inventory:     { method: "POST", path: "/inventory/changes/batch-create", body: { idempotency_key: "", changes: [] } },
      transfer_inventory:   { method: "POST", path: "/inventory/transfers/batch-create", body: { idempotency_key: "", transfers: [] } },
      // Invoices
      create_invoice:       { method: "POST", path: "/invoices", body: { invoice: {}, idempotency_key: "" } },
      list_invoices:        { method: "GET",  path: "/invoices", query: ["location_id", "cursor", "limit"] },
      get_invoice:          { method: "GET",  path: "/invoices/{invoiceId}" },
      update_invoice:       { method: "PUT",  path: "/invoices/{invoiceId}", body: { invoice: {} } },
      publish_invoice:      { method: "POST", path: "/invoices/{invoiceId}/publish", body: { version: 0, idempotency_key: "" } },
      cancel_invoice:       { method: "POST", path: "/invoices/{invoiceId}/cancel" },
      // Subscriptions
      create_subscription:  { method: "POST", path: "/subscriptions", body: { idempotency_key: "", location_id: "", plan_variation_id: "", customer_id: "" } },
      list_subscriptions:   { method: "POST", path: "/subscriptions/search", body: { query: {} } },
      get_subscription:     { method: "GET",  path: "/subscriptions/{subscriptionId}" },
      update_subscription:  { method: "PUT",  path: "/subscriptions/{subscriptionId}", body: {} },
      cancel_subscription:  { method: "POST", path: "/subscriptions/{subscriptionId}/cancel" },
      // Loyalty
      create_loyalty_account: { method: "POST", path: "/loyalty/accounts", body: { account: {}, idempotency_key: "" } },
      search_loyalty_accounts:{ method: "POST", path: "/loyalty/accounts/search", body: { query: {} } },
      accumulate_loyalty:     { method: "POST", path: "/loyalty/accounts/{accountId}/accumulate", body: { accumulate_points: {}, idempotency_key: "" } },
      redeem_loyalty:         { method: "POST", path: "/loyalty/rewards", body: { reward: {}, idempotency_key: "" } },
      // Gift Cards
      create_gift_card:     { method: "POST", path: "/gift-cards", body: { idempotency_key: "", location_id: "", type: "DIGITAL" } },
      list_gift_cards:      { method: "GET",  path: "/gift-cards", query: ["type", "state", "cursor", "limit"] },
      get_gift_card:        { method: "GET",  path: "/gift-cards/{giftCardId}" },
      link_gift_card:       { method: "POST", path: "/gift-cards/{giftCardId}/link-customer", body: { customer_id: "" } },
      // Bookings
      create_booking:       { method: "POST", path: "/bookings", body: { booking: {}, idempotency_key: "" } },
      list_bookings:        { method: "GET",  path: "/bookings", query: ["limit", "cursor", "team_member_id", "location_id", "start_at_min", "start_at_max"] },
      get_booking:          { method: "GET",  path: "/bookings/{bookingId}" },
      update_booking:       { method: "PUT",  path: "/bookings/{bookingId}", body: { booking: {} } },
      cancel_booking:       { method: "POST", path: "/bookings/{bookingId}/cancel" },
      // Team
      create_team_member:   { method: "POST", path: "/team-members", body: { idempotency_key: "", team_member: {} } },
      search_team_members:  { method: "POST", path: "/team-members/search", body: { query: {} } },
      get_team_member:      { method: "GET",  path: "/team-members/{teamMemberId}" },
      update_team_member:   { method: "PUT",  path: "/team-members/{teamMemberId}", body: { team_member: {} } },
      // Locations
      list_locations:       { method: "GET",  path: "/locations" },
      get_location:         { method: "GET",  path: "/locations/{locationId}" },
      create_location:      { method: "POST", path: "/locations", body: { location: {} } },
      update_location:      { method: "PUT",  path: "/locations/{locationId}", body: { location: {} } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
      "Square-Version": "2024-01-18",
    }),
  },

  // ── WooCommerce ──────────────────────────────────────────────
  woocommerce: {
    name: "WooCommerce",
    type: "ecommerce",
    description: "WordPress e-commerce — products, orders, customers, coupons, categories, reports, shipping, taxes, refunds",
    baseUrl: "https://{siteUrl}/wp-json/wc/v3",
    authType: "basic",
    credentialKeys: ["siteUrl", "consumerKey", "consumerSecret"],
    capabilities: [
      { name: "manage_products", actions: ["create", "list", "get", "update", "delete"], description: "Full product lifecycle management" },
      { name: "manage_orders", actions: ["create", "list", "get", "update", "delete"], description: "Order processing and fulfillment" },
      { name: "manage_customers", actions: ["create", "list", "get", "update", "delete"], description: "Customer directory" },
      { name: "manage_coupons", actions: ["create", "list", "get", "update", "delete"], description: "Discount coupon management" },
      { name: "manage_categories", actions: ["create", "list", "get", "update", "delete"], description: "Product categories" },
      { name: "manage_shipping", actions: ["list_zones", "list_methods"], description: "Shipping configuration" },
      { name: "manage_reports", actions: ["sales", "top_sellers", "coupons"], description: "Sales and performance reports" },
      { name: "manage_refunds", actions: ["create", "list"], description: "Order refunds" },
    ],
    endpoints: {
      // Products
      create_product:       { method: "POST", path: "/products", body: { name: "", type: "simple", regular_price: "" } },
      list_products:        { method: "GET",  path: "/products", query: ["per_page", "page", "search", "status", "category", "sku", "orderby", "order"] },
      get_product:          { method: "GET",  path: "/products/{productId}" },
      update_product:       { method: "PUT",  path: "/products/{productId}", body: {} },
      delete_product:       { method: "DELETE", path: "/products/{productId}", query: ["force"] },
      // Product Variations
      list_variations:      { method: "GET",  path: "/products/{productId}/variations" },
      create_variation:     { method: "POST", path: "/products/{productId}/variations", body: { regular_price: "" } },
      update_variation:     { method: "PUT",  path: "/products/{productId}/variations/{variationId}", body: {} },
      // Product Categories
      create_category:      { method: "POST", path: "/products/categories", body: { name: "" } },
      list_categories:      { method: "GET",  path: "/products/categories", query: ["per_page", "page", "search"] },
      get_category:         { method: "GET",  path: "/products/categories/{categoryId}" },
      update_category:      { method: "PUT",  path: "/products/categories/{categoryId}", body: {} },
      delete_category:      { method: "DELETE", path: "/products/categories/{categoryId}" },
      // Orders
      create_order:         { method: "POST", path: "/orders", body: { payment_method: "", billing: {}, line_items: [] } },
      list_orders:          { method: "GET",  path: "/orders", query: ["per_page", "page", "status", "customer", "after", "before", "orderby", "order"] },
      get_order:            { method: "GET",  path: "/orders/{orderId}" },
      update_order:         { method: "PUT",  path: "/orders/{orderId}", body: {} },
      delete_order:         { method: "DELETE", path: "/orders/{orderId}" },
      // Order Notes
      create_order_note:    { method: "POST", path: "/orders/{orderId}/notes", body: { note: "" } },
      list_order_notes:     { method: "GET",  path: "/orders/{orderId}/notes" },
      // Refunds
      create_refund:        { method: "POST", path: "/orders/{orderId}/refunds", body: { amount: "", reason: "" } },
      list_refunds:         { method: "GET",  path: "/orders/{orderId}/refunds" },
      // Customers
      create_customer:      { method: "POST", path: "/customers", body: { email: "", first_name: "", last_name: "" } },
      list_customers:       { method: "GET",  path: "/customers", query: ["per_page", "page", "search", "role", "orderby", "order"] },
      get_customer:         { method: "GET",  path: "/customers/{customerId}" },
      update_customer:      { method: "PUT",  path: "/customers/{customerId}", body: {} },
      delete_customer:      { method: "DELETE", path: "/customers/{customerId}" },
      // Coupons
      create_coupon:        { method: "POST", path: "/coupons", body: { code: "", discount_type: "percent", amount: "" } },
      list_coupons:         { method: "GET",  path: "/coupons", query: ["per_page", "page", "search"] },
      get_coupon:           { method: "GET",  path: "/coupons/{couponId}" },
      update_coupon:        { method: "PUT",  path: "/coupons/{couponId}", body: {} },
      delete_coupon:        { method: "DELETE", path: "/coupons/{couponId}" },
      // Shipping
      list_shipping_zones:  { method: "GET",  path: "/shipping/zones" },
      list_shipping_methods:{ method: "GET",  path: "/shipping/zones/{zoneId}/methods" },
      // Reports
      sales_report:         { method: "GET",  path: "/reports/sales", query: ["period", "date_min", "date_max"] },
      top_sellers_report:   { method: "GET",  path: "/reports/top_sellers", query: ["period"] },
      coupons_report:       { method: "GET",  path: "/reports/coupons/totals" },
      // Taxes
      list_tax_classes:     { method: "GET",  path: "/taxes/classes" },
      list_tax_rates:       { method: "GET",  path: "/taxes" },
      // Settings
      list_settings:        { method: "GET",  path: "/settings" },
      get_setting_group:    { method: "GET",  path: "/settings/{group}" },
    },
    authHeader: (creds) => ({
      "Authorization": `Basic ${Buffer.from(`${creds.consumerKey}:${creds.consumerSecret}`).toString('base64')}`,
      "Content-Type": "application/json",
    }),
  },

  // ── TikTok Ads ──────────────────────────────────────────────
  tiktok_ads: {
    name: "TikTok Ads",
    type: "advertising",
    description: "TikTok advertising — campaigns, ad groups, ads, reports, audiences",
    baseUrl: "https://business-api.tiktok.com/open_api/v1.3",
    authType: "access_token",
    credentialKeys: ["accessToken", "advertiserId"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage ad campaigns" },
      { name: "manage_ad_groups", actions: ["create", "list", "update"], description: "Manage ad groups and targeting" },
      { name: "manage_ads", actions: ["create", "list", "update"], description: "Manage ad creatives" },
      { name: "manage_reports", actions: ["get"], description: "Pull performance reports" },
      { name: "manage_audiences", actions: ["create", "list"], description: "Create and manage custom audiences" },
    ],
    endpoints: {
      create_campaign:         { method: "POST", path: "/campaign/create/", body: { advertiser_id: "", campaign_name: "", objective_type: "", budget_mode: "" } },
      list_campaigns:          { method: "GET",  path: "/campaign/get/", query: ["advertiser_id", "page", "page_size"] },
      update_campaign_status:  { method: "POST", path: "/campaign/update/status/", body: { advertiser_id: "", campaign_ids: [], opt_status: "" } },
      create_adgroup:          { method: "POST", path: "/adgroup/create/", body: { advertiser_id: "", campaign_id: "", adgroup_name: "", placement_type: "" } },
      list_adgroups:           { method: "GET",  path: "/adgroup/get/", query: ["advertiser_id", "page", "page_size"] },
      update_adgroup:          { method: "POST", path: "/adgroup/update/", body: { advertiser_id: "", adgroup_id: "" } },
      create_ad:               { method: "POST", path: "/ad/create/", body: { advertiser_id: "", adgroup_id: "", creatives: [] } },
      list_ads:                { method: "GET",  path: "/ad/get/", query: ["advertiser_id", "page", "page_size"] },
      update_ad:               { method: "POST", path: "/ad/update/", body: { advertiser_id: "", ad_ids: [] } },
      get_report:              { method: "POST", path: "/report/integrated/get/", body: { advertiser_id: "", report_type: "", dimensions: [], metrics: [], data_level: "" } },
      create_audience:         { method: "POST", path: "/dmp/custom_audience/create/", body: { advertiser_id: "", custom_audience_name: "" } },
      list_audiences:          { method: "GET",  path: "/dmp/custom_audience/list/", query: ["advertiser_id", "page", "page_size"] },
    },
    authHeader: (creds) => ({
      "Access-Token": creds.accessToken,
      "Content-Type": "application/json",
    }),
  },

  // ── X Ads ───────────────────────────────────────────────────
  x_ads: {
    name: "X Ads",
    type: "advertising",
    description: "X (Twitter) advertising — campaigns, line items, promoted tweets, reports, audiences",
    baseUrl: "https://ads-api.x.com/12",
    authType: "oauth",
    credentialKeys: ["access_token", "accountId"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage ad campaigns" },
      { name: "manage_line_items", actions: ["create", "list", "get"], description: "Manage line items and targeting" },
      { name: "manage_promoted_tweets", actions: ["create", "list"], description: "Manage promoted tweets" },
      { name: "manage_reports", actions: ["get"], description: "Pull campaign analytics" },
      { name: "manage_audiences", actions: ["create", "list"], description: "Manage tailored audiences" },
    ],
    endpoints: {
      list_campaigns:        { method: "GET",  path: "/accounts/{accountId}/campaigns", query: ["count", "cursor", "sort_by"] },
      create_campaign:       { method: "POST", path: "/accounts/{accountId}/campaigns", body: { name: "", funding_instrument_id: "", daily_budget_amount_local_micro: 0, status: "PAUSED" } },
      get_campaign:          { method: "GET",  path: "/accounts/{accountId}/campaigns/{campaignId}" },
      update_campaign:       { method: "PUT",  path: "/accounts/{accountId}/campaigns/{campaignId}", body: {} },
      list_line_items:       { method: "GET",  path: "/accounts/{accountId}/line_items", query: ["campaign_ids", "count", "cursor"] },
      create_line_item:      { method: "POST", path: "/accounts/{accountId}/line_items", body: { campaign_id: "", objective: "", placements: [], bid_amount_local_micro: 0 } },
      list_promoted_tweets:  { method: "GET",  path: "/accounts/{accountId}/promoted_tweets", query: ["line_item_ids", "count"] },
      create_promoted_tweet: { method: "POST", path: "/accounts/{accountId}/promoted_tweets", body: { line_item_id: "", tweet_ids: [] } },
      get_stats:             { method: "GET",  path: "/stats/accounts/{accountId}", query: ["entity", "entity_ids", "start_time", "end_time", "granularity", "metric_groups"] },
      create_audience:       { method: "POST", path: "/accounts/{accountId}/tailored_audiences", body: { name: "", list_type: "" } },
      list_audiences:        { method: "GET",  path: "/accounts/{accountId}/tailored_audiences", query: ["count", "cursor"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── LinkedIn Ads ────────────────────────────────────────────
  linkedin_ads: {
    name: "LinkedIn Ads",
    type: "advertising",
    description: "Professional advertising — campaigns, campaign groups, creatives, reports, audiences",
    baseUrl: "https://api.linkedin.com/rest",
    authType: "oauth",
    credentialKeys: ["access_token", "adAccountId"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage ad campaigns" },
      { name: "manage_campaign_groups", actions: ["create", "list"], description: "Manage campaign groups" },
      { name: "manage_creatives", actions: ["create", "list"], description: "Manage ad creatives" },
      { name: "manage_reports", actions: ["get"], description: "Pull campaign analytics" },
      { name: "manage_audiences", actions: ["create", "list"], description: "Manage matched audiences" },
    ],
    endpoints: {
      list_campaigns:        { method: "GET",  path: "/adCampaigns", query: ["q", "search", "count", "start"] },
      create_campaign:       { method: "POST", path: "/adCampaigns", body: { account: "", name: "", type: "SPONSORED_UPDATES", status: "PAUSED" } },
      get_campaign:          { method: "GET",  path: "/adCampaigns/{campaignId}" },
      update_campaign:       { method: "POST", path: "/adCampaigns/{campaignId}", body: {} },
      list_campaign_groups:  { method: "GET",  path: "/adCampaignGroups", query: ["q", "search", "count"] },
      create_campaign_group: { method: "POST", path: "/adCampaignGroups", body: { account: "", name: "", status: "ACTIVE" } },
      list_creatives:        { method: "GET",  path: "/adCreatives", query: ["q", "search", "campaigns", "count"] },
      create_creative:       { method: "POST", path: "/adCreatives", body: { campaign: "", reference: "" } },
      get_analytics:         { method: "GET",  path: "/adAnalytics", query: ["q", "dateRange", "campaigns", "pivot", "timeGranularity", "fields"] },
      create_audience:       { method: "POST", path: "/dmpSegments", body: { name: "", account: "", type: "" } },
      list_audiences:        { method: "GET",  path: "/dmpSegments", query: ["q", "account", "count"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
      "LinkedIn-Version": "202402",
      "X-Restli-Protocol-Version": "2.0.0",
    }),
  },

  // ── Instagram Ads ───────────────────────────────────────────
  instagram_ads: {
    name: "Instagram Ads",
    type: "advertising",
    description: "Instagram advertising — campaigns, ad sets, ads, insights via Facebook Marketing API",
    baseUrl: "https://graph.facebook.com/v19.0",
    authType: "access_token",
    credentialKeys: ["accessToken", "adAccountId"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list"], description: "Manage Instagram ad campaigns" },
      { name: "manage_adsets", actions: ["create", "list"], description: "Manage ad sets with Instagram placement" },
      { name: "manage_ads", actions: ["create", "list"], description: "Manage Instagram ad creatives" },
      { name: "manage_insights", actions: ["get"], description: "View Instagram ad performance" },
    ],
    endpoints: {
      create_campaign:      { method: "POST", path: "/act_{adAccountId}/campaigns", body: { name: "", objective: "", status: "PAUSED", special_ad_categories: [] } },
      list_campaigns:       { method: "GET",  path: "/act_{adAccountId}/campaigns", query: ["fields", "limit", "effective_status"] },
      create_adset:         { method: "POST", path: "/act_{adAccountId}/adsets", body: { name: "", campaign_id: "", daily_budget: 0, targeting: { publisher_platforms: ["instagram"] }, status: "PAUSED" } },
      list_adsets:          { method: "GET",  path: "/act_{adAccountId}/adsets", query: ["fields", "limit"] },
      create_ad:            { method: "POST", path: "/act_{adAccountId}/ads", body: { name: "", adset_id: "", creative: {}, status: "PAUSED" } },
      list_ads:             { method: "GET",  path: "/act_{adAccountId}/ads", query: ["fields", "limit"] },
      get_insights:         { method: "GET",  path: "/act_{adAccountId}/insights", query: ["fields", "date_preset", "level", "filtering"] },
      get_ad_previews:      { method: "GET",  path: "/{adId}/previews", query: ["ad_format"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Smartlead ───────────────────────────────────────────────
  smartlead: {
    name: "Smartlead",
    type: "marketing",
    description: "Cold email outreach — campaigns, leads, sequences, email accounts",
    baseUrl: "https://server.smartlead.ai/api/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_campaigns", actions: ["create", "list", "get", "update"], description: "Manage outreach campaigns" },
      { name: "manage_leads", actions: ["add", "list", "get"], description: "Add and manage leads" },
      { name: "manage_sequences", actions: ["create", "list"], description: "Create email sequences" },
      { name: "manage_email_accounts", actions: ["list", "add"], description: "Manage sending email accounts" },
    ],
    endpoints: {
      create_campaign:      { method: "POST", path: "/campaigns/create", query: ["api_key"], body: { name: "" } },
      list_campaigns:       { method: "GET",  path: "/campaigns", query: ["api_key"] },
      get_campaign:         { method: "GET",  path: "/campaigns/{campaignId}", query: ["api_key"] },
      update_campaign:      { method: "POST", path: "/campaigns/{campaignId}/settings", query: ["api_key"], body: {} },
      add_leads:            { method: "POST", path: "/campaigns/{campaignId}/leads", query: ["api_key"], body: { lead_list: [] } },
      list_leads:           { method: "GET",  path: "/campaigns/{campaignId}/leads", query: ["api_key", "offset", "limit"] },
      get_lead:             { method: "GET",  path: "/leads/{leadId}", query: ["api_key"] },
      add_email_account:    { method: "POST", path: "/email-accounts/save", query: ["api_key"], body: { from_name: "", from_email: "", smtp_host: "", smtp_port: 587 } },
      list_email_accounts:  { method: "GET",  path: "/email-accounts", query: ["api_key"] },
      get_campaign_stats:   { method: "GET",  path: "/campaigns/{campaignId}/analytics", query: ["api_key"] },
      create_sequence:      { method: "POST", path: "/campaigns/{campaignId}/sequences", query: ["api_key"], body: { sequences: [] } },
      list_sequences:       { method: "GET",  path: "/campaigns/{campaignId}/sequences", query: ["api_key"] },
    },
    authHeader: (creds) => ({
      "Content-Type": "application/json",
    }),
  },

  // ── Zapier ──────────────────────────────────────────────────
  zapier: {
    name: "Zapier",
    type: "automation",
    description: "Workflow automation — zaps, actions (limited API, most interaction via webhooks)",
    baseUrl: "https://api.zapier.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_zaps", actions: ["list", "get", "enable", "disable"], description: "View and toggle zaps" },
      { name: "manage_actions", actions: ["list"], description: "List available actions" },
    ],
    endpoints: {
      list_zaps:            { method: "GET",  path: "/zaps" },
      get_zap:              { method: "GET",  path: "/zaps/{zapId}" },
      enable_zap:           { method: "PUT",  path: "/zaps/{zapId}", body: { is_enabled: true } },
      disable_zap:          { method: "PUT",  path: "/zaps/{zapId}", body: { is_enabled: false } },
      list_actions:         { method: "GET",  path: "/actions" },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── MuleSoft ────────────────────────────────────────────────
  mulesoft: {
    name: "MuleSoft",
    type: "integration",
    description: "Integration platform — APIs, applications, environments via Anypoint Platform",
    baseUrl: "https://anypoint.mulesoft.com",
    authType: "token",
    credentialKeys: ["token"],
    capabilities: [
      { name: "manage_apis", actions: ["list", "get"], description: "View API definitions and specifications" },
      { name: "manage_applications", actions: ["list", "get", "deploy"], description: "Deploy and manage applications" },
      { name: "manage_environments", actions: ["list"], description: "List deployment environments" },
    ],
    endpoints: {
      list_organizations:   { method: "GET",  path: "/accounts/api/me" },
      list_environments:    { method: "GET",  path: "/accounts/api/organizations/{orgId}/environments" },
      list_apis:            { method: "GET",  path: "/apimanager/api/v1/organizations/{orgId}/environments/{envId}/apis", query: ["limit", "offset"] },
      get_api:              { method: "GET",  path: "/apimanager/api/v1/organizations/{orgId}/environments/{envId}/apis/{apiId}" },
      list_applications:    { method: "GET",  path: "/amc/application-manager/api/v2/organizations/{orgId}/environments/{envId}/deployments" },
      get_application:      { method: "GET",  path: "/amc/application-manager/api/v2/organizations/{orgId}/environments/{envId}/deployments/{deploymentId}" },
      deploy_application:   { method: "POST", path: "/amc/application-manager/api/v2/organizations/{orgId}/environments/{envId}/deployments", body: { name: "", target: {} } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Microsoft Azure ─────────────────────────────────────────
  azure: {
    name: "Microsoft Azure",
    type: "cloud",
    description: "Cloud infrastructure — resources, resource groups, storage, VMs via Azure Resource Manager",
    baseUrl: "https://management.azure.com",
    authType: "oauth",
    credentialKeys: ["access_token", "subscriptionId"],
    capabilities: [
      { name: "manage_resources", actions: ["list", "get", "create", "delete"], description: "Manage Azure resources" },
      { name: "manage_resource_groups", actions: ["list", "create"], description: "Manage resource groups" },
      { name: "manage_storage", actions: ["list_accounts", "list_containers"], description: "Manage storage accounts" },
      { name: "manage_vms", actions: ["list", "get", "start", "stop"], description: "Manage virtual machines" },
    ],
    endpoints: {
      list_subscriptions:    { method: "GET",  path: "/subscriptions", query: ["api-version=2022-12-01"] },
      list_resource_groups:  { method: "GET",  path: "/subscriptions/{subscriptionId}/resourcegroups", query: ["api-version=2023-07-01"] },
      create_resource_group: { method: "PUT",  path: "/subscriptions/{subscriptionId}/resourcegroups/{resourceGroupName}", query: ["api-version=2023-07-01"], body: { location: "" } },
      list_resources:        { method: "GET",  path: "/subscriptions/{subscriptionId}/resources", query: ["api-version=2023-07-01"] },
      get_resource:          { method: "GET",  path: "/{resourceId}", query: ["api-version=2023-07-01"] },
      delete_resource:       { method: "DELETE", path: "/{resourceId}", query: ["api-version=2023-07-01"] },
      list_storage_accounts: { method: "GET",  path: "/subscriptions/{subscriptionId}/providers/Microsoft.Storage/storageAccounts", query: ["api-version=2023-01-01"] },
      list_vms:              { method: "GET",  path: "/subscriptions/{subscriptionId}/providers/Microsoft.Compute/virtualMachines", query: ["api-version=2023-09-01"] },
      get_vm:                { method: "GET",  path: "/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}", query: ["api-version=2023-09-01"] },
      start_vm:              { method: "POST", path: "/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}/start", query: ["api-version=2023-09-01"] },
      stop_vm:               { method: "POST", path: "/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{vmName}/deallocate", query: ["api-version=2023-09-01"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Pipedrive ───────────────────────────────────────────────
  pipedrive: {
    name: "Pipedrive",
    type: "crm",
    description: "Sales CRM — deals, persons, organizations, activities, pipelines, products, leads, goals, projects, files, mail, webhooks, subscriptions, notes, stages, users",
    baseUrl: "https://api.pipedrive.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_deals", actions: ["create", "list", "get", "update", "delete", "search", "merge", "duplicate"], description: "Full deal lifecycle with merge and duplicate" },
      { name: "manage_persons", actions: ["create", "list", "get", "update", "delete", "search", "merge"], description: "Contact persons with merge" },
      { name: "manage_organizations", actions: ["create", "list", "get", "update", "delete", "search", "merge"], description: "Organizations with merge" },
      { name: "manage_activities", actions: ["create", "list", "get", "update", "delete"], description: "Schedule, track, and manage activities" },
      { name: "manage_pipelines", actions: ["list", "get", "create", "update", "delete"], description: "Pipeline CRUD + stage management" },
      { name: "manage_stages", actions: ["list", "get", "create", "update", "delete"], description: "Deal stages within pipelines" },
      { name: "manage_products", actions: ["create", "list", "get", "update", "delete", "search"], description: "Product catalog management" },
      { name: "manage_leads", actions: ["create", "list", "get", "update", "delete"], description: "Lead management before conversion to deals" },
      { name: "manage_notes", actions: ["create", "list", "get", "update", "delete"], description: "Notes on deals, persons, organizations" },
      { name: "manage_files", actions: ["list", "get", "create", "delete"], description: "File attachments" },
      { name: "manage_mail", actions: ["list_threads", "get_thread", "list_messages", "send"], description: "Email integration" },
      { name: "manage_goals", actions: ["create", "list", "get", "update", "delete"], description: "Sales goals and targets" },
      { name: "manage_projects", actions: ["create", "list", "get", "update"], description: "Project management" },
      { name: "manage_webhooks", actions: ["create", "list", "delete"], description: "Event webhooks" },
      { name: "manage_subscriptions", actions: ["create", "list", "get", "update", "cancel"], description: "Recurring revenue subscriptions" },
      { name: "manage_users", actions: ["list", "get", "update"], description: "Team user management" },
    ],
    endpoints: {
      // Deals
      create_deal:          { method: "POST", path: "/deals", query: ["api_token"], body: { title: "" } },
      list_deals:           { method: "GET",  path: "/deals", query: ["api_token", "start", "limit", "status", "sort", "filter_id"] },
      get_deal:             { method: "GET",  path: "/deals/{dealId}", query: ["api_token"] },
      update_deal:          { method: "PUT",  path: "/deals/{dealId}", query: ["api_token"], body: {} },
      delete_deal:          { method: "DELETE", path: "/deals/{dealId}", query: ["api_token"] },
      search_deals:         { method: "GET",  path: "/deals/search", query: ["api_token", "term", "fields", "exact_match", "start", "limit"] },
      merge_deals:          { method: "PUT",  path: "/deals/{dealId}/merge", query: ["api_token"], body: { merge_with_id: 0 } },
      duplicate_deal:       { method: "POST", path: "/deals/{dealId}/duplicate", query: ["api_token"] },
      list_deal_activities: { method: "GET",  path: "/deals/{dealId}/activities", query: ["api_token", "start", "limit"] },
      list_deal_files:      { method: "GET",  path: "/deals/{dealId}/files", query: ["api_token", "start", "limit"] },
      list_deal_products:   { method: "GET",  path: "/deals/{dealId}/products", query: ["api_token", "start", "limit"] },
      add_deal_product:     { method: "POST", path: "/deals/{dealId}/products", query: ["api_token"], body: { product_id: 0, item_price: 0, quantity: 1 } },
      list_deal_participants:{ method: "GET", path: "/deals/{dealId}/participants", query: ["api_token", "start", "limit"] },
      add_deal_participant: { method: "POST", path: "/deals/{dealId}/participants", query: ["api_token"], body: { person_id: 0 } },
      list_deal_followers:  { method: "GET",  path: "/deals/{dealId}/followers", query: ["api_token"] },
      // Persons
      create_person:        { method: "POST", path: "/persons", query: ["api_token"], body: { name: "" } },
      list_persons:         { method: "GET",  path: "/persons", query: ["api_token", "start", "limit", "sort", "filter_id"] },
      get_person:           { method: "GET",  path: "/persons/{personId}", query: ["api_token"] },
      update_person:        { method: "PUT",  path: "/persons/{personId}", query: ["api_token"], body: {} },
      delete_person:        { method: "DELETE", path: "/persons/{personId}", query: ["api_token"] },
      search_persons:       { method: "GET",  path: "/persons/search", query: ["api_token", "term", "fields", "exact_match", "start", "limit"] },
      merge_persons:        { method: "PUT",  path: "/persons/{personId}/merge", query: ["api_token"], body: { merge_with_id: 0 } },
      list_person_deals:    { method: "GET",  path: "/persons/{personId}/deals", query: ["api_token", "start", "limit"] },
      list_person_activities:{ method: "GET", path: "/persons/{personId}/activities", query: ["api_token", "start", "limit"] },
      // Organizations
      create_organization:  { method: "POST", path: "/organizations", query: ["api_token"], body: { name: "" } },
      list_organizations:   { method: "GET",  path: "/organizations", query: ["api_token", "start", "limit", "sort", "filter_id"] },
      get_organization:     { method: "GET",  path: "/organizations/{orgId}", query: ["api_token"] },
      update_organization:  { method: "PUT",  path: "/organizations/{orgId}", query: ["api_token"], body: {} },
      delete_organization:  { method: "DELETE", path: "/organizations/{orgId}", query: ["api_token"] },
      search_organizations: { method: "GET",  path: "/organizations/search", query: ["api_token", "term", "fields", "exact_match"] },
      merge_organizations:  { method: "PUT",  path: "/organizations/{orgId}/merge", query: ["api_token"], body: { merge_with_id: 0 } },
      // Activities
      create_activity:      { method: "POST", path: "/activities", query: ["api_token"], body: { subject: "", type: "" } },
      list_activities:      { method: "GET",  path: "/activities", query: ["api_token", "start", "limit", "type", "user_id", "done"] },
      get_activity:         { method: "GET",  path: "/activities/{activityId}", query: ["api_token"] },
      update_activity:      { method: "PUT",  path: "/activities/{activityId}", query: ["api_token"], body: {} },
      delete_activity:      { method: "DELETE", path: "/activities/{activityId}", query: ["api_token"] },
      // Pipelines + Stages
      list_pipelines:       { method: "GET",  path: "/pipelines", query: ["api_token"] },
      get_pipeline:         { method: "GET",  path: "/pipelines/{pipelineId}", query: ["api_token"] },
      create_pipeline:      { method: "POST", path: "/pipelines", query: ["api_token"], body: { name: "" } },
      update_pipeline:      { method: "PUT",  path: "/pipelines/{pipelineId}", query: ["api_token"], body: {} },
      delete_pipeline:      { method: "DELETE", path: "/pipelines/{pipelineId}", query: ["api_token"] },
      list_stages:          { method: "GET",  path: "/stages", query: ["api_token", "pipeline_id"] },
      get_stage:            { method: "GET",  path: "/stages/{stageId}", query: ["api_token"] },
      create_stage:         { method: "POST", path: "/stages", query: ["api_token"], body: { name: "", pipeline_id: 0 } },
      update_stage:         { method: "PUT",  path: "/stages/{stageId}", query: ["api_token"], body: {} },
      delete_stage:         { method: "DELETE", path: "/stages/{stageId}", query: ["api_token"] },
      list_stage_deals:     { method: "GET",  path: "/stages/{stageId}/deals", query: ["api_token", "start", "limit"] },
      // Products
      create_product:       { method: "POST", path: "/products", query: ["api_token"], body: { name: "" } },
      list_products:        { method: "GET",  path: "/products", query: ["api_token", "start", "limit"] },
      get_product:          { method: "GET",  path: "/products/{productId}", query: ["api_token"] },
      update_product:       { method: "PUT",  path: "/products/{productId}", query: ["api_token"], body: {} },
      delete_product:       { method: "DELETE", path: "/products/{productId}", query: ["api_token"] },
      search_products:      { method: "GET",  path: "/products/search", query: ["api_token", "term", "fields"] },
      // Leads
      create_lead:          { method: "POST", path: "/leads", query: ["api_token"], body: { title: "" } },
      list_leads:           { method: "GET",  path: "/leads", query: ["api_token", "start", "limit", "sort", "filter_id"] },
      get_lead:             { method: "GET",  path: "/leads/{leadId}", query: ["api_token"] },
      update_lead:          { method: "PATCH", path: "/leads/{leadId}", query: ["api_token"], body: {} },
      delete_lead:          { method: "DELETE", path: "/leads/{leadId}", query: ["api_token"] },
      // Notes
      create_note:          { method: "POST", path: "/notes", query: ["api_token"], body: { content: "" } },
      list_notes:           { method: "GET",  path: "/notes", query: ["api_token", "start", "limit", "sort"] },
      get_note:             { method: "GET",  path: "/notes/{noteId}", query: ["api_token"] },
      update_note:          { method: "PUT",  path: "/notes/{noteId}", query: ["api_token"], body: {} },
      delete_note:          { method: "DELETE", path: "/notes/{noteId}", query: ["api_token"] },
      // Files
      list_files:           { method: "GET",  path: "/files", query: ["api_token", "start", "limit", "sort"] },
      get_file:             { method: "GET",  path: "/files/{fileId}", query: ["api_token"] },
      delete_file:          { method: "DELETE", path: "/files/{fileId}", query: ["api_token"] },
      // Mail
      list_mail_threads:    { method: "GET",  path: "/mailbox/mailThreads", query: ["api_token", "folder", "start", "limit"] },
      get_mail_thread:      { method: "GET",  path: "/mailbox/mailThreads/{threadId}", query: ["api_token"] },
      list_mail_messages:   { method: "GET",  path: "/mailbox/mailMessages", query: ["api_token", "start", "limit"] },
      // Goals
      create_goal:          { method: "POST", path: "/goals", query: ["api_token"], body: { title: "", assignee: {} } },
      list_goals:           { method: "GET",  path: "/goals", query: ["api_token"] },
      get_goal:             { method: "GET",  path: "/goals/{goalId}", query: ["api_token"] },
      update_goal:          { method: "PUT",  path: "/goals/{goalId}", query: ["api_token"], body: {} },
      delete_goal:          { method: "DELETE", path: "/goals/{goalId}", query: ["api_token"] },
      // Projects
      create_project:       { method: "POST", path: "/projects", query: ["api_token"], body: { title: "", board_id: 0 } },
      list_projects:        { method: "GET",  path: "/projects", query: ["api_token", "start", "limit", "status"] },
      get_project:          { method: "GET",  path: "/projects/{projectId}", query: ["api_token"] },
      update_project:       { method: "PUT",  path: "/projects/{projectId}", query: ["api_token"], body: {} },
      // Webhooks
      create_webhook:       { method: "POST", path: "/webhooks", query: ["api_token"], body: { subscription_url: "", event_action: "", event_object: "" } },
      list_webhooks:        { method: "GET",  path: "/webhooks", query: ["api_token"] },
      delete_webhook:       { method: "DELETE", path: "/webhooks/{webhookId}", query: ["api_token"] },
      // Subscriptions
      create_subscription:  { method: "POST", path: "/subscriptions/recurring", query: ["api_token"], body: { deal_id: 0, currency: "USD" } },
      list_subscriptions:   { method: "GET",  path: "/subscriptions/{dealId}", query: ["api_token"] },
      get_subscription:     { method: "GET",  path: "/subscriptions/{subscriptionId}", query: ["api_token"] },
      update_subscription:  { method: "PUT",  path: "/subscriptions/recurring/{subscriptionId}", query: ["api_token"], body: {} },
      cancel_subscription:  { method: "DELETE", path: "/subscriptions/recurring/{subscriptionId}", query: ["api_token"] },
      // Users
      list_users:           { method: "GET",  path: "/users", query: ["api_token"] },
      get_user:             { method: "GET",  path: "/users/{userId}", query: ["api_token"] },
      update_user:          { method: "PUT",  path: "/users/{userId}", query: ["api_token"], body: {} },
      // Search
      search_items:         { method: "GET",  path: "/itemSearch", query: ["api_token", "term", "item_types", "fields", "exact_match", "start", "limit"] },
      search_field:         { method: "GET",  path: "/itemSearch/field", query: ["api_token", "term", "field_type", "field_key", "exact_match"] },
      // Filters
      list_filters:         { method: "GET",  path: "/filters", query: ["api_token", "type"] },
      get_filter:           { method: "GET",  path: "/filters/{filterId}", query: ["api_token"] },
      create_filter:        { method: "POST", path: "/filters", query: ["api_token"], body: { name: "", type: "", conditions: {} } },
      // Recents
      list_recents:         { method: "GET",  path: "/recents", query: ["api_token", "since_timestamp", "items"] },
    },
    authHeader: (creds) => ({
      "Content-Type": "application/json",
    }),
  },

  // ── LinkedIn ────────────────────────────────────────────────
  linkedin: {
    name: "LinkedIn",
    type: "social",
    description: "Professional network — profile, posts, comments, likes, organizations, page analytics, events, advertising, ad reporting via LinkedIn API v2",
    baseUrl: "https://api.linkedin.com",
    authType: "oauth2",
    scopes: ["rw_organization_admin", "w_member_social", "r_profile_basicinfo", "rw_events", "r_ads", "r_basicprofile", "r_organization_admin", "email", "r_1st_connections_size", "openid", "profile", "r_ads_reporting", "r_organization_social", "r_verify", "w_organization_social", "rw_ads", "r_events"],
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "manage_profile", actions: ["get", "get_email", "get_connections", "get_verification", "get_photos"], description: "View profile, email, connections count, verification status, and photos" },
      { name: "manage_posts", actions: ["create", "get", "delete"], description: "Create, read, and delete posts for members or organizations" },
      { name: "manage_social_actions", actions: ["comment", "list_comments", "like", "unlike"], description: "Comment on and like/unlike posts" },
      { name: "manage_shares", actions: ["list"], description: "List shared content" },
      { name: "manage_media", actions: ["upload_image", "upload_video"], description: "Upload images and videos for posts" },
      { name: "manage_organizations", actions: ["get", "list_admin_orgs", "update", "get_brand_pages"], description: "View and manage organization pages" },
      { name: "manage_org_analytics", actions: ["page_stats", "follower_stats", "share_stats", "follower_count", "visitor_stats"], description: "Organization page analytics and statistics" },
      { name: "manage_ads", actions: ["list_accounts", "get_account", "create_campaign_group", "list_campaign_groups", "create_campaign", "list_campaigns", "update_campaign", "create_creative", "list_creatives", "update_creative"], description: "Manage ad accounts, campaigns, and creatives" },
      { name: "manage_ad_extras", actions: ["get_analytics", "get_budget_pricing", "create_sponsored_content", "get_targeting", "get_form_responses"], description: "Ad analytics, targeting, budget suggestions, and lead gen forms" },
      { name: "manage_ad_reporting", actions: ["get_performance", "get_statistics", "get_conversions", "get_budget_reports", "get_inmail_analytics"], description: "Campaign performance metrics, conversion tracking, and InMail analytics" },
      { name: "manage_events", actions: ["create", "get", "update", "delete", "list_attendees"], description: "Create, manage, and track events and attendees" },
    ],
    endpoints: {
      // ── Profile (5) ───────────────────────────────────────────
      get_profile:                { method: "GET",  path: "/v2/me", query: ["projection"] },
      get_email:                  { method: "GET",  path: "/v2/emailAddress", query: ["q=members", "projection=(elements*(handle~))"] },
      get_connections_size:       { method: "GET",  path: "/v2/connections", query: ["q=viewer", "start", "count"] },
      get_verification:           { method: "GET",  path: "/v2/profileVerification", query: ["q=member"] },
      get_profile_pictures:       { method: "GET",  path: "/v2/profilePictures", query: ["q=member", "projection"] },

      // ── Social / Posts (10) ───────────────────────────────────
      create_post:                { method: "POST", path: "/v2/posts", body: { author: "", commentary: "", visibility: "PUBLIC", distribution: { feedDistribution: "MAIN_FEED" }, lifecycleState: "PUBLISHED" } },
      get_post:                   { method: "GET",  path: "/v2/posts/{postId}" },
      delete_post:                { method: "DELETE", path: "/v2/posts/{postId}" },
      add_comment:                { method: "POST", path: "/v2/socialActions/{activityId}/comments", body: { actor: "", message: { text: "" } } },
      list_comments:              { method: "GET",  path: "/v2/socialActions/{activityId}/comments", query: ["start", "count"] },
      like_post:                  { method: "POST", path: "/v2/socialActions/{activityId}/likes", body: { actor: "" } },
      unlike_post:                { method: "DELETE", path: "/v2/socialActions/{activityId}/likes/{likeId}" },
      list_shares:                { method: "GET",  path: "/v2/shares", query: ["q", "owners", "count", "start"] },
      upload_image:               { method: "POST", path: "/v2/images", query: ["action=initializeUpload"], body: { initializeUploadRequest: { owner: "" } } },
      upload_video:               { method: "POST", path: "/v2/videos", query: ["action=initializeUpload"], body: { initializeUploadRequest: { owner: "", fileSizeBytes: 0 } } },

      // ── Organization Pages (10) ───────────────────────────────
      get_organization:           { method: "GET",  path: "/v2/organizations/{organizationId}", query: ["projection"] },
      list_admin_orgs:            { method: "GET",  path: "/v2/organizationalEntityAcls", query: ["q=roleAssignee", "role", "projection"] },
      create_org_post:            { method: "POST", path: "/v2/posts", body: { author: "urn:li:organization:{organizationId}", commentary: "", visibility: "PUBLIC", distribution: { feedDistribution: "MAIN_FEED" }, lifecycleState: "PUBLISHED" } },
      get_page_statistics:        { method: "GET",  path: "/v2/organizationPageStatistics", query: ["q=organization", "organization", "timeIntervals"] },
      get_follower_statistics:    { method: "GET",  path: "/v2/organizationalEntityFollowerStatistics", query: ["q=organizationalEntity", "organizationalEntity", "timeIntervals"] },
      get_share_statistics:       { method: "GET",  path: "/v2/organizationalEntityShareStatistics", query: ["q=organizationalEntity", "organizationalEntity", "shares"] },
      get_follower_count:         { method: "GET",  path: "/v2/networkSizes/{organizationUrn}", query: ["edgeType=CompanyFollowedByMember"] },
      update_organization:        { method: "PUT",  path: "/v2/organizations/{organizationId}", body: {} },
      get_brand_pages:            { method: "GET",  path: "/v2/organizationBrandPages", query: ["q=parentOrganization", "parentOrganization"] },
      get_visitor_statistics:     { method: "GET",  path: "/v2/organizationPageVisitorStatistics", query: ["q=organization", "organization", "timeIntervals"] },

      // ── Advertising (15) ──────────────────────────────────────
      list_ad_accounts:           { method: "GET",  path: "/v2/adAccountsV2", query: ["q=search", "search", "count", "start"] },
      get_ad_account:             { method: "GET",  path: "/v2/adAccountsV2/{adAccountId}" },
      create_campaign_group:      { method: "POST", path: "/v2/adCampaignGroupsV2", body: { account: "", name: "", status: "ACTIVE" } },
      list_campaign_groups:       { method: "GET",  path: "/v2/adCampaignGroupsV2", query: ["q=search", "search", "count", "start"] },
      create_campaign:            { method: "POST", path: "/v2/adCampaignsV2", body: { account: "", campaignGroup: "", name: "", type: "SPONSORED_UPDATES", costType: "CPM", status: "PAUSED" } },
      list_campaigns:             { method: "GET",  path: "/v2/adCampaignsV2", query: ["q=search", "search", "count", "start"] },
      update_campaign:            { method: "PATCH", path: "/v2/adCampaignsV2/{campaignId}", body: {} },
      create_creative:            { method: "POST", path: "/v2/adCreativesV2", body: { campaign: "", reference: "" } },
      list_creatives:             { method: "GET",  path: "/v2/adCreativesV2", query: ["q=search", "search", "campaigns", "count"] },
      update_creative:            { method: "PATCH", path: "/v2/adCreativesV2/{creativeId}", body: {} },
      get_ad_analytics:           { method: "GET",  path: "/v2/adAnalyticsV2", query: ["q=analytics", "dateRange", "campaigns", "pivot", "timeGranularity", "fields"] },
      get_budget_pricing:         { method: "GET",  path: "/v2/adBudgetPricingV2", query: ["account", "campaign", "bidType", "match"] },
      create_sponsored_content:   { method: "POST", path: "/v2/adDirectSponsoredContents", body: { account: "", owner: "", content: {} } },
      get_targeting_facets:       { method: "GET",  path: "/v2/adTargetingFacets", query: ["q=search", "search", "queryType"] },
      get_form_responses:         { method: "GET",  path: "/v2/adFormResponses", query: ["q=account", "account", "versionedLeadGenFormUrn", "count", "start"] },

      // ── Ad Reporting (5) ──────────────────────────────────────
      get_performance_metrics:    { method: "GET",  path: "/v2/adAnalyticsV2", query: ["q=analytics", "dateRange", "accounts", "campaigns", "creatives", "pivot", "timeGranularity", "fields"] },
      get_aggregate_statistics:   { method: "GET",  path: "/v2/adAnalyticsV2", query: ["q=statistics", "accounts", "dateRange", "fields"] },
      get_conversion_tracking:    { method: "GET",  path: "/v2/conversionTrackingV2", query: ["q=account", "account", "count", "start"] },
      get_budget_reports:         { method: "GET",  path: "/v2/adBudgetV2", query: ["q=account", "account", "count", "start"] },
      get_inmail_analytics:       { method: "GET",  path: "/v2/adInMailContentV2", query: ["q=account", "account", "campaign", "count", "start"] },

      // ── Events (5) ────────────────────────────────────────────
      create_event:               { method: "POST", path: "/v2/events", body: { organizer: "", name: { locale: { language: "en", country: "US" }, value: "" }, description: {}, startAt: "", endAt: "" } },
      get_event:                  { method: "GET",  path: "/v2/events/{eventId}" },
      update_event:               { method: "PUT",  path: "/v2/events/{eventId}", body: {} },
      delete_event:               { method: "DELETE", path: "/v2/events/{eventId}" },
      list_event_attendees:       { method: "GET",  path: "/v2/eventAttendees", query: ["q=event", "event", "count", "start"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.access_token}`,
      "Content-Type": "application/json",
      "LinkedIn-Version": "202402",
      "X-Restli-Protocol-Version": "2.0.0",
    }),
  },

  // ── Cloudflare ──────────────────────────────────────────────
  cloudflare: {
    name: "Cloudflare",
    type: "cloud",
    description: "Edge computing & CDN — Workers, KV, R2 storage, D1 database, DNS, WAF, DDoS protection, analytics",
    baseUrl: "https://api.cloudflare.com/client/v4",
    authType: "api_key",
    credentialKeys: ["apiToken", "accountId"],
    capabilities: [
      { name: "manage_workers", actions: ["list", "create", "update", "delete", "deploy"], description: "Deploy and manage Cloudflare Workers" },
      { name: "manage_kv", actions: ["list_namespaces", "read", "write", "delete"], description: "Key-Value storage for Workers" },
      { name: "manage_r2", actions: ["list_buckets", "create_bucket", "list_objects", "put_object", "get_object", "delete_object"], description: "S3-compatible object storage" },
      { name: "manage_d1", actions: ["list_databases", "create_database", "query"], description: "Serverless SQL database" },
      { name: "manage_dns", actions: ["list_zones", "list_records", "create_record", "update_record", "delete_record"], description: "DNS zone and record management" },
      { name: "manage_waf", actions: ["list_rules", "create_rule", "update_rule"], description: "Web Application Firewall rules" },
      { name: "manage_pages", actions: ["list_projects", "create_deployment"], description: "Cloudflare Pages static site deployments" },
      { name: "analytics", actions: ["get_zone_analytics", "get_worker_analytics"], description: "Traffic and performance analytics" },
    ],
    endpoints: {
      list_zones:            { method: "GET",  path: "/zones", query: ["name", "status", "page", "per_page"] },
      get_zone:              { method: "GET",  path: "/zones/{zoneId}" },
      list_dns_records:      { method: "GET",  path: "/zones/{zoneId}/dns_records", query: ["type", "name", "page", "per_page"] },
      create_dns_record:     { method: "POST", path: "/zones/{zoneId}/dns_records", body: { type: "", name: "", content: "", ttl: 1, proxied: true } },
      update_dns_record:     { method: "PUT",  path: "/zones/{zoneId}/dns_records/{recordId}", body: {} },
      delete_dns_record:     { method: "DELETE", path: "/zones/{zoneId}/dns_records/{recordId}" },
      list_workers:          { method: "GET",  path: "/accounts/{accountId}/workers/scripts" },
      get_worker:            { method: "GET",  path: "/accounts/{accountId}/workers/scripts/{scriptName}" },
      delete_worker:         { method: "DELETE", path: "/accounts/{accountId}/workers/scripts/{scriptName}" },
      list_kv_namespaces:    { method: "GET",  path: "/accounts/{accountId}/storage/kv/namespaces" },
      create_kv_namespace:   { method: "POST", path: "/accounts/{accountId}/storage/kv/namespaces", body: { title: "" } },
      read_kv_value:         { method: "GET",  path: "/accounts/{accountId}/storage/kv/namespaces/{namespaceId}/values/{keyName}" },
      write_kv_value:        { method: "PUT",  path: "/accounts/{accountId}/storage/kv/namespaces/{namespaceId}/values/{keyName}" },
      delete_kv_value:       { method: "DELETE", path: "/accounts/{accountId}/storage/kv/namespaces/{namespaceId}/values/{keyName}" },
      list_r2_buckets:       { method: "GET",  path: "/accounts/{accountId}/r2/buckets" },
      create_r2_bucket:      { method: "POST", path: "/accounts/{accountId}/r2/buckets", body: { name: "" } },
      list_d1_databases:     { method: "GET",  path: "/accounts/{accountId}/d1/database" },
      create_d1_database:    { method: "POST", path: "/accounts/{accountId}/d1/database", body: { name: "" } },
      query_d1:              { method: "POST", path: "/accounts/{accountId}/d1/database/{databaseId}/query", body: { sql: "" } },
      list_pages_projects:   { method: "GET",  path: "/accounts/{accountId}/pages/projects" },
      get_zone_analytics:    { method: "GET",  path: "/zones/{zoneId}/analytics/dashboard", query: ["since", "until"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── GoDaddy ───────────────────────────────────────────────────
  godaddy: {
    name: "GoDaddy",
    type: "domains",
    description: "Domain registrar — search, check availability, manage DNS records, domain registration and management",
    baseUrl: "https://api.godaddy.com/v1",
    authType: "api_key",
    credentialKeys: ["apiKey", "apiSecret"],
    capabilities: [
      { name: "search_domains", actions: ["suggest", "check_availability"], description: "Search and check domain name availability" },
      { name: "manage_domains", actions: ["list", "get", "purchase"], description: "List owned domains and purchase new ones" },
      { name: "manage_dns", actions: ["list_records", "add_record", "update_record", "delete_record"], description: "Manage DNS records for owned domains" },
    ],
    endpoints: {
      suggest_domains:       { method: "GET",  path: "/domains/suggest", query: ["query", "limit", "tlds"] },
      check_availability:    { method: "GET",  path: "/domains/available", query: ["domain"] },
      list_domains:          { method: "GET",  path: "/domains", query: ["limit", "marker", "status"] },
      get_domain:            { method: "GET",  path: "/domains/{domain}" },
      purchase_domain:       { method: "POST", path: "/domains/purchase", body: { domain: "", consent: {} } },
      list_dns_records:      { method: "GET",  path: "/domains/{domain}/records", query: ["type", "name"] },
      add_dns_records:       { method: "PATCH", path: "/domains/{domain}/records", body: [] },
      update_dns_record:     { method: "PUT",  path: "/domains/{domain}/records/{type}/{name}", body: [] },
      delete_dns_record:     { method: "DELETE", path: "/domains/{domain}/records/{type}/{name}" },
    },
    // Three shapes in the wild: the classic key + secret pair ("sso-key KEY:SECRET"), the same pair pasted as one
    // "KEY:SECRET" string, and GoDaddy's newer scoped keys (domains.domain:read, domains.dns:update…) — a single token
    // sent as a Bearer. A record holding only apiKey used to go out as "sso-key KEY:undefined" and 401 (2026-10-31).
    authHeader: (creds) => ({
      "Authorization": creds.apiSecret ? `sso-key ${creds.apiKey}:${creds.apiSecret}`
        : String(creds.apiKey || "").includes(":") ? `sso-key ${creds.apiKey}`
        : `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── n8n ─────────────────────────────────────────────────────
  n8n: {
    name: "n8n",
    type: "automation",
    description: "Open-source workflow automation — workflows, executions, credentials, triggers, webhooks (self-hosted or cloud)",
    baseUrl: "https://app.n8n.cloud/api/v1",
    authType: "api_key",
    credentialKeys: ["apiKey", "baseUrl"],
    capabilities: [
      { name: "manage_workflows", actions: ["list", "get", "create", "update", "delete", "activate", "deactivate"], description: "Create and manage automation workflows" },
      { name: "manage_executions", actions: ["list", "get", "delete"], description: "View and manage workflow execution history" },
      { name: "manage_credentials", actions: ["list", "create", "delete"], description: "Manage integration credentials" },
      { name: "trigger_workflow", actions: ["execute"], description: "Trigger a workflow via webhook or API" },
    ],
    endpoints: {
      list_workflows:        { method: "GET",  path: "/workflows", query: ["active", "limit", "cursor"] },
      get_workflow:           { method: "GET",  path: "/workflows/{workflowId}" },
      create_workflow:        { method: "POST", path: "/workflows", body: { name: "", nodes: [], connections: {} } },
      update_workflow:        { method: "PUT",  path: "/workflows/{workflowId}", body: {} },
      delete_workflow:        { method: "DELETE", path: "/workflows/{workflowId}" },
      activate_workflow:      { method: "PATCH", path: "/workflows/{workflowId}", body: { active: true } },
      deactivate_workflow:    { method: "PATCH", path: "/workflows/{workflowId}", body: { active: false } },
      list_executions:        { method: "GET",  path: "/executions", query: ["workflowId", "status", "limit", "cursor"] },
      get_execution:          { method: "GET",  path: "/executions/{executionId}" },
      delete_execution:       { method: "DELETE", path: "/executions/{executionId}" },
      list_credentials:       { method: "GET",  path: "/credentials", query: ["limit", "cursor"] },
      create_credential:      { method: "POST", path: "/credentials", body: { name: "", type: "", data: {} } },
      delete_credential:      { method: "DELETE", path: "/credentials/{credentialId}" },
      execute_workflow:        { method: "POST", path: "/workflows/{workflowId}/run", body: {} },
    },
    authHeader: (creds) => ({
      "X-N8N-API-KEY": creds.apiKey,
      "Content-Type": "application/json",
    }),
  },

  // ── Pabbly Connect ──────────────────────────────────────────
  pabbly: {
    name: "Pabbly Connect",
    type: "automation",
    description: "Workflow automation — connect apps, build automations, manage workflows with webhook triggers",
    baseUrl: "https://connect.pabbly.com/api",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_workflows", actions: ["list", "get", "create", "enable", "disable"], description: "Create and manage automation workflows" },
      { name: "manage_connections", actions: ["list"], description: "View connected app integrations" },
      { name: "manage_executions", actions: ["list", "get"], description: "View workflow execution history and logs" },
      { name: "trigger_workflow", actions: ["execute"], description: "Trigger a workflow via webhook" },
    ],
    endpoints: {
      list_workflows:        { method: "GET",  path: "/workflows", query: ["page", "limit"] },
      get_workflow:           { method: "GET",  path: "/workflows/{workflowId}" },
      create_workflow:        { method: "POST", path: "/workflows", body: { name: "", trigger: {} } },
      enable_workflow:        { method: "PUT",  path: "/workflows/{workflowId}/enable" },
      disable_workflow:       { method: "PUT",  path: "/workflows/{workflowId}/disable" },
      list_connections:       { method: "GET",  path: "/connections" },
      list_executions:        { method: "GET",  path: "/workflows/{workflowId}/executions", query: ["page", "limit"] },
      get_execution:          { method: "GET",  path: "/workflows/{workflowId}/executions/{executionId}" },
      trigger_webhook:        { method: "POST", path: "/webhooks/{webhookId}", body: {} },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.apiKey}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Make (Integromat) ─────────────────────────────────────
  make: {
    name: "Make",
    type: "automation",
    description: "Visual automation platform (formerly Integromat) — scenarios, organizations, connections, data stores",
    baseUrl: "https://us1.make.com/api/v2",
    authType: "api_key",
    credentialKeys: ["apiToken"],
    capabilities: [
      { name: "manage_scenarios", actions: ["list", "get", "create", "update", "start", "stop", "run"], description: "Create and manage automation scenarios" },
      { name: "manage_connections", actions: ["list", "get", "verify"], description: "Manage app connections" },
      { name: "manage_data_stores", actions: ["list", "get_records"], description: "Access internal data stores" },
      { name: "manage_organizations", actions: ["list", "get"], description: "View organizations and teams" },
      { name: "manage_executions", actions: ["list"], description: "View scenario execution history" },
    ],
    endpoints: {
      list_scenarios:        { method: "GET",  path: "/scenarios", query: ["teamId", "folderId", "pg[limit]", "pg[offset]"] },
      get_scenario:          { method: "GET",  path: "/scenarios/{scenarioId}" },
      create_scenario:       { method: "POST", path: "/scenarios", body: { teamId: 0, name: "", blueprint: {} } },
      update_scenario:       { method: "PATCH", path: "/scenarios/{scenarioId}", body: {} },
      start_scenario:        { method: "POST", path: "/scenarios/{scenarioId}/start" },
      stop_scenario:         { method: "POST", path: "/scenarios/{scenarioId}/stop" },
      run_scenario:          { method: "POST", path: "/scenarios/{scenarioId}/run", body: {} },
      list_connections:      { method: "GET",  path: "/connections", query: ["teamId", "pg[limit]"] },
      get_connection:        { method: "GET",  path: "/connections/{connectionId}" },
      verify_connection:     { method: "POST", path: "/connections/{connectionId}/test" },
      list_data_stores:      { method: "GET",  path: "/data-stores", query: ["teamId"] },
      get_data_store_records:{ method: "GET",  path: "/data-stores/{dataStoreId}/data", query: ["pg[limit]", "pg[offset]"] },
      list_organizations:    { method: "GET",  path: "/organizations" },
      get_organization:      { method: "GET",  path: "/organizations/{organizationId}" },
      list_executions:       { method: "GET",  path: "/scenarios/{scenarioId}/logs", query: ["pg[limit]", "pg[offset]"] },
    },
    authHeader: (creds) => ({
      "Authorization": `Token ${creds.apiToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Whimsical ──────────────────────────────────────────────
  whimsical: {
    name: "Whimsical",
    type: "design",
    description: "Visual collaboration — flowcharts, wireframes, mind maps, docs, sticky notes, and AI-powered diagramming",
    baseUrl: "https://api.whimsical.com",
    authType: "oauth",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_workspaces", actions: ["list", "get"], description: "List and view workspaces" },
      { name: "manage_boards", actions: ["list", "get", "create", "update", "delete"], description: "Create and manage whiteboards, flowcharts, wireframes" },
      { name: "manage_docs", actions: ["list", "get", "create", "update"], description: "Create and manage documents" },
      { name: "manage_mind_maps", actions: ["list", "get", "create"], description: "Create and manage mind maps" },
      { name: "generate_diagrams", actions: ["create_from_mermaid", "create_from_text"], description: "AI-powered diagram generation from text or Mermaid markup" },
      { name: "manage_users", actions: ["list", "create", "update", "deactivate"], description: "SCIM user provisioning and management" },
    ],
    endpoints: {
      list_workspaces:       { method: "GET",  path: "/workspaces" },
      get_workspace:         { method: "GET",  path: "/workspaces/{workspaceId}" },
      list_boards:           { method: "GET",  path: "/workspaces/{workspaceId}/boards", query: ["type", "limit", "cursor"] },
      get_board:             { method: "GET",  path: "/boards/{boardId}" },
      create_board:          { method: "POST", path: "/workspaces/{workspaceId}/boards", body: { name: "", type: "flowchart" } },
      update_board:          { method: "PATCH", path: "/boards/{boardId}", body: {} },
      delete_board:          { method: "DELETE", path: "/boards/{boardId}" },
      get_board_export:      { method: "GET",  path: "/boards/{boardId}/export", query: ["format"] },
      list_docs:             { method: "GET",  path: "/workspaces/{workspaceId}/docs", query: ["limit", "cursor"] },
      get_doc:               { method: "GET",  path: "/docs/{docId}" },
      create_doc:            { method: "POST", path: "/workspaces/{workspaceId}/docs", body: { title: "", content: "" } },
      update_doc:            { method: "PATCH", path: "/docs/{docId}", body: {} },
      create_from_mermaid:   { method: "POST", path: "/boards/from-mermaid", body: { workspaceId: "", mermaid: "", name: "" } },
      create_from_text:      { method: "POST", path: "/boards/from-text", body: { workspaceId: "", text: "", type: "flowchart" } },
      list_scim_users:       { method: "GET",  path: "/scim-v2/Users", query: ["filter", "count", "startIndex"] },
      create_scim_user:      { method: "POST", path: "/scim-v2/Users", body: { schemas: ["urn:ietf:params:scim:schemas:core:2.0:User"], userName: "", name: {} } },
      update_scim_user:      { method: "PUT",  path: "/scim-v2/Users/{userId}", body: {} },
      deactivate_scim_user:  { method: "PATCH", path: "/scim-v2/Users/{userId}", body: { Operations: [{ op: "replace", value: { active: false } }] } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "Content-Type": "application/json",
    }),
  },

  // ── Ollama (Local AI) ──────────────────────────────────────
  ollama: {
    name: "Ollama",
    type: "ai",
    description: "Local AI inference — chat completions, embeddings, model management. Free, private, no API costs.",
    baseUrl: "http://localhost:11434",
    authType: "none",
    credentialKeys: [],
    capabilities: [
      { name: "generate_text", actions: ["create"], description: "Generate text completions with local models (Llama, Mistral, etc.)" },
      { name: "chat_completion", actions: ["create"], description: "Multi-turn chat with local models" },
      { name: "create_embedding", actions: ["create"], description: "Create text embeddings locally" },
      { name: "manage_models", actions: ["list", "pull", "delete", "show"], description: "List, pull, inspect, and delete local models" },
    ],
    endpoints: {
      chat_completion:  { method: "POST", path: "/api/chat", body: { model: "llama3.1", messages: [], stream: false } },
      generate:         { method: "POST", path: "/api/generate", body: { model: "llama3.1", prompt: "", stream: false } },
      create_embedding: { method: "POST", path: "/api/embed", body: { model: "llama3.1", input: "" } },
      list_models:      { method: "GET",  path: "/api/tags" },
      show_model:       { method: "POST", path: "/api/show", body: { name: "" } },
      pull_model:       { method: "POST", path: "/api/pull", body: { name: "", stream: false } },
      delete_model:     { method: "DELETE", path: "/api/delete", body: { name: "" } },
      list_running:     { method: "GET",  path: "/api/ps" },
    },
    authHeader: () => ({
      "Content-Type": "application/json",
    }),
  },

  // ── Reddit ──────────────────────────────────────────────────
  reddit: {
    name: "Reddit",
    type: "social",
    description: "Social platform — posts, comments, subreddits, user profiles, search, monitoring via Reddit Data API. IMPORTANT: Reddit requires pre-approved OAuth apps as of Nov 2025. Auto-posting must comply with Reddit's Responsible Builder Policy. Default mode is MANUAL — auto mode requires double confirmation.",
    baseUrl: "https://oauth.reddit.com",
    authType: "oauth",
    credentialKeys: ["accessToken", "refreshToken", "clientId", "clientSecret", "username"],
    safetyConfig: {
      defaultMode: "manual",
      autoModeRequiresDoubleConfirmation: true,
      minPostDelayMs: 600000,
      minCommentDelayMs: 300000,
      maxPostsPerHour: 3,
      maxCommentsPerHour: 10,
      rateLimitPerMinute: 60,
      disclaimer: "Reddit aggressively bans automated promotional activity. Accounts suspected of bot behavior may be required to pass human verification (passkeys, biometrics, or government ID). All automated accounts must carry an [APP] label. Respect the 90/10 rule: 90% genuine value, 10% promotional. Each subreddit has its own rules — check before posting.",
    },
    capabilities: [
      { name: "manage_posts", actions: ["create", "list", "get", "delete"], description: "Submit text/link posts to subreddits and manage them" },
      { name: "manage_comments", actions: ["create", "list", "get", "delete"], description: "Post comments and replies on Reddit threads" },
      { name: "manage_subreddits", actions: ["get", "list", "search"], description: "Browse and search subreddit info, rules, and hot/new/top posts" },
      { name: "manage_profile", actions: ["get"], description: "View authenticated user profile, karma, and account age" },
      { name: "search_content", actions: ["search"], description: "Search Reddit posts, comments, and subreddits" },
      { name: "monitor_mentions", actions: ["search"], description: "Monitor keyword mentions across Reddit for brand/topic tracking" },
      { name: "manage_messages", actions: ["list", "send"], description: "Read and send private messages" },
    ],
    endpoints: {
      submit_post:          { method: "POST", path: "/api/submit", contentType: "application/x-www-form-urlencoded", body: { sr: "", kind: "self", title: "", text: "" } },
      submit_link:          { method: "POST", path: "/api/submit", contentType: "application/x-www-form-urlencoded", body: { sr: "", kind: "link", title: "", url: "" } },
      get_post:             { method: "GET",  path: "/r/{subreddit}/comments/{postId}" },
      delete_thing:         { method: "POST", path: "/api/del", contentType: "application/x-www-form-urlencoded", body: { id: "" } },
      get_user_posts:       { method: "GET",  path: "/user/{username}/submitted", query: ["sort", "t", "limit"] },
      post_comment:         { method: "POST", path: "/api/comment", contentType: "application/x-www-form-urlencoded", body: { thing_id: "", text: "" } },
      get_comments:         { method: "GET",  path: "/r/{subreddit}/comments/{postId}", query: ["sort", "limit", "depth"] },
      get_subreddit:        { method: "GET",  path: "/r/{subreddit}/about" },
      get_subreddit_rules:  { method: "GET",  path: "/r/{subreddit}/about/rules" },
      get_hot:              { method: "GET",  path: "/r/{subreddit}/hot", query: ["limit", "after"] },
      get_new:              { method: "GET",  path: "/r/{subreddit}/new", query: ["limit", "after"] },
      get_top:              { method: "GET",  path: "/r/{subreddit}/top", query: ["t", "limit", "after"] },
      search_subreddits:    { method: "GET",  path: "/subreddits/search", query: ["q", "limit", "sort"] },
      list_my_subreddits:   { method: "GET",  path: "/subreddits/mine/subscriber", query: ["limit", "after"] },
      search_posts:         { method: "GET",  path: "/search", query: ["q", "type", "sort", "t", "limit", "restrict_sr", "sr"] },
      get_me:               { method: "GET",  path: "/api/v1/me" },
      get_user:             { method: "GET",  path: "/user/{username}/about" },
      get_user_comments:    { method: "GET",  path: "/user/{username}/comments", query: ["sort", "t", "limit"] },
      get_inbox:            { method: "GET",  path: "/message/inbox", query: ["limit", "after"] },
      send_message:         { method: "POST", path: "/api/compose", contentType: "application/x-www-form-urlencoded", body: { to: "", subject: "", text: "" } },
      vote:                 { method: "POST", path: "/api/vote", contentType: "application/x-www-form-urlencoded", body: { id: "", dir: 1 } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.accessToken}`,
      "User-Agent": `0nMCP:RedditService:1.0.0 (by /u/${creds.username || "0nMCP"})`,
    }),
  },

  // ── Figma ─────────────────────────────────────────────────
  figma: {
    name: "Figma",
    type: "design",
    description: "Design platform — files, components, styles, variables, images, comments, webhooks, dev resources",
    baseUrl: "https://api.figma.com",
    authType: "api_key",
    credentialKeys: ["personalAccessToken"],
    capabilities: [
      { name: "manage_files", actions: ["get", "list"], description: "Read design files and nodes" },
      { name: "export_images", actions: ["export"], description: "Export frames as PNG/SVG/PDF" },
      { name: "manage_components", actions: ["list", "get"], description: "List and read components and styles" },
      { name: "manage_variables", actions: ["get", "update"], description: "Read and write design tokens/variables" },
      { name: "manage_comments", actions: ["list", "create", "delete"], description: "Manage file comments" },
      { name: "manage_webhooks", actions: ["create", "list", "delete"], description: "Subscribe to design events" },
      { name: "manage_dev_resources", actions: ["create", "list", "delete"], description: "Manage developer annotations" },
    ],
    endpoints: {
      get_file:              { method: "GET",  path: "/v1/files/{file_key}" },
      get_file_nodes:        { method: "GET",  path: "/v1/files/{file_key}/nodes", query: ["ids", "depth"] },
      get_file_meta:         { method: "GET",  path: "/v1/files/{file_key}/meta" },
      get_file_versions:     { method: "GET",  path: "/v1/files/{file_key}/versions" },
      export_images:         { method: "GET",  path: "/v1/images/{file_key}", query: ["ids", "scale", "format", "svg_outline_text"] },
      get_image_fills:       { method: "GET",  path: "/v1/files/{file_key}/images" },
      get_team_components:   { method: "GET",  path: "/v1/teams/{team_id}/components", query: ["page_size", "after"] },
      get_file_components:   { method: "GET",  path: "/v1/files/{file_key}/components" },
      get_component:         { method: "GET",  path: "/v1/components/{key}" },
      get_team_component_sets: { method: "GET", path: "/v1/teams/{team_id}/component_sets" },
      get_team_styles:       { method: "GET",  path: "/v1/teams/{team_id}/styles" },
      get_file_styles:       { method: "GET",  path: "/v1/files/{file_key}/styles" },
      get_style:             { method: "GET",  path: "/v1/styles/{key}" },
      get_local_variables:   { method: "GET",  path: "/v1/files/{file_key}/variables/local" },
      get_published_variables: { method: "GET", path: "/v1/files/{file_key}/variables/published" },
      update_variables:      { method: "POST", path: "/v1/files/{file_key}/variables", body: {} },
      get_comments:          { method: "GET",  path: "/v1/files/{file_key}/comments" },
      post_comment:          { method: "POST", path: "/v1/files/{file_key}/comments", body: { message: "" } },
      delete_comment:        { method: "DELETE", path: "/v1/files/{file_key}/comments/{comment_id}" },
      react_to_comment:      { method: "POST", path: "/v1/files/{file_key}/comments/{comment_id}/reactions", body: { emoji: "" } },
      create_webhook:        { method: "POST", path: "/v2/webhooks", body: { event_type: "", team_id: "", endpoint: "", passcode: "" } },
      list_webhooks:         { method: "GET",  path: "/v2/webhooks", query: ["team_id"] },
      get_webhook:           { method: "GET",  path: "/v2/webhooks/{webhook_id}" },
      update_webhook:        { method: "PUT",  path: "/v2/webhooks/{webhook_id}", body: {} },
      delete_webhook:        { method: "DELETE", path: "/v2/webhooks/{webhook_id}" },
      get_dev_resources:     { method: "GET",  path: "/v1/files/{file_key}/dev_resources", query: ["node_ids"] },
      create_dev_resources:  { method: "POST", path: "/v1/dev_resources", body: { dev_resources: [] } },
      update_dev_resources:  { method: "PUT",  path: "/v1/dev_resources", body: { dev_resources: [] } },
      delete_dev_resource:   { method: "DELETE", path: "/v1/files/{file_key}/dev_resources/{dev_resource_id}" },
      list_projects:         { method: "GET",  path: "/v1/teams/{team_id}/projects" },
      list_project_files:    { method: "GET",  path: "/v1/projects/{project_id}/files" },
      get_me:                { method: "GET",  path: "/v1/me" },
    },
    authHeader: (creds) => ({ "X-Figma-Token": creds.personalAccessToken }),
  },

  // ── ElevenLabs ──────────────────────────────────────────
  elevenlabs: {
    name: "ElevenLabs",
    type: "ai",
    description: "AI voice synthesis — text-to-speech, voice cloning, audio generation",
    baseUrl: "https://api.elevenlabs.io",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "text_to_speech", actions: ["generate"], description: "Convert text to natural speech" },
      { name: "manage_voices", actions: ["list", "get", "clone"], description: "List, get, and clone voices" },
      { name: "manage_audio", actions: ["get_history"], description: "View generation history" },
    ],
    endpoints: {
      text_to_speech:     { method: "POST", path: "/v1/text-to-speech/{voice_id}", body: { text: "", model_id: "eleven_monolingual_v1" } },
      text_to_speech_stream: { method: "POST", path: "/v1/text-to-speech/{voice_id}/stream", body: { text: "", model_id: "eleven_monolingual_v1" } },
      list_voices:        { method: "GET",  path: "/v1/voices" },
      get_voice:          { method: "GET",  path: "/v1/voices/{voice_id}" },
      delete_voice:       { method: "DELETE", path: "/v1/voices/{voice_id}" },
      get_models:         { method: "GET",  path: "/v1/models" },
      get_history:        { method: "GET",  path: "/v1/history", query: ["page_size", "start_after_history_item_id"] },
      get_user:           { method: "GET",  path: "/v1/user" },
    },
    authHeader: (creds) => ({ "xi-api-key": creds.apiKey, "Content-Type": "application/json" }),
  },

  // ── Deepgram ────────────────────────────────────────────
  deepgram: {
    name: "Deepgram",
    type: "ai",
    description: "Speech-to-text and audio intelligence — transcription, summarization, topic detection",
    baseUrl: "https://api.deepgram.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "transcribe", actions: ["transcribe_url", "transcribe_file"], description: "Convert speech to text" },
      { name: "manage_projects", actions: ["list", "get"], description: "Manage Deepgram projects" },
      { name: "manage_keys", actions: ["list", "create"], description: "Manage API keys" },
    ],
    endpoints: {
      transcribe_url:     { method: "POST", path: "/v1/listen", query: ["model", "language", "punctuate", "diarize", "summarize", "topics"], body: { url: "" } },
      list_projects:      { method: "GET",  path: "/v1/projects" },
      get_project:        { method: "GET",  path: "/v1/projects/{project_id}" },
      list_keys:          { method: "GET",  path: "/v1/projects/{project_id}/keys" },
      create_key:         { method: "POST", path: "/v1/projects/{project_id}/keys", body: { comment: "", scopes: [] } },
      get_usage:          { method: "GET",  path: "/v1/projects/{project_id}/usage", query: ["start", "end"] },
      list_balances:      { method: "GET",  path: "/v1/projects/{project_id}/balances" },
    },
    authHeader: (creds) => ({ "Authorization": `Token ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Groq ────────────────────────────────────────────────
  groq: {
    name: "Groq",
    type: "ai",
    description: "Ultra-fast AI inference — chat completions, embeddings, audio transcription",
    baseUrl: "https://api.groq.com/openai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "chat", actions: ["complete"], description: "Chat completions with Llama, Mixtral, Gemma" },
      { name: "audio", actions: ["transcribe"], description: "Audio transcription via Whisper" },
      { name: "models", actions: ["list"], description: "List available models" },
    ],
    endpoints: {
      chat_completion:    { method: "POST", path: "/v1/chat/completions", body: { model: "openai/gpt-oss-120b", messages: [] } },
      create_transcription: { method: "POST", path: "/v1/audio/transcriptions", contentType: "multipart/form-data" },
      list_models:        { method: "GET",  path: "/v1/models" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Cohere ──────────────────────────────────────────────
  cohere: {
    name: "Cohere",
    type: "ai",
    description: "Enterprise AI — text generation, embeddings, reranking, classification",
    baseUrl: "https://api.cohere.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "generate", actions: ["chat", "generate"], description: "Text generation and chat" },
      { name: "embed", actions: ["embed"], description: "Create text embeddings" },
      { name: "rerank", actions: ["rerank"], description: "Rerank search results" },
      { name: "classify", actions: ["classify"], description: "Text classification" },
    ],
    endpoints: {
      chat:               { method: "POST", path: "/v2/chat", body: { model: "command-r-plus", messages: [] } },
      generate:           { method: "POST", path: "/v1/generate", body: { model: "command", prompt: "" } },
      embed:              { method: "POST", path: "/v2/embed", body: { model: "embed-english-v3.0", texts: [], input_type: "search_document" } },
      rerank:             { method: "POST", path: "/v2/rerank", body: { model: "rerank-english-v3.0", query: "", documents: [] } },
      classify:           { method: "POST", path: "/v1/classify", body: { model: "embed-english-v3.0", inputs: [], examples: [] } },
      list_models:        { method: "GET",  path: "/v1/models" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Mistral ─────────────────────────────────────────────
  mistral: {
    name: "Mistral",
    type: "ai",
    description: "Open-weight AI models — chat, embeddings, code generation, function calling",
    baseUrl: "https://api.mistral.ai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "chat", actions: ["complete"], description: "Chat completions" },
      { name: "embed", actions: ["embed"], description: "Text embeddings" },
      { name: "models", actions: ["list"], description: "List available models" },
    ],
    endpoints: {
      chat_completion:    { method: "POST", path: "/v1/chat/completions", body: { model: "mistral-large-latest", messages: [] } },
      create_embedding:   { method: "POST", path: "/v1/embeddings", body: { model: "mistral-embed", input: [] } },
      list_models:        { method: "GET",  path: "/v1/models" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Replicate ───────────────────────────────────────────
  replicate: {
    name: "Replicate",
    type: "ai",
    description: "Run open-source AI models — image generation, LLMs, video, audio",
    baseUrl: "https://api.replicate.com",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "predictions", actions: ["create", "get", "list", "cancel"], description: "Run model predictions" },
      { name: "models", actions: ["list", "get", "search"], description: "Browse and search models" },
    ],
    endpoints: {
      create_prediction:  { method: "POST", path: "/v1/predictions", body: { version: "", input: {} } },
      get_prediction:     { method: "GET",  path: "/v1/predictions/{prediction_id}" },
      list_predictions:   { method: "GET",  path: "/v1/predictions" },
      cancel_prediction:  { method: "POST", path: "/v1/predictions/{prediction_id}/cancel" },
      get_model:          { method: "GET",  path: "/v1/models/{owner}/{name}" },
      list_model_versions:{ method: "GET",  path: "/v1/models/{owner}/{name}/versions" },
      search_models:      { method: "GET",  path: "/v1/models", query: ["query"] },
      list_collections:   { method: "GET",  path: "/v1/collections" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Stability AI ────────────────────────────────────────
  stability: {
    name: "Stability AI",
    type: "ai",
    description: "Image generation — Stable Diffusion, upscaling, inpainting, image-to-image",
    baseUrl: "https://api.stability.ai",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "generate_image", actions: ["generate", "upscale", "edit"], description: "Generate and edit images" },
      { name: "engines", actions: ["list"], description: "List available engines" },
    ],
    endpoints: {
      text_to_image:      { method: "POST", path: "/v1/generation/{engine_id}/text-to-image", body: { text_prompts: [{ text: "" }], cfg_scale: 7, steps: 30 } },
      image_to_image:     { method: "POST", path: "/v1/generation/{engine_id}/image-to-image", contentType: "multipart/form-data" },
      upscale:            { method: "POST", path: "/v1/generation/{engine_id}/image-to-image/upscale", contentType: "multipart/form-data" },
      list_engines:       { method: "GET",  path: "/v1/engines/list" },
      get_account:        { method: "GET",  path: "/v1/user/account" },
      get_balance:        { method: "GET",  path: "/v1/user/balance" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Telegram ────────────────────────────────────────────
  telegram: {
    name: "Telegram",
    type: "messaging",
    description: "Messaging platform — bots, channels, groups, payments, inline mode, stickers, forum topics, gifts, verification",
    baseUrl: "https://api.telegram.org/bot{botToken}",
    authType: "api_key",
    credentialKeys: ["botToken"],
    capabilities: [
      { name: "send_messages", actions: ["send_text", "send_photo", "send_video", "send_audio", "send_document", "send_animation", "send_voice", "send_video_note", "send_location", "send_venue", "send_contact", "send_poll", "send_dice", "send_sticker", "send_media_group", "send_paid_media"], description: "Send any type of message — text, media, locations, contacts, polls, dice" },
      { name: "edit_messages", actions: ["edit_text", "edit_caption", "edit_media", "edit_markup", "edit_live_location", "stop_live_location", "delete", "bulk_delete"], description: "Edit, update, and delete messages" },
      { name: "manage_chats", actions: ["get_chat", "get_admins", "get_member_count", "get_member", "set_title", "set_description", "set_photo", "delete_photo", "set_permissions", "leave", "set_background"], description: "Full chat management — info, settings, permissions, appearance" },
      { name: "manage_members", actions: ["ban", "unban", "restrict", "promote", "approve_join", "decline_join", "ban_channel", "unban_channel", "set_admin_title"], description: "Member moderation — ban, kick, restrict, promote, join requests" },
      { name: "manage_invites", actions: ["export_link", "create_link", "edit_link", "revoke_link", "create_subscription_link", "edit_subscription_link"], description: "Invite link management including subscription-based invites" },
      { name: "manage_updates", actions: ["get_updates", "set_webhook", "delete_webhook", "get_webhook_info"], description: "Receive updates via polling or webhook" },
      { name: "manage_forum_topics", actions: ["create", "edit", "close", "reopen", "delete", "unpin_all", "manage_general"], description: "Forum topic management for supergroups" },
      { name: "manage_bot", actions: ["set_commands", "get_commands", "delete_commands", "set_name", "set_description", "set_short_description", "set_menu_button", "set_admin_rights"], description: "Configure bot profile, commands, menu, and permissions" },
      { name: "manage_stickers", actions: ["send", "get_set", "create_set", "add_to_set", "delete_from_set", "replace", "set_thumbnail", "set_title", "delete_set", "upload_file", "set_emoji", "set_keywords", "set_mask_position"], description: "Full sticker set management — create, edit, delete, upload" },
      { name: "inline_mode", actions: ["answer_inline", "answer_webapp", "save_prepared"], description: "Inline query responses and web app integration" },
      { name: "payments", actions: ["send_invoice", "create_invoice_link", "answer_shipping", "answer_pre_checkout", "get_star_transactions", "refund_star_payment", "edit_subscription"], description: "Telegram Stars and provider-based payments — invoices, subscriptions, refunds" },
      { name: "games", actions: ["send_game", "set_score", "get_high_scores"], description: "Game integration — send, score, leaderboards" },
      { name: "manage_reactions", actions: ["set_reaction"], description: "Set emoji reactions on messages" },
      { name: "manage_pins", actions: ["pin", "unpin", "unpin_all"], description: "Pin and unpin messages" },
      { name: "manage_gifts", actions: ["send_gift", "get_gifts", "gift_premium"], description: "Send gifts and Telegram Premium subscriptions" },
      { name: "verification", actions: ["verify_user", "verify_chat", "remove_user_verification", "remove_chat_verification"], description: "Verify users and chats on behalf of organization" },
      { name: "manage_files", actions: ["get_file"], description: "Download files from Telegram servers" },
    ],
    endpoints: {
      // ── Updates ──────────────────────────────────────────
      get_updates:                  { method: "POST", path: "/getUpdates", body: { offset: 0, limit: 100, timeout: 30 } },
      set_webhook:                  { method: "POST", path: "/setWebhook", body: { url: "", max_connections: 40, allowed_updates: [] } },
      delete_webhook:               { method: "POST", path: "/deleteWebhook", body: { drop_pending_updates: false } },
      get_webhook_info:             { method: "GET",  path: "/getWebhookInfo" },

      // ── Bot Info ─────────────────────────────────────────
      get_me:                       { method: "GET",  path: "/getMe" },
      log_out:                      { method: "POST", path: "/logOut" },
      close:                        { method: "POST", path: "/close" },
      get_user_profile_photos:      { method: "POST", path: "/getUserProfilePhotos", body: { user_id: 0, offset: 0, limit: 100 } },
      get_user_chat_boosts:         { method: "POST", path: "/getUserChatBoosts", body: { chat_id: "", user_id: 0 } },
      get_business_connection:      { method: "POST", path: "/getBusinessConnection", body: { business_connection_id: "" } },

      // ── Sending Messages ─────────────────────────────────
      send_message:                 { method: "POST", path: "/sendMessage", body: { chat_id: "", text: "", parse_mode: "HTML" } },
      forward_message:              { method: "POST", path: "/forwardMessage", body: { chat_id: "", from_chat_id: "", message_id: 0 } },
      forward_messages:             { method: "POST", path: "/forwardMessages", body: { chat_id: "", from_chat_id: "", message_ids: [] } },
      copy_message:                 { method: "POST", path: "/copyMessage", body: { chat_id: "", from_chat_id: "", message_id: 0 } },
      copy_messages:                { method: "POST", path: "/copyMessages", body: { chat_id: "", from_chat_id: "", message_ids: [] } },
      send_photo:                   { method: "POST", path: "/sendPhoto", body: { chat_id: "", photo: "", caption: "" } },
      send_audio:                   { method: "POST", path: "/sendAudio", body: { chat_id: "", audio: "", caption: "" } },
      send_document:                { method: "POST", path: "/sendDocument", body: { chat_id: "", document: "", caption: "" } },
      send_video:                   { method: "POST", path: "/sendVideo", body: { chat_id: "", video: "", caption: "" } },
      send_animation:               { method: "POST", path: "/sendAnimation", body: { chat_id: "", animation: "", caption: "" } },
      send_voice:                   { method: "POST", path: "/sendVoice", body: { chat_id: "", voice: "", caption: "" } },
      send_video_note:              { method: "POST", path: "/sendVideoNote", body: { chat_id: "", video_note: "" } },
      send_paid_media:              { method: "POST", path: "/sendPaidMedia", body: { chat_id: "", star_count: 0, media: [] } },
      send_media_group:             { method: "POST", path: "/sendMediaGroup", body: { chat_id: "", media: [] } },
      send_location:                { method: "POST", path: "/sendLocation", body: { chat_id: "", latitude: 0, longitude: 0 } },
      send_venue:                   { method: "POST", path: "/sendVenue", body: { chat_id: "", latitude: 0, longitude: 0, title: "", address: "" } },
      send_contact:                 { method: "POST", path: "/sendContact", body: { chat_id: "", phone_number: "", first_name: "" } },
      send_poll:                    { method: "POST", path: "/sendPoll", body: { chat_id: "", question: "", options: [] } },
      send_dice:                    { method: "POST", path: "/sendDice", body: { chat_id: "", emoji: "🎲" } },
      send_chat_action:             { method: "POST", path: "/sendChatAction", body: { chat_id: "", action: "typing" } },

      // ── Message Editing & Deletion ───────────────────────
      edit_message_text:            { method: "POST", path: "/editMessageText", body: { chat_id: "", message_id: 0, text: "", parse_mode: "HTML" } },
      edit_message_caption:         { method: "POST", path: "/editMessageCaption", body: { chat_id: "", message_id: 0, caption: "" } },
      edit_message_media:           { method: "POST", path: "/editMessageMedia", body: { chat_id: "", message_id: 0, media: {} } },
      edit_message_reply_markup:    { method: "POST", path: "/editMessageReplyMarkup", body: { chat_id: "", message_id: 0 } },
      edit_message_live_location:   { method: "POST", path: "/editMessageLiveLocation", body: { chat_id: "", message_id: 0, latitude: 0, longitude: 0 } },
      stop_message_live_location:   { method: "POST", path: "/stopMessageLiveLocation", body: { chat_id: "", message_id: 0 } },
      delete_message:               { method: "POST", path: "/deleteMessage", body: { chat_id: "", message_id: 0 } },
      delete_messages:              { method: "POST", path: "/deleteMessages", body: { chat_id: "", message_ids: [] } },
      set_message_reaction:         { method: "POST", path: "/setMessageReaction", body: { chat_id: "", message_id: 0, reaction: [] } },

      // ── Chat Management ──────────────────────────────────
      get_chat:                     { method: "POST", path: "/getChat", body: { chat_id: "" } },
      get_chat_administrators:      { method: "POST", path: "/getChatAdministrators", body: { chat_id: "" } },
      get_chat_member_count:        { method: "POST", path: "/getChatMemberCount", body: { chat_id: "" } },
      get_chat_member:              { method: "POST", path: "/getChatMember", body: { chat_id: "", user_id: 0 } },
      leave_chat:                   { method: "POST", path: "/leaveChat", body: { chat_id: "" } },
      set_chat_title:               { method: "POST", path: "/setChatTitle", body: { chat_id: "", title: "" } },
      set_chat_description:         { method: "POST", path: "/setChatDescription", body: { chat_id: "", description: "" } },
      set_chat_photo:               { method: "POST", path: "/setChatPhoto", contentType: "multipart/form-data" },
      delete_chat_photo:            { method: "POST", path: "/deleteChatPhoto", body: { chat_id: "" } },
      set_chat_permissions:         { method: "POST", path: "/setChatPermissions", body: { chat_id: "", permissions: {} } },
      set_chat_administrator_custom_title: { method: "POST", path: "/setChatAdministratorCustomTitle", body: { chat_id: "", user_id: 0, custom_title: "" } },
      set_chat_menu_button:         { method: "POST", path: "/setChatMenuButton", body: { chat_id: "", menu_button: {} } },
      get_chat_menu_button:         { method: "POST", path: "/getChatMenuButton", body: { chat_id: "" } },
      set_my_default_admin_rights:  { method: "POST", path: "/setMyDefaultAdministratorRights", body: { rights: {} } },
      get_my_default_admin_rights:  { method: "POST", path: "/getMyDefaultAdministratorRights" },
      set_chat_background:          { method: "POST", path: "/setChatBackground", body: { chat_id: "", background: {} } },

      // ── Invite Links ─────────────────────────────────────
      export_chat_invite_link:      { method: "POST", path: "/exportChatInviteLink", body: { chat_id: "" } },
      create_chat_invite_link:      { method: "POST", path: "/createChatInviteLink", body: { chat_id: "", name: "", expire_date: 0, member_limit: 0 } },
      edit_chat_invite_link:        { method: "POST", path: "/editChatInviteLink", body: { chat_id: "", invite_link: "" } },
      revoke_chat_invite_link:      { method: "POST", path: "/revokeChatInviteLink", body: { chat_id: "", invite_link: "" } },
      create_chat_subscription_invite_link: { method: "POST", path: "/createChatSubscriptionInviteLink", body: { chat_id: "", subscription_period: 2592000, subscription_price: 0 } },
      edit_chat_subscription_invite_link: { method: "POST", path: "/editChatSubscriptionInviteLink", body: { chat_id: "", invite_link: "" } },

      // ── Member Management ────────────────────────────────
      ban_chat_member:              { method: "POST", path: "/banChatMember", body: { chat_id: "", user_id: 0 } },
      unban_chat_member:            { method: "POST", path: "/unbanChatMember", body: { chat_id: "", user_id: 0, only_if_banned: true } },
      restrict_chat_member:         { method: "POST", path: "/restrictChatMember", body: { chat_id: "", user_id: 0, permissions: {} } },
      promote_chat_member:          { method: "POST", path: "/promoteChatMember", body: { chat_id: "", user_id: 0 } },
      approve_chat_join_request:    { method: "POST", path: "/approveChatJoinRequest", body: { chat_id: "", user_id: 0 } },
      decline_chat_join_request:    { method: "POST", path: "/declineChatJoinRequest", body: { chat_id: "", user_id: 0 } },
      ban_chat_sender_chat:         { method: "POST", path: "/banChatSenderChat", body: { chat_id: "", sender_chat_id: 0 } },
      unban_chat_sender_chat:       { method: "POST", path: "/unbanChatSenderChat", body: { chat_id: "", sender_chat_id: 0 } },

      // ── Forum Topics ─────────────────────────────────────
      create_forum_topic:           { method: "POST", path: "/createForumTopic", body: { chat_id: "", name: "" } },
      edit_forum_topic:             { method: "POST", path: "/editForumTopic", body: { chat_id: "", message_thread_id: 0, name: "" } },
      close_forum_topic:            { method: "POST", path: "/closeForumTopic", body: { chat_id: "", message_thread_id: 0 } },
      reopen_forum_topic:           { method: "POST", path: "/reopenForumTopic", body: { chat_id: "", message_thread_id: 0 } },
      delete_forum_topic:           { method: "POST", path: "/deleteForumTopic", body: { chat_id: "", message_thread_id: 0 } },
      unpin_all_forum_topic_messages: { method: "POST", path: "/unpinAllForumTopicMessages", body: { chat_id: "", message_thread_id: 0 } },
      get_forum_topic_icon_stickers: { method: "GET", path: "/getForumTopicIconStickers" },
      edit_general_forum_topic:     { method: "POST", path: "/editGeneralForumTopic", body: { chat_id: "", name: "" } },
      close_general_forum_topic:    { method: "POST", path: "/closeGeneralForumTopic", body: { chat_id: "" } },
      reopen_general_forum_topic:   { method: "POST", path: "/reopenGeneralForumTopic", body: { chat_id: "" } },
      hide_general_forum_topic:     { method: "POST", path: "/hideGeneralForumTopic", body: { chat_id: "" } },
      unhide_general_forum_topic:   { method: "POST", path: "/unhideGeneralForumTopic", body: { chat_id: "" } },
      unpin_all_general_forum_topic_messages: { method: "POST", path: "/unpinAllGeneralForumTopicMessages", body: { chat_id: "" } },

      // ── Bot Configuration ────────────────────────────────
      set_my_commands:              { method: "POST", path: "/setMyCommands", body: { commands: [] } },
      get_my_commands:              { method: "POST", path: "/getMyCommands" },
      delete_my_commands:           { method: "POST", path: "/deleteMyCommands" },
      set_my_name:                  { method: "POST", path: "/setMyName", body: { name: "" } },
      get_my_name:                  { method: "POST", path: "/getMyName" },
      set_my_description:           { method: "POST", path: "/setMyDescription", body: { description: "" } },
      get_my_description:           { method: "POST", path: "/getMyDescription" },
      set_my_short_description:     { method: "POST", path: "/setMyShortDescription", body: { short_description: "" } },
      get_my_short_description:     { method: "POST", path: "/getMyShortDescription" },

      // ── Pins ─────────────────────────────────────────────
      pin_chat_message:             { method: "POST", path: "/pinChatMessage", body: { chat_id: "", message_id: 0 } },
      unpin_chat_message:           { method: "POST", path: "/unpinChatMessage", body: { chat_id: "", message_id: 0 } },
      unpin_all_chat_messages:      { method: "POST", path: "/unpinAllChatMessages", body: { chat_id: "" } },

      // ── Stickers ─────────────────────────────────────────
      send_sticker:                 { method: "POST", path: "/sendSticker", body: { chat_id: "", sticker: "" } },
      get_sticker_set:              { method: "POST", path: "/getStickerSet", body: { name: "" } },
      get_custom_emoji_stickers:    { method: "POST", path: "/getCustomEmojiStickers", body: { custom_emoji_ids: [] } },
      upload_sticker_file:          { method: "POST", path: "/uploadStickerFile", contentType: "multipart/form-data" },
      create_new_sticker_set:       { method: "POST", path: "/createNewStickerSet", body: { user_id: 0, name: "", title: "", stickers: [] } },
      add_sticker_to_set:           { method: "POST", path: "/addStickerToSet", body: { user_id: 0, name: "", sticker: {} } },
      set_sticker_position_in_set:  { method: "POST", path: "/setStickerPositionInSet", body: { sticker: "", position: 0 } },
      delete_sticker_from_set:      { method: "POST", path: "/deleteStickerFromSet", body: { sticker: "" } },
      replace_sticker_in_set:       { method: "POST", path: "/replaceStickerInSet", body: { user_id: 0, name: "", old_sticker: "", sticker: {} } },
      set_sticker_set_thumbnail:    { method: "POST", path: "/setStickerSetThumbnail", body: { name: "", user_id: 0 } },
      set_custom_emoji_sticker_set_thumbnail: { method: "POST", path: "/setCustomEmojiStickerSetThumbnail", body: { name: "" } },
      set_sticker_set_title:        { method: "POST", path: "/setStickerSetTitle", body: { name: "", title: "" } },
      delete_sticker_set:           { method: "POST", path: "/deleteStickerSet", body: { name: "" } },
      set_sticker_emoji_list:       { method: "POST", path: "/setStickerEmojiList", body: { sticker: "", emoji_list: [] } },
      set_sticker_keywords:         { method: "POST", path: "/setStickerKeywords", body: { sticker: "", keywords: [] } },
      set_sticker_mask_position:    { method: "POST", path: "/setStickerMaskPosition", body: { sticker: "" } },

      // ── Inline Mode ──────────────────────────────────────
      answer_inline_query:          { method: "POST", path: "/answerInlineQuery", body: { inline_query_id: "", results: [] } },
      answer_web_app_query:         { method: "POST", path: "/answerWebAppQuery", body: { web_app_query_id: "", result: {} } },
      save_prepared_inline_message: { method: "POST", path: "/savePreparedInlineMessage", body: { user_id: 0, result: {} } },

      // ── Payments ─────────────────────────────────────────
      send_invoice:                 { method: "POST", path: "/sendInvoice", body: { chat_id: "", title: "", description: "", payload: "", currency: "XTR", prices: [] } },
      create_invoice_link:          { method: "POST", path: "/createInvoiceLink", body: { title: "", description: "", payload: "", currency: "XTR", prices: [] } },
      answer_shipping_query:        { method: "POST", path: "/answerShippingQuery", body: { shipping_query_id: "", ok: true } },
      answer_pre_checkout_query:    { method: "POST", path: "/answerPreCheckoutQuery", body: { pre_checkout_query_id: "", ok: true } },
      get_star_transactions:        { method: "POST", path: "/getStarTransactions", body: { offset: 0, limit: 100 } },
      refund_star_payment:          { method: "POST", path: "/refundStarPayment", body: { user_id: 0, telegram_payment_charge_id: "" } },
      edit_user_star_subscription:  { method: "POST", path: "/editUserStarSubscription", body: { user_id: 0, telegram_payment_charge_id: "", is_canceled: false } },

      // ── Games ────────────────────────────────────────────
      send_game:                    { method: "POST", path: "/sendGame", body: { chat_id: "", game_short_name: "" } },
      set_game_score:               { method: "POST", path: "/setGameScore", body: { user_id: 0, score: 0, chat_id: "", message_id: 0 } },
      get_game_high_scores:         { method: "POST", path: "/getGameHighScores", body: { user_id: 0, chat_id: "", message_id: 0 } },

      // ── Callback Queries ─────────────────────────────────
      answer_callback_query:        { method: "POST", path: "/answerCallbackQuery", body: { callback_query_id: "", text: "" } },

      // ── Files ────────────────────────────────────────────
      get_file:                     { method: "POST", path: "/getFile", body: { file_id: "" } },

      // ── Gifts ────────────────────────────────────────────
      send_gift:                    { method: "POST", path: "/sendGift", body: { user_id: 0, gift_id: "" } },
      get_available_gifts:          { method: "GET",  path: "/getAvailableGifts" },
      gift_premium_subscription:    { method: "POST", path: "/giftPremiumSubscription", body: { user_id: 0, month_count: 3, star_count: 0 } },

      // ── Verification ─────────────────────────────────────
      verify_user:                  { method: "POST", path: "/verifyUser", body: { user_id: 0 } },
      verify_chat:                  { method: "POST", path: "/verifyChat", body: { chat_id: "" } },
      remove_user_verification:     { method: "POST", path: "/removeUserVerification", body: { user_id: 0 } },
      remove_chat_verification:     { method: "POST", path: "/removeChatVerification", body: { chat_id: "" } },
    },
    authHeader: () => ({ "Content-Type": "application/json" }),
  },

  // ── Postmark ────────────────────────────────────────────
  postmark: {
    name: "Postmark",
    type: "email",
    description: "Transactional email — send, templates, webhooks, bounce management",
    baseUrl: "https://api.postmarkapp.com",
    authType: "api_key",
    credentialKeys: ["serverToken"],
    capabilities: [
      { name: "send_email", actions: ["send", "send_batch", "send_template"], description: "Send transactional emails" },
      { name: "manage_templates", actions: ["list", "get", "create"], description: "Manage email templates" },
      { name: "manage_bounces", actions: ["list", "get"], description: "Track bounces and deliverability" },
    ],
    endpoints: {
      send_email:         { method: "POST", path: "/email", body: { From: "", To: "", Subject: "", HtmlBody: "" } },
      send_batch:         { method: "POST", path: "/email/batch", body: [] },
      send_template:      { method: "POST", path: "/email/withTemplate", body: { TemplateId: 0, To: "", TemplateModel: {} } },
      list_templates:     { method: "GET",  path: "/templates", query: ["Count", "Offset"] },
      get_template:       { method: "GET",  path: "/templates/{templateId}" },
      create_template:    { method: "POST", path: "/templates", body: { Name: "", Subject: "", HtmlBody: "" } },
      list_bounces:       { method: "GET",  path: "/bounces", query: ["count", "offset", "type"] },
      get_delivery_stats: { method: "GET",  path: "/deliverystats" },
      get_server:         { method: "GET",  path: "/server" },
    },
    authHeader: (creds) => ({ "X-Postmark-Server-Token": creds.serverToken, "Content-Type": "application/json", "Accept": "application/json" }),
  },

  // ── Mailgun ─────────────────────────────────────────────
  mailgun: {
    name: "Mailgun",
    type: "email",
    description: "Email API — send, receive, validate, track deliverability",
    baseUrl: "https://api.mailgun.net/v3",
    authType: "api_key",
    credentialKeys: ["apiKey", "domain"],
    capabilities: [
      { name: "send_email", actions: ["send"], description: "Send emails" },
      { name: "manage_domains", actions: ["list", "get"], description: "Manage sending domains" },
      { name: "track_events", actions: ["list"], description: "Track email events" },
      { name: "validate_email", actions: ["validate"], description: "Validate email addresses" },
    ],
    endpoints: {
      send_message:       { method: "POST", path: "/{domain}/messages", contentType: "multipart/form-data" },
      list_domains:       { method: "GET",  path: "/domains" },
      get_domain:         { method: "GET",  path: "/domains/{domain}" },
      list_events:        { method: "GET",  path: "/{domain}/events", query: ["begin", "end", "event", "limit"] },
      get_stats:          { method: "GET",  path: "/{domain}/stats/total", query: ["event", "start", "end"] },
      validate_email:     { method: "GET",  path: "/address/validate", query: ["address"] },
      list_bounces:       { method: "GET",  path: "/{domain}/bounces" },
      list_unsubscribes:  { method: "GET",  path: "/{domain}/unsubscribes" },
    },
    authHeader: (creds) => ({ "Authorization": "Basic " + Buffer.from("api:" + creds.apiKey).toString("base64") }),
  },

  // ── ConvertKit ──────────────────────────────────────────
  convertkit: {
    name: "ConvertKit",
    type: "email_marketing",
    description: "Creator email marketing — subscribers, sequences, broadcasts, forms, tags",
    baseUrl: "https://api.convertkit.com/v3",
    authType: "api_key",
    credentialKeys: ["apiSecret"],
    capabilities: [
      { name: "manage_subscribers", actions: ["list", "get", "create", "tag"], description: "Manage subscribers" },
      { name: "manage_sequences", actions: ["list", "subscribe"], description: "Manage email sequences" },
      { name: "manage_broadcasts", actions: ["list", "create"], description: "Send broadcasts" },
      { name: "manage_tags", actions: ["list", "create"], description: "Manage subscriber tags" },
      { name: "manage_forms", actions: ["list", "subscribe"], description: "Manage signup forms" },
    ],
    endpoints: {
      list_subscribers:   { method: "GET",  path: "/subscribers", query: ["api_secret", "page", "sort_order"] },
      get_subscriber:     { method: "GET",  path: "/subscribers/{subscriber_id}", query: ["api_secret"] },
      create_subscriber:  { method: "POST", path: "/forms/{form_id}/subscribe", body: { api_secret: "", email: "" } },
      tag_subscriber:     { method: "POST", path: "/tags/{tag_id}/subscribe", body: { api_secret: "", email: "" } },
      list_tags:          { method: "GET",  path: "/tags", query: ["api_secret"] },
      create_tag:         { method: "POST", path: "/tags", body: { api_secret: "", tag: { name: "" } } },
      list_sequences:     { method: "GET",  path: "/sequences", query: ["api_secret"] },
      add_to_sequence:    { method: "POST", path: "/sequences/{sequence_id}/subscribe", body: { api_secret: "", email: "" } },
      list_forms:         { method: "GET",  path: "/forms", query: ["api_secret"] },
      list_broadcasts:    { method: "GET",  path: "/broadcasts", query: ["api_secret"] },
      create_broadcast:   { method: "POST", path: "/broadcasts", body: { api_secret: "", subject: "", content: "" } },
    },
    authHeader: () => ({ "Content-Type": "application/json" }),
  },

  // ── Brevo (Sendinblue) ──────────────────────────────────
  brevo: {
    name: "Brevo",
    type: "email_marketing",
    description: "Email & SMS marketing — campaigns, transactional, contacts, automation",
    baseUrl: "https://api.brevo.com/v3",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "send_email", actions: ["send_transactional", "send_campaign"], description: "Send transactional and campaign emails" },
      { name: "manage_contacts", actions: ["create", "update", "list"], description: "Manage contact lists" },
      { name: "send_sms", actions: ["send"], description: "Send SMS messages" },
    ],
    endpoints: {
      send_transactional: { method: "POST", path: "/smtp/email", body: { sender: {}, to: [{}], subject: "", htmlContent: "" } },
      list_contacts:      { method: "GET",  path: "/contacts", query: ["limit", "offset", "sort"] },
      create_contact:     { method: "POST", path: "/contacts", body: { email: "", attributes: {} } },
      update_contact:     { method: "PUT",  path: "/contacts/{identifier}", body: { attributes: {} } },
      get_contact:        { method: "GET",  path: "/contacts/{identifier}" },
      list_lists:         { method: "GET",  path: "/contacts/lists", query: ["limit", "offset"] },
      send_sms:           { method: "POST", path: "/transactionalSMS/sms", body: { sender: "", recipient: "", content: "" } },
      get_account:        { method: "GET",  path: "/account" },
    },
    authHeader: (creds) => ({ "api-key": creds.apiKey, "Content-Type": "application/json" }),
  },

  // ── ActiveCampaign ──────────────────────────────────────
  activecampaign: {
    name: "ActiveCampaign",
    type: "email_marketing",
    description: "Email marketing + CRM — contacts, automations, deals, campaigns, tags",
    baseUrl: "https://{accountName}.api-us1.com/api/3",
    authType: "api_key",
    credentialKeys: ["apiKey", "accountName"],
    capabilities: [
      { name: "manage_contacts", actions: ["create", "update", "list", "search"], description: "Manage contacts" },
      { name: "manage_tags", actions: ["list", "add", "remove"], description: "Tag contacts" },
      { name: "manage_automations", actions: ["list"], description: "List automations" },
      { name: "manage_deals", actions: ["create", "list", "update"], description: "Manage CRM deals" },
    ],
    endpoints: {
      create_contact:     { method: "POST", path: "/contacts", body: { contact: { email: "", firstName: "", lastName: "" } } },
      list_contacts:      { method: "GET",  path: "/contacts", query: ["search", "limit", "offset"] },
      get_contact:        { method: "GET",  path: "/contacts/{id}" },
      update_contact:     { method: "PUT",  path: "/contacts/{id}", body: { contact: {} } },
      add_tag:            { method: "POST", path: "/contactTags", body: { contactTag: { contact: "", tag: "" } } },
      list_tags:          { method: "GET",  path: "/tags", query: ["search", "limit"] },
      list_automations:   { method: "GET",  path: "/automations" },
      create_deal:        { method: "POST", path: "/deals", body: { deal: { title: "", value: 0 } } },
      list_deals:         { method: "GET",  path: "/deals", query: ["search", "limit"] },
      list_lists:         { method: "GET",  path: "/lists" },
    },
    authHeader: (creds) => ({ "Api-Token": creds.apiKey, "Content-Type": "application/json" }),
  },

  // ── Lemlist ─────────────────────────────────────────────
  lemlist: {
    name: "Lemlist",
    type: "cold_email",
    description: "Cold email outreach — campaigns, leads, sequences, email warmup",
    baseUrl: "https://api.lemlist.com/api",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_campaigns", actions: ["list", "get"], description: "Manage outreach campaigns" },
      { name: "manage_leads", actions: ["add", "list", "delete"], description: "Manage campaign leads" },
      { name: "manage_activities", actions: ["list"], description: "Track email activities" },
    ],
    endpoints: {
      list_campaigns:     { method: "GET",  path: "/campaigns" },
      get_campaign:       { method: "GET",  path: "/campaigns/{campaignId}" },
      add_lead:           { method: "POST", path: "/campaigns/{campaignId}/leads/{email}", body: { firstName: "", lastName: "", companyName: "" } },
      list_leads:         { method: "GET",  path: "/campaigns/{campaignId}/leads" },
      delete_lead:        { method: "DELETE", path: "/campaigns/{campaignId}/leads/{email}" },
      list_activities:    { method: "GET",  path: "/activities", query: ["campaignId", "type", "limit"] },
      get_team:           { method: "GET",  path: "/team" },
    },
    authHeader: (creds) => ({ "Authorization": "Basic " + Buffer.from(":" + creds.apiKey).toString("base64") }),
  },

  // ── AWS ─────────────────────────────────────────────────
  aws: {
    name: "AWS",
    type: "cloud",
    description: "Amazon Web Services — S3 storage, Lambda functions, SES email, SNS notifications",
    baseUrl: "https://s3.amazonaws.com",
    authType: "aws_signature",
    credentialKeys: ["accessKeyId", "secretAccessKey", "region"],
    capabilities: [
      { name: "manage_s3", actions: ["list_buckets", "put_object", "get_object", "delete_object"], description: "S3 storage operations" },
      { name: "send_email", actions: ["send"], description: "Send email via SES" },
      { name: "manage_lambda", actions: ["invoke", "list"], description: "Lambda function management" },
    ],
    endpoints: {
      list_buckets:       { method: "GET",  path: "/" },
      list_objects:       { method: "GET",  path: "/{bucket}", query: ["prefix", "max-keys", "delimiter"] },
      put_object:         { method: "PUT",  path: "/{bucket}/{key}" },
      get_object:         { method: "GET",  path: "/{bucket}/{key}" },
      delete_object:      { method: "DELETE", path: "/{bucket}/{key}" },
    },
    authHeader: (creds) => ({ "Content-Type": "application/json" }),
  },

  // ── Webflow ─────────────────────────────────────────────
  webflow: {
    name: "Webflow",
    type: "websites",
    description: "Visual web builder — sites, CMS collections, forms, e-commerce, memberships",
    baseUrl: "https://api.webflow.com/v2",
    authType: "api_key",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_sites", actions: ["list", "get", "publish"], description: "Manage Webflow sites" },
      { name: "manage_collections", actions: ["list", "get", "create_item"], description: "Manage CMS collections" },
      { name: "manage_forms", actions: ["list", "get_submissions"], description: "Get form submissions" },
      { name: "manage_ecommerce", actions: ["list_products", "create_order"], description: "E-commerce operations" },
    ],
    endpoints: {
      list_sites:         { method: "GET",  path: "/sites" },
      get_site:           { method: "GET",  path: "/sites/{site_id}" },
      publish_site:       { method: "POST", path: "/sites/{site_id}/publish", body: { domains: [] } },
      list_collections:   { method: "GET",  path: "/sites/{site_id}/collections" },
      get_collection:     { method: "GET",  path: "/collections/{collection_id}" },
      list_items:         { method: "GET",  path: "/collections/{collection_id}/items", query: ["limit", "offset"] },
      create_item:        { method: "POST", path: "/collections/{collection_id}/items", body: { fieldData: {} } },
      update_item:        { method: "PATCH", path: "/collections/{collection_id}/items/{item_id}", body: { fieldData: {} } },
      delete_item:        { method: "DELETE", path: "/collections/{collection_id}/items/{item_id}" },
      list_forms:         { method: "GET",  path: "/sites/{site_id}/forms" },
      list_form_submissions: { method: "GET", path: "/forms/{form_id}/submissions" },
      list_products:      { method: "GET",  path: "/sites/{site_id}/products" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── WordPress ───────────────────────────────────────────
  wordpress: {
    name: "WordPress",
    type: "websites",
    description: "WordPress REST API — posts, pages, media, users, comments, plugins",
    baseUrl: "https://{siteUrl}/wp-json/wp/v2",
    authType: "basic",
    credentialKeys: ["siteUrl", "username", "applicationPassword"],
    capabilities: [
      { name: "manage_posts", actions: ["create", "update", "list", "delete"], description: "Manage blog posts" },
      { name: "manage_pages", actions: ["create", "update", "list"], description: "Manage pages" },
      { name: "manage_media", actions: ["upload", "list"], description: "Manage media library" },
      { name: "manage_users", actions: ["list", "get"], description: "Manage users" },
    ],
    endpoints: {
      list_posts:         { method: "GET",  path: "/posts", query: ["per_page", "page", "search", "status"] },
      create_post:        { method: "POST", path: "/posts", body: { title: "", content: "", status: "draft" } },
      update_post:        { method: "PUT",  path: "/posts/{id}", body: {} },
      delete_post:        { method: "DELETE", path: "/posts/{id}" },
      list_pages:         { method: "GET",  path: "/pages", query: ["per_page", "page", "search"] },
      create_page:        { method: "POST", path: "/pages", body: { title: "", content: "", status: "draft" } },
      update_page:        { method: "PUT",  path: "/pages/{id}", body: {} },
      list_media:         { method: "GET",  path: "/media", query: ["per_page", "page"] },
      upload_media:       { method: "POST", path: "/media", contentType: "multipart/form-data" },
      list_users:         { method: "GET",  path: "/users" },
      list_comments:      { method: "GET",  path: "/comments", query: ["post", "per_page"] },
      list_categories:    { method: "GET",  path: "/categories" },
      list_tags:          { method: "GET",  path: "/tags" },
    },
    authHeader: (creds) => ({ "Authorization": "Basic " + Buffer.from(creds.username + ":" + creds.applicationPassword).toString("base64"), "Content-Type": "application/json" }),
  },

  // ── Monday.com ──────────────────────────────────────────
  monday: {
    name: "Monday.com",
    type: "project_mgmt",
    description: "Work management — boards, items, columns, updates, automations via GraphQL",
    baseUrl: "https://api.monday.com/v2",
    authType: "api_key",
    credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_boards", actions: ["list", "create"], description: "Manage boards" },
      { name: "manage_items", actions: ["create", "update", "list"], description: "Manage items/rows" },
      { name: "manage_updates", actions: ["create", "list"], description: "Post updates on items" },
    ],
    endpoints: {
      graphql:            { method: "POST", path: "/", body: { query: "" } },
    },
    authHeader: (creds) => ({ "Authorization": creds.apiKey, "Content-Type": "application/json" }),
  },

  // ── Trello ──────────────────────────────────────────────
  trello: {
    name: "Trello",
    type: "project_mgmt",
    description: "Kanban boards — cards, lists, boards, checklists, labels, members",
    baseUrl: "https://api.trello.com/1",
    authType: "api_key",
    credentialKeys: ["apiKey", "apiToken"],
    capabilities: [
      { name: "manage_boards", actions: ["list", "get", "create"], description: "Manage Trello boards" },
      { name: "manage_cards", actions: ["create", "update", "move", "delete"], description: "Manage cards" },
      { name: "manage_lists", actions: ["create", "list"], description: "Manage lists" },
    ],
    endpoints: {
      list_boards:        { method: "GET",  path: "/members/me/boards", query: ["key", "token"] },
      get_board:          { method: "GET",  path: "/boards/{id}", query: ["key", "token"] },
      create_board:       { method: "POST", path: "/boards", query: ["key", "token", "name"] },
      get_lists:          { method: "GET",  path: "/boards/{boardId}/lists", query: ["key", "token"] },
      create_list:        { method: "POST", path: "/lists", query: ["key", "token", "name", "idBoard"] },
      create_card:        { method: "POST", path: "/cards", query: ["key", "token", "name", "idList"] },
      update_card:        { method: "PUT",  path: "/cards/{id}", query: ["key", "token"] },
      delete_card:        { method: "DELETE", path: "/cards/{id}", query: ["key", "token"] },
      get_card:           { method: "GET",  path: "/cards/{id}", query: ["key", "token"] },
      list_labels:        { method: "GET",  path: "/boards/{boardId}/labels", query: ["key", "token"] },
    },
    authHeader: () => ({}),
  },

  // ── Typeform ────────────────────────────────────────────
  typeform: {
    name: "Typeform",
    type: "forms",
    description: "Interactive forms — create forms, collect responses, webhooks",
    baseUrl: "https://api.typeform.com",
    authType: "api_key",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_forms", actions: ["list", "get", "create"], description: "Manage forms" },
      { name: "manage_responses", actions: ["list"], description: "Get form responses" },
      { name: "manage_webhooks", actions: ["create", "list"], description: "Manage form webhooks" },
    ],
    endpoints: {
      list_forms:         { method: "GET",  path: "/forms", query: ["page", "page_size", "search"] },
      get_form:           { method: "GET",  path: "/forms/{form_id}" },
      create_form:        { method: "POST", path: "/forms", body: { title: "", fields: [] } },
      list_responses:     { method: "GET",  path: "/forms/{form_id}/responses", query: ["page_size", "since", "until"] },
      create_webhook:     { method: "PUT",  path: "/forms/{form_id}/webhooks/{tag}", body: { url: "", enabled: true } },
      list_webhooks:      { method: "GET",  path: "/forms/{form_id}/webhooks" },
      list_workspaces:    { method: "GET",  path: "/workspaces" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── DocuSign ────────────────────────────────────────────
  docusign: {
    name: "DocuSign",
    type: "productivity",
    description: "E-signatures — envelopes, templates, recipients, signing workflows",
    baseUrl: "https://demo.docusign.net/restapi/v2.1",
    // Sign in with DocuSign records the account's own server (base_uri). Only a docusign.net host is accepted, so a
    // record cannot point the bearer token anywhere else.
    baseUrlFor: (creds) => (/^https:\/\/[a-z0-9.-]+\.docusign\.net\/?$/i.test(String(creds.baseUri || "")) ? `${String(creds.baseUri).replace(/\/$/, "")}/restapi/v2.1` : null),
    authType: "oauth",
    credentialKeys: ["accessToken", "accountId"],
    capabilities: [
      { name: "manage_envelopes", actions: ["create", "get", "list", "send"], description: "Create and send documents for signing" },
      { name: "manage_templates", actions: ["list", "get"], description: "Manage document templates" },
    ],
    endpoints: {
      create_envelope:    { method: "POST", path: "/accounts/{accountId}/envelopes", body: { emailSubject: "", documents: [], recipients: {}, status: "sent" } },
      get_envelope:       { method: "GET",  path: "/accounts/{accountId}/envelopes/{envelopeId}" },
      list_envelopes:     { method: "GET",  path: "/accounts/{accountId}/envelopes", query: ["from_date", "status"] },
      list_recipients:    { method: "GET",  path: "/accounts/{accountId}/envelopes/{envelopeId}/recipients" },
      list_templates:     { method: "GET",  path: "/accounts/{accountId}/templates" },
      get_template:       { method: "GET",  path: "/accounts/{accountId}/templates/{templateId}" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── Xero ────────────────────────────────────────────────
  xero: {
    name: "Xero",
    type: "accounting",
    description: "Cloud accounting — invoices, contacts, payments, bank reconciliation, reports",
    baseUrl: "https://api.xero.com/api.xro/2.0",
    authType: "oauth",
    credentialKeys: ["accessToken", "tenantId"],
    capabilities: [
      { name: "manage_invoices", actions: ["create", "list", "get"], description: "Manage invoices" },
      { name: "manage_contacts", actions: ["create", "list", "get"], description: "Manage accounting contacts" },
      { name: "manage_payments", actions: ["create", "list"], description: "Record payments" },
    ],
    endpoints: {
      list_invoices:      { method: "GET",  path: "/Invoices" },
      create_invoice:     { method: "POST", path: "/Invoices", body: { Type: "ACCREC", Contact: {}, LineItems: [] } },
      get_invoice:        { method: "GET",  path: "/Invoices/{InvoiceID}" },
      list_contacts:      { method: "GET",  path: "/Contacts" },
      create_contact:     { method: "POST", path: "/Contacts", body: { Name: "", EmailAddress: "" } },
      list_payments:      { method: "GET",  path: "/Payments" },
      create_payment:     { method: "PUT",  path: "/Payments", body: { Invoice: {}, Account: {}, Amount: 0 } },
      list_accounts:      { method: "GET",  path: "/Accounts" },
      get_organisation:   { method: "GET",  path: "/Organisation" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "xero-tenant-id": creds.tenantId, "Content-Type": "application/json" }),
  },

  // ── Freshdesk ───────────────────────────────────────────
  freshdesk: {
    name: "Freshdesk",
    type: "support",
    description: "Help desk — tickets, contacts, agents, groups, automations",
    baseUrl: "https://{domain}.freshdesk.com/api/v2",
    authType: "api_key",
    credentialKeys: ["apiKey", "domain"],
    capabilities: [
      { name: "manage_tickets", actions: ["create", "update", "list", "get"], description: "Manage support tickets" },
      { name: "manage_contacts", actions: ["create", "list", "get"], description: "Manage contacts" },
    ],
    endpoints: {
      list_tickets:       { method: "GET",  path: "/tickets", query: ["per_page", "page", "filter"] },
      create_ticket:      { method: "POST", path: "/tickets", body: { subject: "", description: "", email: "", priority: 1, status: 2 } },
      update_ticket:      { method: "PUT",  path: "/tickets/{id}", body: {} },
      get_ticket:         { method: "GET",  path: "/tickets/{id}" },
      list_contacts:      { method: "GET",  path: "/contacts", query: ["per_page", "page"] },
      create_contact:     { method: "POST", path: "/contacts", body: { name: "", email: "" } },
      get_contact:        { method: "GET",  path: "/contacts/{id}" },
      list_agents:        { method: "GET",  path: "/agents" },
    },
    authHeader: (creds) => ({ "Authorization": "Basic " + Buffer.from(creds.apiKey + ":X").toString("base64"), "Content-Type": "application/json" }),
  },

  // ── WooCommerce ─────────────────────────────────────────
  woocommerce: {
    name: "WooCommerce",
    type: "ecommerce",
    description: "WordPress e-commerce — products, orders, customers, coupons, reports",
    baseUrl: "https://{siteUrl}/wp-json/wc/v3",
    authType: "basic",
    credentialKeys: ["siteUrl", "consumerKey", "consumerSecret"],
    capabilities: [
      { name: "manage_products", actions: ["create", "update", "list", "delete"], description: "Manage products" },
      { name: "manage_orders", actions: ["create", "update", "list"], description: "Manage orders" },
      { name: "manage_customers", actions: ["create", "list", "get"], description: "Manage customers" },
      { name: "manage_coupons", actions: ["create", "list"], description: "Manage coupons" },
    ],
    endpoints: {
      list_products:      { method: "GET",  path: "/products", query: ["per_page", "page", "search", "status"] },
      create_product:     { method: "POST", path: "/products", body: { name: "", type: "simple", regular_price: "" } },
      update_product:     { method: "PUT",  path: "/products/{id}", body: {} },
      get_product:        { method: "GET",  path: "/products/{id}" },
      list_orders:        { method: "GET",  path: "/orders", query: ["per_page", "page", "status"] },
      create_order:       { method: "POST", path: "/orders", body: { line_items: [] } },
      update_order:       { method: "PUT",  path: "/orders/{id}", body: {} },
      list_customers:     { method: "GET",  path: "/customers", query: ["per_page", "page", "search"] },
      create_customer:    { method: "POST", path: "/customers", body: { email: "", first_name: "", last_name: "" } },
      list_coupons:       { method: "GET",  path: "/coupons" },
      create_coupon:      { method: "POST", path: "/coupons", body: { code: "", amount: "", discount_type: "percent" } },
      get_reports:        { method: "GET",  path: "/reports/sales", query: ["period"] },
    },
    authHeader: (creds) => ({ "Authorization": "Basic " + Buffer.from(creds.consumerKey + ":" + creds.consumerSecret).toString("base64"), "Content-Type": "application/json" }),
  },

  // ── YouTube ─────────────────────────────────────────────
  youtube: {
    name: "YouTube",
    type: "social_media",
    description: "Video platform — channels, videos, playlists, comments, analytics",
    baseUrl: "https://www.googleapis.com/youtube/v3",
    authType: "oauth",
    credentialKeys: ["accessToken", "apiKey"],
    capabilities: [
      { name: "manage_videos", actions: ["list", "search"], description: "Search and list videos" },
      { name: "manage_channels", actions: ["list"], description: "Get channel information" },
      { name: "manage_playlists", actions: ["list", "create"], description: "Manage playlists" },
      { name: "manage_comments", actions: ["list"], description: "List video comments" },
    ],
    endpoints: {
      search:             { method: "GET",  path: "/search", query: ["q", "type", "part", "maxResults", "order", "key"] },
      list_videos:        { method: "GET",  path: "/videos", query: ["id", "part", "chart", "maxResults", "key"] },
      list_channels:      { method: "GET",  path: "/channels", query: ["id", "part", "mine", "key"] },
      list_playlists:     { method: "GET",  path: "/playlists", query: ["channelId", "part", "maxResults", "key"] },
      list_playlist_items:{ method: "GET",  path: "/playlistItems", query: ["playlistId", "part", "maxResults", "key"] },
      list_comments:      { method: "GET",  path: "/commentThreads", query: ["videoId", "part", "maxResults", "key"] },
    },
    authHeader: (creds) => creds.accessToken ? { "Authorization": `Bearer ${creds.accessToken}` } : {},
  },

  // ── Netlify ─────────────────────────────────────────────
  netlify: {
    name: "Netlify",
    type: "cloud",
    description: "Web deployment — sites, deploys, forms, functions, DNS",
    baseUrl: "https://api.netlify.com/api/v1",
    authType: "api_key",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_sites", actions: ["list", "get", "create"], description: "Manage sites" },
      { name: "manage_deploys", actions: ["list", "create"], description: "Manage deployments" },
      { name: "manage_forms", actions: ["list"], description: "Get form submissions" },
    ],
    endpoints: {
      list_sites:         { method: "GET",  path: "/sites" },
      get_site:           { method: "GET",  path: "/sites/{site_id}" },
      create_site:        { method: "POST", path: "/sites", body: { name: "" } },
      list_deploys:       { method: "GET",  path: "/sites/{site_id}/deploys" },
      get_deploy:         { method: "GET",  path: "/deploys/{deploy_id}" },
      list_forms:         { method: "GET",  path: "/sites/{site_id}/forms" },
      list_form_submissions: { method: "GET", path: "/forms/{form_id}/submissions" },
      list_dns_zones:     { method: "GET",  path: "/dns_zones" },
      get_account:        { method: "GET",  path: "/accounts" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}` }),
  },

  // ── Google Apps Script ──────────────────────────────────
  // Added 2026-10-29: create, fill, version and deploy Apps Script projects (web apps, automations) with the account's
  // Google connection that carries script.projects + script.deployments (a service account can never do this).
  google_apps_script: {
    name: "Google Apps Script",
    type: "developer",
    description: "Create, update, version and deploy Apps Script projects and web apps",
    baseUrl: "https://script.googleapis.com/v1",
    authType: "oauth",
    credentialKeys: ["access_token"],
    capabilities: [
      { name: "projects", actions: ["create", "update", "get"], description: "Script projects and their files" },
      { name: "deploy", actions: ["create", "list"], description: "Versions and web-app deployments" },
    ],
    endpoints: {
      create_project:    { method: "POST", path: "/projects" },
      get_project:       { method: "GET",  path: "/projects/{scriptId}" },
      get_content:       { method: "GET",  path: "/projects/{scriptId}/content" },
      update_content:    { method: "PUT",  path: "/projects/{scriptId}/content" },
      create_version:    { method: "POST", path: "/projects/{scriptId}/versions" },
      list_deployments:  { method: "GET",  path: "/projects/{scriptId}/deployments" },
      create_deployment: { method: "POST", path: "/projects/{scriptId}/deployments" },
      update_deployment: { method: "PUT",  path: "/projects/{scriptId}/deployments/{deploymentId}" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.access_token}`, "Content-Type": "application/json" }),
  },

  // ── npm ─────────────────────────────────────────────────
  // Added 2026-10-29 (Mike: "make that an application people can connect with an API key … this will allow us to publish
  // and create MCP servers"). Connect with an npm access token (automation or granular with publish). Package names are
  // whole path segments, so a scoped name (@scope/name) travels as one encoded segment. Publishing a whole package is the
  // `npm_publish_mcp_server` mini-app (it builds the tarball); `publish_package` is the raw registry PUT it uses.
  npm: {
    name: "npm",
    type: "developer",
    description: "The npm registry — who you are, package details and downloads, search, and publishing packages (including MCP servers)",
    baseUrl: "https://registry.npmjs.org",
    authType: "api_key",
    credentialKeys: ["token"],
    capabilities: [
      { name: "read_packages", actions: ["get", "search"], description: "Package metadata, versions, search and download counts" },
      { name: "publish", actions: ["create"], description: "Publish a package version (use the npm_publish_mcp_server app to build one)" },
    ],
    endpoints: {
      whoami:             { method: "GET", path: "/-/whoami" },
      get_package:        { method: "GET", path: "/{pkg}", wholeSegment: ["pkg"] },
      get_version:        { method: "GET", path: "/{pkg}/{version}", wholeSegment: ["pkg"] },
      search:             { method: "GET", path: "/-/v1/search", query: ["text", "size", "from"] },
      downloads_last_week:{ method: "GET", path: "/downloads/point/last-week/{pkg}", baseUrl: "https://api.npmjs.org" },
      publish_package:    { method: "PUT", path: "/{pkg}", wholeSegment: ["pkg"] },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.token}` }),
  },

  // ── Vercel ──────────────────────────────────────────────
  // Added 2026-10-28 (Mike: "Why is vercel not in the 0n3 catalog?? Put it in there"). The vault already held a `vercel`
  // record (apiKey + teamId) that nothing could call. Credential names match that record. Every path carries its own API
  // version (Vercel versions per endpoint). `teamId` from the record is added to every call unless the caller passes one.
  vercel: {
    name: "Vercel",
    type: "cloud",
    description: "Hosting and deploys — projects, deployments and their build logs, environment variables, domains, aliases",
    baseUrl: "https://api.vercel.com",
    authType: "api_key",
    credentialKeys: ["apiKey", "teamId"],
    capabilities: [
      { name: "manage_projects", actions: ["list", "get"], description: "Projects and their settings (install/build commands, framework)" },
      { name: "manage_deployments", actions: ["list", "get", "create", "cancel"], description: "Deployments, their state and their build log" },
      { name: "manage_env", actions: ["list", "create", "update", "delete"], description: "Project environment variables" },
      { name: "manage_domains", actions: ["list", "add"], description: "Domains, project domains and aliases" },
    ],
    endpoints: {
      get_user:                { method: "GET",    path: "/v2/user" },
      list_teams:              { method: "GET",    path: "/v2/teams" },
      list_projects:           { method: "GET",    path: "/v9/projects" },
      get_project:             { method: "GET",    path: "/v9/projects/{idOrName}" },
      list_deployments:        { method: "GET",    path: "/v6/deployments" },
      get_deployment:          { method: "GET",    path: "/v13/deployments/{idOrUrl}" },
      get_deployment_events:   { method: "GET",    path: "/v3/deployments/{idOrUrl}/events" },
      create_deployment:       { method: "POST",   path: "/v13/deployments", query: ["forceNew", "skipAutoDetectionConfirmation"], body: { name: "", target: "production" } },
      cancel_deployment:       { method: "PATCH",  path: "/v12/deployments/{id}/cancel" },
      list_deployment_aliases: { method: "GET",    path: "/v2/deployments/{id}/aliases" },
      list_env:                { method: "GET",    path: "/v9/projects/{idOrName}/env" },
      create_env:              { method: "POST",   path: "/v10/projects/{idOrName}/env", query: ["upsert"], body: { key: "", value: "", type: "encrypted", target: ["production"] } },
      update_env:              { method: "PATCH",  path: "/v9/projects/{idOrName}/env/{id}" },
      delete_env:              { method: "DELETE", path: "/v9/projects/{idOrName}/env/{id}" },
      list_project_domains:    { method: "GET",    path: "/v9/projects/{idOrName}/domains" },
      add_project_domain:      { method: "POST",   path: "/v10/projects/{idOrName}/domains", body: { name: "" } },
      list_domains:            { method: "GET",    path: "/v5/domains" },
      list_aliases:            { method: "GET",    path: "/v4/aliases" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}` }),
    defaultQuery: (creds) => (creds.teamId ? { teamId: creds.teamId } : {}),
  },

  // ── Cloudflare (already exists but ensure it's comprehensive) ──

  // ── Pinterest ───────────────────────────────────────────
  pinterest: {
    name: "Pinterest",
    type: "social_media",
    description: "Visual discovery — pins, boards, ads, analytics",
    baseUrl: "https://api.pinterest.com/v5",
    authType: "oauth",
    credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_pins", actions: ["create", "list", "get"], description: "Manage pins" },
      { name: "manage_boards", actions: ["create", "list"], description: "Manage boards" },
      { name: "analytics", actions: ["get"], description: "Get account analytics" },
    ],
    endpoints: {
      create_pin:         { method: "POST", path: "/pins", body: { board_id: "", title: "", description: "", media_source: {} } },
      list_pins:          { method: "GET",  path: "/pins", query: ["bookmark", "page_size"] },
      get_pin:            { method: "GET",  path: "/pins/{pin_id}" },
      list_boards:        { method: "GET",  path: "/boards", query: ["bookmark", "page_size"] },
      create_board:       { method: "POST", path: "/boards", body: { name: "", description: "" } },
      get_user_account:   { method: "GET",  path: "/user_account" },
      get_analytics:      { method: "GET",  path: "/user_account/analytics", query: ["start_date", "end_date", "metric_types"] },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── BigCommerce ──────────────────────────────────────────
  bigcommerce: {
    name: "BigCommerce", type: "ecommerce",
    description: "E-commerce platform — products, orders, customers, categories",
    baseUrl: "https://api.bigcommerce.com/stores/{store_hash}/v3",
    authType: "api_key", credentialKeys: ["accessToken", "storeHash"],
    capabilities: [
      { name: "manage_products", actions: ["create", "list", "get"], description: "Manage products" },
      { name: "manage_orders", actions: ["list", "get"], description: "Manage orders" },
      { name: "manage_customers", actions: ["create", "list"], description: "Manage customers" },
    ],
    endpoints: {
      list_products:  { method: "GET",  path: "/catalog/products", query: ["page", "limit"] },
      create_product: { method: "POST", path: "/catalog/products", body: { name: "", type: "physical", weight: 0, price: 0 } },
      get_product:    { method: "GET",  path: "/catalog/products/{product_id}" },
      list_orders:    { method: "GET",  path: "/orders", query: ["page", "limit"] },
      get_order:      { method: "GET",  path: "/orders/{order_id}" },
      list_customers: { method: "GET",  path: "/customers", query: ["page", "limit"] },
      create_customer:{ method: "POST", path: "/customers", body: [{ email: "", first_name: "", last_name: "" }] },
      list_categories:{ method: "GET",  path: "/catalog/categories" },
    },
    authHeader: (creds) => ({ "X-Auth-Token": creds.accessToken, "Content-Type": "application/json" }),
  },

  // ── Twitch ──────────────────────────────────────────────
  twitch: {
    name: "Twitch", type: "social_media",
    description: "Live streaming — streams, users, channels, clips, chat",
    baseUrl: "https://api.twitch.tv/helix",
    authType: "oauth", credentialKeys: ["accessToken", "clientId"],
    capabilities: [
      { name: "manage_streams", actions: ["list"], description: "Get stream info" },
      { name: "manage_users", actions: ["get", "search"], description: "Get user data" },
      { name: "manage_clips", actions: ["list", "create"], description: "Manage clips" },
    ],
    endpoints: {
      get_streams:       { method: "GET", path: "/streams", query: ["user_id", "user_login", "game_id", "first"] },
      get_users:         { method: "GET", path: "/users", query: ["id", "login"] },
      search_channels:   { method: "GET", path: "/search/channels", query: ["query", "first"] },
      get_clips:         { method: "GET", path: "/clips", query: ["broadcaster_id", "id", "first"] },
      create_clip:       { method: "POST", path: "/clips", query: ["broadcaster_id"] },
      get_channel_info:  { method: "GET", path: "/channels", query: ["broadcaster_id"] },
      get_top_games:     { method: "GET", path: "/games/top", query: ["first"] },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Client-Id": creds.clientId }),
  },

  // ── Wave ────────────────────────────────────────────────
  wave: {
    name: "Wave", type: "accounting",
    description: "Free accounting — invoicing, payments, expenses via GraphQL",
    baseUrl: "https://gql.waveapps.com/graphql/public",
    authType: "oauth", credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_invoices", actions: ["create", "list"], description: "Manage invoices" },
      { name: "manage_customers", actions: ["create", "list"], description: "Manage customers" },
    ],
    endpoints: {
      graphql: { method: "POST", path: "/", body: { query: "" } },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── Loom ────────────────────────────────────────────────
  loom: {
    name: "Loom", type: "productivity",
    description: "Video messaging — recordings, transcripts, workspace",
    baseUrl: "https://developer.loom.com",
    authType: "api_key", credentialKeys: ["accessToken"],
    capabilities: [
      { name: "manage_videos", actions: ["list", "get", "delete"], description: "Manage recordings" },
    ],
    endpoints: {
      list_videos:         { method: "POST", path: "/v1/videos", body: {} },
      get_video:           { method: "GET",  path: "/v1/videos/{id}" },
      delete_video:        { method: "DELETE", path: "/v1/videos/{id}" },
      get_video_transcript:{ method: "GET",  path: "/v1/videos/{id}/transcript" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── Google Cloud ────────────────────────────────────────
  gcloud: {
    name: "Google Cloud", type: "cloud",
    description: "GCP — Cloud Storage, Compute Engine, BigQuery",
    baseUrl: "https://storage.googleapis.com/storage/v1",
    authType: "oauth", credentialKeys: ["accessToken", "projectId"],
    capabilities: [
      { name: "manage_storage", actions: ["list_buckets", "list_objects"], description: "Cloud Storage" },
    ],
    endpoints: {
      list_buckets:  { method: "GET", path: "/b", query: ["project"] },
      get_bucket:    { method: "GET", path: "/b/{bucket}" },
      list_objects:  { method: "GET", path: "/b/{bucket}/o", query: ["prefix", "maxResults"] },
      get_object:    { method: "GET", path: "/b/{bucket}/o/{object}" },
      delete_object: { method: "DELETE", path: "/b/{bucket}/o/{object}" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}` }),
  },

  // ── Neon ────────────────────────────────────────────────
  neon: {
    name: "Neon", type: "database",
    description: "Serverless Postgres — projects, branches, databases, endpoints",
    baseUrl: "https://console.neon.tech/api/v2",
    authType: "api_key", credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_projects", actions: ["create", "list", "delete"], description: "Manage projects" },
      { name: "manage_branches", actions: ["create", "list"], description: "Manage branches" },
    ],
    endpoints: {
      list_projects:  { method: "GET",  path: "/projects" },
      create_project: { method: "POST", path: "/projects", body: { project: { name: "" } } },
      get_project:    { method: "GET",  path: "/projects/{project_id}" },
      delete_project: { method: "DELETE", path: "/projects/{project_id}" },
      list_branches:  { method: "GET",  path: "/projects/{project_id}/branches" },
      create_branch:  { method: "POST", path: "/projects/{project_id}/branches", body: {} },
      list_databases: { method: "GET",  path: "/projects/{project_id}/branches/{branch_id}/databases" },
      list_endpoints: { method: "GET",  path: "/projects/{project_id}/endpoints" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── PlanetScale ─────────────────────────────────────────
  planetscale: {
    name: "PlanetScale", type: "database",
    description: "Serverless MySQL — databases, branches, deploy requests",
    baseUrl: "https://api.planetscale.com/v1",
    authType: "oauth", credentialKeys: ["accessToken", "organizationId"],
    capabilities: [
      { name: "manage_databases", actions: ["create", "list", "delete"], description: "Manage databases" },
      { name: "manage_branches", actions: ["create", "list"], description: "Manage branches" },
    ],
    endpoints: {
      list_databases:       { method: "GET",  path: "/organizations/{organization}/databases" },
      create_database:      { method: "POST", path: "/organizations/{organization}/databases", body: { name: "" } },
      get_database:         { method: "GET",  path: "/organizations/{organization}/databases/{database}" },
      delete_database:      { method: "DELETE", path: "/organizations/{organization}/databases/{database}" },
      list_branches:        { method: "GET",  path: "/organizations/{organization}/databases/{database}/branches" },
      create_branch:        { method: "POST", path: "/organizations/{organization}/databases/{database}/branches", body: { name: "" } },
      list_deploy_requests: { method: "GET",  path: "/organizations/{organization}/databases/{database}/deploy-requests" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.accessToken}`, "Content-Type": "application/json" }),
  },

  // ── Turso ───────────────────────────────────────────────
  turso: {
    name: "Turso", type: "database",
    description: "Edge SQLite — databases, groups, locations, tokens",
    baseUrl: "https://api.turso.tech/v1",
    authType: "api_key", credentialKeys: ["apiToken", "organizationName"],
    capabilities: [
      { name: "manage_databases", actions: ["create", "list", "delete"], description: "Manage databases" },
      { name: "manage_groups", actions: ["create", "list"], description: "Manage groups" },
    ],
    endpoints: {
      list_databases:  { method: "GET",  path: "/organizations/{organizationName}/databases" },
      create_database: { method: "POST", path: "/organizations/{organizationName}/databases", body: { name: "", group: "default" } },
      get_database:    { method: "GET",  path: "/organizations/{organizationName}/databases/{databaseName}" },
      delete_database: { method: "DELETE", path: "/organizations/{organizationName}/databases/{databaseName}" },
      list_groups:     { method: "GET",  path: "/organizations/{organizationName}/groups" },
      create_group:    { method: "POST", path: "/organizations/{organizationName}/groups", body: { name: "", location: "ord" } },
      list_locations:  { method: "GET",  path: "/organizations/{organizationName}/locations" },
      create_token:    { method: "POST", path: "/organizations/{organizationName}/databases/{databaseName}/auth/tokens" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiToken}`, "Content-Type": "application/json" }),
  },

  // ── CockroachDB ─────────────────────────────────────────
  cockroachdb: {
    name: "CockroachDB", type: "database",
    description: "Distributed SQL — clusters, databases, SQL users, backups",
    baseUrl: "https://cockroachlabs.cloud/api/v1",
    authType: "api_key", credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_clusters", actions: ["create", "list", "get"], description: "Manage clusters" },
    ],
    endpoints: {
      list_clusters:   { method: "GET",  path: "/clusters" },
      create_cluster:  { method: "POST", path: "/clusters", body: { name: "", provider: "GCP", spec: {} } },
      get_cluster:     { method: "GET",  path: "/clusters/{cluster_id}" },
      delete_cluster:  { method: "DELETE", path: "/clusters/{cluster_id}" },
      list_sql_users:  { method: "GET",  path: "/clusters/{cluster_id}/sql-users" },
      create_sql_user: { method: "POST", path: "/clusters/{cluster_id}/sql-users", body: { name: "", password: "" } },
      list_databases:  { method: "GET",  path: "/clusters/{cluster_id}/databases" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── Railway ─────────────────────────────────────────────
  railway: {
    name: "Railway", type: "cloud",
    description: "Deploy anything — projects, services, environments via GraphQL",
    baseUrl: "https://backboard.railway.app/graphql/v2",
    authType: "api_key", credentialKeys: ["apiToken"],
    capabilities: [
      { name: "manage_projects", actions: ["create", "list"], description: "Manage projects" },
    ],
    endpoints: {
      graphql: { method: "POST", path: "/", body: { query: "" } },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiToken}`, "Content-Type": "application/json" }),
  },

  // ── Render ──────────────────────────────────────────────
  render: {
    name: "Render", type: "cloud",
    description: "Cloud platform — web services, static sites, databases, cron jobs",
    baseUrl: "https://api.render.com/v1",
    authType: "api_key", credentialKeys: ["apiKey"],
    capabilities: [
      { name: "manage_services", actions: ["create", "list", "get"], description: "Manage services" },
      { name: "manage_deploys", actions: ["list", "create"], description: "Manage deploys" },
    ],
    endpoints: {
      list_services:  { method: "GET",  path: "/services", query: ["limit", "cursor", "type"] },
      get_service:    { method: "GET",  path: "/services/{serviceId}" },
      create_service: { method: "POST", path: "/services", body: { type: "web_service", name: "" } },
      list_deploys:   { method: "GET",  path: "/services/{serviceId}/deploys", query: ["limit"] },
      create_deploy:  { method: "POST", path: "/services/{serviceId}/deploys", body: {} },
      get_deploy:     { method: "GET",  path: "/services/{serviceId}/deploys/{deployId}" },
      list_env_groups:{ method: "GET",  path: "/env-groups" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── CloudConvert ────────────────────────────────────────────────
  cloudconvert: {
    name: "CloudConvert",
    type: "utility",
    description: "File conversion API — convert between 200+ formats (PDF, DOCX, PNG, MP4, etc.), optimize, merge, capture websites, create thumbnails",
    baseUrl: "https://api.cloudconvert.com/v2",
    authType: "apiKey",
    credentialKeys: ["apiKey"],
    capabilities: [
      "convert files between 200+ formats",
      "merge PDFs and documents",
      "optimize images and PDFs",
      "capture website screenshots",
      "create thumbnails from documents",
      "extract text from PDFs (OCR)",
      "convert spreadsheets to CSV/JSON",
      "watermark PDFs",
      "compress videos",
      "manage conversion jobs and tasks",
    ],
    endpoints: {
      // Jobs (multi-step conversion pipelines)
      create_job:         { method: "POST", path: "/jobs", body: { tasks: {} } },
      list_jobs:          { method: "GET",  path: "/jobs", query: ["status", "tag", "per_page", "page"] },
      get_job:            { method: "GET",  path: "/jobs/{jobId}" },
      delete_job:         { method: "DELETE", path: "/jobs/{jobId}" },
      wait_job:           { method: "GET",  path: "/jobs/{jobId}/wait" },

      // Tasks
      create_task:        { method: "POST", path: "/tasks", body: { operation: "", input: "" } },
      list_tasks:         { method: "GET",  path: "/tasks", query: ["status", "operation", "job_id", "per_page", "page"] },
      get_task:           { method: "GET",  path: "/tasks/{taskId}" },
      delete_task:        { method: "DELETE", path: "/tasks/{taskId}" },
      wait_task:          { method: "GET",  path: "/tasks/{taskId}/wait" },
      cancel_task:        { method: "POST", path: "/tasks/{taskId}/cancel" },
      retry_task:         { method: "POST", path: "/tasks/{taskId}/retry" },

      // Conversion operations
      convert:            { method: "POST", path: "/convert", body: { input: "", input_format: "", output_format: "" } },
      optimize:           { method: "POST", path: "/optimize", body: { input: "", input_format: "" } },
      capture_website:    { method: "POST", path: "/capture-website", body: { url: "", output_format: "pdf" } },
      create_thumbnail:   { method: "POST", path: "/thumbnail", body: { input: "", output_format: "png" } },
      merge:              { method: "POST", path: "/merge", body: { input: [], output_format: "pdf" } },
      create_archive:     { method: "POST", path: "/archive", body: { input: [], output_format: "zip" } },
      watermark:          { method: "POST", path: "/watermark", body: { input: "", input_format: "pdf" } },
      metadata:           { method: "POST", path: "/metadata", body: { input: "", input_format: "" } },

      // Import/Export (file transfer)
      import_url:         { method: "POST", path: "/import/url", body: { url: "" } },
      import_upload:      { method: "POST", path: "/import/upload" },
      import_s3:          { method: "POST", path: "/import/s3", body: { bucket: "", region: "", key: "" } },
      import_google_cloud: { method: "POST", path: "/import/google-cloud-storage", body: { bucket: "", key: "" } },
      export_url:         { method: "POST", path: "/export/url", body: { input: "" } },
      export_s3:          { method: "POST", path: "/export/s3", body: { input: "", bucket: "", region: "", key: "" } },
      export_google_cloud: { method: "POST", path: "/export/google-cloud-storage", body: { input: "", bucket: "", key: "" } },

      // Users & Usage
      get_user:           { method: "GET",  path: "/users/me" },
      get_balance:        { method: "GET",  path: "/users/me/balance" },

      // Webhooks
      create_webhook:     { method: "POST", path: "/webhooks", body: { url: "", events: [] } },
      list_webhooks:      { method: "GET",  path: "/webhooks" },
      delete_webhook:     { method: "DELETE", path: "/webhooks/{webhookId}" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.apiKey}`, "Content-Type": "application/json" }),
  },

  // ── shadcn/ui registry ─────────────────────────────────────
  shadcn: {
    name: "shadcn/ui",
    type: "design-system",
    description: "shadcn/ui component registry — search, recommend, and install official primitives + curated blocks. The default UI system across the 0n ecosystem.",
    baseUrl: "https://ui.shadcn.com",
    authType: "none",
    credentialKeys: [],
    capabilities: [
      { name: "list_components", actions: ["list"], description: "List all official shadcn primitives, grouped by purpose" },
      { name: "search_components", actions: ["search"], description: "Fuzzy search components by name or description" },
      { name: "get_component", actions: ["get"], description: "Fetch live component schema (files, deps, source) from the registry" },
      { name: "install_command", actions: ["build"], description: "Generate `npx shadcn@latest add <name>` install command" },
      { name: "list_blocks", actions: ["list"], description: "List curated block patterns (login, dashboard, pricing, FAQ, etc.)" },
      { name: "recommend", actions: ["recommend"], description: "Recommend components for a free-text use case" },
      { name: "theme", actions: ["get"], description: "Return brand-themed @theme inline CSS for Tailwind v4" },
      { name: "init", actions: ["build"], description: "One-shot bootstrap commands for new projects" },
    ],
    endpoints: {
      get_component_schema: { method: "GET", path: "/r/styles/new-york/{name}.json" },
      get_index:            { method: "GET", path: "/r/styles/new-york/index.json" },
    },
    authHeader: () => ({ "User-Agent": "0nMCP/4.10", "Accept": "application/json" }),
  },

  // ── CrewAI Enterprise ─────────────────────────────────────
  // Wraps the per-crew REST API at https://<crew>.crewai.com.
  // 50 free crew runs/month on the CrewAI free tier.
  // Standalone MCP server also published as `0nmcp-crewai` on npm.
  crewai: {
    name: "CrewAI",
    type: "ai-agents",
    description: "Multi-agent orchestration via CrewAI Enterprise. Kick off crew runs, check status, list inputs, resume paused runs. 50 free runs/month per account on the free tier.",
    baseUrl: "https://crew.crewai.com", // placeholder — actual base is per-crew, resolved at call time
    authType: "bearer",
    credentialKeys: ["bearerToken", "crewName"],
    capabilities: [
      { name: "kickoff", actions: ["create"], description: "Start a crew run with the given inputs. Returns kickoff_id." },
      { name: "status", actions: ["get"], description: "Check progress of a running crew." },
      { name: "get_inputs", actions: ["list"], description: "List the inputs a crew expects." },
      { name: "resume", actions: ["create"], description: "Resume a paused run waiting on human input." },
    ],
    endpoints: {
      kickoff:    { method: "POST", path: "/kickoff", body: { inputs: {}, meta: {}, taskWebhookUrl: "", stepWebhookUrl: "", crewWebhookUrl: "" } },
      status:     { method: "GET",  path: "/status/{kickoffId}" },
      get_inputs: { method: "GET",  path: "/inputs" },
      resume:     { method: "POST", path: "/resume", body: { kickoff_id: "", task_outputs: {} } },
    },
    authHeader: (creds) => ({
      "Authorization": `Bearer ${creds.bearerToken}`,
      "Content-Type": "application/json",
      "Accept": "application/json",
    }),
  },

  // ============================================================
  // v4.10.0 — 0nCore product surface (UCP, Marketplace, builders)
  // Each wraps the corresponding onork-app HTTP endpoint.
  // ============================================================

  // ── UCP — Universal Commerce Protocol ─────────────────────
  ucp: {
    name: "UCP — Universal Commerce Protocol",
    type: "commerce",
    description: "Universal commerce: discover, list, and check out any product/app/download from the unified 0n catalog. One protocol, every store.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "list_offers",       actions: ["list"],   description: "List all active products, downloads, and plans" },
      { name: "create_checkout",   actions: ["create"], description: "Generate a Stripe Checkout session for a product slug" },
      { name: "get_download_link", actions: ["get"],    description: "Verify entitlement and return a signed download URL" },
      { name: "list_purchases",    actions: ["list"],   description: "List the user's completed purchases" },
    ],
    endpoints: {
      list_offers:       { method: "GET",  path: "/api/commerce/offers", query: ["category", "limit"] },
      create_checkout:   { method: "POST", path: "/api/commerce/checkout", body: { slug: "", quantity: 1 } },
      get_download_link: { method: "GET",  path: "/api/commerce/download", query: ["slug"] },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Marketplace — .0n App Marketplace ─────────────────────
  marketplace: {
    name: ".0n App Marketplace",
    type: "marketplace",
    description: "Browse, install, and execute .0n apps + first-party 0nCore products. Unified catalog of UCP products and marketplace apps with plan-aware install + Stripe checkout.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "list_apps",     actions: ["list"],    description: "Browse the unified catalog (UCP products + apps)" },
      { name: "install_app",   actions: ["install"], description: "Install a free app for the current location" },
      { name: "checkout_app",  actions: ["create"],  description: "Stripe checkout for a paid app" },
      { name: "execute_app",   actions: ["run"],     description: "Execute an installed .0n app" },
      { name: "list_installed",actions: ["list"],    description: "List apps installed on the current location" },
    ],
    endpoints: {
      list_apps:      { method: "GET",  path: "/api/widgets/marketplace/catalog", query: ["locationId", "mode"] },
      install_app:    { method: "POST", path: "/api/widgets/marketplace/install",  body: { slug: "", source: "" } },
      checkout_app:   { method: "POST", path: "/api/widgets/marketplace/checkout", body: { slug: "", source: "" } },
      execute_app:    { method: "POST", path: "/api/marketplace/execute/{appId}",  body: {} },
      list_installed: { method: "GET",  path: "/api/marketplace/my-apps" },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Course Builder — AI course generator ──────────────────
  course_builder: {
    name: "0n Course Builder",
    type: "ai-builder",
    description: "Generate complete courses from a description. Outline + lesson content + quizzes + sales page, published into the connected courses platform. Radial-burst lesson generation; graceful publish fallback.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "generate_course", actions: ["create"], description: "End-to-end course generation: outline + all lessons + sales page" },
      { name: "list_courses",    actions: ["list"],   description: "List previously-generated courses" },
      { name: "publish_course",  actions: ["create"], description: "Publish a generated course (graceful fallback if rejected)" },
    ],
    endpoints: {
      generate_course: { method: "POST", path: "/api/course-builder/courses", body: { topic: "", audience: "", lessonCount: 6, includeQuizzes: true, learningOutcome: "", tone: "professional" } },
      list_courses:    { method: "GET",  path: "/api/course-builder/courses", query: ["status", "limit"] },
      publish_course:  { method: "POST", path: "/api/course-builder/courses/{id}/publish", body: { priceCents: 0 } },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Lead Magnet — viral growth loop ───────────────────────
  lead_magnet: {
    name: "0n Lead Magnet",
    type: "marketing",
    description: "Run viral growth loops. Landing page + opt-in + ebook delivery + recommendations modal + builtwith page. Every funnel grows the customer's list AND grows the platform.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "list_funnels",     actions: ["list"],   description: "List the user's funnels with subscriber stats" },
      { name: "create_funnel",    actions: ["create"], description: "Create a new lead-magnet funnel" },
      { name: "update_funnel",    actions: ["update"], description: "Update funnel config (offer, copy, redirects)" },
      { name: "set_recommendations", actions: ["update"], description: "Bulk-replace the modal's ordered recommendation list" },
      { name: "record_optin",     actions: ["create"], description: "Record a public opt-in (used by landing pages)" },
      { name: "get_recommendations", actions: ["get"], description: "Read the modal's config + active recommendations" },
    ],
    endpoints: {
      list_funnels:           { method: "GET",  path: "/api/lead-magnet/funnels" },
      create_funnel:          { method: "POST", path: "/api/lead-magnet/funnels",  body: { funnel_name: "", offer_title: "", offer_description: "", offer_file_url: "" } },
      get_funnel:             { method: "GET",  path: "/api/lead-magnet/funnels/{funnelId}" },
      update_funnel:          { method: "PUT",  path: "/api/lead-magnet/funnels/{funnelId}", body: {} },
      set_recommendations:    { method: "PUT",  path: "/api/lead-magnet/funnels/{funnelId}/recommendations", body: { recommendations: [] } },
      record_optin:           { method: "POST", path: "/api/lead-magnet/opt-in", body: { email: "", funnel_id: "default" } },
      get_recommendations:    { method: "GET",  path: "/api/lead-magnet/recommendations", query: ["funnel_id"] },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Automation Builder — visual + agentic ─────────────────
  automation_builder: {
    name: "0n Automation Builder",
    type: "ai-builder",
    description: "Generate, test, save, schedule, and run automations from natural language. Backed by the visual workflow canvas + .0n SWITCH file format. Mutations gated by user confirmation.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "generate_workflow", actions: ["create"], description: "Natural language → .0n workflow JSON (non-mutating)" },
      { name: "test_workflow",     actions: ["create"], description: "Dry-run a workflow against sample input (non-mutating)" },
      { name: "activate_workflow", actions: ["create"], description: "Save + register trigger (cron or webhook) + activate" },
      { name: "run_workflow",      actions: ["create"], description: "Execute a saved workflow on-demand" },
      { name: "list_workflows",    actions: ["list"],   description: "List the user's saved workflows" },
      { name: "suggest",           actions: ["create"], description: "AI-powered next-capability suggestions for a workflow-in-progress" },
    ],
    endpoints: {
      generate_workflow: { method: "POST", path: "/api/automations/generate", body: { description: "" } },
      test_workflow:     { method: "POST", path: "/api/automations/execute",  body: { workflow: {}, dryRun: true } },
      activate_workflow: { method: "POST", path: "/api/automations/activate", body: { workflow: {} } },
      run_workflow:      { method: "POST", path: "/api/automations/execute",  body: { workflow: {} } },
      list_workflows:    { method: "GET",  path: "/api/automations/list" },
      suggest:           { method: "POST", path: "/api/automations/suggest",  body: { currentNodes: [] } },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── SaaS Factory — full SaaS provisioning ─────────────────
  saas_factory: {
    name: "0n SaaS Factory",
    type: "ai-builder",
    description: "One-shot provisioning of a complete SaaS for a customer or sub-account: brand-themed landing page, auth, billing pipeline, custom domain wiring, CRM mirror. The same factory that ships RocketPost-style apps.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "provision_saas",  actions: ["create"], description: "Provision a new SaaS instance with brand, auth, billing, domain" },
      { name: "deploy_snapshot", actions: ["create"], description: "Deploy a starter snapshot (custom fields, tags, pipelines, custom values) to a sub-account" },
      { name: "configure_billing", actions: ["update"], description: "Configure Stripe products + tier mapping for a SaaS instance" },
    ],
    endpoints: {
      provision_saas:    { method: "POST", path: "/api/provision",                 body: { brand: "", domain: "" } },
      deploy_snapshot:   { method: "POST", path: "/api/snapshots/deploy",           body: { locationId: "", version: 0 } },
      configure_billing: { method: "POST", path: "/api/marketplace/onboard",       body: {} },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── App Builder — .0n app generator ───────────────────────
  app_builder: {
    name: "0n App Builder",
    type: "ai-builder",
    description: "Generate a .0n app from a description. Produces a packaged .0n bundle that installs via the marketplace and runs against the universal capability surface.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "generate_app", actions: ["create"], description: "Build a complete .0n app from a description" },
      { name: "publish_app",  actions: ["create"], description: "Publish a generated app to the marketplace" },
      { name: "execute_app",  actions: ["run"],    description: "Execute an installed .0n app for a location" },
    ],
    endpoints: {
      generate_app: { method: "POST", path: "/api/app-builder/generate",       body: { description: "", capabilities: [] } },
      publish_app:  { method: "POST", path: "/api/marketplace/publish",        body: {} },
      execute_app:  { method: "POST", path: "/api/marketplace/execute/{appId}",body: {} },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Website Builder — landing + multi-page generator ──────
  website_builder: {
    name: "0n AI Website Editor",
    type: "ai-builder",
    description: "AI Website Editor — describe an outcome, get a live editable site. Drag-and-drop canvas, block-level AI editing, import an existing site, brand-aware copy, safe publish (fallback / editable / frozen), curated shadcn themes, and one-shot Vercel deploy. The /studio editor and the 0nCore renderer behind one API.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "list_themes",   actions: ["list"],   description: "List the curated shadcn themes" },
      { name: "generate_page", actions: ["create"], description: "Generate a page from brand + theme + prompt" },
      { name: "plan_edit",     actions: ["create"], description: "Plan an AI edit or a site import as a reviewable page spec" },
      { name: "render_page",   actions: ["create"], description: "Render a page spec to HTML — document, widget, or blog target" },
      { name: "deploy_page",   actions: ["create"], description: "One-shot Vercel deploy of a generated page" },
    ],
    endpoints: {
      list_themes:    { method: "GET",  path: "/api/landing-pages/themes" },
      generate_page:  { method: "POST", path: "/api/landing-pages/generate", body: { theme: "", brand: {}, prompt: "" } },
      render_targets: { method: "GET",  path: "/api/site/targets" },
      plan_edit:      { method: "POST", path: "/api/site/plan",   body: { spec: {}, instruction: "" } },
      render_page:    { method: "POST", path: "/api/site/render", body: { spec: {}, target: "document" } },
      deploy_page:    { method: "POST", path: "/api/landing-pages/deploy", body: { page: {}, domain: "" } },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Agentic Automation Generator ──────────────────────────
  agentic_automation: {
    name: "Agentic Automation Generator",
    type: "agentic-ai",
    description: "Tell it what you want done. The agent breaks it down, picks tools, configures inputs, runs the workflow, and reports outcomes. Combines automation_builder + 0nMCP's full tool catalog into a self-driving generator.",
    baseUrl: "https://0ncore.com",
    authType: "bearer_or_session",
    credentialKeys: ["onToken"],
    capabilities: [
      { name: "generate_plan",  actions: ["create"], description: "Decompose an outcome into a step plan with tool selections" },
      { name: "execute_plan",   actions: ["run"],    description: "Execute a generated plan with confirmation gating on mutations" },
      { name: "iterate_plan",   actions: ["update"], description: "Refine a plan based on user feedback" },
    ],
    endpoints: {
      generate_plan: { method: "POST", path: "/api/agentic/plan",     body: { outcome: "", context: {} } },
      execute_plan:  { method: "POST", path: "/api/agentic/execute",  body: { planId: "", autoApprove: false } },
      iterate_plan:  { method: "POST", path: "/api/agentic/iterate",  body: { planId: "", feedback: "" } },
    },
    authHeader: (creds) => ({ "Authorization": `Bearer ${creds.onToken}`, "Content-Type": "application/json" }),
  },

  // ── Detect & Refine — closed-loop ad optimization ─────────
  detect_and_refine: {
    name: "Detect & Refine",
    type: "ad-intelligence",
    description: "Behavioral tracking + Groq grading. Score every visitor click A+ → F, route the signal back to ad networks (Google, Meta, LinkedIn, TikTok, X), and optionally export graded rows to a Google Sheet. Closes the loop between ad spend and real conversion intent.",
    baseUrl: "https://detect-and-refine-cryptogoatz.vercel.app",
    authType: "supabase_service_role",
    credentialKeys: ["oncore_supabase_service_key"],
    capabilities: [
      { name: "track",           actions: ["ingest"], description: "Beacon ingestion — find-or-create dr_clicks row, upsert dr_sessions by uuid" },
      { name: "grade",           actions: ["score"],  description: "Rule-based + Groq openai/gpt-oss-20b refinement, persists to dr_ai_scores" },
      { name: "lookup_grade",    actions: ["read"],   description: "Fetch latest grade for a session_id, click_id, or click_id_value" },
      { name: "rollup",          actions: ["read"],   description: "Counts by grade, network, and crm_pipeline (sale/nurture/dead/x)" },
      { name: "export_to_sheet", actions: ["append"], description: "Append graded rows to a Google Sheet via OAuth (composes with google_sheets)" },
    ],
    endpoints: {
      track: { method: "POST", path: "/api/track" },
      grade: { method: "POST", path: "/api/grade" },
      stats: { method: "GET",  path: "/api/stats" },
    },
    tools: ["dr_track", "dr_grade", "dr_get_grade", "dr_get_rollup", "dr_export_to_sheet"],
  },

  // ── Rocket Convert — unified Forms + Pages + Commerce ─────
  rocket_convert: {
    name: "Rocket Convert",
    type: "conversion-suite",
    description: "Unified RocketPost + CRO9 + Detect & Refine product. Tier 1 (live): AI-generated forms with email follow-up sequences and CRO9-driven A/B variant testing via Thompson-sampling bandits. Tier 2 (stubbed): AI landing pages with LVOS variant optimization. Tier 3 (stubbed): commerce + Stripe/PayPal with product-page testing. Composes with detect_and_refine (DR grades each submission) and crm (sequences enroll into CRM workflows).",
    baseUrl: "https://detect-and-refine-cryptogoatz.vercel.app",
    authType: "supabase_service_role",
    credentialKeys: ["oncore_supabase_service_key", "groq_api_key"],
    capabilities: [
      { name: "form_create",       actions: ["generate"], description: "AI generates form fields + headline + CTA from a goal prompt" },
      { name: "form_publish",      actions: ["update"],   description: "Flip form to published — required before embed renders it" },
      { name: "form_render",       actions: ["read"],     description: "Pick a CRO9 variant via Thompson sampling and return the merged spec" },
      { name: "form_submit",       actions: ["create"],   description: "Record submission, attribute to variant, optionally enroll in sequence" },
      { name: "form_variants",     actions: ["generate"], description: "Groq creates A/B headline / CTA / color variants — bandit explores them automatically" },
      { name: "sequence_create",   actions: ["generate"], description: "Define email follow-up; AI drafts steps from goal if none provided" },
      { name: "sequence_enroll",   actions: ["create"],   description: "Enroll an email — locally + (when bound) into the linked CRM workflow" },
    ],
    endpoints: {
      form_create: { method: "POST", path: "/api/rc/forms" },
      form_render: { method: "GET",  path: "/api/rc/forms/{id}/render" },
      form_submit: { method: "POST", path: "/api/rc/forms/{id}/submit" },
    },
    tools: [
      "rc_form_create",
      "rc_form_get",
      "rc_form_update",
      "rc_form_publish",
      "rc_form_list",
      "rc_form_render",
      "rc_form_submit",
      "rc_form_variants_generate",
      "rc_form_variant_pick",
      "rc_sequence_create",
      "rc_sequence_get",
      "rc_sequence_enroll",
    ],
    notes: "Tiers 2/3 schema is in place (rc_pages, rc_page_variants, rc_products, rc_orders) but tool surface is Tier 1 only for v1. Tier 2 ships next sprint.",
  },

};

// ── Helpers ────────────────────────────────────────────────

/**
 * Alias → canonical key, built once from the catalog itself.
 *
 * An alias exists so a credential ALREADY in someone's vault under an older or
 * shorter name keeps working — `ga4` for `google_analytics`. It is NOT a second
 * service: aliases are deliberately absent from `listServices()`, because a
 * catalogue that counts the same thing twice is how "116 services" becomes
 * three different numbers on three different pages.
 */
const ALIASES = (() => {
  const m = new Map();
  for (const [key, svc] of Object.entries(SERVICE_CATALOG)) {
    for (const a of svc.aliases || []) {
      if (SERVICE_CATALOG[a]) throw new Error(`catalog: alias "${a}" collides with a real service`);
      if (m.has(a)) throw new Error(`catalog: alias "${a}" claimed by both ${m.get(a)} and ${key}`);
      m.set(a, key);
    }
  }
  return m;
})();

export function getService(key) {
  return SERVICE_CATALOG[key] || SERVICE_CATALOG[ALIASES.get(key)] || null;
}

/** The catalog's own name for a service, given any name it answers to. */
export function canonicalService(key) {
  return SERVICE_CATALOG[key] ? key : (ALIASES.get(key) || null);
}

export function listServices() {
  return Object.entries(SERVICE_CATALOG).map(([key, svc]) => ({
    key,
    name: svc.name,
    type: svc.type,
    description: svc.description,
    authType: svc.authType,
    credentialKeys: svc.credentialKeys,
    capabilityCount: svc.capabilities.length,
  }));
}

export function getServicesByType(type) {
  return Object.entries(SERVICE_CATALOG)
    .filter(([, svc]) => svc.type === type)
    .map(([key, svc]) => ({ key, ...svc }));
}

export function findServiceForCapability(capabilityName) {
  const matches = [];
  for (const [key, svc] of Object.entries(SERVICE_CATALOG)) {
    const cap = svc.capabilities.find(c => c.name === capabilityName);
    if (cap) matches.push({ key, service: svc, capability: cap });
  }
  return matches;
}
