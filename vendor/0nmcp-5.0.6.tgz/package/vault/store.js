/**
 * THE VAULT — one table of .0n connection records, keyed by account.
 *
 *   vault_records  (account_id, service, label) → envelope (non-secret jsonb) + secret_ciphertext
 *   vault_members  account_id ↔ member_id (a person can act for an agency account)
 *   vault_audit    every credential use: who, which record, which tool, ok/not
 *
 * The store speaks to Postgres through a tiny `rest` seam so tests run against
 * an in-memory implementation and production runs against supabase-js with the
 * service role (RLS is ON, no policies: only the runtime can read it).
 */
import { encrypt, decrypt, keyFromHex } from './kms.js';
import { validateConnection, stripSecrets, labelOf } from '../envelope.js';

export const TABLES = { records: 'vault_records', members: 'vault_members', audit: 'vault_audit' };

/** supabase-js backed rest seam. */
export function supabaseRest(client) {
  return {
    // opts { order, desc, limit }: sort and cap IN THE DATABASE. A caller that sorted and sliced in JS pulled the whole table
    // first — desk_runs did that on every list and every board poll until it held the pool hostage (2026-11-24).
    async select(table, filters, columns = '*', opts = {}) {
      let q = client.from(table).select(columns);
      for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
      if (opts.order) q = q.order(opts.order, { ascending: !opts.desc });
      if (opts.limit) q = q.limit(opts.limit);
      const { data, error } = await q;
      if (error) throw new Error(`${table} select: ${error.message}`);
      return data || [];
    },
    async upsert(table, row, onConflict) {
      const { data, error } = await client.from(table).upsert(row, { onConflict }).select();
      if (error) throw new Error(`${table} upsert: ${error.message}`);
      return data?.[0] || row;
    },
    async delete(table, filters) {
      let q = client.from(table).delete();
      for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
      const { error } = await q;
      if (error) throw new Error(`${table} delete: ${error.message}`);
    },
    async insert(table, row) {
      const { error } = await client.from(table).insert(row);
      if (error) throw new Error(`${table} insert: ${error.message}`);
    },
    async rpc(fn, args) {
      const { data, error } = await client.rpc(fn, args);
      if (error) throw new Error(`${fn}: ${error.message}`);
      return data;
    },
    async update(table, filters, patch) {
      let q = client.from(table).update(patch);
      for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
      const { error } = await q;
      if (error) throw new Error(`${table} update: ${error.message}`);
    },
  };
}

/** In-memory rest seam for tests and `0n3 doctor --offline`. */
export function memoryRest() {
  const tables = new Map();
  const rows = (t) => { if (!tables.has(t)) tables.set(t, []); return tables.get(t); };
  const match = (row, f) => Object.entries(f).every(([k, v]) => row[k] === v);
  return {
    tables,
    async select(t, f, _c, o = {}) { let out = rows(t).filter((r) => match(r, f)).map((r) => ({ ...r })); if (o.order) out.sort((a, b) => (String(a[o.order]).localeCompare(String(b[o.order]))) * (o.desc ? -1 : 1)); return o.limit ? out.slice(0, o.limit) : out; },
    async upsert(t, row, onConflict) {
      const keys = String(onConflict || '').split(',').map((s) => s.trim()).filter(Boolean);
      const arr = rows(t);
      const i = keys.length ? arr.findIndex((r) => keys.every((k) => r[k] === row[k])) : -1;
      const next = { id: i >= 0 ? arr[i].id : `mem_${arr.length + 1}`, ...(i >= 0 ? arr[i] : {}), ...row };
      if (i >= 0) arr[i] = next; else arr.push(next);
      return { ...next };
    },
    async delete(t, f) { const arr = rows(t); for (let i = arr.length - 1; i >= 0; i--) if (match(arr[i], f)) arr.splice(i, 1); },
    async insert(t, row) { rows(t).push({ id: `mem_${rows(t).length + 1}`, ...row }); },
    async update(t, f, patch) { for (const r of rows(t)) if (match(r, f)) Object.assign(r, patch); },
    // The one database function the runtime calls, mirrored so tests see the same totals production returns.
    async rpc(fn, a) {
      if (fn === 'security_ip_bump') {
        const arr = rows('security_ip_state'); let r = arr.find((x) => x.ip === a.p_ip);
        if (!r) { r = { ip: a.p_ip, score: 0, distinct_keys: [], flagged_until: null }; arr.push(r); }
        r.score += a.p_weight || 0; if (a.p_distinct && !r.distinct_keys.includes(a.p_distinct)) r.distinct_keys.push(a.p_distinct);
        if (a.p_flag_minutes) r.flagged_until = new Date(Math.max(r.flagged_until ? new Date(r.flagged_until).getTime() : 0, Date.now() + a.p_flag_minutes * 60e3)).toISOString();
        return [{ score: r.score, distinct_count: r.distinct_keys.length, flagged_until: r.flagged_until }];
      }
      if (fn === 'usage_bump') {
        const arr = rows('usage_counts'); let r = arr.find((x) => x.account_id === a.p_account && x.month === a.p_month);
        if (!r) { r = { account_id: a.p_account, month: a.p_month, units: 0, reported: 0 }; arr.push(r); }
        r.units += Math.max(0, a.p_n || 0); return [{ units: r.units }];
      }
      if (fn === 'usage_unreported') return rows('usage_counts').filter((x) => x.month === a.p_month && x.units > x.reported).slice(0, a.p_limit || 500).map(({ account_id, units, reported }) => ({ account_id, units, reported }));
      if (fn !== 'grant_usage_bump') throw new Error(`memoryRest: no function ${fn}`);
      const day = new Date().toISOString().slice(0, 10); const arr = rows('grant_usage');
      let r = arr.find((x) => x.account_id === a.p_account && x.client_id === a.p_client && x.day === day);
      if (!r) { r = { account_id: a.p_account, client_id: a.p_client, day, calls: 0, writes: 0 }; arr.push(r); }
      r.calls += 1; if (a.p_write) r.writes += 1;
      return [{ calls: r.calls, writes: r.writes }];
    },
  };
}

export class VaultStore {
  /** @param {{ rest: ReturnType<typeof supabaseRest>, masterKeyHex: string }} o */
  constructor({ rest, masterKeyHex }) {
    if (!rest) throw new Error('VaultStore needs a rest seam');
    this.rest = rest;
    this.key = keyFromHex(masterKeyHex);
  }

  /** Non-secret listing for one account. */
  async list(accountId) {
    const rows = await this.rest.select(TABLES.records, { account_id: accountId });
    return rows
      .filter((r) => r.status !== 'revoked')
      .map((r) => ({ ...(r.envelope || {}), service: r.service, environment: r.environment, status: r.status, last_verified_at: r.last_verified_at || null, updated_at: r.updated_at || null }))
      .sort((a, b) => a.service.localeCompare(b.service) || labelOf(a).localeCompare(labelOf(b)));
  }

  /** Full envelope (credentials decrypted) or null. `label` may be a record name or a meta value such as a CRM location id. */
  async get(accountId, service, label) {
    // No label asked for → the NEWEST live record, never "whichever row the database listed first". A reconnect writes a
    // new record (eBay names it by the seller's current username), so newest-first is what makes reconnecting fix things.
    // Measured 2026-11-07: four eBay records, the dead one was returned, and CardFlow could not list.
    const rows = (await this.rest.select(TABLES.records, { account_id: accountId, service })).filter((r) => r.status !== 'revoked')
      .sort((a, b) => String(b.updated_at || b.created_at || '').localeCompare(String(a.updated_at || a.created_at || '')));
    if (!rows.length) return null;
    let row = rows[0];
    if (label) {
      const l = String(label).trim();
      row = rows.find((r) => r.label === l) || rows.find((r) => Object.values(r.envelope?.meta || {}).some((v) => String(v) === l)) || null;
      // A CRM record made by the builder keeps its location id only with the credentials (2026-11-08: the "Eagles" record,
      // so every crm_* call with location_id 156DS3j770K0lGkdOY7m answered "No CRM connection"). Match that field only —
      // never compare a label against secret values.
      if (!row && service === 'crm') row = rows.find((r) => { try { const c = decrypt(r.secret_ciphertext, this.key) || {}; return String(c.location_id || c.locationId || '') === l; } catch { return false; } }) || null;
      if (!row) return null;
    }
    const credentials = decrypt(row.secret_ciphertext, this.key);
    const env = row.envelope || {};
    return { ...env, service: row.service, environment: row.environment, auth: { type: env.auth?.type || 'custom', credentials } };
  }

  /** Store or replace one record. Returns the non-secret view. */
  async put(accountId, envelope, { actor } = {}) {
    const v = validateConnection(envelope);
    if (!v.ok) throw new Error(`invalid connection record: ${v.errors.join('; ')}`);
    const now = new Date().toISOString();
    // The location a CRM record acts on is not a secret: keep it in meta too, so a lookup by location id finds it.
    const loc = envelope.service === 'crm' ? (envelope.auth?.credentials?.location_id || envelope.auth?.credentials?.locationId) : null;
    if (loc && !envelope.meta?.location_id) envelope = { ...envelope, meta: { ...(envelope.meta || {}), location_id: loc } };
    const stripped = stripSecrets({ ...envelope, $0n: { ...envelope.$0n, updated: now } });
    const row = {
      account_id: accountId,
      service: envelope.service,
      label: labelOf(envelope),
      kind: envelope.auth.type || 'custom',
      environment: envelope.environment || 'production',
      envelope: stripped,
      secret_ciphertext: encrypt(envelope.auth.credentials, this.key),
      status: 'active',
      updated_at: now,
    };
    const saved = await this.rest.upsert(TABLES.records, row, 'account_id,service,label');
    await this.audit({ accountId, service: envelope.service, label: row.label, action: 'put', ok: true, actor });
    return { ...stripped, status: saved.status || 'active' };
  }

  async markVerified(accountId, service, label, ok, detail) {
    const rows = await this.rest.select(TABLES.records, { account_id: accountId, service });
    const row = rows.find((r) => !label || r.label === label);
    if (!row) return;
    await this.rest.upsert(TABLES.records, { ...row, last_verified_at: ok ? new Date().toISOString() : row.last_verified_at || null, status: ok ? 'active' : 'failing', last_error: ok ? null : String(detail || '').slice(0, 500) }, 'account_id,service,label');
  }

  async remove(accountId, service, label, { actor } = {}) {
    const f = { account_id: accountId, service };
    if (label) f.label = label;
    await this.rest.delete(TABLES.records, f);
    await this.audit({ accountId, service, label: label || null, action: 'remove', ok: true, actor });
  }

  /** Accounts this person may act for: their own plus every membership. */
  async accountsFor(memberId) {
    const rows = await this.rest.select(TABLES.members, { member_id: memberId });
    return [memberId, ...rows.map((r) => r.account_id).filter((a) => a && a !== memberId)];
  }

  /** Fire-and-forget audit line; never throws into a tool call. */
  async audit({ accountId, service, label = null, action, tool = null, ok = true, status = null, detail = null, actor = null }) {
    try {
      // An audit line that names a tool IS an action — the one place metered usage is counted (usage.js), so no caller can skip it.
      const counted = tool && accountId && this.onAction ? Promise.resolve(this.onAction(accountId, { service, tool, ok })).catch(() => {}) : null;
      await this.rest.insert(TABLES.audit, { account_id: accountId, service, label, action, tool, ok: !!ok, status, detail: detail ? String(detail).slice(0, 500) : null, actor, at: new Date().toISOString() });
      if (counted) await counted;
    } catch (e) {
      console.error('[vault] audit write failed:', e.message);
    }
  }
}
