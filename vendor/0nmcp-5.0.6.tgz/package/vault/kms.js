/**
 * Vault encryption for hosted records: AES-256-GCM under one 32-byte master
 * key (ON3_VAULT_KEY, 64 hex chars — the same shape as ~/.0n/keys/on-connect.key).
 *
 * Ciphertext layout, base64: [iv:12][tag:16][ciphertext]. The key never leaves
 * the server; the database holds only this string. This is deliberately NOT
 * the machine-bound seal from vault/cipher.js — that one exists so a LOCAL
 * file can be bound to one laptop; a hosted vault has to be readable by the
 * runtime on every request.
 */
import { randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';

export function keyFromHex(hex) {
  if (typeof hex !== 'string' || !/^[0-9a-fA-F]{64}$/.test(hex.trim())) throw new Error('vault key must be 64 hex characters (32 bytes)');
  return Buffer.from(hex.trim(), 'hex');
}

export function generateKeyHex() {
  return randomBytes(32).toString('hex');
}

export function encrypt(value, key) {
  const iv = randomBytes(12);
  const c = createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([c.update(JSON.stringify(value), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}

export function decrypt(b64, key) {
  const buf = Buffer.from(String(b64), 'base64');
  if (buf.length < 29) throw new Error('ciphertext too short');
  const d = createDecipheriv('aes-256-gcm', key, buf.subarray(0, 12));
  d.setAuthTag(buf.subarray(12, 28));
  const pt = Buffer.concat([d.update(buf.subarray(28)), d.final()]).toString('utf8');
  return JSON.parse(pt);
}
