/**
 * The consent page for /oauth/authorize — "Sign in with 0n3" (2026-10-28). Served by the handler itself so an app's or an
 * MCP client's OAuth round-trip never depends on the SPA.
 *
 * Ways in: already signed in to 0n3 in this browser ("Continue as …", one tap) · Google or GitHub (Supabase, back to this
 * same page) · email + password · paste a 0n token (for developers). The person sees exactly what the app asks for — who
 * they are, and which apps it may use through 0n3 — and can Allow or Cancel.
 */
import { describeScopes } from './oidc.js';
import { nameOf, domainOf } from './flow-defs.js';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SB = 'https://pwujhhmlrtxjmjzyttwn.supabase.co';
const SB_KEY = 'sb-pwujhhmlrtxjmjzyttwn-auth-token';

export function renderAuthorize({ q = {}, client = null, scopes = [], error = null }) {
  const host = (() => { try { return new URL(q.redirect_uri).host; } catch { return ''; } })();
  const hidden = ['client_id', 'redirect_uri', 'response_type', 'code_challenge', 'code_challenge_method', 'scope', 'state', 'resource', 'nonce']
    .filter((k) => q[k] !== undefined && q[k] !== '')
    .map((k) => `<input type="hidden" name="${k}" value="${esc(q[k])}">`).join('');
  const name = esc(client?.name || 'An app');
  const logo = client?.logo_url && /^https:\/\//.test(client.logo_url) ? esc(client.logo_url) : null;
  const lines = describeScopes(scopes, nameOf);
  const fav = (k) => `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domainOf(k))}&sz=64`;
  const list = lines.map((l) => `<li>${l.kind === 'app' ? `<img src="${fav(l.app)}" alt="">` : `<span class="ic">${l.kind === 'id' ? '◉' : l.kind === 'mcp' ? '✦' : '↻'}</span>`}<span>${esc(l.text)}</span></li>`).join('');
  const writes = scopes.some((s) => s.startsWith('apps:'));
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Sign in with 0n3</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
<style>
:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#fafafa;color:#171717;font:15px/1.5 Inter,system-ui,-apple-system,Segoe UI,sans-serif;min-height:100vh;display:grid;place-items:center;padding:20px}
.card{width:100%;max-width:440px;background:#fff;border:1px solid rgba(229,229,229,.7);border-radius:28px;padding:28px 24px;box-shadow:0 1px 2px rgba(10,10,10,.04),0 6px 16px rgba(10,10,10,.06),0 18px 40px rgba(10,10,10,.06)}
.top{display:flex;align-items:center;gap:12px;margin-bottom:18px}.top img.mark{height:28px;width:auto}.top .x{color:#a3a3a3}.applogo{width:44px;height:44px;border-radius:12px;object-fit:cover;border:1px solid #e5e5e5}
h1{font-size:22px;line-height:1.2;margin:0 0 6px;letter-spacing:-.02em}p{margin:0 0 14px;color:#737373;font-size:14px}
ul{list-style:none;margin:16px 0;padding:0;display:flex;flex-direction:column;gap:8px}li{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid rgba(229,229,229,.8);border-radius:14px;font-weight:500;font-size:14px}
li img{width:24px;height:24px;border-radius:7px;flex:none}li .ic{width:24px;height:24px;border-radius:7px;background:rgba(22,163,74,.1);color:#16a34a;display:flex;align-items:center;justify-content:center;flex:none;font-size:13px}
.note{font-size:12px;color:#737373;margin:0 0 14px}
.btn{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:52px;margin-top:10px;border-radius:999px;border:1px solid transparent;background:#171717;color:#fff;font:inherit;font-weight:600;font-size:15px;cursor:pointer;text-decoration:none}
.btn.glow{box-shadow:0 0 0 1px rgba(110,224,90,.45),0 10px 28px rgba(110,224,90,.32)}.btn.ghost{background:#fff;color:#171717;border-color:rgba(229,229,229,.9)}.btn.bare{background:transparent;color:#737373;min-height:44px}
.btn img{width:20px;height:20px;border-radius:5px;background:#fff;padding:2px}
.who{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:14px;background:#fafafa;border:1px solid rgba(229,229,229,.8);font-size:14px;margin-top:6px}.av{width:32px;height:32px;border-radius:999px;background:#171717;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;flex:none}
details{margin-top:12px}summary{cursor:pointer;color:#737373;font-size:13px;text-align:center;list-style:none}summary::-webkit-details-marker{display:none}
label{display:block;font-size:12px;font-weight:500;color:#737373;margin:12px 0 6px}input[type=email],input[type=password],input[type=text]{width:100%;background:#fff;border:1px solid #e5e5e5;border-radius:12px;color:#171717;padding:12px;font:inherit}input:focus{outline:none;border-color:#22c55e;box-shadow:0 0 0 3px rgba(110,224,90,.18)}
.err{border:1px solid rgba(220,38,38,.3);background:rgba(220,38,38,.05);color:#b91c1c;border-radius:12px;padding:10px 12px;font-size:13px;margin:10px 0}
.foot{margin-top:18px;font-size:12px;color:#a3a3a3;text-align:center;line-height:1.5}.foot a{color:#16a34a;text-decoration:none}
[hidden]{display:none!important}
</style></head><body><main class="card">
<div class="top">${logo ? `<img class="applogo" src="${logo}" alt=""><span class="x">⇄</span>` : ''}<img class="mark" src="/0n3-logo.png" alt="0n3"></div>
<h1>${name} wants to use your 0n3 account</h1>
<p>${host ? `You'll go back to <b style="color:#171717">${esc(host)}</b> after you choose.` : ''}</p>
${error ? `<div class="err">${esc(error)}</div>` : ''}
${client ? `
<ul>${list}</ul>
${writes ? `<p class="note">${name} never sees your passwords or keys. It asks 0n3, and 0n3 uses only the apps above. Remove it any time under Connected programs.</p>` : ''}

<form id="as" method="post" action="/oauth/authorize" hidden>${hidden}<input type="hidden" name="jwt" id="jwt">
  <div class="who"><span class="av" id="ini">·</span><span>Continue as <b id="em"></b></span></div>
  <button class="btn glow" type="submit">Allow</button>
</form>

<div id="signin">
  <a class="btn glow" id="g" href="#"><img src="https://www.google.com/s2/favicons?domain=google.com&sz=64" alt="">Continue with Google</a>
  <a class="btn ghost" id="gh" href="#"><img src="https://www.google.com/s2/favicons?domain=github.com&sz=64" alt="">Continue with GitHub</a>
  <details><summary>Use email and password</summary>
    <form method="post" action="/oauth/authorize">${hidden}
      <label>Email</label><input type="email" name="email" autocomplete="username" required>
      <label>Password</label><input type="password" name="password" autocomplete="current-password" required>
      <button class="btn" type="submit">Sign in and allow</button>
    </form>
  </details>
  <details><summary>I'm a developer — use a 0n token</summary>
    <form method="post" action="/oauth/authorize">${hidden}
      <label>Your 0n token</label><input type="text" name="token" placeholder="0n_…" autocomplete="off" spellcheck="false">
      <button class="btn ghost" type="submit">Allow with this token</button>
    </form>
  </details>
</div>

<form method="post" action="/oauth/authorize">${hidden}<input type="hidden" name="deny" value="1"><button class="btn bare" type="submit">Cancel</button></form>
<script>
(function(){
  var KEY=${JSON.stringify(SB_KEY)}, SB=${JSON.stringify(SB)};
  function show(jwt,email){document.getElementById('jwt').value=jwt;document.getElementById('em').textContent=email||'your account';document.getElementById('ini').textContent=(email||'?').charAt(0).toUpperCase();document.getElementById('as').hidden=false;document.getElementById('signin').hidden=true;}
  // 1) Back from Google/GitHub: the session arrives in the fragment.
  var h=new URLSearchParams(location.hash.slice(1));
  if(h.get('access_token')){var t=h.get('access_token');var em='';try{em=JSON.parse(atob(t.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).email||'';}catch(e){}history.replaceState(null,'',location.pathname+location.search);show(t,em);return;}
  // 2) Already signed in to 0n3 in this browser.
  try{var s=JSON.parse(localStorage.getItem(KEY)||'null');if(s&&s.access_token&&(!s.expires_at||s.expires_at*1000>Date.now()+60000)){show(s.access_token,(s.user&&s.user.email)||'');}}catch(e){}
  // 3) Otherwise: Google / GitHub, returning to this exact page.
  function go(p){location.href=SB+'/auth/v1/authorize?provider='+p+'&redirect_to='+encodeURIComponent(location.href.split('#')[0]);}
  document.getElementById('g').onclick=function(e){e.preventDefault();go('google');};
  document.getElementById('gh').onclick=function(e){e.preventDefault();go('github');};
})();
</script>` : ''}
<div class="foot">No 0n3 account yet? <a href="/m">Create one free</a> — the same account works in every app that offers Sign in with 0n3.</div>
</main></body></html>`;
}
