/**
 * GIFT TOKENS (2026-11-24). Mike: "I want us to be able to offer any user a free usage token — hers will be a DIAMOND
 * TOKEN which she can redeem for free lifetime access of the top tier plan as an early adopter."
 *
 * A token is issued to an EMAIL, not an account (Rule 0-SSO): the person may not have registered yet, and the email is
 * what matches them when they do. It waits, shown on every page, until they press Redeem. Redeeming sets the plan
 * through billing.setPlan — the one place a plan is written, so the managed CRM tier and the 0nTask entitlement follow —
 * with status `lifetime`, which billing never lets a Stripe sync or webhook move.
 *
 * Every tier here is a LIFETIME grant. A timed token would need something that takes the plan away again on the day,
 * and nothing does that yet; a tier that silently never ended would be a bug, so there is none.
 */
import { randomBytes } from 'node:crypto';
import { PLANS, planOf } from './billing.js';

export const TIERS = {
  diamond: { key: 'diamond', name: 'Diamond Token', plan: 'business', vip: true,  rank: 3, line: 'Free lifetime access to 0n3 Business, the top plan.' },
  gold:    { key: 'gold',    name: 'Gold Token',    plan: 'pro',      vip: false, rank: 2, line: 'Free lifetime access to 0n3 Pro.' },
  silver:  { key: 'silver',  name: 'Silver Token',  plan: 'starter',  vip: false, rank: 1, line: 'Free lifetime access to 0n3 Starter.' },
};
export const normEmail = (e) => String(e || '').trim().toLowerCase();
const ALPHA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no 0/O, 1/I/L: a code gets read aloud and typed
export const makeCode = (tier) => { const b = randomBytes(8); const part = (o) => Array.from({ length: 4 }, (_, i) => ALPHA[b[o + i] % ALPHA.length]).join(''); return `${String(tier).toUpperCase()}-${part(0)}-${part(4)}`; };
const open = (g) => g && !g.redeemed_at && !g.revoked_at;

/** What the person is shown. Never the row itself: no issuer, no other person's email. */
export function publicGift(g) {
  const t = TIERS[g.tier]; if (!t) return null;
  return { id: g.id, code: g.code, tier: t.key, name: t.name, plan: t.plan, planName: PLANS[t.plan].name, value: PLANS[t.plan].price, lifetime: true, line: t.line, note: g.note || null, redeemed: !!g.redeemed_at };
}

export function createGifts({ rest, billing }) {
  const byEmail = async (email) => (await rest.select('gift_tokens', { email: normEmail(email) })).filter(open).sort((a, b) => (TIERS[b.tier]?.rank || 0) - (TIERS[a.tier]?.rank || 0));

  /** Give `email` a token. Asking twice for the same tier returns the one already waiting. */
  async function issue({ email, tier = 'diamond', note = '', by = '' }) {
    const e = normEmail(email); const t = TIERS[tier];
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) throw new Error('That is not an email address.');
    if (!t) throw new Error(`Unknown tier: ${tier}. Use ${Object.keys(TIERS).join(', ')}.`);
    const had = (await byEmail(e)).find((g) => g.tier === tier);
    if (had) return { gift: had, existed: true };
    const row = { code: makeCode(tier), email: e, tier, plan: t.plan, lifetime: true, note: String(note || '').slice(0, 300) || null, issued_by: normEmail(by) || null };
    await rest.insert('gift_tokens', row);
    const made = (await rest.select('gift_tokens', { code: row.code }))[0];
    return { gift: made || row, existed: false };
  }

  /** The best token waiting for this person, or null. */
  async function waiting(email) { const g = (await byEmail(email))[0]; return g ? publicGift(g) : null; }

  /**
   * Redeem. The person's own waiting token (by their email), or a code they were handed and typed in.
   * `account` = { accountId, email } from the signed-in session.
   */
  async function redeem(account, { code = '' } = {}) {
    const email = normEmail(account?.email); if (!account?.accountId || !email) throw new Error('Sign in first.');
    let g;
    if (code) {
      g = (await rest.select('gift_tokens', { code: String(code).trim().toUpperCase() }))[0];
      if (!g) throw new Error('That code is not a token we issued.');
      if (g.revoked_at) throw new Error('That token was withdrawn.');
      if (g.redeemed_at) throw new Error(g.redeemed_account === account.accountId ? 'You already redeemed this token.' : 'That token has already been redeemed.');
    } else {
      g = (await byEmail(email))[0];
      if (!g) throw new Error('There is no token waiting for this account.');
    }
    const t = TIERS[g.tier]; if (!t) throw new Error('This token is of a kind we no longer give out.');
    const [p] = await rest.select('profiles', { id: account.accountId }, 'id, plan, plan_status, stripe_customer_id');
    // Never a step down: someone already on a higher plan keeps it, and the token still becomes theirs for life.
    const cur = planOf(p?.plan); const plan = PLANS[cur].price > PLANS[t.plan].price ? cur : t.plan;
    await billing.setPlan(account.accountId, plan, { status: 'lifetime' });
    if (t.vip) await rest.update('profiles', { id: account.accountId }, { is_vip: true });
    await rest.update('gift_tokens', { id: g.id }, { redeemed_at: new Date().toISOString(), redeemed_account: account.accountId });
    // A live paid subscription keeps charging until it is cancelled; say so rather than let the card be billed for a free plan.
    const paying = !!p?.stripe_customer_id && ['active', 'trialing', 'past_due'].includes(String(p?.plan_status || ''));
    return { gift: publicGift({ ...g, redeemed_at: new Date().toISOString() }), plan, planName: PLANS[plan].name, cancelSubscription: paying };
  }

  async function list() { return (await rest.select('gift_tokens', {}, '*', { order: 'created_at' })).reverse(); }
  async function revoke(id) {
    const [g] = await rest.select('gift_tokens', { id }); if (!g) throw new Error('No such token.');
    if (g.redeemed_at) throw new Error('That token was already redeemed; change the plan on the account instead.');
    await rest.update('gift_tokens', { id }, { revoked_at: new Date().toISOString() });
    return { ok: true };
  }
  return { issue, waiting, redeem, list, revoke };
}
