/**
 * 0n3's DECEPTION LAYER (2026-10-29) — the standalone `0n-decoy` package, wired to 0n3's database and phones.
 *
 * Mike: "make our vault and our backend purposely built to mislead and confuse any AI that tries to attack, brute force
 * or manipulate or access our database." The package decides (honey paths, canary tokens, brute force, tarpit); this file
 * keeps the state shared across serverless instances (security_ip_state via security_ip_bump), records every event
 * (security_events), names planted canaries (security_canaries) and pushes high/critical events to the admins' phones.
 * Off unless ON3_DECOY_SECRET is set. The secret lives only in the deploy environment, never in the database.
 */
import { createDecoy } from '0n-decoy';

/** A store for the package backed by Postgres, with a short per-instance cache so a normal request costs no query. */
export function pgStore(rest, { onBan = () => {} } = {}) {
  const cache = new Map(); // ip → { at, s }
  const bans = new Map(); const remembered = new Set();
  const toS = (r) => ({ score: Number(r?.score || 0), distinct: Array.from({ length: Number(r?.distinct_count || 0) }), flaggedUntil: r?.flagged_until ? new Date(r.flagged_until).getTime() : 0 });
  return {
    async get(ip) {
      const hit = cache.get(ip); if (hit && hit.at > Date.now() - 30_000) return hit.s;
      let s = null;
      try { const r = (await rest.select('security_ip_state', { ip }, 'score, distinct_keys, flagged_until'))[0]; if (r) s = { score: r.score, distinct: r.distinct_keys || [], flaggedUntil: r.flagged_until ? new Date(r.flagged_until).getTime() : 0 }; } catch { /* fail open: never block real users on a store error */ }
      cache.set(ip, { at: Date.now(), s }); if (cache.size > 5000) cache.delete(cache.keys().next().value);
      return s;
    },
    // Permanent bans: cached per instance for a minute (a fresh ban is cached at once on the instance that made it).
    async banned(ip) {
      const hit = bans.get(ip); if (hit && hit.at > Date.now() - 60_000) return hit.v;
      let v = null; try { v = (await rest.select('security_bans', { ip }, 'ip, reason'))[0] || null; } catch { /* fail open */ }
      bans.set(ip, { at: Date.now(), v }); if (bans.size > 5000) bans.delete(bans.keys().next().value); return v;
    },
    async ban(ip, { reason, origin = null }) {
      try { await rest.upsert('security_bans', { ip, reason: String(reason).slice(0, 200), origin_ip: origin }, 'ip'); } catch (e) { console.error('[0n3 security] ban:', e.message); }
      const v = { ip, reason }; bans.set(ip, { at: Date.now(), v }); onBan(ip); return v;
    },
    async remember(tag, ip) { if (remembered.has(tag)) return; remembered.add(tag); try { if (!(await rest.select('security_beacons', { tag }, 'tag'))[0]) await rest.insert('security_beacons', { tag, origin_ip: ip }); } catch { /* */ } },
    async recall(tag) {
      const r = (await rest.select('security_beacons', { tag }, 'origin_ip, hits').catch(() => []))[0]; if (!r) return null;
      return r.origin_ip;
    },
    async bump(ip, { weight = 1, flagMinutes = 0, distinct = null } = {}) {
      const r = await rest.rpc('security_ip_bump', { p_ip: ip, p_weight: weight, p_flag_minutes: flagMinutes, p_distinct: distinct });
      const s = toS(Array.isArray(r) ? r[0] : r); cache.set(ip, { at: Date.now(), s }); return s;
    },
  };
}

export function createSecurity({ rest, desk = null, env = process.env, host = '0n3.app', fetchImpl = fetch }) {
  const secret = env.ON3_DECOY_SECRET || '';
  if (!secret || !rest?.rpc) return null;
  const pushed = new Map(); // `${ip}:${kind}` → ms, one push per address and kind per hour per instance
  let admins = null;
  const adminIds = async () => {
    if (admins) return admins;
    const emails = String(env.ON3_ADMIN_EMAILS || 'mike@rocketopp.com').split(',').map((e) => e.trim().toLowerCase()).filter(Boolean);
    const rows = []; for (const email of emails) { try { rows.push(...await rest.select('profiles', { email }, 'id')); } catch { /* */ } }
    admins = rows.map((r) => r.id); return admins;
  };
  const onEvent = async (e) => {
    const { at, kind, severity, ip, ua, path, ...detail } = e;
    let label = null;
    if (detail.nonce) { try { const c = (await rest.select('security_canaries', { nonce: detail.nonce }, 'label'))[0]; label = c?.label || null; await rest.update('security_canaries', { nonce: detail.nonce }, { last_seen_at: new Date().toISOString() }); } catch { /* */ } }
    try { await rest.insert('security_events', { at: at || new Date().toISOString(), kind, severity, ip: ip || null, ua: String(ua || '').slice(0, 300), path: String(path || '').slice(0, 300), detail: { ...detail, ...(label ? { label } : {}) } }); } catch (err) { console.error('[0n3 security] event:', err.message); }
    console.warn('[0n3 security]', severity, kind, ip, path, label || '');
    if (desk && (severity === 'critical' || severity === 'high')) {
      const k = `${ip}:${kind}`; if ((pushed.get(k) || 0) > Date.now() - 3600e3) return; pushed.set(k, Date.now());
      const title = kind === 'canary_used' ? `Canary used${label ? `: ${label}` : ''}` : kind === 'honey_path' ? 'Someone probed a trap path' : kind === 'token_bruteforce' ? 'Token brute force blocked' : `Security: ${kind}`;
      for (const id of await adminIds()) await desk.notify(id, { title, body: `${ip || 'unknown address'} · ${path || ''}`.slice(0, 140), url: '/shield', tag: `sec-${k}` }).catch(() => {});
    }
  };
  // The paths that hand out data; a flagged address without a valid token gets the fake world only here.
  const guarded = (p) => p === '/mcp' || p === '/vault' || p.startsWith('/vault/') || /^\/api\/(x|admin|tokens|approvals|grants|dev|me|profile|settings)(\/|$)/.test(p);
  // PRIVATE traps: the package is public, so its default trap list can be read and avoided. These live only in the deploy
  // environment (ON3_DECOY_EXTRA_PATHS, comma-separated path prefixes) and are invisible to anyone reading our code.
  const extraHoney = String(env.ON3_DECOY_EXTRA_PATHS || '').split(',').map((x) => x.trim()).filter((x) => x.startsWith('/'))
    .map((x) => new RegExp(`^${x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(\\/|$)`, 'i'));
  // NEVER BAN an address that used a valid token in the last 30 days, or one listed in ON3_BAN_NEVER: shared office and
  // carrier networks must not lock real people out of every site.
  const never = new Set(String(env.ON3_BAN_NEVER || '').split(',').map((x) => x.trim()).filter(Boolean));
  const neverBan = async (ip) => {
    if (never.has(ip)) return true;
    const r = (await rest.select('security_trusted_ips', { ip }, 'last_valid_at').catch(() => []))[0];
    return !!r && new Date(r.last_valid_at).getTime() > Date.now() - 30 * 864e5;
  };
  const trusted = new Map();
  const trust = async (ip) => { if (!ip || ip === 'unknown' || (trusted.get(ip) || 0) > Date.now() - 3600e3) return; trusted.set(ip, Date.now()); try { await rest.upsert('security_trusted_ips', { ip, last_valid_at: new Date().toISOString() }, 'ip'); } catch { /* */ } };

  // EDGE BANS ON EVERY SITE: each banned address is written into the Vercel firewall of every project on the team.
  const vt = env.VERCEL_TOKEN || ''; const team = env.VERCEL_TEAM_ID || 'team_VtbfSzhDgB6OwglLfuPDFcd2';
  const vapi = async (path, init = {}) => { const r = await fetchImpl(`https://api.vercel.com${path}${path.includes('?') ? '&' : '?'}teamId=${team}`, { ...init, headers: { Authorization: `Bearer ${vt}`, 'Content-Type': 'application/json', ...(init.headers || {}) } }); const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = { raw: t }; } return { ok: r.ok, status: r.status, j }; };
  const projects = async () => { const out = []; let next = null; do { const r = await vapi(`/v10/projects?limit=100${next ? `&until=${next}` : ''}`); if (!r.ok) throw new Error(`projects ${r.status}`); out.push(...(r.j.projects || []).map((p) => p.id)); next = r.j.pagination?.next || null; } while (next && out.length < 1000); return out; };
  // Vercel rate-limits firewall changes, so this paces itself (3 at a time, honours Retry-After, stops at ~45 s) and
  // RECONCILES: adds every banned address missing from a project and removes 0n3 entries no longer banned. Running
  // every 5 minutes, it converges on its own; nothing is lost when one run is cut short.
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const vcall = async (path, init) => { for (let i = 0; i < 4; i++) { const r = await vapi(path, init); if (r.status !== 429) return r; await sleep(Math.min(10_000, 1000 * (2 ** i))); } return { ok: false, status: 429, j: {} }; };
  async function syncFirewall({ budgetMs = 45_000 } = {}) {
    if (!vt) return { ok: false, reason: 'VERCEL_TOKEN is not set' };
    const t0 = Date.now();
    const bansAll = await rest.select('security_bans', {}, 'ip, reason, firewall');
    const want = new Map(bansAll.map((b) => [b.ip, b]));
    const ids = await projects(); let added = 0, removed = 0, done = 0, pending = 0; const failed = [];
    for (let i = 0; i < ids.length; i += 3) {
      if (Date.now() - t0 > budgetMs) { pending = ids.length - i; break; }
      await Promise.all(ids.slice(i, i + 3).map(async (pid) => {
        const cur = await vcall(`/v1/security/firewall/config/active?projectId=${pid}`);
        const have = (cur.ok && cur.j.ips) || [];
        for (const b of bansAll) {
          if (have.some((x) => x.ip === b.ip)) { b.firewall = { ...(b.firewall || {}), [pid]: true }; continue; }
          const r = await vcall(`/v1/security/firewall/config?projectId=${pid}`, { method: 'PATCH', body: JSON.stringify({ action: 'ip.insert', id: null, value: { hostname: '*', ip: b.ip, action: 'deny', notes: `0n3 ban: ${b.reason}`.slice(0, 200) } }) });
          if (r.ok) { added++; b.firewall = { ...(b.firewall || {}), [pid]: true }; } else failed.push(`${pid}:${r.status}`);
        }
        for (const x of have.filter((y) => String(y.notes || '').startsWith('0n3 ban:') && !want.has(y.ip))) {
          const r = await vcall(`/v1/security/firewall/config?projectId=${pid}`, { method: 'PATCH', body: JSON.stringify({ action: 'ip.remove', id: x.id, value: null }) });
          if (r.ok) removed++; else failed.push(`${pid}:remove:${r.status}`);
        }
        done++;
      }));
    }
    for (const b of bansAll) { try { await rest.update('security_bans', { ip: b.ip }, { firewall: b.firewall || {} }); } catch { /* */ } }
    return { ok: failed.length === 0 && pending === 0, bans: bansAll.length, projects: ids.length, checked: done, pending, added, removed, failed: failed.slice(0, 10) };
  }
  /** Unban: off the list now; the firewall entries come off on this and the following sync runs. */
  async function unban(ip) {
    const b = (await rest.select('security_bans', { ip }, 'ip').catch(() => []))[0]; if (!b) return { ok: false, reason: 'not banned' };
    await rest.delete('security_bans', { ip }); await rest.delete('security_ip_state', { ip }).catch(() => {});
    await onEvent({ kind: 'unbanned', severity: 'info', ip });
    const sync = vt ? await syncFirewall({ budgetMs: 40_000 }).catch((e) => ({ ok: false, error: e.message })) : null;
    return { ok: true, firewall: sync };
  }

  const base = (env.ON3_PUBLIC_URL || `https://${host}`).replace(/\/$/, '');
  const decoy = createDecoy({ secret, store: pgStore(rest), onEvent, host, guarded, extraHoney, neverBan, beaconBase: `${base}/api/k`, hopUrl: env.ON3_DECOY_HOP_URL || null });
  return {
    decoy, trust, syncFirewall, unban,
    async mintCanary(label, by) { const c = decoy.mint(String(label || 'unlabelled').slice(0, 200)); await rest.insert('security_canaries', { nonce: c.nonce, label: c.label, created_by: by || null }); return { token: c.token, label: c.label }; },
    async overview() {
      const [events, ips, canaries, bansList] = await Promise.all([
        rest.select('security_events', {}, 'id, at, kind, severity, ip, path, detail').catch(() => []),
        rest.select('security_ip_state', {}, 'ip, score, flagged_until, updated_at').catch(() => []),
        rest.select('security_canaries', {}, 'nonce, label, created_at, last_seen_at').catch(() => []),
        rest.select('security_bans', {}, 'ip, reason, origin_ip, banned_at, firewall').catch(() => []),
      ]);
      const now = Date.now();
      return {
        events: events.sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, 200),
        flagged: ips.filter((i) => i.flagged_until && new Date(i.flagged_until).getTime() > now).sort((a, b) => b.score - a.score),
        canaries: canaries.map(({ nonce, ...c }) => ({ ...c, id: nonce.slice(0, 8) })),
        bans: bansList.map((b) => ({ ip: b.ip, reason: b.reason, origin_ip: b.origin_ip, banned_at: b.banned_at, sites: Object.keys(b.firewall || {}).length })).sort((a, b) => String(b.banned_at).localeCompare(String(a.banned_at))),
        counts: { events24h: events.filter((e) => new Date(e.at).getTime() > now - 864e5).length, critical24h: events.filter((e) => e.severity === 'critical' && new Date(e.at).getTime() > now - 864e5).length },
      };
    },
  };
}
